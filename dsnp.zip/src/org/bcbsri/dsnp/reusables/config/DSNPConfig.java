package org.bcbsri.dsnp.reusables.config;

import com.dell.acoe.framework.config.Environment;

public class DSNPConfig {

	public static String DRIVER_PATH_CHROME = "";
	public static String DRIVER_PATH_IE = "";
	public static String RIproviderportal_WEB_URL = "";
	public static int BROWSER_STATUS = 0;
	public static String BASE_DIR = "";
	public static String TDP = "";

	public static void init(){
		DSNPConfig.DRIVER_PATH_CHROME = Environment.get("DRIVER_PATH_IE");
		DSNPConfig.DRIVER_PATH_CHROME = Environment.get("DRIVER_PATH_CHROME");
		DSNPConfig.RIproviderportal_WEB_URL = Environment.get("RIproviderportal_WEB_URL");
		DSNPConfig.BASE_DIR = Environment.get("BASE_DIR");
		DSNPConfig.TDP =  Environment.get("BASE_DIR")+"/testdata/";
	}
}
