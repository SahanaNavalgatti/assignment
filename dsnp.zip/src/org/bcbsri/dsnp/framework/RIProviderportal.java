package org.bcbsri.dsnp.framework;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
//import javax.xml.bind.DatatypeConverter;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.bcbsri.dsnp.reusables.config.DSNPConfig;
import org.bcbsri.dsnp.scripts.bot.DSNP270upload999download;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.testng.Reporter;

import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.selenium.Driver;
import com.dell.acoe.framework.selenium.testdata.DataTable;
import com.dell.acoe.framework.selenium.testdata.ExcelMethods;
import com.dell.acoe.framework.selenium.verify.Assert;
import com.ntt.cryptic.aesTest;

public class RIProviderportal {

	WebDriver driver;
	static File testdata;
	static File testoutput;
	static File testenvdata;
	static File testenvironment;
	static DataTable dt;
	static String strTestEnvironment;
	static DataTable environment;
	
	
	static String host1_999 = Environment.get("snow.host1_999");
	static String host2_999 =Environment.get("snow.host2_999");
	static String oid_999 = Environment.get("snow.oid_999");
	static String msg999_999 =Environment.get("snow.999msg_999");
	static String community_999 = Environment.get("snow.group_999");
	static String severity_999 =Environment.get("snow.severity_999");
	
	static String host1_exit = Environment.get("snow.host1_exit");
	static String host2_exit =Environment.get("snow.host2_exit");
	static String oid_exit = Environment.get("snow.oid_exit");
    static String community_exit = Environment.get("snow.group_exit");
    static String msgEXIT_exit =Environment.get("snow.EXITmsg_exit");
	static String msgEXIT_exit1 =Environment.get("snow.EXITmsg_exit_Password");
    static String severity_exit =Environment.get("snow.severity_exit");
	static String ODSuploadpath = Environment.get("RIproviderportal.fileuploadpathODS");
	static String TestcaseID = Environment.get("RIproviderportal.testcaseid");
	public static String  requiredDate_formatted;
	public static String  requiredDate;
	public static String  checkDate1;
	public static String  checkDate2;
	public static String  checkDate3;
	public static String  checkDate4;
	public static String  checkDate5;
	public static String  checkDate6;
	public static String  checkDate7;
	public static String  checkDate0;
	public static String date2;
	public RIProviderportal(WebDriver driver) {
		this.driver = driver;

	}

	// Using FindBy for locating elements
	@FindBy(how = How.XPATH, using = "//body")
	WebElement mainPage;
	@FindBy(how = How.XPATH, using = "//div[@class='navLinks']")
	WebElement consoleTab;
	@FindBy(how = How.XPATH, using = "//input[@title='Search Salesforce']")
	WebElement salesforceSearchBox;
	@FindBy(how = How.XPATH, using = "//a[text()='My Profile']")
	WebElement riproviderportalmyprofile;
	@FindBy(how = How.XPATH, using = "//input[contains(@id,'LogoutStandardPopupConfirmation') and contains(@id,'OKButton')]")
	//WebElement riprovidererrorpage;
	WebElement LogOutPopUp;
	//@FindBy(how = How.XPATH, using = "//label[contains(@title,'Error')]")
	//WebElement riprovidererrorpage;
	//WebElement LogOutPopUp;
	@FindBy(how = How.XPATH, using = "//input[contains(@id,'RedirectCmnPopupConfirmation') and contains(@id,'OKButton')]")
	WebElement UploadPopUp;

	@FindBy(how = How.XPATH, using = "//div[@id='navigatortab']//descendant::iframe[1]")
	WebElement leftFrame;
	@FindBy(how = How.XPATH, using = "//frame[@title='Search']")
	WebElement searchFrame;
	@FindBy(how = How.XPATH, using = "//div[@id='servicedesk']//descendant::iframe[1]")
	WebElement firstSubTab;
	@FindBy(how = How.XPATH, using = "//div[@id='servicedesk']//descendant::iframe[2]")
	WebElement secondSubTab;
	@FindBy(how = How.XPATH, using = "//div[@id='servicedesk']//descendant::iframe[3]")
	WebElement thirdSubTab;
	@FindBy(how = How.XPATH, using = "//div[@id='servicedesk']//descendant::iframe[4]")
	WebElement FourthSubTab;
	@FindBy(how = How.XPATH, using = "//div[@id='servicedesk']//descendant::iframe[5]")
	WebElement FifthSubTab;
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'sd_primary_container')][last()]//div[contains(@class,'sd_secondary_container')][last()]//div[contains(@class,'x-border-panel')][1]//iframe[last()]")
	WebElement contentTab;
	@FindBy(how = How.XPATH, using = "//iframe[@title='CC_CaseMileStoneTracker']")
	WebElement milestoneFrame;
	@FindBy(how = How.XPATH, using = "//iframe[@title='CC_GAU_QPI_SIUCasesOnAccount']")
	WebElement ccgauqpisiucasesFrame;
	@FindBy(how = How.XPATH, using = "//iframe[@id='ext-comp-1005']")
	WebElement BaseFrame;
	@FindBy(how = How.XPATH, using = "//iframe[@title='HomePageCustomLinks']")
	WebElement HomeFrame;
	@FindBy(how = How.XPATH, using = "//iframe[@title='ViewHomePageNotification']")
	WebElement NotificationFrame;
	@FindBy(how = How.XPATH, using = "//span[@class='listViewTitle']")
	WebElement pagelistTitle;
//	@FindBy(how=How.XPATH, using="//*[@id='refresh']") WebElement refresh;
	@FindBy(how = How.XPATH, using = "//*[@id='refreshButton']")
	WebElement refresh;
	@FindBy(how = How.XPATH, using = "//*[@id='db_ds_quickfindInput']")
	WebElement datasourcequickfind;
	@FindBy(how = How.XPATH, using = "//*[@id='runMuttonButton']")
	WebElement runReportbtn;
//	@FindBy(how=How.XPATH, using="//input[@value='Run Report']")WebElement runReportbtn;
//	@FindBy(how=How.XPATH, using="//button[text()='Run Report']")WebElement runReportbtn;
	@FindBy(how = How.XPATH, using = "//*[@id='runMuttonLabel']")
	WebElement runReportbtndrpdwn;

	@FindBy(how = How.XPATH, using = "//div[@id='servicedesk']//following::iframe[1]")
	WebElement mainTab;
	@FindBy(how = How.XPATH, using = "//frame[@title='Results']")
	WebElement resultsFrame;
	@FindBy(how = How.XPATH, using = "//iframe[@title='CC_GAU_QPI_SIUCasesOnPolicy']")
	WebElement ccgauqpisiucasesPolicyFrame;
	@FindBy(how = How.XPATH, using = "//head[@id='Head']//title[1]")
	WebElement pageTitle;
	@FindBy(how = How.XPATH, using = "//h1[contains(@class,'pageType')]")
	WebElement pageType;
	@FindBy(how = How.XPATH, using = "//button[text()=\"Don't Save\"]")
	WebElement dontSaveButton;
	@FindBy(how = How.XPATH, using = "//div[@class='filterLinks']//preceding::select[1]")
	WebElement selQueue;
	@FindBy(how = How.XPATH, using = "//select[@name='fcf']")
	WebElement selMenuQueue;
	@FindBy(how = How.XPATH, using = "//span[@id='userNavLabel']")
	WebElement icnProfile;
	@FindBy(how = How.XPATH, using = "//a[@id='app_logout']")
	WebElement lnkLogOut;

	@FindBy(how = How.XPATH, using = "//*[@id='tsidLabel']")
	WebElement appMenu;

	@FindBy(how = How.XPATH, using = "//iframe[@title='CC_PolicyTabs']")
	WebElement ccpolicytabs;
	@FindBy(how = How.XPATH, using = "//iframe[contains(@src,'CC_PolicyAccumulators')]")
	WebElement ccpolicyaccumulators;
	@FindBy(how = How.XPATH, using = "//iframe[contains(@src,'CC_ViewPolicybenefits')]")
	WebElement ccviewpolicybenefits;
	@FindBy(how = How.XPATH, using = "//iframe[contains(@src,'CC_SearchMemberPolicyCoverage')]")
	WebElement ccsearachmemberpolicycoverage;
	@FindBy(how = How.XPATH, using = "//iframe[contains(@src,'CC_PolicyPlanSubsidyHistory')]")
	WebElement ccpolicyplansubsidyhistory;

	@FindBy(how = How.XPATH, using = "//iframe[contains(@src,'CC_PolicyViewAuthorizationStatus')]")
	WebElement ccpolicyviewauthorizationstatus;
	@FindBy(how = How.XPATH, using = "//iframe[contains(@src,'CC_PolicyAuthorization_CCMS')]")
	WebElement ccpolicyauthorizationccms;

	@FindBy(how = How.XPATH, using = "//iframe[contains(@id,'ext-comp-1056')]")
	WebElement sdhistoryframe;
	@FindBy(how = How.XPATH, using = "//*[@id='phSearchInput']")
	WebElement globalsearchtxtbox;

	String oldTab = null;
	// @FindBy(how=How.XPATH, using="//h3[.='Contact History']/following::tbody")
	// List<org.openqa.selenium.WebElement> tableElement;
	@FindBy(how = How.XPATH, using = "//h3[.='Contact History']/following::tbody")
	public List<org.openqa.selenium.WebElement> tableElement;
	@FindBy(how = How.XPATH, using = "//h3[.='Case History']/following::tbody")
	public List<org.openqa.selenium.WebElement> tablecaseElement;
	@FindBy(how = How.XPATH, using = "//h3[.='Priority Notes History']/following::tbody")
	public List<org.openqa.selenium.WebElement> tablePriorityNotesHistory;
	@FindBy(how = How.XPATH, using = "//h3[.='Contact History']/following::tbody/tr[2]")
	public List<org.openqa.selenium.WebElement> tableContactHistory;

	// Defining all the user actions (Methods) that can be performed in the Main
	// Page

	// elements used for user info extract
	@FindBy(how = How.XPATH, using = "//*[@id='phSearchInput']")
	WebElement searchtopInput;
	@FindBy(how = How.XPATH, using = "//*[@id='phSearchButton']")
	WebElement searchtopButton;

	/**
	 * Method to open SFDC menu using shortcut ESC + v
	 */
	public void OpenMenu() throws Exception {
		Log("Opening SFDC Menu", "DONE", false);
		// Thread.sleep(10000);

		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[@class=' x-btn-text'])[4]")));
		WebElement element = driver.findElement(By.xpath("(//button[@class=' x-btn-text'])[4]"));
		Actions action = new Actions(driver);
		action.sendKeys(Keys.ESCAPE).build().perform();
		Thread.sleep(2000);
		mainPage.sendKeys("v");
		action.moveToElement(element, 20, 23).click().build().perform();
	}

	/**
	 * Method to select SFDC menu item by text
	 * 
	 * @param strMenuItem - Menu Item text
	 */
	public void SelectMenuItem(String strMenuItem) throws Exception {
		WaitForPageToLoad(30);
		Log("Selecting Menu Item - " + strMenuItem, "DONE", true);
		Actions action = new Actions(driver);
		action.moveToElement(
				driver.findElement(By.xpath("//span[@class='x-menu-item-text' and text()='" + strMenuItem + "']")))
				.click().perform();
		WaitForPageToLoad(30);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();",
				driver.findElement(By.xpath("//span[@class='x-menu-item-text' and text()='" + strMenuItem + "']")));
	}

	/**
	 * Method to select SFDC menu item by text (Overloaded Method)
	 * 
	 * @param strMenuItem    - Menu Item text
	 * @param strTag-TagName of the WebElement
	 */
	public void SelectMenuItem(String strTag, String strMenuItem) throws Exception {
		WaitForPageToLoad(30);
		Log("Selecting Menu Item - " + strMenuItem, "DONE", true);
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//" + strTag + "[text()='" + strMenuItem + "']"))).click()
				.perform();
		WaitForPageToLoad(30);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();",
				driver.findElement(By.xpath("//" + strTag + "[text()='" + strMenuItem + "']")));
	}

	/**
	 * Method to close primary tabs using SFDC shortcut ESC + c
	 * 
	 * @param intTabCount - Number of tabs to close
	 */
	// Dhruv 14 jan 2020
	public void CloseAllPrimaryTabs() throws Exception {
		Actions action = new Actions(driver);
		SwitchToFrame("Default");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		int intTabCount = driver.findElements(By.xpath("//div[contains(@class,'sd_primary_container')]")).size();
		Log("Closing " + intTabCount + " Primary Tab(s)", "DONE", false);
		for (int i = 0; i < intTabCount; i++) {
			SwitchToFrame("Default");
			action.sendKeys(Keys.ESCAPE).build().perform();
			mainPage.sendKeys("c");
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			try {
				if (dontSaveButton.isDisplayed()) {
					Thread.sleep(2000);
					dontSaveButton.click();
				}
			} catch (NoSuchElementException ex) {
				continue;
			} finally {
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			}
		}
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * Method to close all sub tabs
	 */
	public void CloseAllSubTabs() throws Exception {
		Log("Closing all subtabs", "DONE", false);
		SwitchToFrame("Default");
		ClickOnSubtabsDropdown();
		SelectMenuItem("Close all subtabs");
		WaitForPageToLoad(30);
		SwitchToFrame("Default");
		SwitchToFrame("Content");
	}

	/**
	 * Method to refresh all subtabs
	 */
	public void RefreshAllSubTabs() throws Exception {
		Log("Refreshing all subtabs", "DONE", false);
		SwitchToFrame("Default");
		ClickOnSubtabsDropdown();
		SelectMenuItem("Refresh all subtabs");
		WaitForPageToLoad(30);
		SwitchToFrame("Default");
		SwitchToFrame("Content");
	}

	/**
	 * Method to close all sub tabs
	 */
	public void ClickOnSubtabsDropdown() throws Exception {
		SwitchToFrame("Default");
		WaitForPageToLoad(30);
		Log("Selecting Subtabs Dropdown", "DONE", false);
		WebElement element = driver.findElement(
				By.xpath("//div[@class='x-tab-tabmenu-right']//following::div[@class='x-tab-tabmenu-right']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		Thread.sleep(500);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
		// element.click();
		WaitForPageToLoad(30);
	}

	/**
	 * Method to click on a Button type - Input identified by @title tag
	 * 
	 * @param strButtonName - @title of the Button
	 */
	public void ClickOnButtonByTitle(String strButtonName) throws Exception {
		Log("Clicking on Button - " + strButtonName, "DONE", true);
		WebElement element = driver.findElement(By.xpath("//input[@title='" + strButtonName + "']"));
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		} catch (StaleElementReferenceException e) {
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		} catch (Exception e) {
			Log("Clicking on Button - " + strButtonName, "FAIL", true);
		}
	}

	/**
	 * Method to click on a Button type - Input identified by @title tag
	 * 
	 * @param strButtonName - @title of the Button and clear the text
	 */
	public void ClickOnButtonByTitleSendKeys(String strButtonName, String strValue) throws Exception {
		Log("Clicking on Button - " + strButtonName, "DONE", true);
		WebElement element = driver.findElement(By.xpath("//input[@title='" + strButtonName + "']"));
		element.click();
		try {
			element.clear();
		} catch (Exception e) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		}
		WaitForPageToLoad(30);
	}

	/**
	 * Method to click on a Button type - Input identified by @value tag
	 * 
	 * @param strButtonValue - @value of the Button
	 */
	public void ClickOnButtonByValue(String strButtonValue) throws Exception {
		Log("Clicking on Button - " + strButtonValue, "DONE", true);
		WebElement element = driver.findElement(By.xpath("//input[@value='" + strButtonValue + "']"));
		element.click();
		/*
		 * if (element.isEnabled()) { JavascriptExecutor js =
		 * (JavascriptExecutor)driver; js.executeScript("arguments[0].click();",
		 * element); driver.findElement(By.xpath("//input[@value='" + strButtonValue +
		 * "']")).click(); WaitForPageToLoad(30); } else { element.click();
		 * Log(strButtonValue + " Button is not enabled", "FAIL", false); }
		 */
	}

	/**
	 * Method to click on a Button type - Following Input tag
	 * 
	 * @param strButtonValue - @value of the Button
	 * @param strButtonTitle - @Title of the Button
	 */
	public void ClickOnButtonByValueorTitle(String strButtonValue, String strButtonTitle) throws Exception {
		Log("Clicking on Button - " + strButtonValue, "DONE", true);
		WebDriverWait wd = new WebDriverWait(driver, 30);
		wd.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//input [contains(@value,' "
				+ strButtonValue + " ') or contains(@title,'" + strButtonTitle + "')]"))));
		WebElement elem = driver.findElement(By.xpath(
				"//input [contains(@value,' " + strButtonValue + " ') or contains(@title,'" + strButtonTitle + "')]"));
		if (driver instanceof JavascriptExecutor) {
			((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px solid red'", elem);
		}
		WebElement ele = driver.findElement(By.xpath(
				"//input [contains(@value,' " + strButtonValue + " ') or contains(@title,'" + strButtonTitle + "')]"));
		// ElemIDUtil.domElementClick(ele);
		ele.click();
		AcceptAlert();
		Thread.sleep(5000);
		Log("Clicked on Button - " + strButtonValue, "DONE", true);
		WaitForPageToLoad(30);
	}

	/**
	 * Method to click on a Button type - Having any tag
	 * 
	 * @param strButtonValue - @value of the Button
	 * @param strButtonTitle - @Title of the Button
	 */
	public void ClickOnButtonByText(String tagName, String strText) throws Exception {
		Log("Clicking on Button - " + strText, "DONE", true);
		WebDriverWait wd = new WebDriverWait(driver, 60);
		wd.until(ExpectedConditions
				.visibilityOf(driver.findElement(By.xpath("//" + tagName + "[contains(text(),'" + strText + "')]"))));
		WebElement elem = driver.findElement(By.xpath("//" + tagName + "[contains(text(),'" + strText + "')]"));
		if (driver instanceof JavascriptExecutor) {
			((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px solid red'", elem);
		}
		WebElement ele = driver.findElement(By.xpath("//" + tagName + "[contains(text(),'" + strText + "')]"));
		ElemIDUtil.domElementClick(ele);
		Log("Clicked on Button - " + strText, "DONE", true);
		WaitForPageToLoad(30);
	}

	/**
	 * Method to wait for a Button by Title to be enabled
	 * 
	 * @param strButtonValue - @value of the Button
	 */
	public boolean WaitForButtonByTitle(String strButtonTitle) throws Exception {
		try {
			if (driver.findElement(By.xpath("//input[@title='" + strButtonTitle + "']")).isEnabled()) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Method to click on a Tab identified by tag-td
	 * 
	 * @param strTabText - @value of the Button
	 */
	public void ClickOnTabByText(String strTabText) throws Exception {
		Log("Clicking on Tab - " + strTabText, "DONE", true);
		driver.findElement(By.xpath("//td[text()='" + strTabText + "']")).click();
		WaitForPageToLoad(30);
	}

	/**
	 * Method to click on a Button type - Input identified by text
	 * 
	 * @param strMenuButtonText - Text of the Button
	 */
	public void ClickOnMenuButtonByText(String strMenuButtonText) throws Exception {
		Log("Clicking on Menu Button - " + strMenuButtonText, "DONE", false);
		driver.findElement(By.xpath("//span[@class='menuButtonLabel' and text()='" + strMenuButtonText + "']")).click();
	}

	/**
	 * Method to click on a Check Box having type - Input following a Label
	 * containing text
	 * 
	 * @param strLabel - Text of the Label after which the element is present
	 */
	public void SelectCheckBoxAfterLabel(String strLabel) throws Exception {
		Log("Clicking on Checkbox - " + strLabel, "DONE", false);
		WebElement element = driver
				.findElement(By.xpath("//label[contains(.,'" + strLabel + "')]//following::input[1]"));
		if (element.isEnabled()) {
			element.click();
			Thread.sleep(3000);
		} else {
			Log(strLabel + " Checkbox is not enabled", "FAIL", false);

		}
	}

	/**
	 * Method to click on a Radio Button having type - Input preceding a Label
	 * containing text
	 * 
	 * @param strLabel - Text of the Label before which the Radio button is present
	 */
	public void SelectRadioButtonBeforeLabel(String strLabel) throws Exception {
		Log("Clicking on Checkbox - " + strLabel, "DONE", false);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element = driver
				.findElement(By.xpath("//label[contains(.,'" + strLabel + "')]//preceding::input[1]"));
		if (element.isEnabled()) {
			js.executeScript("arguments[0].click();", element);
//			element.click();
			Thread.sleep(3000);
		} else {
			Log(strLabel + " Radio Button is not enabled", "FAIL", false);

		}
	}

	/**
	 * Method to click on a Check Box having type - Input preceding a Label
	 * containing text
	 * 
	 * @param strLabel - Text of the Label before which the Check box is present
	 */
	public void SelectCheckBoxBeforeLabel(String strLabel) throws Exception {
		Log("Clicking on Checkbox - " + strLabel, "DONE", false);
		WaitForPageToLoad(30);
		WebElement element = driver
				.findElement(By.xpath("//label[contains(.,'" + strLabel + "')]//preceding::input[1]"));
		if (element.isEnabled()) {
			element.click();
			WaitForPageToLoad(30);
		} else {
			Log(strLabel + " Checkbox is not enabled", "FAIL", false);

		}
	}

	/**
	 * Method to click on a Check Box having type - Input preceding a Link
	 * containing text
	 * 
	 * @param strLinkText - Text of the Link before which the Check box is present
	 */
	public void SelectCheckBoxBeforeLinkText(String strLinkText) throws Exception {
		if (strLinkText.substring(0, 2).equals("dt")) {
			strLinkText = GetTestData(strLinkText);
		}
		Log("Selecting Checkbox - " + strLinkText, "DONE", false);
		WaitForPageToLoad(30);
		WebElement element = driver
				.findElement(By.xpath("//a[contains(.,'" + strLinkText + "')]//preceding::input[1]"));
		if (element.isEnabled()) {
			try {
				element.click();
			} catch (Exception e) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].click();", element);
//			element.click();
				WaitForPageToLoad(30);
			}
		} else {
			Log(strLinkText + " Checkbox is not enabled", "FAIL", false);

		}
	}

	/**
	 * Method to click on a Radio Button having type - Input preceding a Link
	 * containing text
	 * 
	 * @param strLinkText - Text of the Link before which the Radio button is
	 *                    present
	 */
	public void SelectRadioButtonBeforeLinkText(String strLinkText) throws Exception {
		if (strLinkText.substring(0, 2).equals("dt")) {
			strLinkText = GetTestData(strLinkText);
		}
		Log("Selecting Radio Button - " + strLinkText, "DONE", false);
		WaitForPageToLoad(30);
		WebElement element = driver
				.findElement(By.xpath("//a[contains(.,'" + strLinkText + "')]//preceding::input[1]"));
		if (element.isEnabled()) {
			element.click();
			WaitForPageToLoad(30);
		} else {
			Log(strLinkText + " Radio Button is not enabled", "FAIL", false);

		}
	}

	/**
	 * Method to click on a Radio Button having type - Input in a Table Row
	 * 
	 * @param strTableHeader - Text of the Header having tag
	 *                       <h3>preceding the Radio button
	 * @param intRow         - Row of the Table where the Radio button is present
	 */
	public void SelectRadioButtonFromTable(String strTableHeader, int intRow) throws Exception {
		Log("Clicking on Checkbox - " + strTableHeader + "Row " + intRow, "DONE", false);
		WaitForPageToLoad(30);
		WebElement element = driver
				.findElement(By.xpath("//h3[text()='" + strTableHeader + "']/../../descendant::input[" + intRow + "]"));
		element.click();
		Thread.sleep(3000);
	}

	/**
	 * Method to verify on a Radio Button having type - Input in a Table Row
	 * 
	 * @param strTableHeader - Text of the Header having tag
	 *                       <h3>preceding the Radio button
	 * @param intRow         - Row of the Table where the Radio button is present
	 * @return
	 */
	public boolean IsRadioButtonFromTableDisplays(String strTableHeader, int intRow) throws Exception {
		Log("Clicking on Checkbox - " + strTableHeader + "Row " + intRow, "DONE", false);
		WaitForPageToLoad(30);
		WebElement element = driver
				.findElement(By.xpath("//h3[text()='" + strTableHeader + "']/../../descendant::input[" + intRow + "]"));
		if (element.isDisplayed()) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * Method to click on (x) icon next to Member Filed to clear the input data
	 */

	public void clearMemberdata(String strLabel) throws Exception {
		WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::img[1]"));
		element.click();
	}

	/**
	 * Method to Modify Policy Details for already created case
	 */
	public void ModifyPolicyDetails(String strLabel, String strValue) throws Exception {
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::input[7]"));
		element.clear();
		element.sendKeys(strValue);

		/*
		 * driver.findElement(By.xpath("//label[text()='Policy']//following::input[7]"))
		 * .clear();
		 * driver.findElement(By.xpath("//label[text()='Policy']//following::input[7]"))
		 * .sendKeys("200100124-001");
		 */
	}

	/**
	 * Method to Select a List Item following a Label
	 * 
	 * @param strList  - Text of the Label after which Select box is present
	 * @param strValue - Text value of the option to be selected
	 */
	public void SelectListItemAfterLabel(String strList, String strValue) throws Exception {

		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		Log("Selecting " + strList + " - " + strValue, "DONE", false);

		for (int i = 0; i < 2; i++) {
			try {
				WebElement element = driver
						.findElement(By.xpath("//label[text()='" + strList + "']//following::select[1]"));
				Select dropdown = new Select(element);
				dropdown.selectByVisibleText(strValue);
				break;
			} catch (StaleElementReferenceException e) {
				Log("Caught stale element! Will try two more times at max.", "DONE", false);
				continue;
			}
		}
	}

	/**
	 * Method to Select a List Item following a Label (Overloaded)
	 * 
	 * @param strList  - Text of the Label after which Select box is present
	 * @param strValue - Text value of the option to be selected
	 * @param strMatch - Use any text for partial match e.g. "Partial"
	 */
	public void SelectListItemAfterLabel(String strList, String strValue, String strMatch) throws Exception {
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		Log("Selecting " + strList + " - " + strValue, "DONE", false);
		WebElement element = driver
				.findElement(By.xpath("//label[contains(text(),'" + strList + "')]//following::select[1]"));
		Select dropdown = new Select(element);
		dropdown.selectByVisibleText(strValue);
	}

	/**
	 * Method to Select a List Item following a Label (Overloaded)
	 * 
	 * @param strList  - Text of the Label after which Select box is present
	 * @param strValue - Text value of the option to be selected
	 * @param strMatch - Use any text for partial match e.g. "Partial"
	 * @param intvalue - Value of the index
	 */
	public void SelectListItemAfterLabel(String strList, String strValue, String strMatch, int index) throws Exception {
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		Log("Selecting " + strList + " - " + strValue, "DONE", false);
		WebElement element = driver
				.findElement(By.xpath("//label[contains(text(),'" + strList + "')]//following::select[" + index + "]"));
		Select dropdown = new Select(element);
		dropdown.selectByVisibleText(strValue);
	}

	/**
	 * Method to Select an option from Option group following a Label
	 * 
	 * @param strLabel - Label after which Option group is present
	 * @param strValue - Text value of the option to be selected
	 */
	public void SelectOptionFromOptionGroupAfterLabel(String strLabel, String strValue) throws Exception {
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		Log("Selecting " + strLabel + " - " + strValue, "DONE", false);
		WebElement element = driver.findElement(By.xpath(
				"//label[text()='" + strLabel + "']//following::optgroup[1]//option[text()='" + strValue + "']"));
		element.click();
	}

	/**
	 * Method to Select an Item from SFDC Queue
	 * 
	 * @param strItem - Link text before which the Check box is present e.g. Check
	 *                box before Case Number
	 */
	public void SelectItemFromQueue(String strItem) throws Exception {
		Thread.sleep(2000);
		Log("Selecting " + strItem + " from Queue", "DONE", false);
		WebElement element = driver.findElement(By.xpath("//a[text()='" + strItem + "']//preceding::input[1]"));
		element.click();
		WaitForPageToLoad(30);
	}

	/**
	 * Method to Select a SFDC Queue
	 * 
	 * @param strQueue - Queue item identified by text
	 */
	public void SelectQueue(String strQueue) throws Exception {
		WaitForPageToLoad(30);
		if (strQueue.substring(0, 2).equals("dt")) {
			strQueue = GetTestData(strQueue);
		}
		Log("Selecting Queue - " + strQueue, "DONE", false);
		for (int i = 0; i < 2; i++) {
			try {
				Select dropdown = new Select(selQueue);
				dropdown.selectByVisibleText(strQueue);
				break;
			} catch (StaleElementReferenceException e) {
				Log("Caught stale element! Will try two more times at max.", "DONE", false);
				continue;
			}
		}
	}

	/**
	 * Method to Select a SFDC Queue say My Cases, My Open Cases etc.
	 * 
	 * @param strQueue - Queue item identified by text
	 */
	public void SelectMenuQueue(String selQueueMenu) throws Exception {
		if (selQueueMenu.substring(0, 2).equals("dt")) {
			selQueueMenu = GetTestData(selQueueMenu);
		}
		Log("Selecting Queue - " + selQueueMenu, "DONE", false);
		Select sel = new Select(selMenuQueue);
		sel.selectByVisibleText(selQueueMenu);
	}

	/**
	 * Method to Click on a lookup icon following a Label
	 * 
	 * @param strLabel - Label text after which the lookup icon is present
	 */
	public void ClickOnLookupAfterLabel(String strLabel) throws Exception {
		Log("Clicking on " + strLabel + " Lookup", "DONE", false);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::a[1]"));
		js.executeScript("arguments[0].click();", element);
		Thread.sleep(2000);
	}

	/**
	 * Method to Click on a lookup icon following a Label
	 * 
	 * @param strLabel - Label text after which the lookup icon is present Provide
	 *                 StringLabe2 as User, Customer Portal User or Partner User The
	 *                 text box is developed with input Tag instead of Label tag
	 */
	public void ClickOnLookupAfterLabel(String strLabel, int value) throws Exception {
		Log("Clicking on " + strLabel + " Lookup", "DONE", false);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element = driver
				.findElement(By.xpath("//label[text()='" + strLabel + "']//following::span['" + value + "']/input"));
		js.executeScript("arguments[0].click();", element);
		Thread.sleep(2000);
	}

	/**
	 * Method to sort a column identified by @title tag
	 * 
	 * @param strColumn - Column value of HTML table identified by @title tag
	 */
	public void SortQueueByTitle(String strColumn) throws Exception {
		Log("Sorting Queue by " + strColumn, "DONE", false);
		Thread.sleep(5000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(By.xpath("//div[@title='" + strColumn + "']"));
		js.executeScript("arguments[0].click();", element);
		WaitForPageToLoad(30);

	}

	/**
	 * Method to set text in to a Input box following a Label with partial match
	 * (Overloaded)
	 * 
	 * @param strLabel      - Label after which Input box is present
	 * @param strValue      - Text value to be set in to Input box
	 * @param strSearchType - Use any text for partial match e.g. "Partial"
	 */
	public void SetTextAfterLabel(String strLabel, String strValue, String strSearchType) throws Exception {
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		Log("Setting Text Into " + strLabel + " - " + strValue, "DONE", false);
		WebElement element = driver
				.findElement(By.xpath("//label[contains(.,'" + strLabel + "')]//following::input[1]"));
		element.clear();
		element.sendKeys(strValue);
	}

	/**
	 * Method to set text in to a Input box following a Label with Full Match
	 * 
	 * @param strLabel - Label after which Input box is present
	 * @param strValue - Text value to be set in to Input box
	 */
	public void SetTextAfterLabel(String strLabel, String strValue) throws Exception {
		WaitForPageToLoad(30);
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		if (strLabel.equalsIgnoreCase("Password")) {
			Log("Setting Text Into " + strLabel + "", "DONE", false);
		} else
			Log("Setting Text Into " + strLabel + " - " + strValue, "DONE", false);
		WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::input[1]"));
		element.sendKeys(strValue);
	}

	/**
	 * Method to set date in to a Input box following a Label with Full Match
	 * 
	 * @param strLabel - Label after which Input box is present
	 * @param strValue - Text value of date to be set in to Input box
	 */
	public void SetDateAfterLabel(String strLabel, String strValue) throws Exception {
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		if (strValue.equals("NULL")) {
			return;
		}
		Log("Setting Text Into " + strLabel + " - " + strValue, "DONE", false);
		WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::input[1]"));
		element.clear();
		Thread.sleep(1000);
		element.sendKeys(strValue);
	}

	/**
	 * Method to set text in to a Text Area following a Label with Full Match
	 * 
	 * @param strLabel - Label after which Text Area is present
	 * @param strValue - Text value of date to be set in to Input box
	 */
	public void SetTextAreaAfterLabel(String strLabel, String strValue) throws Exception {
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		Log("Setting Text Into " + strLabel + " - " + strValue, "DONE", false);
		WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::textarea[1]"));
		element.sendKeys(strValue);
	}

	/**
	 * Method to set text in to a input field following a Label with Full Match
	 * 
	 * @param strLabel - Label after which input is present
	 * @param strValue - Input value of ChangeOwner to be set in to Input box
	 * @author XPXSTSO:Prasanta
	 */
	public void SetInputValueAfterLabel(String strLabel, String strValue) throws Exception {
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		Log("Setting Text Into " + strLabel + " - " + strValue, "DONE", false);
		WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::input[7]"));
		element.sendKeys(strValue);
	}

	/**
	 * Method to click on a Link with Partial Match
	 * 
	 * @param strLinkText - Link Text
	 */
	public void ClickOnLinkByText(String strLinkText) throws Exception {
		try {
			strLinkText = strLinkText.trim();
			if (strLinkText.substring(0, 2).equals("dt")) {
				strLinkText = GetTestData(strLinkText);
			}

			Log("Clicking on Link - " + strLinkText, "DONE", true);
			WaitForPageToLoad(30);
			WebElement element = driver.findElement(By.xpath("//a[contains(.,'" + strLinkText + "')]"));
			if (driver.findElement(By.xpath("//a[contains(.,'" + strLinkText + "')]")).isEnabled()) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].click();", element);
			}
		} catch (Exception e) {
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			WebElement element = driver.findElement(By.xpath("//a[contains(.,'" + strLinkText + "')]"));
			if (driver.findElement(By.xpath("//a[contains(.,'" + strLinkText + "')]")).isEnabled()) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].click();", element);
			}
		}
	}

	/**
	 * Method to click on a Link following a Label
	 * 
	 * @param strLabel - Label after which Link is present
	 */
	public void ClickOnLinkAfterLabel(String strLabel) throws Exception {
		Log("Clicking on Link - " + strLabel, "DONE", false);
		driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::a[1]")).click();
	}

	/**
	 * Method to click on a Link following a Label
	 * 
	 * @param strLabel - Label after which Link is present
	 */
	public void ClickOnLinkAfterLabel(String strLabel, String StrTag, int index) throws Exception {
		Log("Clicking on Link - " + strLabel, "DONE", false);
		driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::" + StrTag + "[" + index + "]"))
				.click();
	}

	/**
	 * Method to click get text value following a Label
	 * 
	 * @param strLabel - Label after which Link is present
	 */
	public String GetAttributeValuefollowingLabel(String strTag, String attribute, String Text, String strTag2)
			throws Exception {
		String attributevalue = "";
		WaitForPageToLoad(30);
		for (int i = 0; i < 2; i++) {
			try {
				Log("Getting the text of - " + Text, "DONE", false);
				// driver.switchTo().frame("(//*[contains(@class,'sd_secondary_container
				// x-border-layout-ct')]//iframe)[4]");
				// WebDriverWait wait =new WebDriverWait(driver,45);
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//"+strTag+"["+attribute+"='"+Text+"']//following::"+strTag2+"[1]")));
				attributevalue = driver
						.findElement(By.xpath(
								"//" + strTag + "[" + attribute + "='" + Text + "']//following::" + strTag2 + "[1]"))
						.getText();
				System.out.println("attributevalue ->" + attributevalue);
			} catch (StaleElementReferenceException e) {
				Log("Caught stale element! Will try two more times at max.", "DONE", false);
				continue;
			}
		}
		WaitForPageToLoad(30);
		return attributevalue;
	}

	/**
	 * Method to click get text value following a Label
	 * 
	 * @param strLabel - Label after which Link is present Overloading above method
	 *                 to fetch the attribute value
	 */
	public String GetAttributeValuefollowingLabel(String strTag, String attribute, String attributevalue,
			String strTag2, String attributeValue2) throws Exception {
		Log("Clicking on Link - " + strTag, "DONE", false);
		String value = driver
				.findElement(By.xpath(
						"//" + strTag + "[" + attribute + "='" + attributevalue + "']//following::" + strTag2 + ""))
				.getAttribute(attributeValue2);
		return value;
	}

	/**
	 * Method to click on a Check Box following a Label
	 * 
	 * @param strLabel - Label after which Link is present
	 */
	public void ClickOncheckboxAfterLabel(String strLabel) throws Exception {
		Log("Clicking on Link - " + strLabel, "DONE", false);
		driver.findElement(By.xpath("//input[@name='" + strLabel + "']")).click();
	}

	/**
	 * Method to click on a Check Box following a Label
	 * 
	 * @param strLabel - Label after which Link is present
	 */
	public void ClickOncheckboxAfterLabelText(String strLabel) throws Exception {
		Log("Clicking on Checkbox - " + strLabel, "DONE", false);
		WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::input[1]"));
		if (!element.isSelected()) {
			element.click();
		}
	}

	/**
	 * Method to click on a Link following a Label
	 * 
	 * @param strLabel - Label after which Link is present
	 * @author XPXSTSO
	 */
	public void ClickOnLinkAfterTablecolumnvalue(String strLabel) throws Exception {
		Log("Clicking on Link - " + strLabel, "DONE", false);
		driver.findElement(By.xpath("//td[text()='" + strLabel + "']//following::a[1]")).click();
	}

	/**
	 * Method to click on an Image having @title following a Label
	 * 
	 * @param strLabel - Label after which Image is present
	 * @param strTitle - Image title identified by @title
	 * @author XPXSTSO[Prasanta Seth]
	 */

	public void ClickOnLinkAfterLabelandTextarea(String strLabel, String strTitle) throws Exception {
		Log("Clicking on " + strTitle + " - " + strLabel, "DONE", true);
		driver.findElement(
				By.xpath("(//td[text()='" + strLabel + "']//following::a[contains(., '" + strTitle + "')])[1]"))
				.click();
	}

	/**
	 * Method to click on a Link having text following a Label - View Form
	 * 
	 * @param strLabel    - Label after which Link is present
	 * @param strLinkText - Link Text
	 */
	public void ClickOnReadOnlyFormLinkAfterLabel(String strLabel, String strLinkText) throws Exception {
		Log("Clicking on Link - " + strLinkText + " " + strLabel, "DONE", false);
		driver.findElement(By.xpath("//td[text()='" + strLabel + "']//following::a[contains(.,'" + strLinkText + "')]"))
				.click();
	}

	/**
	 * Method to click on an Image having @title following a Label
	 * 
	 * @param strLabel - Label after which Image is present
	 * @param strTitle - Image title identified by @title
	 */
	public void ClickOnImageAfterLabelByTitle(String strLabel, String strTitle) throws Exception {
		Log("Clicking on " + strTitle + " - " + strLabel, "DONE", true);
		driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::img[@title='" + strTitle + "']"))
				.click();
	}

	/**
	 * Method to click on child menu item under a parent item e.g. Manage Users ->
	 * Users
	 * 
	 * @param strParent - Parent menu item
	 * @param strChild  - Child menu item
	 */
	public void ClickOnCollapsibleMenuItem(String strParent, String strChild) throws Exception {
		WebDriverWait wd = new WebDriverWait(driver, 60);
		wd.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='" + strParent + "']")));
		Log("Clicking on Menu Item - " + strParent + " -> " + strChild, "DONE", true);
		driver.findElement(By.xpath("//a[text()='" + strParent + "']")).click();
		Thread.sleep(5000);
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		try {
			WebElement childEle = driver
					.findElement(By.xpath("//a[text()='" + strParent + "']//following::a[text()='" + strChild + "']"));
		} catch (NoSuchElementException e) {
			ClickOnLinkByText(strParent);
		}
		driver.findElement(By.xpath("//a[text()='" + strParent + "']//following::a[text()='" + strChild + "']"))
				.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * Method to click on a Link following a Label
	 * 
	 * @param strLabel - Label after which Link is present
	 */
	public void ClickOnLinkByTitle(String strTitle) throws Exception {
		Log("Clicking on Link - " + strTitle, "DONE", true);
		try {
			driver.findElement(By.xpath("//a[contains(@title,'" + strTitle + "')]")).click();
		} catch (Exception e) {
			Log("Clicking on Link - js invoked - " + strTitle, "DONE", true);
			WebElement element = driver.findElement(By.xpath("//a[contains(@title,'" + strTitle + "')]"));
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		}
	}

	/**
	 * Method to click on a List Title Link e.g. Links present in Case Page - Case
	 * History[5], Notes[2], Nature-Subnature[0] etc.
	 * 
	 * @param strLinkText - Text of the Link
	 */
	public void ClickListTitleByText(String strLinkText) throws Exception {
		Log("Clicking on Link - " + strLinkText, "DONE", false);
		WebElement element = driver
				.findElement(By.xpath("//span[contains(text(),'" + strLinkText + "') and @class='listTitle']"));
		try {

			element.click();
		} catch (Exception e) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		}
	}

	/**
	 * *Author -Kiran Above method is not narrowing the search down for case History
	 * hence creating more generic method Method to click on a caseOptione Link e.g.
	 * Links present in Case Page - Case History[5], Notes[2], Nature-Subnature[0]
	 * etc.
	 * 
	 * @param strLinkInt - Integer of the Link
	 */

	public void ClickCaseOption(int strLinkInt) throws Exception {
		Log("Clicking on Link - " + strLinkInt, "DONE", false);
		driver.findElement(By.xpath("//a[contains(@data-uidsfdc, " + strLinkInt + ")]")).click();
	}

	/**
	 * Method to click on a Link in a Table Row
	 * 
	 * @param strTableHeader - Heading of the Table identified by
	 *                       <h3>tag
	 * @param intRow         - Table row in which the link is present
	 * @param strLinkText    - Link Text
	 */
	public void ClickOnLinkByTextInTableRow(String strTableHeader, int intRow, String strLinkText) throws Exception {
		Log("Clicking on Link - " + strLinkText, "DONE", true);

		JavascriptExecutor js = (JavascriptExecutor) driver;
		Actions action = new Actions(driver);

		WaitForPageToLoad(30);
		try {
			action.moveToElement(driver.findElement(
					By.xpath("//h3[text()='" + strTableHeader + "']//following::tbody//tr[contains(@class,'dataRow')]["
							+ intRow + "]//a[text()='" + strLinkText + "']")))
					.perform();
			WebElement element = driver.findElement(
					By.xpath("//h3[text()='" + strTableHeader + "']//following::tbody//tr[contains(@class,'dataRow')]["
							+ intRow + "]//a[text()='" + strLinkText + "']"));
			driver.findElement(
					By.xpath("//h3[text()='" + strTableHeader + "']//following::tbody//tr[contains(@class,'dataRow')]["
							+ intRow + "]//a[text()='" + strLinkText + "']"))
					.click();
		} catch (Exception e) {
			try {
				WebElement element = driver.findElement(By.xpath(
						"//h3[text()='" + strTableHeader + "']//following::tbody//tr[contains(@class,'dataRow')]["
								+ intRow + "]//a[text()='" + strLinkText + "']"));

				js.executeScript("arguments[0].click();", element);
			} catch (Exception e1) {
				ClickOnLinkByText("Go to list (50+) »");
				try {
					WebElement element = driver.findElement(By.xpath(
							"//h3[text()='" + strTableHeader + "']//following::tbody//tr[contains(@class,'dataRow')]["
									+ intRow + "]//a[text()='" + strLinkText + "']"));
					js.executeScript("arguments[0].click();", element);
				} catch (Exception e2) {
					WebElement element = driver.findElement(By.xpath(
							"//h3[text()='" + strTableHeader + "']//following::tbody//tr[contains(@class,'dataRow')]["
									+ intRow + "]//a[text()='" + strLinkText + "']"));
					SortQueueByTitle("Date/Time Opened");
					js.executeScript("arguments[0].click();", element);
				}
			}
		}

	}

	/**
	 * Method to click on a Link in a Table Row
	 * 
	 * @param strTableHeader - Heading of the Table identified by
	 *                       <h3>tag
	 * @param intRow         - Table row in which the link is present
	 * @param strLinkText    - Link Text
	 */
	public void ClickOnLinkInGridTableRowColumn(int intRow, int intCol) throws Exception {
		Log("Clicking on Link in Grid Table - Row " + intRow + " Column " + intCol, "DONE", true);
		Actions action = new Actions(driver);
		action.moveToElement(driver
				.findElement(By.xpath("//div[contains(@class,'x-grid3-body')]//div[contains(@class,'x-grid3-row')]["
						+ intRow + "]//table//td[" + intCol + "]//a[1]")))
				.perform();
		WaitForPageToLoad(30);
		driver.findElement(By.xpath("//div[contains(@class,'x-grid3-body')]//div[contains(@class,'x-grid3-row')]["
				+ intRow + "]//table//td[" + intCol + "]//a[1]")).click();
	}

	/**
	 * Method to get Cell Data with html tag
	 * <th>from a Table
	 * 
	 * @param strTableHeader - Heading of the Table
	 * @param intRow         - Table Row number
	 * @param intCol         - Table Column number
	 * @return String in the specified row and column
	 */
	public String GetMainCellDataFromTableByName(String strTableHeader, int intRow, int intColumn) throws Exception {
		Log("Getting Cell Data from " + strTableHeader + " - Row " + intRow + " Column " + intColumn, "DONE", false);
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//h3[text()='" + strTableHeader
				+ "']//following::tbody//tr[contains(@class,'dataRow')][" + intRow + "]//th[" + intColumn + "]")))
				.perform();
		WaitForPageToLoad(30);
		return driver.findElement(By.xpath("//h3[text()='" + strTableHeader
				+ "']//following::tbody//tr[contains(@class,'dataRow')][" + intRow + "]//th[" + intColumn + "]"))
				.getText();
	}

	/**
	 * Method to get Cell Data with html tag
	 * <td>from a Table
	 * 
	 * @param strTableHeader - Heading of the Table
	 * @param intRow         - Table Row number
	 * @param intCol         - Table Column number
	 * @return String in the specified row and column
	 */
	public String GetCellDataFromGridTable(String strTableHeader, int intRow, int intColumn) throws Exception {
		Log("Getting Cell Data from " + strTableHeader + " - Row " + intRow + " Column " + intColumn, "DONE", false);
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//h3[text()='" + strTableHeader
				+ "']//following::tbody//tr[contains(@class,'dataRow')][" + intRow + "]//td[" + intColumn + "]")))
				.perform();
		WaitForPageToLoad(30);
		return driver.findElement(By.xpath("//h3[text()='" + strTableHeader
				+ "']//following::tbody//tr[contains(@class,'dataRow')][" + intRow + "]//td[" + intColumn + "]"))
				.getText();
	}

	/**
	 * Method to get Cell Data with html tag
	 * <td>from a Table
	 * 
	 * @param strTableHeader - Heading of the Table
	 * @param intRow         - Table Row number
	 * @param intCol         - Table Column number
	 * @return String in the specified row and column
	 */
	public String GetCellDataFromTableByName(String strTableHeader, int intRow, int intColumn) throws Exception {
		Log("Getting Cell Data from " + strTableHeader + " - Row " + intRow + " Column " + intColumn, "DONE", false);
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//h3[text()='" + strTableHeader
				+ "']//following::tbody//tr[contains(@class,'dataRow')][" + intRow + "]//td[" + intColumn + "]")))
				.perform();
		WaitForPageToLoad(30);
		return driver.findElement(By.xpath("//h3[text()='" + strTableHeader
				+ "']//following::tbody//tr[contains(@class,'dataRow')][" + intRow + "]//td[" + intColumn + "]"))
				.getText();
	}

	/**
	 * Method to get Cell Data with html tag
	 * <td>from a Table
	 * 
	 * @param strTableHeader - Heading of the Table
	 * @param intRow         - Table Row number
	 * @return String in the specified row and column
	 */
	public void clickCellDataFromTableByName(String strTableHeader, int intRow) throws Exception {
		// Log("Clicking on Cell Data from " + strTableHeader + " - Row " + intRow + "
		// Column "DONE", false);
		/*
		 * Actions action = new Actions(driver);
		 * action.moveToElement(driver.findElement(By.xpath("//h3[text()='" +
		 * strTableHeader + "']//following::tbody//tr[contains(@class,'dataRow')][" +
		 * intRow + "]//td[" + intColumn + "]"))).perform(); WaitForPageToLoad(5);
		 */
		driver.findElement(By.xpath("//h3[text()='" + strTableHeader
				+ "']//following::tbody//tr[contains(@class,'dataRow')][" + intRow + "]//a")).click();
	}

	/**
	 * Method to get Cell Data with html tag
	 * <th>from a Table
	 * 
	 * @param strTableHeader - Heading of the Table
	 * @param intRow         - Table Row number
	 * @param index          - Index in case of multiple elements on page
	 * @return String in the specified row
	 */
	public String GetCellDataWithLinkFromTableByName(String strTableHeader, int intRow, int index) throws Exception {
		Log("Getting Cell Data from " + strTableHeader + " - Row " + intRow + "  ", "DONE", false);
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("(//h3[text()='" + strTableHeader
				+ "']//following::tbody//tr[contains(@class,'dataRow')][" + intRow + "]//th/a)[" + index + "]")))
				.perform();
		WaitForPageToLoad(30);
		return driver
				.findElement(By.xpath("(//h3[text()='" + strTableHeader
						+ "']//following::tbody//tr[contains(@class,'dataRow')][" + intRow + "]//th/a)[" + index + "]"))
				.getText();
	}

	/**
	 * Method to get Cell Header Data with html tag
	 * <td>from a Table
	 * 
	 * @param strTableHeader - Heading of the Table
	 * @param intRow         - Table Row number
	 * @param intCol         - Table Column number
	 * @return String in the specified row and column
	 */
	public String GetCellHeaderFromTableByName(String strTableHeader, int intColumn) throws Exception {
		Log("Getting Cell Header from " + strTableHeader + " Column " + intColumn, "DONE", false);
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//h3[text()='" + strTableHeader
				+ "']//following::tbody//tr[contains(@class,'headerRow')][1]//th[" + intColumn + "]"))).perform();
		WaitForPageToLoad(30);
		return driver
				.findElement(By.xpath("//h3[text()='" + strTableHeader
						+ "']//following::tbody//tr[contains(@class,'headerRow')][1]//th[" + intColumn + "]"))
				.getText();
	}

	/**
	 * Method to get Cell Data with html tag
	 * <td>from a Table
	 * 
	 * @param strTableHeader - Heading of the Table
	 * @param intRow         - Table Row number
	 * @param intCol         - Table Column number
	 * @return String in the specified row and column
	 */
	public String GetCellDataFromTableRowContainingLinkText(String strLinkText, int intColumn) throws Exception {
		if (strLinkText.substring(0, 2).equals("dt")) {
			strLinkText = GetTestData(strLinkText);
		}
		Log("Getting Cell Data from Table containing Link Text " + strLinkText + " - Column " + intColumn, "DONE",
				false);
		// Actions action = new Actions(driver);
		// action.moveToElement(driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//td[contains(.,'"
		// + strLinkText + "')]//following::td["+ intColumn + "]"))).perform();
		WaitForPageToLoad(30);
		try {
			return driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//td[contains(.,'" + strLinkText
					+ "')]//following::td[" + intColumn + "]")).getText();
		} catch (Exception e) {
			return driver.findElement(By.xpath("//table[contains(@class,'list pagination')]//td[contains(.,'"
					+ strLinkText + "')]//following::td[" + intColumn + "]")).getText();
		}
	}

	/**
	 * Method to click on a Drown down icon present inside a button
	 * 
	 * @param strLinkText - Link Text in the drop down list of button
	 */
	public void ClickOnMenuButtonDropdownLinkByText(String strLinkText) throws Exception {
		Log("Clicking on Link - " + strLinkText, "DONE", true);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//a[text()='" + strLinkText + "']")));
		WaitForPageToLoad(30);
	}

	/**
	 * Method to click on a Link in Reports Table Row
	 * 
	 * @param strTableHeader - Heading of the Table
	 * @param intRow         - Row in which Report link is present
	 */
	public void ClickOnReportInTableRow(String strTableHeader, int intRow) throws Exception {
		Log("Clicking on Report in " + strTableHeader + " - Row " + intRow, "DONE", true);
		WaitForPageToLoad(30);
		driver.findElement(By.xpath("//span[text()='" + strTableHeader
				+ "']//following::div[contains(@class,\"x-grid3-body\")]//div[contains(@class,'x-grid3-row')][" + intRow
				+ "]//a[1]")).click();
	}

	/**
	 * Method to click on a Date link present after a Label
	 * 
	 * @param strLabel - Label after which Date link is present
	 */
	public void ClickOnDateAfterLabel(String strLabel) throws Exception {
		Log("Selecting " + strLabel, "DONE", false);
		driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::a[contains(@href,'DatePicker')]"))
				.click();
	}

	/**
	 * Method to accept a popup alert
	 */
	public void AcceptAlert() throws Exception {
		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.switchTo().alert().accept();
			Log("Accepting Popup Alert", "DONE", false);
		} catch (Exception e) {
		}
	}

	/**
	 * Method to switch to a Frame - Refer to WebElement list initialized in SFDC
	 * Class
	 * 
	 * @param strFrame - Frame Name e.g. Default, Menu, Content
	 */
	public void SwitchToFrame(String strFrame) throws InterruptedException {
		switch (strFrame) {
		case "Menu":
			Thread.sleep(1000);
			driver.switchTo().frame(leftFrame);
			break;
		case "Content":
			Thread.sleep(1000);
			driver.switchTo().frame(contentTab);
			break;
		case "Milestone":
			Thread.sleep(1000);
			driver.switchTo().frame(milestoneFrame);
			break;
		case "CC GAU QPI SIU Cases":
			Thread.sleep(1000);
			driver.switchTo().frame(ccgauqpisiucasesFrame);
			break;
		case "Main":
			Thread.sleep(1000);
			driver.switchTo().frame(mainTab);
			break;
		case "First":
			Thread.sleep(5000);
			driver.switchTo().frame(firstSubTab);
			break;
		case "Second":
			Thread.sleep(5000);
			driver.switchTo().frame(secondSubTab);
			break;
		case "Third":
			Thread.sleep(5000);
			driver.switchTo().frame(thirdSubTab);
			break;
		case "Fourth":
			Thread.sleep(5000);
			driver.switchTo().frame(FourthSubTab);
			break;
		case "Fifth":
			Thread.sleep(5000);
			driver.switchTo().frame(FifthSubTab);
			break;
		case "Search":
			Thread.sleep(5000);
			driver.switchTo().frame(searchFrame);
		case "Results":
			Thread.sleep(5000);
			driver.switchTo().frame(resultsFrame);
		case "Policy CC GAU QPI SIU Cases":
			Thread.sleep(5000);
			driver.switchTo().frame(ccgauqpisiucasesPolicyFrame);
			break;
		case "Base":
			Thread.sleep(5000);
			driver.switchTo().frame(BaseFrame);
			break;
		case "Base to Home":
			Thread.sleep(5000);
			driver.switchTo().frame(BaseFrame).switchTo().frame(HomeFrame);
			break;
		case "Base to Notification":
			Thread.sleep(5000);
			driver.switchTo().frame(BaseFrame).switchTo().frame(NotificationFrame);
			break;
		case "Default":
			Thread.sleep(1000);
			driver.switchTo().defaultContent();
			break;
		case "PolicyTabs":
			Thread.sleep(1000);
			driver.switchTo().frame(ccpolicytabs);
			break;
		case "PolicyAccumulators":
			Thread.sleep(1000);
			driver.switchTo().frame(ccpolicyaccumulators);
			break;
		case "ViewPolicyBenefits":
			Thread.sleep(1000);
			driver.switchTo().frame(ccviewpolicybenefits);
			break;
		case "SearchMemberPolicyCoverage":
			Thread.sleep(1000);
			driver.switchTo().frame(ccsearachmemberpolicycoverage);
			break;
		case "PolicyPlanSubsidyHistory":
			Thread.sleep(1000);
			driver.switchTo().frame(ccpolicyplansubsidyhistory);
			break;
		case "PolicyViewAuthorizationStatus":
			Thread.sleep(1000);
			driver.switchTo().frame(ccpolicyviewauthorizationstatus);
			break;
		case "PolicyAuthorizationCCMS":
			Thread.sleep(1000);
			driver.switchTo().frame(ccpolicyauthorizationccms);
		case "searchClaims":
			Thread.sleep(1000);
			driver.switchTo().frame(sdhistoryframe);
			break;
		default:
			break;
		}
	}

	/**
	 * Method to Verify whether Console Tab is displayed or not
	 * 
	 * @return true or false
	 */
	public boolean VerifyHomePageIsDisplayed() throws Exception {
		try {
			return riproviderportalmyprofile.isDisplayed();
		} catch (Exception e) {
			WaitForPageToLoad(30);
			return riproviderportalmyprofile.isDisplayed();
		}
	}
	
	/**
	 * Method to Verify whether Error Page  is displayed or not
	 * 
	 * @return true or false
	 */
	/*public boolean VerifyErrorPageIsDisplayed() throws Exception {
		//String msg =riprovidererrorpage.getText();
		//(msg.contains("Error"))
		
		boolean eleSelected= driver.findElement(By.xpath("//label[contains(@title,'Error')]")).isDisplayed();
		{
		return eleSelected ;
		}
	}
		/*try {
			Log("Checking if Error Page is displayed", "DONE", false);
			return riprovidererrorpage.isDisplayed();
		} catch (Exception e) {
			WaitForPageToLoad(30);
			
			return riprovidererrorpage.isDisplayed();
		}
}*/
	public boolean VerifyErrorPageIsDisplayed() throws Exception{
		driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		try {
			
			if(driver.findElement(By.xpath("//label[contains(@title,'Error')]")).isDisplayed());{
				
					
				return true;
			}
			
		}
		catch(Exception e) {
			
			return false;
		}
		
		
	}
	
	
	
	
	
	/**
	 * Method to Verify whether page is displayed or not
	 * 
	 * @param strTitle - Page title identified by @class-pageDescription and HTML
	 *                 tag-h2
	 * @return true or false Modified on 04/30/2018
	 */
	public boolean IsPageDisplayed(String strTitle) throws Exception {
		Log("Verifying Page Title - " + strTitle, "DONE", false);
		String strActualTitle = driver.getTitle();

		if (strActualTitle.contains(strTitle)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Method to Verify whether page type is displayed or not
	 * 
	 * @param strTitle - Page type identified by @class-pageDescription and HTML
	 *                 tag-h1
	 * @return true or false
	 */
	public boolean IsPageTypeDisplayed(String strTitle) throws Exception {
		Log("Verifying Menu Page Title - " + strTitle, "DONE", false);
		String strActualTitle = pageType.getText();
		if (strActualTitle.toLowerCase().contains(strTitle.toLowerCase())) {
			return true;

		} else {
			return false;
		}
	}

	/**
	 * Method to Get page title
	 * 
	 * @param strTitleForReporting - Title to be used for logging the step in report
	 * @return strTitle - Page title identified by @class-pageDescription and HTML
	 *         tag-h2
	 */
	public String GetPageTitle(String strTitleForReporting) throws Exception {
		Log("Getting " + strTitleForReporting, "DONE", false);
		WaitForPageToLoad(30);
		String strActualTitle = pageTitle.getText();
		return strActualTitle;
	}

	/**
	 * Method to Get page type
	 * 
	 * @param strTitleForReporting - Title to be used for logging the step in report
	 * @return strTitle - Page type identified by @class-pageDescription and HTML
	 *         tag-h1
	 */
	public String GetPageType(String strTitleForReporting) throws Exception {
		Log("Getting " + strTitleForReporting, "DONE", false);
		WaitForPageToLoad(30);
		String strActualTitle = pageType.getText();
		return strActualTitle;
	}

	/**
	 * Method to Get check box status following a TD text in a Read only form e.g.
	 * View Case
	 * 
	 * @param strLabel - Label (Table cell) after which check box is present
	 * @return strStatus - Check box status (Checked/Unchecked)
	 */
	public String GetCheckboxStatusFromReadOnlyFormAfterLabel(String strLabel) throws Exception {
		Log("Getting status of Checkbox - " + strLabel, "DONE", false);
		WaitForPageToLoad(30);
		String strStatus = driver.findElement(By.xpath("//td[text()='" + strLabel + "']//following::div[1]//img[1]"))
				.getAttribute("title");
		return strStatus;
	}

	/**
	 * Method to Get check box status following a Label text in a Read only form
	 * e.g. Active
	 * 
	 * @param strLabel - Label (Table cell) after which check box is present
	 * @return strStatus - Check box status (Checked/Unchecked)
	 */
	public String GetCheckboxStatusFromAfterLabel(String strLabel) throws Exception {
		Log("Getting status of Checkbox - " + strLabel, "DONE", false);
		WaitForPageToLoad(30);
		String strStatus = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::input[1]"))
				.getAttribute("checked");
		return strStatus;
	}

	/**
	 * Method to Get value from a Input box following a Label
	 * 
	 * @param strLabel - Label after which Input box is present
	 * @return strValue - Value of the Input box
	 */
	public String GetValueFromInputBoxAfterLabel(String strLabel) throws Exception {
		Log("Getting value of - " + strLabel, "DONE", false);
		String strValue;
		try {
			WaitForPageToLoad(30);
			strValue = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::input[1]"))
					.getAttribute("value");
		} catch (Exception e) {
			return "";
		}
		return strValue;
	}

	/**
	 * Method to Get title from a label after a label
	 * 
	 * @param strLabel - Label before which Label is present
	 * @return strTitle - title of the label after label
	 */
	public String GetTitleFromLabelafterLabel(String strLabel) throws Exception {
		Log("Getting Title of the label after the label - " + strLabel, "DONE", false);
		String strValue;
		try {
			WaitForPageToLoad(30);
			String strLabelid = strLabel.replaceAll(" ", "");
			strValue = driver.findElement(By.xpath(
					"//label[text()='" + strLabel + "' and contains(@id,'" + strLabelid + "') ]//following::label[1]"))
					.getAttribute("title");
		} catch (Exception e) {
			return "";
		}
		return strValue;
	}

	/**
	 * Method to Get Error text following a Label
	 * 
	 * @param strLabel - Label after which Error message is present
	 * @return strMessage - Error message text
	 */
	public String GetErrorTextAfterLabel(String strLabel) throws Exception {
		Log("Getting Error Message related to - " + strLabel, "DONE", false);
		String strMessage;
		try {
			WaitForPageToLoad(30);
			strMessage = driver
					.findElement(By.xpath("//label[text()='" + strLabel + "']//following::div[@class='errorMsg']"))
					.getText();
		} catch (Exception e) {
			return "";
		}
		return strMessage;
	}

	/**
	 * Method to Get Error text displayed on top of the form
	 * 
	 * @param strForm - Form in which Error is present - Dummy value used for
	 *                reporting ONLY
	 * @return strErrorMessage - Error message text
	 */
	public String GetErrorAfterAction(String strForm) throws Exception {
		Log("Getting Error Message from Form - " + strForm, "DONE", false);
		String strErrorMessage;
		try {
			WaitForPageToLoad(30);
			strErrorMessage = driver.findElement(By.xpath("//div[@class='pbError']")).getText();
		} catch (Exception e) {
			return "";
		}
		return strErrorMessage;
	}

	/**
	 * Method to Get Error text displayed on top of the form
	 * 
	 * @param strForm - Form in which Error is present - Dummy value used for
	 *                reporting ONLY
	 * @return strErrorMessage - Error message text
	 */
	public String GetErrorAfterAction(String strTag, String strTag2, String attribute, String attributeValue)
			throws Exception {
		Log("Getting Error Message from Form - " + strTag, "DONE", false);
		String strErrorMessage;
		try {
			WaitForPageToLoad(30);
			strErrorMessage = driver
					.findElement(
							By.xpath("//" + strTag + "//" + strTag2 + "[@" + attribute + "='" + attributeValue + "']"))
					.getText();
		} catch (Exception e) {
			return "";
		}
		return strErrorMessage;
	}

	/**
	 * Method to Get text following a TD text in a Read only form e.g. View Case
	 * 
	 * @param strLabel - Label (Table cell) after which check box is present
	 * @return strValue - Text
	 */
	public String GetTextFromReadOnlyFormAfterLabel(String strLabel) throws Exception {
		Log("Getting value of - " + strLabel, "DONE", false);
		WaitForPageToLoad(30);
		String strValue = driver.findElement(By.xpath("//td[text()='" + strLabel + "']//following::td[1]")).getText();
		return strValue;
	}

	/**
	 * Method to Get Current Date and Time
	 * 
	 * @return Date in M/d/yyyy h:mm aaa format e.g. 4/3/2018 11:29 PM
	 */
	public String GetCurrentDateTime() throws InterruptedException {
		SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy h:mm aaa");
		Date date = new Date();
		return formatter.format(date);
	}

	/**
	 * Method to Get Current Date and Time (Overloaded)
	 * 
	 * @param strDateTimeFormat - Dummy input
	 * @return Date in M/d/yyyy format e.g. 4/3/2018
	 */
	public String GetCurrentDateTime(String strDateTimeFormat) throws InterruptedException {
		SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy");
		Date date = new Date();
		return formatter.format(date);
	}

	/**
	 * Method to Get Date and Time offset by number of days
	 * 
	 * @param intOffsetDays - Offset days, Accepts both Positive and Negative
	 *                      integers
	 * @return Date in M/d/yyyy h:mm aaa format e.g. 4/3/2018 11:29 PM
	 */
	public String GetDateTime(String intOffsetDays) throws InterruptedException {
		if (intOffsetDays.substring(0, 2).equals("dt")) {
			intOffsetDays = GetTestData(intOffsetDays);
		}
		if (intOffsetDays.equals("NULL")) {
			return "NULL";
		}
		SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy h:mm aaa");
		Date date = new Date();
		date = addDays(date, Integer.parseInt(intOffsetDays));
		return formatter.format(date);
	}

	/**
	 * Method to Get Current Date
	 * 
	 * @return Date in M/d/yyyy format e.g. 4/3/2018
	 */
	public String GetSimpleCurrentDateTime() throws InterruptedException {
		SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy");
		Date date = new Date();
		return formatter.format(date);
	}

	/**
	 * Method to Get Current Date in MMddyyyy
	 * 
	 * @return Date in MMddyyyy format e.g. 11042021
	 */
	public static String GetSimpleCurrentDate() throws InterruptedException {
		SimpleDateFormat formatter = new SimpleDateFormat("MMddyyyy");
		Date date = new Date();
		return formatter.format(date);
	}
	
	/**
	 * Method to Get passed Date in required format
	 * 
	 * @param format,required format eg.MMddyyy,yyMMdd.etc
	 * @date - required date.
	 * @return Date in requested format in format variable
	 */
	public static String dateFormatter( String date,String currentFormat ,String requiredFormat ) {
		LocalDate d2 = LocalDate.parse(date,DateTimeFormatter.ofPattern(currentFormat));
		return d2.format(DateTimeFormatter.ofPattern(requiredFormat));
		}

	/**
	 * Method to Get Date/Date Time offset by number of days
	 * 
	 * @param intDays - Offset days, Accepts both Positive and Negative integers
	 * @return Date/Date Time in input format
	 */
	public String GetCurrentDateAndAddDays(int intDays) throws InterruptedException {
		SimpleDateFormat formatter = new SimpleDateFormat("MMddyyyy");
		Date date = new Date();
		date = addDays(date, intDays);
		return formatter.format(date);
	}

	/**
	 * Method to add/subtract days from a given date
	 * 
	 * @param datDate - Date
	 * @param intDays - Offset days, Accepts both Positive and Negative integers
	 * @return Date in M/d/yyyy e.g. 4/3/2018
	 */
	public static Date addDays(Date datDate, int intDays) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(datDate);
		cal.add(Calendar.DATE, intDays); // minus number would decrement the days
		return cal.getTime();
	}

	/**
	 * Method to switch to a newly opened Browser Tab
	 */
	public void SwitchToNewTab() throws Exception {
		Log("Switching focus to New Tab", "DONE", false);
		// Switch to new window opened
		Thread.sleep(5000);
		oldTab = driver.getWindowHandle();
		ArrayList<String> newTab = new ArrayList<String>(driver.getWindowHandles());
		newTab.remove(oldTab);
		// change focus to new tab
		driver.switchTo().window(newTab.get(0));

		// Do what you want here, you are in the new tab

		driver.close();
		// change focus back to old tab
		driver.switchTo().window(oldTab);
	}

	/**
	 * Method to switch to a old Tab after moving to a new Browser Tab
	 */
	public void SwitchToOldTab(String strValue) throws Exception {
		Log("Switching back to Old Tab", "DONE", false);
		driver.close();
		// change focus back to old tab
		driver.switchTo().window(oldTab);
	}

	/**
	 * Method to wait for the java script in the page to load for the mentioned
	 * seconds before timing out
	 * 
	 * @param sec - Number of seconds to wait
	 * @throws InterruptedException
	 */
	public void WaitForPageToLoad(int sec) throws InterruptedException {
		new WebDriverWait(driver, 180).until((ExpectedCondition<Boolean>) wd -> ((JavascriptExecutor) wd)
				.executeScript("return document.readyState").toString().equals("complete"));
		Thread.sleep(1000);
	}

	public void ChangeownerStringLookup(String strValue) {
		String MainWindow = driver.getWindowHandle();
		// To handle all new opened window.
		Set<String> s1 = driver.getWindowHandles();
		Iterator<String> i1 = s1.iterator();
		while (i1.hasNext()) {
			String ChildWindow = i1.next();
			if (!MainWindow.equalsIgnoreCase(ChildWindow)) {
				// Switching to Child window
				driver.switchTo().window(ChildWindow);
			}
		}
		try {
			driver.manage().window().maximize();
			WaitForPageToLoad(30);
			driver.switchTo().frame(0);
			SetTextAfterLabel("Search", strValue);
			ClickOnButtonByTitle("Go!");
			Thread.sleep(2000);
			driver.switchTo().defaultContent();
			driver.manage().window().maximize();
			driver.switchTo().frame(1);
			WaitForPageToLoad(30);
			try {
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				ClickOnLinkByText("Show all results");
				Thread.sleep(1000);
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			} catch (Exception e) {
			}
			try {
				ClickOnLinkByText(strValue);
				Thread.sleep(3000);
				driver.switchTo().window(MainWindow);
				driver.switchTo().defaultContent();
			} catch (Exception e) {

				Assert.error(e, "There is an exception while Click");

			}
		} catch (Exception e) {
			Assert.error(e, "There is an exception while opening the page");
		}
	}

	/**
	 * Method to log results to HTML report and to console
	 * 
	 * @param strStepName - Step description
	 * @param strResult   - PASS/FAIL/DONE
	 * @blnScreenshot - Attach screenshot? true/false
	 */
	public static  void Log(String strStepName, String strResult, Boolean blnScreenshot) throws Exception {
		// String strLog = "";
		// String strScreenshotPath = "";
		// String strEndHref="";

		// Check for Screenshot flag
		// if (blnScreenshot) {
		// String base64Screenshot =
		// "data:image/jpg;base64,"+((TakesScreenshot)driver).getScreenshotAs(OutputType.BASE64);
		// strScreenshotPath = "<p><p><img src='" + base64Screenshot + "'
		// style='width:25%;height:25%'>";
		// //strScreenshotPath = "<a href='" + base64Screenshot + "'>";
		// //strEndHref = "</a>";
		//
		// }

		// Format HTML based on test status
		switch (strResult) {
		case "PASS":
			// strLog = strScreenshotPath + "<p><font color='GREEN'>" + strResult + "
			// </font>" + strStepName + strEndHref;
			// strLog = strScreenshotPath + "<p><font color='GREEN'>" + strResult + "
			// </font>" + strStepName + strEndHref;
			Assert.pass(strStepName);
			break;
		case "FAIL":
			// strLog = strScreenshotPath + "<p><font color='RED'> " + strResult + "
			// </font>" + strStepName + strEndHref;
			Assert.fail(strStepName);
			break;
		default:
			// strLog = strScreenshotPath + "<p><font color='GREY'> " + strResult + "
			// </font>" + strStepName + strEndHref;
			Assert.done(strStepName);
			break;
		}

		// Log the Result
		// Reporter.log(strLog, 0);
		// System.out.println(strResult + " - " + strStepName);

	}

	/**
	 * Method to Launch URL
	 * 
	 * @param strURL - Dummy Value
	 */
	public void Launch(String strURL) throws Exception {
		Thread.sleep(3000);
		String URL = Environment.get("RIproviderportal_WEB_URL");
		driver.get(URL);
		boolean loginpage = IsPageDisplayed("HCP Provider Portal > Home");
		if (loginpage) {
			Log("Log in page is displayed", "DONE", false);
		} else {
			Log("Log in page is not displayed", "DONE", false);
			throw new Exception("EXIT TEST");
		}

		try {
			driver.switchTo().alert().accept();
		} catch (Exception e) {
		}
	}

	/**
	 * Method to Login to RIproviderportal
	 * 
	 * @param strUserName - UserID
	 * @param strPassword - Password
	 */
	public void Login() throws Exception {
		String strUser = Environment.get("RIproviderportal.Username");
		String strPwd = Environment.get("RIproviderportal.Password");
		String strQ1 = Environment.get("RIproviderportal.Q1");
		String strQ2 = Environment.get("RIproviderportal.Q2");
		String strAns1 = Environment.get("RIproviderportal.SecAns1");
		String strAns2 = Environment.get("RIproviderportal.SecAns2");
		String strpassphrase = Environment.get("RIproviderportal.Passphrase");
		WaitForPageToLoad(30);
		Log("Logging in to RIProviderportal with User Name - " + strUser, "DONE", false);
		// Entering the user ID in the text field.
		SetTextAfterLabel("User ID", strUser);
		// Click on the Log In button with the title match
		ClickOnButtonByTitle("Log In");
		WaitForPageToLoad(30);
		boolean challQpage = IsPageDisplayed("Challenge Question");

		if (challQpage) {

			String strquestiondisplayed = GetTitleFromLabelafterLabel("Challenge Question");

			if (strquestiondisplayed.equals(aesTest.decrypt(strQ1))) {
				SetTextAfterLabel("Your Answer", aesTest.decrypt(strAns1));
				ClickOnButtonByTitle("Continue");
			}

			if (strquestiondisplayed.equals(aesTest.decrypt(strQ2))) {
				SetTextAfterLabel("Your Answer", aesTest.decrypt(strAns2));
				ClickOnButtonByTitle("Continue");
			}

		}

		boolean blnpassphrase = IsLabelByTitleDisplayed("Passphrase");

		if (blnpassphrase) {
			boolean blnpassphraseans = IsLabelDisplayed(aesTest.decrypt(strpassphrase));
			if (blnpassphraseans) {
				// Entering the Password in the text field.
				SetTextAfterLabel("Password", aesTest.decrypt(strPwd));
			}
		}
		try {
			// Clicking on the Sign In button
			ClickOnButtonByTitle("Sign In");
		} catch (Exception e) {
			Log("Logging in to RIproviderportal didn't succeed using native click - " + strUser, "DONE", false);
			
			RIProviderportal.snowtrigger(community_exit,host1_exit,oid_exit,severity_exit,msgEXIT_exit1);
			//RIProviderportal.snowtrigger(community_exit,host2_exit,oid_exit,severity_exit,msgEXIT_exit1);
			Log("Incident Requested","DONE",true);
			throw new Exception("EXIT TEST");
		}
	}

	/**
	 * Method to navigate to the File Exchange (by default it navigates to Upload
	 * Files section)
	 * 
	 */
	public void NavigatetoFileExchange() throws Exception {
		WaitForPageToLoad(30);
		ClickOnLinkByText("Files Exchange");
	}

	/**
	 * Method to navigate to the File Exchange to Download Files section)
	 * 
	 */
	public void NavigatetoFileExchangeDownload() throws Exception {
		ClickOnLinkByText("Files Exchange");
		WaitForPageToLoad(30);
		ClickOnLinkByText("Download Files");
	}

	/**
	 * Method to Upload the file
	 * 
	 * @param strFilePath - File path of the file to be uploaded
	 */
	public void riProviderportalFileupload(String strFilePath) throws Exception {
		try {
			// Navigating to the File Exchange page
			NavigatetoFileExchange();

			File Uploadfile = new File(strFilePath);
			if (Uploadfile.exists()) {
				SetTextAfterLabel("Upload File #1", strFilePath);
				ClickOnButtonByTitle("Upload");
			} else {
				Log("No file found to upload", "FAIL", true);
				throw new Exception("EXIT TEST");
			}
		} catch (Exception e) {
			RIProviderportal.snowtrigger(community_exit,host1_exit,oid_exit,severity_exit,msgEXIT_exit);
			//RIProviderportal.snowtrigger(community_exit,host2_exit,oid_exit,severity_exit,msgEXIT_exit);
			Log("Incident Requested","DONE",true);
			throw new Exception("EXIT TEST");
			
			
		}
	}

	/**
	 * Method to capture the tracking number
	 */
	public String riProviderportalFileuploadtrackingID(String sheetname) throws Exception {
		String strtrackingconfirmationmsg = "";
		String strtrackingID = "";
		String currentDate = GetSimpleCurrentDate();
		String strTestDataDir = GetExecutionEnvironment("Environment");
		try {
			WebElement element = driver
					.findElement(By.xpath("//div[contains(text(),'Upload File Confirmation')]//following::p[1]"));
			strtrackingconfirmationmsg = element.getText();
			Log("Tracking Confirmation message - " + strtrackingconfirmationmsg, "DONE", true);
			strtrackingID = strtrackingconfirmationmsg.substring(strtrackingconfirmationmsg.lastIndexOf(" ") + 1);
			strtrackingID = strtrackingID.substring(0, strtrackingID.length() - 1);
			Log("Tracking ID - " + strtrackingID, "DONE", true);

			DataTable dsnpday1bot = new DataTable(strTestDataDir + "DSNP.xlsx", sheetname, TestcaseID + currentDate);
			String strtrackingfromsheet = dsnpday1bot.getValue("270TrackingID");
			if (strtrackingfromsheet.equals("")) {
				dsnpday1bot.setValue("270TrackingID", 1, strtrackingID);
			} else {
				dsnpday1bot.setValue("270TrackingID", 1, strtrackingfromsheet + "||" + strtrackingID);
			}
			RIProviderportalPopUp(UploadPopUp);
		} catch (Exception e) {
			RIProviderportal.snowtrigger(community_exit,host1_exit,oid_exit,severity_exit,msgEXIT_exit);
			//RIProviderportal.snowtrigger(community_exit,host2_exit,oid_exit,severity_exit,msgEXIT_exit);
			Log("Incident Requested","DONE",true);
			throw new Exception("EXIT TEST");
		}
		return strtrackingID;
	}

	/**
	 * Method to download the required file type for a given date
	 * 
	 * @param strTrackingID         - Tracking ID to be download
	 * @param strCategoryValue         - Category name that needs to be filtered
	 * @param strFileDownloadPath - File path where the file need to download
	 */

	public void RIProviderportalFiledownload(String strTrackingID, String strCategoryValue, String strDate,
			String strFileDownloadPath) throws Exception {
		String currentDate =GetSimpleCurrentDate();
		/*String strTestDataDir = GetExecutionEnvironment("Environment");
		 DataTable dsnpbot1 = new DataTable(strTestDataDir + "DSNP.xlsx", "271Tracker",  "D" + RIProviderportal.checkDate1);
		 DataTable dsnpbot2 = new DataTable(strTestDataDir + "DSNP.xlsx", "271Tracker",  "D" + RIProviderportal.checkDate2);
		 DataTable dsnpbot3 = new DataTable(strTestDataDir + "DSNP.xlsx", "271Tracker",  "D" + RIProviderportal.checkDate3);
		 DataTable dsnpbot4 = new DataTable(strTestDataDir + "DSNP.xlsx", "271Tracker",  "D" + RIProviderportal.checkDate4);
		 DataTable dsnpbot5 = new DataTable(strTestDataDir + "DSNP.xlsx", "271Tracker",  "D" + RIProviderportal.checkDate5);
		 DataTable dsnpbot6 = new DataTable(strTestDataDir + "DSNP.xlsx", "271Tracker",  "D" + RIProviderportal.checkDate6);
		 DataTable dsnpbot7 = new DataTable(strTestDataDir + "DSNP.xlsx", "271Tracker",  "D" + RIProviderportal.checkDate7);*/
		WaitForPageToLoad(30);
		NavigatetoFileExchangeDownload();
		boolean blntrackingid = false;
		SelectListItemAfterLabel("Category", strCategoryValue);
		String time = Environment.get("Riproviderportal.999wait");
		String ODSuploadpath = Environment.get("RIproviderportal.fileuploadpathODS");
	    String downloadpath = ODSuploadpath + "//Inbound";
        int duration = (int)Float.parseFloat(time);
		if (strCategoryValue.contains("271")) {
			SelectListItemAfterLabel("Max Files", "400");
		}

		ClickOnButtonByTitle("Search");
		WaitForPageToLoad(30);
		if (strCategoryValue.contains("999")) {
			for (int i = 1; i <= duration; i++) {
				blntrackingid = IsLinkDisplayed(strTrackingID);
				Log("Look up of Tracking ID - attempt - " + i, "DONE", true);
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				if (blntrackingid) {
					break;
				} else {
					Thread.sleep(60000);//make it 6 
					ClickOnButtonByTitle("Search");
					  if(VerifyErrorPageIsDisplayed())
				 
				{
					Log("Error Page is displayed verified " , "DONE", true);
					 
					System.out.println("before for");
					loop1:
					for(int p=1; p<10; p++)
					 {
						System.out.println("p"+p);
						Log("Look for error page attempt " + p, "DONE", true);
						NavigatetoFileExchangeDownload();
						SelectListItemAfterLabel("Category", strCategoryValue);
						if (strCategoryValue.contains("999")) {
							//SelectListItemAfterLabel("Max Files", "400");
							ClickOnButtonByTitle("Search");
							WaitForPageToLoad(30);
	                    	break loop1; 
								
							}
						}
						
                    
					}
				}
			}

			if (blntrackingid) {
				Log("Tracking ID - " + strTrackingID + " is present", "DONE", true);
				String SoruceFilepath = riProviderportalDownload(strTrackingID,strCategoryValue);
				//FileRename(downloadpath, strTrackingID);
				FileMove(SoruceFilepath, strFileDownloadPath);
			} else {
				Log("Tracking ID - " + strTrackingID + " is not present even after waiting for 30 mins", "FAIL", true);
				RIProviderportal.snowtrigger(community_999,host1_999,oid_999,severity_999,String.format(msg999_999,strTrackingID,GetSimpleCurrentDate()));
				//RIProviderportal.snowtrigger(community_999,host2_999,oid_999,severity_999,String.format(msg999_999,strTrackingID,GetSimpleCurrentDate()));
				
				Log("Incident Requested","DONE",true);
			}
		}

		if (strCategoryValue.contains("271")) {
			//blntrackingid = IsLinkDisplayed(strTrackingID);
			
//			if (blntrackingid) {
//				Log("Tracking ID - " + strTrackingID + " is present in the first page", "DONE", true);
//				String SoruceFilepath = riProviderportalDownload(strTrackingID);
//				FileMove(SoruceFilepath, strFileDownloadPath);
//			} else {
//				Log("Tracking ID - " + strTrackingID + " is not present in the first page", "DONE", true);
			/*	while (true) {
					Thread.sleep(3000);
					WaitForPageToLoad(30);
					boolean b = driver.findElements(By.xpath("//a[contains(text(),'" + strTrackingID + "')]"))
							.size() != 0;
					if (b == true) {
						Log("Tracking ID found  - " + strTrackingID, "DONE", true);
						String SoruceFilepath = riProviderportalDownload(strTrackingID);
						FileMove(SoruceFilepath, strFileDownloadPath);
						break;
					} else {
						String lastrowdate = driver
								.findElement(
										By.xpath("//table[@class='GridContainer']//tbody//tr[11]//following::label"))
								.getText();
						if (dayCount(lastrowdate) < 8) {
							driver.findElement(By.xpath("//tr[@class='GridRowPager']//td//span//following::a[1]"))
									.click();
							Log("Clicked on the next page", "DONE", true);
						} else {
							Log("BOT navigated to the last 7 days of data and can't find the corresponding match for the tracking ID - "
									+ strTrackingID, "DONE", true);
							break;
						}*/
			while (true)
			{
				String strTestDataDir = GetExecutionEnvironment("Environment");
				 DataTable dsnpbot0 = new DataTable(strTestDataDir + "DSNP.xlsx", "271Tracker",  "D" + RIProviderportal.checkDate0);
				 DataTable dsnpbot1 = new DataTable(strTestDataDir + "DSNP.xlsx", "271Tracker",  "D" + RIProviderportal.checkDate1);
				 DataTable dsnpbot2 = new DataTable(strTestDataDir + "DSNP.xlsx", "271Tracker",  "D" + RIProviderportal.checkDate2);
				 DataTable dsnpbot3 = new DataTable(strTestDataDir + "DSNP.xlsx", "271Tracker",  "D" + RIProviderportal.checkDate3);
				 DataTable dsnpbot4 = new DataTable(strTestDataDir + "DSNP.xlsx", "271Tracker",  "D" + RIProviderportal.checkDate4);
				 DataTable dsnpbot5 = new DataTable(strTestDataDir + "DSNP.xlsx", "271Tracker",  "D" + RIProviderportal.checkDate5);
				 DataTable dsnpbot6 = new DataTable(strTestDataDir + "DSNP.xlsx", "271Tracker",  "D" + RIProviderportal.checkDate6);
				 DataTable dsnpbot7 = new DataTable(strTestDataDir + "DSNP.xlsx", "271Tracker",  "D" + RIProviderportal.checkDate7);
				Thread.sleep(3000);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				boolean b=driver.findElements(By.xpath("//a[contains(text(),'"+strDate+"')]")).size()!=0;
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				if(b) {
				List<WebElement> s = driver.findElements(By.xpath("//a[contains(text(),'"+strDate+"')]"));
				
				List<String> tids = new ArrayList<String>();
				tids.clear();
				for(WebElement x : s)
				{
					
					String newstrTrackingID = x.getText();
					tids.add(newstrTrackingID);
				}
				for(String newstrTrackingID :tids)
				{
					String FileName0 = dsnpbot0.getValue("271FileName").toString();
					String FileName1 = dsnpbot1.getValue("271FileName").toString();
					String FileName2 = dsnpbot2.getValue("271FileName").toString();
					String FileName3 = dsnpbot3.getValue("271FileName").toString();
					String FileName4 = dsnpbot4.getValue("271FileName").toString();
					String FileName5 = dsnpbot5.getValue("271FileName").toString();
					String FileName6 = dsnpbot6.getValue("271FileName").toString();
					String FileName7 = dsnpbot7.getValue("271FileName").toString();
				//System.out.println(FileName1);
				//System.out.println(FileName2);
				
				if((FileName0.contains(newstrTrackingID.substring(0,11))==false)&&(FileName1.contains(newstrTrackingID.substring(0,11))==false)&&(FileName2.contains(newstrTrackingID.substring(0,11))==false)&&(FileName3.contains(newstrTrackingID.substring(0,11))==false)&&(FileName4.contains(newstrTrackingID.substring(0,11))==false)&&(FileName5.contains(newstrTrackingID.substring(0,11))==false)&&(FileName6.contains(newstrTrackingID.substring(0,11))==false)&&(FileName7.contains(newstrTrackingID.substring(0,11))==false))
					
					
				
				
				//if(!fileexists(strFileDownloadPath,newstrTrackingID.substring(0,11)))
					{
						Log(newstrTrackingID+" -Not available at Inbound Location, Downloading..  ", "DONE", true);
						//x.click();//---> 
						String SoruceFilepath = riProviderportalDownload(newstrTrackingID,strCategoryValue);
						
						renameupdate271(newstrTrackingID, strDate);
						
						
						continue;
					}
					
					
					
					Thread.sleep(2000);
					
				}
				String date2 = driver.findElement(By.xpath("//table[@class='GridContainer']//tbody//tr[11]//following::label")).getText();
				if(dayCount(date2)<=0)
			    //if(dayCount(date2)<=8)
			    driver.findElement(By.xpath("//tr[@class='GridRowPager']//td//span//following::a[1]")).click();
				else
				{
					Log(" No Downloadable files in next page for -"+strDate, "DONE", true);
				break;
			}
				//break ;
			
				
				}
			
				else
				{
				    String date2 = driver.findElement(By.xpath("//table[@class='GridContainer']//tbody//tr[11]//following::label")).getText();
					if(dayCount(date2)<=0)
				    //if(dayCount(date2)<=8)
				    driver.findElement(By.xpath("//tr[@class='GridRowPager']//td//span//following::a[1]")).click();
					else
					{
						Log(" No Downloadable files for -"+strDate, "DONE", true);
					break;
				}}
					}
		}
			}
	
	

	/**
	 * Method to find the difference between the given date and current date
	 * 
	 * @param - strDate - Date from which we need to find the difference between the
	 *          current date
	 **/

	public static long dayCount(String strDate) throws Exception {
		
		
		
			
		//Parsing the date
		String requiredDate_formatted1 = dateFormatter(strDate,"MM/dd/yyyy" ,"yyyy-MM-dd");
		String requiredDate_formatted2 = dateFormatter(RIProviderportal.requiredDate,"MMddyyyy" ,"yyyy-MM-dd");
		System.out.println(requiredDate_formatted1);
		System.out.println(requiredDate_formatted2);
		LocalDate dateBefore = LocalDate.parse(requiredDate_formatted1);
		LocalDate dateAfter = LocalDate.parse(requiredDate_formatted2);
			
		//calculating number of days in between
		long noOfDaysBetween = ChronoUnit.DAYS.between(dateBefore, dateAfter);
			
		//displaying the number of days
		System.out.println(noOfDaysBetween);
		/*String date = new SimpleDateFormat("MM/dd/yyyy").format(new Date());
		LocalDate d1 = LocalDate.parse(strDate, DateTimeFormatter.ofPattern("MM/dd/yyyy"));//last col
		LocalDate d2 = LocalDate.parse(date, DateTimeFormatter.ofPattern("MM/dd/yyyy")); //currrent date
		
		Duration duration = Duration.between(d2.atStartOfDay(), d1.atStartOfDay());//(17,22)*/
		//int days = (int) duration.toDays();
		return noOfDaysBetween;
	}
	
	public void renameupdate271(String strtrackingid,String strDate) throws Exception 
	{
		String ODSuploadpath = Environment.get("RIproviderportal.fileuploadpathODS");
	    String strfiledownloadpath = ODSuploadpath + "//Inbound";
	String strTestDataDir = GetExecutionEnvironment("Environment");
	//String fpath = strTestDataDir + "DSNP.xlsx";
	String date1 = dateFormatter(strDate,"yyMMdd", "MMddyyyy");
	
	DataTable dsnpbot = new DataTable(strTestDataDir + "DSNP.xlsx", "271Tracker",  TestcaseID + GetSimpleCurrentDate());
	String  strfilenamefromsheet = dsnpbot.getValue("271Filename");
	
	
	String newname ="271_"+date1+"_"+strtrackingid.substring(0,11)+".txt";
	
	if(strfilenamefromsheet.equals(""))
	{
		dsnpbot.setValue("271Filename", 1, newname);
		FileRename(strfiledownloadpath,strtrackingid,newname);
         Log("271 File renamed" , "DONE", true);
	}
	else
	{
		dsnpbot.setValue("271Filename", 1, strfilenamefromsheet+" || "+newname);
	    FileRename(strfiledownloadpath,strtrackingid,newname);
	    Log("271 File renamed" , "DONE", true);
	}
	

	}
	
	
	/**
	 * Method to create an incident when the 271 is not available beyond 7 working days
	 * 
	 * @param - frequency - Daily/Weekly
	 */
	
	 @SuppressWarnings("unused")
	public void find271defaulters(String frequency) throws Exception{
	 try{
		String strTestDataDir = GetExecutionEnvironment("Environment");
		String fpath = strTestDataDir + "DSNP.xlsx";
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_MONTH, -7);
		String date = new SimpleDateFormat("MMddyyyy").format(calendar.getTime());
		int rnum = ExcelMethods.getRowNum(fpath,frequency,TestcaseID+date);
		System.out.println(rnum);
		System.out.println(date);
		Log("Total number of rows to be scanned - "+rnum, "DONE", false);
		Log("Scanning for 271downloadeddate from the date - "+date, "DONE", false);
		File file = new File(fpath);
		FileInputStream fileStream = new FileInputStream(file);
		Workbook book = new XSSFWorkbook(fileStream);
		org.apache.poi.ss.usermodel.Sheet s = book.getSheet(frequency);
		 
		for(int rowIndex = 1; rowIndex<= rnum; rowIndex++)
		 {
			 Row r= s.getRow(rowIndex);
			 Cell cell271DownloadedDate = r.getCell(3);//271DownloadedDate
			 Cell cell999DownloadedDate = r.getCell(2);//999DownloadedDate
			 Cell cell270TrackingID =r.getCell(1);
			 Cell cell270date =r.getCell(0);
			 Log(" cell999DownloadedDate - "+cell999DownloadedDate.getStringCellValue(), "DONE", false);
			 Log(" cell271DownloadedDate - "+cell271DownloadedDate.getStringCellValue(), "DONE", false);
			 if(cell271DownloadedDate.toString()== "") {
				 if(cell999DownloadedDate.toString() == "") {
					
				 } 
				 else {
					// System.out.println(cell270TrackingID);
					 //System.out.println(cell999DownloadedDate);
					// System.out.println(cell270date);
					 Log(frequency+ " - There is no 271 file available for the date - "+cell999DownloadedDate, "DONE", false);
			// SNOW ticket creation incident method to be called here
					// RIProviderportal.snowtrigger(community,host1, oid, severity,String.format(msg271,cell270TrackingID,cell270date));
					 //RIProviderportal.snowtrigger(community,host2, oid, severity,String.format(msg271,cell270TrackingID,cell270date));
					
					 Log("Incident Requested","DONE",true);	
					 cell271DownloadedDate.setCellValue("Incident requested");
					// System.out.println(cell271DownloadedDate.getStringCellValue());
				 }
			 }
			 
		 }
		 book.close();
		 }
		catch (Exception e) {
			RIProviderportal.snowtrigger(community_exit,host1_exit,oid_exit,severity_exit,msgEXIT_exit);
			//RIProviderportal.snowtrigger(community_exit,host2_exit,oid_exit,severity_exit,msgEXIT_exit);
			Log("Incident Requested","DONE",true);
			throw new Exception("EXIT TEST");
		}
	 }
	
	

	/**
	 * Method to download the file if it is not present in the first page
	 * 
	 * @param - strTrackingID - Tracking ID for which the file needs to be download
	 */

	public void file_download(String strTrackingID) throws Exception {
		while (true) {
			Thread.sleep(3000);
			boolean b = driver.findElements(By.xpath("//a[contains(text(),'" + strTrackingID + "')]")).size() != 0;
			if (b == true) {
				Log("Tracking ID found  - " + strTrackingID, "DONE", true);
				String filename = driver.findElement(By.xpath("//a[contains(text()," + strTrackingID + ")]")).getText();
				driver.findElement(By.xpath("//a[contains(text()," + strTrackingID + ")]")).click();
				WaitForPageToLoad(30);
				File sourcefile = new File(Environment.get("RIproviderportal.filedownloadpath") + filename);

				FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver);
				wait.pollingEvery(250, TimeUnit.MILLISECONDS);
				wait.withTimeout(300, TimeUnit.SECONDS);
				wait.ignoring(NoSuchElementException.class, StaleElementReferenceException.class);
				wait.until((webDriver) -> sourcefile.exists());
				break;
			} else {
				String lastrowdate = driver
						.findElement(By.xpath("//table[@class='GridContainer']//tbody//tr[11]//following::label"))
						.getText();
				if (dayCount(lastrowdate) <= 7)
					driver.findElement(By.xpath("//tr[@class='GridRowPager']//td//span//following::a[1]")).click();
				else
					break;
			}
		}
	}

	/**
	 * Rename File 
	 * 
	 * @param - strSourcefilepath - source file path
	 * @param - currentfilename   - current filename
	 * @param - currentfilename   - required filename
	 * 
	 */
	public void FileRename(String strSourcefilepath, String currentfilename, String requiredfilename) throws Exception {
		try {
		File sourcefile = new File(strSourcefilepath+"//"+currentfilename);

		File destifile = new File(strSourcefilepath+"//"+requiredfilename);

		if (sourcefile.exists()) {
		sourcefile.renameTo(destifile) ;}
		else {
		
			throw new Exception("File Does not exist to rename");
		
		}
		
		}
		catch (Exception e) {
			RIProviderportal.snowtrigger(community_exit,host1_exit,oid_exit,severity_exit,msgEXIT_exit);
			//RIProviderportal.snowtrigger(community_exit,host2_exit,oid_exit,severity_exit,msgEXIT_exit);
			Log("Incident Requested","DONE",true);
		throw new Exception("EXIT TEST");
		}
		}
	/**
	 * Move File from one location to another
	 * 
	 * @param - strSourcefilepath - source file path
	 * @param - strDestfilepath - Destination file path
	 */
	public static void FileMove(String strSourcefilepath, String strDestfilepath) throws Exception {
		try {
			File sourcefile = new File(strSourcefilepath);
			// renaming the file and moving it to a SQL Final Reports-Error Files location
			File destifile = new File(strDestfilepath);
			if (destifile.exists()) {
				destifile.delete();
			}
			if (sourcefile.exists()) {
				if (sourcefile.renameTo(destifile)) {
					Log("File moved to the path - " + destifile, "DONE", true);
				} else {
					Log("File not moved to the path - " + destifile, "FAIL", true);
				}
			}
		} catch (Exception e) {
			RIProviderportal.snowtrigger(community_exit,host1_exit,oid_exit,severity_exit,msgEXIT_exit);
			//RIProviderportal.snowtrigger(community_exit,host2_exit,oid_exit,severity_exit,msgEXIT_exit);
			Log("Incident Requested","DONE",true);
			throw new Exception("EXIT TEST");
		}
	}
	
	/**
	 * Method to create snow incidents when required
	 * 
	 * @param strmessage - message that needs to be sent
	 */
	
	public static void snowtrigger(String community, String host, String oid, String severity, String message) {
		String snowtriggerpath =Environment.get("snow.triggerpath");
		char q ='"';
		
		try {
			System.out.println(snowtriggerpath+"PublishSnmpTrap.bat" +" "+community+" "+host +" "+oid +" "+severity +" "+q+message+q);
			Process p = Runtime.getRuntime().exec(snowtriggerpath+"PublishSnmpTrap.bat" +" "+community+" "+host +" "+oid +" "+severity +" "+q+message+q);
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
			BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));
			// Read the output from the command
			System.out.println("Here is the output of the snowtrigger command:\n");
			String s = null;
			while ((s = stdInput.readLine()) != null) {
			    System.out.println(s);

			 // Read any errors from the attempted command
		    System.out.println("Here is the standard error of the snow trigger command (if any):\n");
			while ((s = stdError.readLine()) != null) {
			     System.out.println(s);
			 }
			}

	
			
		}
			catch(IOException ioe) {
				System.out.println(ioe);
			}
		}

	public static  ArrayList<String> Filecheck() throws Exception {

		
		
		String strFileArchivePath=ODSuploadpath + "//Outbound//Archive";
		String str270uploadfilepath = ODSuploadpath + "//Outbound";
		String strTestDataDir = GetExecutionEnvironment("Environment");
		DataTable dsnpday1bot = new DataTable(strTestDataDir + "DSNP.xlsx", "270Tracker", TestcaseID + GetSimpleCurrentDate());
		String str270filenamefromsheet = dsnpday1bot.getValue("270Filename");
		// Lists all files in folder
		ArrayList<String> outbound = new ArrayList<String>();
		File folder = new File(str270uploadfilepath);
		File[] fList = folder.listFiles();

		for (int i = 0; i < fList.length; i++) {
		File pes = fList[i];
		  if(pes.getName().contains("270")& pes.getName().endsWith("_0.txt"))
		{
			  DSNP270upload999download.zero270file = true;
			  
			  System.out.println(pes.getName()+" - Zero Byte File Found --> Moving to Archive.");
			FileMove(str270uploadfilepath+"//"+pes.getName(), strFileArchivePath+"//"+pes.getName());
			RIProviderportal.Log("The boolean value after file move is "+DSNP270upload999download.zero270file,"DONE",true);

		}
		else if(pes.getName().contains("270"))
		{
			
			outbound.add(pes.getName());    	
		
		}

		}
		RIProviderportal.Log("The boolean value before return  "+DSNP270upload999download.zero270file,"DONE",true);
		return outbound;
		}
	/**
	 * 270 file uploading
	 * 
	 * @param schedule             - Daily / Weekly
	 * @param str270uploadfilepath - upload file path
	 */
	
	public void file270upload( String uploadfile, int dailyfileid, int weeklyfileid) throws Exception {
		
		try {
			String currentDate = GetSimpleCurrentDate();
			String ODSuploadpath = Environment.get("RIproviderportal.fileuploadpathODS");
			String str270uploadfilepath = ODSuploadpath + "//Outbound//"+uploadfile;
			String strFileArchivePath = ODSuploadpath + "//Outbound//Archive//"+uploadfile;
			String strTestDataDir = GetExecutionEnvironment("Environment");
			String str999downloadfilepath = null;
			 DataTable dsnpbot = new DataTable(strTestDataDir + "DSNP.xlsx", "270Tracker",  TestcaseID + currentDate);
			 String  strdownloaddatefromsheet = dsnpbot.getValue("999DownloadedDate");
			String str270filenamefromsheet = dsnpbot.getValue("270Filename");
			
			// Download path to rename the 999 in required convention
			
			if(uploadfile.contains("Daily"))
			{
			str999downloadfilepath = ODSuploadpath + "//Inbound//999_" +"Daily_" + currentDate+ "_"+dailyfileid+".txt";
			}
			if(uploadfile.contains("Weekly"))
			{
	        str999downloadfilepath = ODSuploadpath + "//Inbound//999_" +"Weekly_" + currentDate+ "_"+weeklyfileid+".txt";
			}
			
			// Writing Currently uploading 270 file to Tracker
			if (str270filenamefromsheet.equals("")) {
    			dsnpbot.setValue("270Filename", 1, uploadfile);
    		} else {
    			dsnpbot.setValue("270Filename", 1, str270filenamefromsheet + "||" + uploadfile);
    		}
			
			// 270 upload method to upload files
		
			riProviderportalFileupload(str270uploadfilepath);
			
			// Method that reads tracking id and closes pop up
			String strtrackingID = riProviderportalFileuploadtrackingID("270Tracker");
			
			// 270  upload check and file move to archive
			if (strtrackingID.equals("")) {
				Log("270 File upload failed", "DONE", true);
			}
			else
				{FileMove(str270uploadfilepath, strFileArchivePath);
				 //DSNP270upload999download.trackingids.add(strtrackingID);
				}
			// Tracking ID download, Update in Tracker, 999 File Rename
			
			 Log("Tracking ID - " + strtrackingID + " for the file - " + uploadfile, "DONE", true);
			 RIProviderportalFiledownload("O" +  strtrackingID, "999 - X12-Func. Ack.", currentDate, str999downloadfilepath);
			  
			  File downloadfile999 = new File(str999downloadfilepath);
			  
			  if (downloadfile999.exists())
			  {
			 
				
				  if (strdownloaddatefromsheet.equals("")) 
				  {
					  dsnpbot.setValue("999DownloadedDate", 1, currentDate);
					
				  }
				  else { dsnpbot.setValue("999DownloadedDate", 1, strdownloaddatefromsheet + "||" + currentDate); }
				 
			  }
			  
			  
			  else { 
				  if (strdownloaddatefromsheet.equals("")) 
				  {
					  dsnpbot.setValue("999DownloadedDate", 1, "INCIDENT REQUESTED");
					
				  }
				  else { dsnpbot.setValue("999DownloadedDate", 1, strdownloaddatefromsheet + "||" + "INCIDENT REQUESTED"); }
				  Log("999 downloaded file is not found", "FAIL", true);
			  
			  }	
				 
				 
		} catch (Exception e) {
			
			RIProviderportal.snowtrigger(community_exit,host1_exit,oid_exit,severity_exit,msgEXIT_exit);
			//RIProviderportal.snowtrigger(community_exit,host2_exit,oid_exit,severity_exit,msgEXIT_exit);
			Log("Incident Requested","DONE",true);
			throw new Exception("EXIT TEST");
			
			
			
		}
	}

	
	/**
	 * 271 file downloading
	 * 
	 * Downloads 271 files for 6 
	 */

	public void file271download() throws Exception {
		try {
			
			String ODSuploadpath = Environment.get("RIproviderportal.fileuploadpathODS");
			                                
			String str271downloadfilepath = ODSuploadpath + "//Inbound";
			//String str271downloadfilepath = ODSuploadpath + "Inbound";
			
			
			for (int i = 0; i < 7; i++) {
			    checkDate0=GetCurrentDateAndAddDays(0);
			    checkDate1=GetCurrentDateAndAddDays(-1);
				checkDate2=GetCurrentDateAndAddDays(-2);
				checkDate3=GetCurrentDateAndAddDays(-3);
				checkDate4=GetCurrentDateAndAddDays(-4);
				checkDate5=GetCurrentDateAndAddDays(-5);
				checkDate6=GetCurrentDateAndAddDays(-6);
				checkDate7=GetCurrentDateAndAddDays(-7);
				requiredDate = GetCurrentDateAndAddDays(-i);
				 requiredDate_formatted = dateFormatter(requiredDate,"MMddyyyy" ,"yyMMdd");
				 
				Log("Downloading Available 271 file(s) for the date - " + requiredDate, "DONE", true);
				RIProviderportalFiledownload("NA","271 - X12-Eligibility",requiredDate_formatted,str271downloadfilepath);
				
				
				
					
				}
			Log("BOT Downloaded all available files for last 7 days" , "DONE", true);
			
			}
		 
	catch (Exception e) {
		RIProviderportal.snowtrigger(community_exit,host1_exit,oid_exit,severity_exit,msgEXIT_exit);
		//RIProviderportal.snowtrigger(community_exit,host2_exit,oid_exit,severity_exit,msgEXIT_exit);
		Log("Incident Requested","DONE",true);
		throw new Exception("EXIT TEST");
			
		}
	}

	/**
	 * Method to download the file for the corresponding trackingID
	 * 
	 * @param strTrackingID - Tracking ID of the file that needs to be downloaded
	 */
	public String riProviderportalDownload(String strTrackingID, String strCategoryValue) throws Exception {
		String sourcefilepath = "";
		String downloadfilepath = ODSuploadpath + "//Inbound//";
		
		try {
//			WebElement lnkzipformatelement = driver.findElement(By.xpath("//a[contains(text(),'"+strTrackingID+"')]//following::a[contains(text(),'Zip Format')][1]"));
			WebElement lnkelement = driver.findElement(By.xpath("//a[contains(text(),'" + strTrackingID + "')]"));
			String filename = lnkelement.getText();
			
				lnkelement.click();	
				
				System.out.println("After clicking on element");
			//driver.get("https://www.riproviderportal.org/hcp/Home/Error/tabid/202/Default.aspx"); 
			   if(VerifyErrorPageIsDisplayed())
				 
				{
					Log("Error Page is displayed verified " , "DONE", true);
					 
					System.out.println("before for");
					loop1:
					for(int p=1; p<6; p++)
					 {
						System.out.println("p"+p);
						Log("Look for error page attempt " + p, "DONE", true);
						NavigatetoFileExchangeDownload();
						SelectListItemAfterLabel("Category", strCategoryValue);
						if (strCategoryValue.contains("271")) {
							SelectListItemAfterLabel("Max Files", "400");
							ClickOnButtonByTitle("Search");
							WaitForPageToLoad(30);
							
							WebElement lnkelement1 = driver.findElement(By.xpath("//a[contains(text(),'" + strTrackingID + "')]"));
							

							lnkelement1.click();
							
							Log("After clicking on the file click ", "DONE", true);
							WaitForPageToLoad(30);
							
	                     File downloadfile = new File(downloadfilepath + filename);
							//File downloadfile = new File("U://Inbound//" +filename);
							if(downloadfile.exists()) {
								Log("Download file exists exiting the loop", "DONE", true);
	                    	break loop1; 
								
							}
						}
						else if(strCategoryValue.contains("999"))
						{
							//SelectListItemAfterLabel("Max Files", "400");
							ClickOnButtonByTitle("Search");
							WaitForPageToLoad(30);
							
							WebElement lnkelement1 = driver.findElement(By.xpath("//a[contains(text(),'" + strTrackingID + "')]"));
							

							lnkelement1.click();
							
							Log("After clicking on the file click ", "DONE", true);
							WaitForPageToLoad(30);
							
	                        File downloadfile = new File(downloadfilepath + filename);
							//File downloadfile = new File("U://Inbound//" +filename);
							if(downloadfile.exists()) {
								Log("Download file exists exiting the loop", "DONE", true);
	                    	break loop1; 
								
							}
						}
                    
					}	
				}
	
			
	

					  WaitForPageToLoad(30);
			

			File sourcefile = new File(downloadfilepath + filename);
			
			//File sourcefile = new File("U://Inbound//" +filename);

			FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver);
			wait.pollingEvery(250, TimeUnit.MILLISECONDS);
			wait.withTimeout(300, TimeUnit.SECONDS);
			wait.ignoring(NoSuchElementException.class, StaleElementReferenceException.class);
			wait.until((webDriver) -> sourcefile.exists());
			// verifying whether the file is present in the download path before reporting
			// as download completed
			if (sourcefile.exists()) {
				sourcefilepath = sourcefile.getAbsolutePath();
				Log("File download successful for the Tracking ID - " + strTrackingID, "DONE", true);
			} else {
				Log("File download failed for the Tracking ID - " + strTrackingID, "FAIL", true);
			//snow trigger for portal error andexcepion
//			throw new Exception("EXIT TEST"); 
			}

		} catch (Exception e) {
			RIProviderportal.snowtrigger(community_exit,host1_exit,oid_exit,severity_exit,msgEXIT_exit);
			//RIProviderportal.snowtrigger(community_exit,host2_exit,oid_exit,severity_exit,msgEXIT_exit);
			Log("Incident Requested","DONE",true);
			throw new Exception("EXIT TEST");
		}
		return sourcefilepath;
	}

	

	/**
	 * Method to Click on the pop up
	 * 
	 */
	public void RIProviderportalPopUp(WebElement element) throws Exception {
		try {
			element.click();
			Log("Clicked on the OK Button in the Pop Up", "DONE", true);
		} catch (Exception e) {
			RIProviderportal.snowtrigger(community_exit,host1_exit,oid_exit,severity_exit,msgEXIT_exit);
			//RIProviderportal.snowtrigger(community_exit,host2_exit,oid_exit,severity_exit,msgEXIT_exit);
			Log("Incident Requested","DONE",true);
			throw new Exception("EXIT TEST");
		}

	}

	/**
	 * Method to Verify Home page is displayed or not
	 */
	public void IsHomePageDisplayed() throws Exception {
		WaitForPageToLoad(30);
		System.out.println("Waiting for Page to Load!!");
		if (VerifyHomePageIsDisplayed()) {
			Log("Home Page is displayed", "PASS", true);
			WaitForPageToLoad(30);
		} else {
			Log("Home Page is not displayed", "FAIL", true);
			RIProviderportal.snowtrigger(community_exit,host1_exit,oid_exit,severity_exit,msgEXIT_exit);
			//RIProviderportal.snowtrigger(community_exit,host2_exit,oid_exit,severity_exit,msgEXIT_exit);
			Log("Incident Requested","DONE",true);
			throw new Exception("EXIT TEST");
		}
	}

	/**
	 * Method to Verify Error page is displayed or not
	 */
	
	/*public void IsErrorpageDisplayed() throws Exception {
		WaitForPageToLoad(30);
		System.out.println("Waiting for Page to Load!!");
		if (VerifyErrorPageIsDisplayed()) {
			Log("Error Page is displayed", "PASS", true);
			WaitForPageToLoad(30);
		} else {
			
			throw new Exception("EXIT TEST");
		}
	}*/

	/**
	 * Method to Set Test Data File
	 * 
	 * @param strFile - Test Data File name with out extension e.g. RQD0001741A for
	 *                RQD0001741A.properties file
	 */
	public void SetTestDataFile(DataTable strFileName) throws Exception {
		Log("Setting Test Data File - " + strFileName, "DONE", false);
		dt = strFileName;
	}

	/**
	 * Method to Set Current Test Environment
	 */
	public void SetTestEnvironmentFile() throws Exception {
		testenvironment = new File(System.getProperty("user.dir") + "//src//data//config//environment.properties");
		strTestEnvironment = GetExecutionEnvironment("Environment");
		testenvdata = new File(
				System.getProperty("user.dir") + "//src//data//config//" + strTestEnvironment + ".properties");
	}

	/**
	 * Method to Set Test Data File to an output file generated by another script
	 * 
	 * @param strFile - Test Data File name with out extension e.g. RQD0001741A for
	 *                RQD0001741A.properties file
	 */
	public void SetTestDataFileFromOutput(String strFileName) throws Exception {
		Log("Setting Test Data File to an Ouput Data File - " + strFileName, "DONE", false);
		SetTestEnvironmentFile();
		String strTestEnvironment = GetExecutionEnvironment("Environment");
		testdata = new File(System.getProperty("user.dir") + "//src//data//output//" + strTestEnvironment + "//"
				+ strFileName + ".properties");
	}

	/**
	 * Method to Set Test Data Output File to write data
	 * 
	 * @param strFile - Test Data File name with out extension e.g. RQO0001741A for
	 *                RQO0001741A.properties file
	 */
	public void SetTestOutputFile(String strFileName) throws Exception {
		Log("Setting Test Ouput Data File - " + strFileName, "DONE", false);
		testoutput = new File(System.getProperty("user.dir") + "//src//data//output//" + strTestEnvironment + "//"
				+ strFileName + ".properties");
	}

	/**
	 * Method to Get value from current test data file by providing Key
	 * 
	 * @param strKey - Key of a Key-Value pair e.g. dtUsername=abc@xyz.com where
	 *               dtUsername is Key
	 * @return Value of the Key
	 */
	public String GetTestData(String strKey) {
		return dt.getValue(strKey);
	}

	/**
	 * Method to Get value from current environment file
	 * 
	 * @param strKey - Key of a Key-Value pair e.g. dtUsername=abc@xyz.com where
	 *               dtUsername is Key
	 * @return Value of the Key
	 */
	public String GetEnvironmentData(String strRowParam, String strColParam) {
		// String strTestConfigDir = System.getProperty("user.dir") +
		// "/resources/config/";
		String strTestConfigDir = Environment.get("BASE_DIR") + "/config/";
		DataTable environment = new DataTable(strTestConfigDir + "Environment.xlsx", strTestEnvironment, strRowParam);
		return environment.getValue(strColParam);
	}

	/**
	 * Method to Get value from current test data file by providing Key
	 * 
	 * @param strKey - Key of a Key-Value pair e.g. dtUsername=abc@xyz.com where
	 *               dtUsername is Key
	 * @return Value of the Key
	 */
	public static String GetExecutionEnvironment(String strKey) {
		System.out.println(Environment.get("BASE_DIR"));
		String strTestConfigDir = Environment.get("BASE_DIR") + "//config//";
		DataTable currentenvironment = new DataTable(strTestConfigDir + "Environment.xlsx", "current", strKey);
		strTestEnvironment = currentenvironment.getValue("dtValue");
		// return
		// System.getProperty("user.dir")+"/resources/testdata/"+strTestEnvironment+"/";
		return Environment.get("BASE_DIR") + "//testdata//" + strTestEnvironment + "//";

	}

	/**
	 * Method to Get value from current test data file by providing Key
	 * 
	 * @param strKey - Key of a Key-Value pair e.g. dtUsername=abc@xyz.com where
	 *               dtUsername is Key
	 * @return Value of the Key
	 */
	public String GetTestEnvironmentData(String strKey) {

		File file = testenvdata;
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			Assert.error(e, "File  Not Found ");
		}
		Properties prop = new Properties();
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			Assert.error(e, "File  Not Found ");
		}
		Enumeration<Object> KeyValues = prop.keys();
		while (KeyValues.hasMoreElements()) {
			String key = (String) KeyValues.nextElement();
			if (key.equals(strKey)) {
				return prop.getProperty(strKey);
			}
		}
		return null;
	}

	/**
	 * Method to Add data to current output file as Key-Value pair
	 * 
	 * @param strKey    - Key of a Key-Value pair e.g. dtUsername=abc@xyz.com where
	 *                  dtUsername is Key
	 * @param strValue  - Value of the Key
	 * @param blnAppend - Append or Overwrite (true for Append and false for
	 *                  Overwrite)
	 */
	public void AddTestData(String strKey, String strValue, Boolean blnAppend) {

		File file = testoutput;
		FileOutputStream fileOutput = null;
		try {
			fileOutput = new FileOutputStream(file, blnAppend);
		} catch (FileNotFoundException e) {
			Assert.error(e, "File  Not Found ");
		}
		Properties prop = new Properties();
		prop.setProperty(strKey, strValue);
		try {
			prop.store(fileOutput, null);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Assert.error(e, "File  Not Found ");
		}
	}

	/**
	 * Method to Add screenshot of an element to Log
	 * 
	 * @param e - Web Element
	 */
	public void getScreenshot(final WebElement e) throws IOException {

		final BufferedImage img;
		final Point topleft;
		final Point bottomright;
		final byte[] screengrab;

		screengrab = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
		img = ImageIO.read(new ByteArrayInputStream(screengrab));
		topleft = e.getLocation();
		bottomright = new Point(e.getSize().getWidth(), e.getSize().getHeight());
		BufferedImage imgScreenshot = (BufferedImage) img.getSubimage(topleft.getX() * 2, topleft.getY() * 2,
				bottomright.getX() * 2, bottomright.getY() * 2);

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(imgScreenshot, "png", baos);
		// String data = DatatypeConverter.printBase64Binary(baos.toByteArray());
		// String imageString = "data:image/png;base64," + data;
		// Reporter.log("<p><img src='" + imageString + "'>",0);

	}

	/**
	 * Method to check a mandatory field in a Form Added on 04/29/2018
	 * 
	 * @param strLabel - Label after which Field is present
	 * @return true or false
	 */
	public boolean IsInputRequired(String strLabel) throws Exception {
		if (strLabel.substring(0, 2).equals("dt")) {
			strLabel = GetTestData(strLabel);
		}
		String strClass = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::div[1]"))
				.getAttribute("class");
		if (strClass.equals("requiredInput")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Method to Get Attribute of a webElement following a Label text in a Read only
	 * form e.g. Active
	 * 
	 * @param tagName - Tag of the WebElement
	 * @return strAttribute - Text of the strAttribute
	 */
	public String GetAttributevalue(String tagName, String strText) throws Exception {

		WaitForPageToLoad(30);
		String strAttribute = driver.findElement(By.xpath("//" + tagName + "[text()='" + strText + "']")).getText();
		Log("Getting status of Checkbox - " + strAttribute, "DONE", false);
		return strAttribute;
	}

	/**
	 * Method to check whether a Select box is enabled or not Added on 04/29/2018
	 * 
	 * @param strLabel - Label after which Field is present
	 * @return true or false
	 */
	public boolean IsSelectBoxDisabled(String strLabel) throws Exception {
		if (strLabel.substring(0, 2).equals("dt")) {
			strLabel = GetTestData(strLabel);
		}
		String strStatus = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::select[1]"))
				.getAttribute("disabled");
		if (strStatus.equals("true")) {
			return true;
		}
		return false;
	}

	/**
	 * Method to Get Picklist Values from Select box Added on 04/29/2018
	 * 
	 * @param strLabel - Label after which Field is present
	 * @return true or false
	 */
	public String GetPickListValuesByLabel(String strLabel) throws Exception {
		String strPickListValues = "";
		if (strLabel.substring(0, 2).equals("dt")) {
			strLabel = GetTestData(strLabel);
		}
		Log("Getting picklist values for - " + strLabel + " ", "DONE", false);
		WaitForPageToLoad(30);
		WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::select[1]"));
		Select dropdown = new Select(element);
		List<WebElement> allOptions = dropdown.getOptions();

		// Loop to print one by one
		for (int j = 0; j < allOptions.size(); j++) {
			if (!allOptions.get(j).getText().contains("None"))
				strPickListValues = strPickListValues + "," + allOptions.get(j).getText();
		}
		return strPickListValues.substring(1);
	}

	/**
	 * Method to Verify an Image by Title is displayed or not Added on 04/29/2018
	 */
	public boolean IsImageByTitleDisplayed(String strTitle) throws Exception {
		// Enter Case Information
		WebElement element = driver.findElement(By.xpath("//img[@title='" + strTitle + "']"));
		return element.isDisplayed();
	}

	/**
	 * Method to Verify a Label by Title is displayed or not
	 * 
	 * @param strTitle - @title of the Label
	 */
	public boolean IsLabelByTitleDisplayed(String strTitle) throws Exception {
		try {
			WebElement element = driver.findElement(By.xpath("//label[@title='" + strTitle + "']"));
			return element.isDisplayed();

		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Method to click on a Submit Button type - Input identified by @title tag
	 * 
	 * @param strButtonName - @title of the Button
	 */
	public void ClickOnSubmitButtonByTitle(String strButtonName) throws Exception {
		Log("Clicking on Button - " + strButtonName, "DONE", true);
		WebElement element = driver.findElement(By.xpath("//input[@title='" + strButtonName + "']"));
		element.click();
	}

	/**
	 * Method to get Cell Data with html tag
	 * <th>from a Table e.g. Case Heirarchy Added on 04/30/2018
	 * 
	 * @param strTableHeaderCell - Column name in the Table
	 * @param intRow             - Table Row number
	 * @return String in the specified row
	 */
	public String GetMainCellDataFromTableByColumnName(String strTableHeaderCell, int intRow) throws Exception {
		Log("Getting Cell Data from " + strTableHeaderCell + " - Row " + intRow, "DONE", false);
		Actions action = new Actions(driver);
		WebElement element = driver.findElement(By.xpath("//tr[@class='headerRow']//th[text()='" + strTableHeaderCell
				+ "']/../../tr[contains(@class,'dataRow')][" + intRow + "]//a[1]"));
		action.moveToElement(element).perform();
		WaitForPageToLoad(30);
		return element.getText();
	}

	/**
	 * Method to compare Picklist Values from Select box Added on 05/07/2018
	 * 
	 * @param strLabel               - Label after which Field is present
	 * @param expectedPickListValues - ArrayList with expected values
	 * @return true or false
	 * @author PS7PTSO
	 */
	public boolean comparePickListValuesByLabel(String strLabel, ArrayList<String> expectedPickListValues)
			throws Exception {
		ArrayList<String> actualPickListValues = new ArrayList<>();
		if (strLabel.substring(0, 2).equals("dt")) {
			strLabel = GetTestData(strLabel);
		}
		Log("Getting picklist values for - " + strLabel + " ", "DONE", false);
		WaitForPageToLoad(120);
		WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::select[1]"));
		Select dropdown = new Select(element);
		List<WebElement> allOptions = dropdown.getOptions();

		for (int j = 0; j < allOptions.size(); j++) {
			if (!allOptions.get(j).getText().contains("None"))
				actualPickListValues.add(allOptions.get(j).getText().trim());
		}
		Collections.sort(actualPickListValues);
		Collections.sort(expectedPickListValues);
		if (actualPickListValues.containsAll(expectedPickListValues))
			return true;
		else
			return false;
	}

	/**
	 * Method to check if a Radio Button having type - Input preceding a Label with
	 * text is selected such as to check if Member radio button is selected on Find
	 * Customer page
	 * 
	 * @param strLabel - Text of the Label before which the Radio button is present
	 * @return true or false
	 * @author PS7PTSO added on 05/10/2018
	 */
	public boolean isRadioButtonSelectedBeforeLabel(String strLabel) throws Exception {
		Log("Checking Radio button selection - " + strLabel, "DONE", false);
		WebElement element = driver
				.findElement(By.xpath("//label[contains(.,'" + strLabel + "')]//preceding::input[1]"));
		// WebElement element = driver.findElement(By.xpath("//label[.='"+ strLabel +
		// "')]//preceding::input[1]"));
		if (element.isSelected()) {
			Log(strLabel + " Radio Button is selected", "PASS", false);
			Thread.sleep(1000);
			return true;
		} else {
			Log(strLabel + " Radio Button is not enabled", "FAIL", false);

		}
		return false;
	}

	/**
	 * Generic Method to click on a check box
	 * 
	 * @param strTag       - Tag of the webElement
	 * @param strAttribute - Attribute of the WebElement
	 * @param strValue     - value of the Attribute value of the WebElement
	 * @author XMRETSO added on 07/11/2018
	 */
	public void SelectcheckboxbyattributeTag(String strTag, String strAttribute, String strvalue) {
		driver.findElement(By.xpath("//" + strTag + "[@" + strAttribute + "='" + strvalue + "']//input")).click();
	}

	/**
	 * Generic Method to click on a check box
	 * 
	 * @param strTag       - Tag of the webElement
	 * @param strAttribute - Attribute of the WebElement
	 * @param strValue     - value of the Attribute value of the WebElement
	 * @author KB7BTSO added on 05/15/2018
	 */
	public void Selectcheckboxbyattribute(String strTag, String strAttribute, String strvalue) {
		driver.findElement(By.xpath("//" + strTag + "[@" + strAttribute + "='" + strvalue + "']")).click();
	}

	/**
	 * Method to click on a Button type using Send Keys - Input identified by @value
	 * tag
	 * 
	 * @param strButtonValue - @value of the Button added on 05/17/2018
	 */
	public void clickOnButtonByValuebySendKeys(String strButtonValue) throws Exception {
		Log("Clicking on Button - " + strButtonValue, "DONE", true);
		try {
			if (driver.findElement(By.xpath("//input[@value='" + strButtonValue + "']")).isEnabled()) {
				driver.findElement(By.xpath("//input[@value='" + strButtonValue + "']")).sendKeys(Keys.RETURN);
				Log("Clicked on Button - " + strButtonValue, "DONE", true);
				WaitForPageToLoad(30);
			}
		} catch (Exception e) {
			Log(strButtonValue + " Button is not enabled", "FAIL", false);
		}
	}

	/**
	 * Verifying whether the link is present or not
	 * 
	 * @param strlinktext - @text of the Link to be verified
	 */
	public boolean IsLinkDisplayed(String strlinktext) throws Exception {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Log("Verifying the link is displayed or not - " + strlinktext, "DONE", true);
		try {
			WaitForPageToLoad(30);
			if (driver.findElement(By.xpath("//a[contains(.,'" + strlinktext + "')]")).isDisplayed()) {
				Log("Link is displayed - " + strlinktext, "PASS", true);
				return true;
			} else {
				Log("Link is not displayed - " + strlinktext, "DONE", true);
				return false;
			}
		} catch (Exception e) {
			Log(strlinktext + " Link is not displayed", "DONE", false);
			return false;
		}
	}

	/**
	 * Verifying whether the Label is present or not
	 * 
	 * @param strlinktext - @text of the Label to be verified added on 02/07/2018
	 * @return
	 */
	public boolean IsLabelDisplayed(String strLabel) throws Exception {
		Log("Verifying the Label is displayed or not - " + strLabel, "DONE", true);
		try {
			WaitForPageToLoad(30);
			if (driver.findElement(By.xpath("//label[text()='" + strLabel + "']")).isDisplayed()) {
				Log("Label is displayed - " + strLabel, "PASS", true);
				return true;
			} else {
				Log("Label is not displayed - " + strLabel, "FAIL", true);
				return false;
			}
		} catch (Exception e) {
			Log(strLabel + " Label is not displayed", "FAIL", false);
			return false;
		}

	}

	/**
	 * Method to check for presence of a WebElement
	 * 
	 * @param locator - value of WebElement locator eg. By.id("abc")
	 * @author PS7PTSO added on 06/12/2018
	 */
	public boolean isElementPresent(By locator) {
		if (driver.findElement(locator).isDisplayed()) {
			return true;
		} else
			return false;
	}

	/**
	 * Method to click on a Radio button by @name and value
	 * 
	 * @param strName Name of the Button
	 * @param sValue  Value of the button position example : Radio button for Screen
	 *                Broker and Search type (//input[@name='strName'])[sValue]
	 */
	public void ClickOnRadioButton(String strName, String sValue) throws Exception {
		Log("Clicking on Radio button - " + strName, "DONE", false);
		driver.findElement(By.xpath("(//input[@name='" + strName + "'])[" + sValue + "]")).click();
	}

	/**
	 * Method to wait for Loader image to be invisible
	 * 
	 * @param sec - Number of seconds to wait
	 * @throws InterruptedException
	 */
	public void driver_WaitForElementInvisible() throws Exception {

		WebDriverWait wait = new WebDriverWait(driver, 180);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//img[@src='/img/loading.gif'])[1]")));

	}

	/**
	 * Method to wait for Loader image to be invisible index - index of the image
	 * where it is present(incase more than one loader symbol)
	 * 
	 * @param sec - Number of seconds to wait
	 * @throws InterruptedException
	 */
	public void driver_WaitForElementInvisible(int index) throws Exception {

		WebDriverWait wait = new WebDriverWait(driver, 180);
		System.out.println("Waiting for the loading symbol to disappear");
		List<WebElement> elements = driver.findElements(By.xpath("//img[@src='/img/loading.gif']"));
		wait.until(ExpectedConditions.invisibilityOfAllElements(elements));

	}

	/**
	 * Method to Select Case by PRIORITY Field
	 * 
	 * @param sPriority - Number of seconds to wait
	 * @return
	 * @throws InterruptedException
	 */
	public void SelectCaseByPriorityField(String sPriority) throws Exception {
		List<WebElement> sizeOf_Table = driver.findElements(By
				.xpath("(//div[@class='x-panel-body x-panel-body-noheader']//table[@class='x-grid3-row-table']//tr)"));
		if (sizeOf_Table.size() == 0) {
			String NoRecordFound = driver.findElement(By.xpath("//div[@class='x-grid-empty']")).getText();
			System.out.println("Result for My Open Cases is: " + NoRecordFound);
		} else {
			for (int i = 1; i <= sizeOf_Table.size(); i++) {
				String stPriority = driver.findElement(By.xpath(
						"(//div[@class='x-panel-body x-panel-body-noheader']//table[@class='x-grid3-row-table']//tr)["
								+ i + "]//td[7]"))
						.getText();
				if (stPriority.equalsIgnoreCase(sPriority)) {
					String Casenumber = driver.findElement(By.xpath(
							"(//div[@class='x-panel-body x-panel-body-noheader']//table[@class='x-grid3-row-table']//tr)["
									+ i + "]//td[3]"))
							.getText();
					System.out.println("The Case number to be  Select is  :" + Casenumber);
					ClickOnLinkByText(Casenumber);
					break;
				} else {
					System.out.println("No Case  is Present with  Priority :" + sPriority);
				}

			}
		}

	}

	/**
	 * Author - XPXSTSO Method to click on Notes and Attachment File Name
	 */
	public void ClickOnNotesAndAttachmentFile() throws Exception {
		String sNotesAndAttachment = driver
				.findElement(By.xpath("(//*[contains(@id,'_RelatedNoteList_body')])[1]//td[2]")).getText().trim();
		if (sNotesAndAttachment != null && sNotesAndAttachment != " ") {
			System.out.println("The title of attachment file Format is:" + sNotesAndAttachment);
		} else {
			Assert.fail("No file Present in Attachment section under Notes and attachment!!");
		}
		driver.findElement(By.xpath("//a[text()='" + sNotesAndAttachment + "']")).click();
		SwitchToFrame("Default");
		SwitchToFrame("Content");
		String sattachmentOwner = driver.findElement(By.xpath("//td[text()='Attachment Owner']//following::a[1]"))
				.getText().trim();
		if (sattachmentOwner != null && sattachmentOwner != " ") {

			Log("The Attachment Details Screen displays - " + sattachmentOwner, "DONE", true);
			driver.findElement(By.xpath("//a[contains(text(),'View file')]")).click();
		} else {
			Assert.fail("The Attachment Details Screen is not displays!" + sattachmentOwner);
		}
	}

	/**
	 * Method to check Radio button is Available
	 * 
	 * @author XCPKTSO
	 * @param Radio button preceeding strLabel
	 */

	public void isRadioButtonEnabledBeforeLabel(String strLabel) throws Exception {
		WebElement element = driver
				.findElement(By.xpath("//label[contains(.,'" + strLabel + "')]//preceding::input[1]"));
		if (element.isEnabled()) {
			Log(strLabel + " Radio Button is Enabled", "PASS", true);
		} else {
			Log(strLabel + " Radio Button is not Enabled", "FAIL", false);
		}
	}

	/**
	 * Method get read only text from WebElement following td text
	 * 
	 * @param tdText - td Text say "Case Origin" in //td[.='Case
	 *               Origin']/following::td[1]
	 * @return WebElement text
	 * @author PS7PTSO added on - 6/22/2018
	 */
	public String getTextAfterColumn(String tdText) {
		return driver.findElement(By.xpath("//td[.='" + tdText + "']/following::td[1]")).getText();
	}

	/**
	 * Method to get Cell Header Data with html tag
	 * <td>and tag //h2 from a Table
	 * 
	 * @param strTableHeader - Heading of the Table
	 * @param intCol         - Table Column number
	 * @return String in the specified row and column
	 */
	public void GetHeaderFromTableByNameAndValue(String strTableHeader) throws Exception {
		Log("Getting Cell Header from " + strTableHeader + "", "DONE", false);
		List<WebElement> sizeOf_Table = (List<WebElement>) driver
				.findElements(By.xpath("//table[contains(@id,'myform:searchGroupResult:j_id')]//th"));
		if (sizeOf_Table.size() == 0) {
			System.out.println("Result for My Open Cases is: " + sizeOf_Table);
		}

		for (int i = 2; i <= sizeOf_Table.size(); i++) {
			String Header = driver
					.findElement(By.xpath("//table[contains(@id,'myform:searchGroupResult:j_id')]//th[" + i + "]"))
					.getText();
			if (Header != null && Header != "") {
				String sColumnValue = driver
						.findElement(By
								.xpath("//h2[text()='" + strTableHeader + "']//following::tbody[1]//tr//td[" + i + "]"))
						.getText().trim();
				if (sColumnValue != null && sColumnValue != " ") {
					// Assert.done("The Table Header is :"+Header+" And value is :"+sColumnValue);
					Log("Getting Cell Header from " + strTableHeader + " And Value is " + sColumnValue + "", "PASS",
							false);
				} else {
					// Assert.fail("The Table Header is :"+Header+" And value is :"+sColumnValue);
					Log("Getting Cell Header from " + strTableHeader + " And Value is " + sColumnValue + "", "FAIL",
							false);
				}

			}

		}

	}

	/**
	 * Method to get Cell Header Data with html tag
	 * <td>and tag //h2 from a Table
	 * 
	 * @param strTableHeader - Heading of the Table
	 * @param intCol         - Table Column number
	 * @return String in the specified row and column
	 */
	public void GetHeaderFromSubGroupTable(String strTableHeader) throws Exception {
		Log("Getting Cell Header from " + strTableHeader + "", "DONE", false);
		List<WebElement> sizeOf_Table = (List<WebElement>) driver
				.findElements(By.xpath("//table[contains(@class,'list pagination dataTable no-footer compact')]//th"));
		if (sizeOf_Table.size() == 0) {
			System.out.println("Result for My Open Cases is: " + sizeOf_Table);
		}

		for (int i = 1; i <= sizeOf_Table.size(); i++) {
			String Header = driver
					.findElement(By.xpath(
							"//table[contains(@class,'list pagination dataTable no-footer compact')]//th[" + i + "]"))
					.getText();
			if (Header != null && Header != "") {
				String sColumnValue = driver
						.findElement(By
								.xpath("//h2[text()='" + strTableHeader + "']//following::tbody[1]//tr//td[" + i + "]"))
						.getText().trim();
				if (sColumnValue != null && sColumnValue != " ") {
					Log("The  Sub-Table Header is  " + Header + "And Value is " + sColumnValue + "", "PASS", true);
				} else {
					Log("The  Sub-Table Header is  " + Header + "And Value is " + sColumnValue + "", "FAIL", true);
				}

			}

		}

	}

	/**
	 * Method to click on Data in sub table dynamic value eg : Group Search and Sub
	 * Group table click on SubGroup Number
	 * 
	 * @param strTableHeader - Heading of the Table
	 */
	public void clickonSubtableFirstvalue(String strTableHeader, int iColumn) throws Exception {
		Log("Getting Cell Header from " + strTableHeader + "", "DONE", false);
		List<WebElement> sizeOf_Table = (List<WebElement>) driver
				.findElements(By.xpath("//table[contains(@class,'list pagination dataTable no-footer compact')]//th"));
		if (sizeOf_Table.size() == 0) {
			System.out.println("Result for My Open Cases is: " + sizeOf_Table);
		}

		String sColumnValue = driver
				.findElement(
						By.xpath("//h2[text()='" + strTableHeader + "']//following::tbody[1]//tr//td[" + iColumn + "]"))
				.getText().trim();
		if (sColumnValue != null && sColumnValue != " ") {
			Log("Clicking Cell data " + sColumnValue + "", "PASS", true);
			ClickOnLinkByText(sColumnValue);
		} else {
			Log("Clicking Cell data " + sColumnValue + "", "FAIL", true);
		}

	}

	/**
	 * Generic Method to click on a check box
	 * 
	 * @param strTag    - Tag of the webElement parent Element
	 * @param strTag2   - Tag of the webElement child Element(link)
	 * @param strValue  - value of the Attribute value of the Parents of the
	 *                  WebElement
	 * @param strValue2 - value of the Attribute value of the Child of the
	 *                  WebElement
	 * @author KB7BTSO added on 06/25/2108
	 */
	public void ClickonLinkbyText(String strTag, String strvalue, String strTag2, String strValue2, int index) {
		driver.findElement(By.xpath("(//" + strTag + "[@class='" + strvalue + "']//" + strTag2 + "[contains(.,'"
				+ strValue2 + "')])[" + index + "]")).click();
	}

	/**
	 * Method to click on a Radio Button having type
	 * -<input id="BrokerId" name="brokerRadio" onchange=
	 * "selectRadioBroker(this.id)" type="radio">
	 * 
	 * @param strLinkText - Text of the Link before which the Check box is present
	 */
	public void selectRadioButtonwithID(String strRadioBNId) throws Exception {
		Log("Clicking on Radio button with ID- " + strRadioBNId, "DONE", false);
		driver.findElement(By.xpath("//input[@id='" + strRadioBNId + "']")).click();
	}

	/**
	 * Method to click on a Checkbox for Broker Validation screen
	 * 
	 * @param strLinkText - Text of the Link before which the Check box is present
	 */

	public void gettableRowandClickonCheckbox() throws Exception {
		boolean flag;
		Log("GettingTable Row and Clickon Checkbox", "DONE", false);
		List<WebElement> BrokerInformationTableSize = driver
				.findElements(By.xpath("//div[@id='page:formid:pb:IsBrokerAgency']//tr"));
		if (BrokerInformationTableSize.size() != 0) {
			for (int i = 2; i <= BrokerInformationTableSize.size(); i++) {
				flag = driver
						.findElement(
								By.xpath("//div[@id='page:formid:pb:IsBrokerAgency']//tr[" + i + "]//td[1]//input"))
						.isEnabled();
				if (flag == true) {
					driver.findElement(
							By.xpath("//div[@id='page:formid:pb:IsBrokerAgency']//tr[" + i + "]//td[1]//input"))
							.click();
					Log("Click on Checkbox Enabled", "PASS", false);
				}
			}
		}
	}

	public void attachArticle(String filepath) {
		Assert.done("Begin attaching file to currently open Knowledge Case");
		try {
			WaitForPageToLoad(60);
			SwitchToFrame("Default");
			SwitchToFrame("Content");
			// driver.findElement(By.logicalName("AttachArticle.AttachButton")).click();
			ClickOnButtonByValue("Attach File");
			WaitForPageToLoad(60);
			SwitchToFrame("Default");
			SwitchToFrame("Content");
			// ClickOnButtonByTitle("Type the path of the file or click the Browse button to
			// find the file.");
			List<WebElement> inputs = driver.findElements(By.tagName("input"));
			inputs.get(6).sendKeys(filepath);
			Thread.sleep(500);
			// inputs.get(7).click();
			WaitForPageToLoad(60);
			SwitchToFrame("Default");
			SwitchToFrame("Content");
			ClickOnButtonByValue("Attach File");
			// driver.findElement(By.logicalName("AttachArticle.AttachfileButton")).click();

			Thread.sleep(5000);
			try {
				ClickOnButtonByValue(" Done ");
			} catch (StaleElementReferenceException e) {
			}

		} catch (Exception e) {
			if (e.toString() == "StaleElementReferenceException")
				;
			else
				Assert.error(e, "File attachment  Failed  ");
		}
		Assert.done("Exiting ContactCenterNavigation  attach Article To Knowledge Case");
	}

	/**
	 * Method to generate a random string
	 */

	public String getRandomString(String s, int maxlength) {

		int i = 0;
		int randomNumber;

		boolean isUpperCase;

		StringBuilder response = new StringBuilder();
		Random randomNumberGenerator = new Random();

		while (i++ < maxlength - s.length()) {
			isUpperCase = randomNumberGenerator.nextBoolean();
			randomNumber = randomNumberGenerator.nextInt(26) + 65;

			response.append(isUpperCase ? (char) randomNumber : Character.toLowerCase((char) randomNumber));
		}

		return response.insert(0, s).toString();
	}

	/**
	 * Method to navigate to Open Menu -> Click on Menu option like Home, Letters,
	 * cases, etc...
	 */
	public void mainMenu(String menuname) throws Exception {
		OpenMenu();
		SelectMenuItem(menuname);
		WaitForPageToLoad(30);
	}

	/**
	 * Method to delete the files of a certain type in a given folder
	 * 
	 * @param strpath     - The root folder path
	 * @param strfilename - The file name contains
	 * @param strfileextn - The extension of the file name
	 * @return success - Returns true or false
	 */
	public boolean deletefiles(String strpath, String strfilename, String strfileextn) throws Exception {
		boolean success = false;
		// Lists all files in folder
		File folder = new File(strpath);
		File[] fList = folder.listFiles();
		// Searchs for strfileextn and file name
		for (int i = 0; i < fList.length; i++) {
			File pes = fList[i];
			if (pes.getName().endsWith(strfileextn) && pes.getName().contains(strfilename)) {
				// and deletes
				success = (pes.delete());
			}
		}
		return success;
	}

	/**
	 * Method to check if a file  is present in a given folder
	 * 
	 * @param strpath     - The root folder path
	 * @param strfilename - The file name contains
	 * @return success - Returns true or false
	 */
	public static boolean fileexists(String strpath, String strfilename) throws Exception {
		boolean success = false;
		// Lists all files in folder
		File folder = new File(strpath);
		File[] fList = folder.listFiles();
		// Searchs extension
		for (int i = 0; i < fList.length; i++) {
		File pes = fList[i];
		if (pes.getName().contains(strfilename)) {

		success = (pes.exists());
		}
		}
		return success;
		}
	/**
	 * Method to check if a file of a certain type is present in a given folder
	 * 
	 * @param strpath     - The root folder path
	 * @param strfilename - The file name contains
	 * @param strfileextn - The extension of the file name
	 * @return success - Returns true or false
	 */
	public boolean fileexists(String strpath, String strfilename, String strfileextn) throws Exception {
		boolean success = false;
		// Lists all files in folder
		File folder = new File(strpath);
		File[] fList = folder.listFiles();
		// Searchs extension
		for (int i = 0; i < fList.length; i++) {
			File pes = fList[i];
			if (pes.getName().endsWith(strfileextn) && pes.getName().contains(strfilename)) {
				// and deletes
				success = (pes.exists());
			}
		}
		return success;
	}

	/**
	 * Method to wait for a Link by Text to be enabled
	 * 
	 * @param strLinkText - @text of the Link
	 */
	public boolean WaitForLinkByText(String strLinkText) throws Exception {
		try {
			if (driver.findElement(By.xpath("//a[contains(.,'" + strLinkText + "')]")).isEnabled()) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Method to Get check box status following a Label text in a Read only form
	 * e.g. Active
	 * 
	 * @param strLabel - Label (Table cell) after which check box is present
	 */
	public void SelectCheckboxAfterLabelinaTable(String strLabel) throws Exception {
		Log("Clicking on Checkbox - " + strLabel, "DONE", false);
		WaitForPageToLoad(30);
		WebElement element = driver.findElement(By.xpath("//td[text()='" + strLabel + "']//following::input[1]"));
		if (element.isEnabled()) {
			element.click();
			Thread.sleep(3000);
		} else {
			Log(strLabel + " Checkbox is not enabled", "FAIL", false);

		}
	}

	/**
	 * Method to click on a Button type - Input identified by @title tag
	 * 
	 * @param strButtonName - @title of the Button
	 */
	public void ClickOnButtonByText(String strButtonName) throws Exception {
		Log("Clicking on Button - " + strButtonName, "DONE", true);
		WebElement element = driver.findElement(By.xpath("//button[text()='" + strButtonName + "']"));
		try {
			element.click();
		} catch (Exception e) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		}
	}

	/**
	 * Method to wait for a Button by Text to be enabled
	 * 
	 * @param strButtonValue - @value of the Button
	 */
	public boolean WaitForButtonByText(String strButtonTitle) throws Exception {
		try {
			if (driver.findElement(By.xpath("//button[text()='" + strButtonTitle + "']")).isEnabled()) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Method to Get page List title
	 * 
	 * @param strTitleForReporting - Title to be used for logging the step in report
	 * @return strTitle - Page title identified by @class-pageDescription and HTML
	 *         tag-h2
	 */
	public String GetPagelistTitle(String strTitleForReporting) throws Exception {
		Log("Getting " + strTitleForReporting, "DONE", false);
		WaitForPageToLoad(30);
		String strActualTitle = pagelistTitle.getText();
		return strActualTitle;
	}

	/**
	 * Method to Get page List title
	 * 
	 * @param strTitleForReporting - Title to be used for logging the step in report
	 * @return strTitle - Page title identified by @class-pageDescription and HTML
	 *         tag-h2
	 */
	public void SetTextbyTitle(String strTitle, String strValue) throws Exception {
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		Log("Setting Text Into " + strTitle + " - " + strValue, "DONE", false);
		WebElement element = driver.findElement(By.xpath("//input[@title='" + strTitle + "']"));
		element.clear();
		element.sendKeys(strValue);
	}

	/**
	 * Method to send Keys
	 * 
	 * @param strTag-         Tag in which the element is present
	 * @param attribute-      Tag attribute which is being used to locate the
	 *                        Element
	 * @param attributeValue- Value of the attribute
	 * @return strTitle - Page title identified by @class-pageDescription and HTML
	 *         tag-h2
	 * 
	 */
	public void SendKeys(String strTag, String attribute, String attributeValue) throws Exception {
		WebElement element = driver
				.findElement(By.xpath("//" + strTag + "[@" + attribute + "='" + attributeValue + "']"));
		element.sendKeys(Keys.ENTER);
	}

	/**
	 * Method to select an item from the app menu (the drop down present on the
	 * right top corner when we click on setup)
	 * 
	 * @param strAppMenuItem - Item name to be selected from the options (possible
	 *                       values like BCBS Sales, Contact Center Console,...)
	 */

	public void selectAppMenuItem(String strAppMenuItem) throws Exception {
		WaitForPageToLoad(30);
		Log("Selecting App Menu Item - " + strAppMenuItem, "DONE", true);
		SwitchToFrame("Default");
		String existingMenuoption = appMenu.getText();
		if (existingMenuoption.equalsIgnoreCase(strAppMenuItem)) {
			Log("App Menu Item is already selected - " + strAppMenuItem, "DONE", true);
		} else {
			appMenu.click();
			ClickOnLinkByText(strAppMenuItem);
			WaitForPageToLoad(30);
		}
	}

	/**
	 * Method to press the escape key to avoid unwanted javascript activation added
	 * on 06/08/2018
	 */

	public void pressescapekeyonly() throws Exception {
		Actions action = new Actions(driver);
		SwitchToFrame("Default");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		int intTabCount = driver.findElements(By.xpath("//div[contains(@class,'sd_primary_container')]")).size();
		// Log("Closing " + intTabCount + " Primary Tab(s)", "DONE", false);
		for (int i = 0; i < intTabCount; i++) {
			SwitchToFrame("Default");
			action.sendKeys(Keys.ESCAPE).build().perform();
		}
	}

	/**
	 * Method to capture the notification added on 06/08/2018
	 */

	public String successnotification() throws Exception {
		String strMessage = "";
		try {
			WaitForPageToLoad(30);
			JavascriptExecutor js = (JavascriptExecutor) driver;
//			WebElement element =  driver.findElement(By.xpath("//h4"));
			js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//h4")));
			strMessage = driver.findElement(By.xpath("//h4")).getText();
			Log("Notification is present", "PASS", false);
		} catch (Exception e) {
			Log("Notification is not present", "FAIL", false);
		}
		return strMessage;

	}

	/**
	 * Method to set text in to a Input box following a Label preceded by a List &
	 * span element
	 * 
	 * @param strLabel - Label after which Input box is present
	 * @param strValue - Text value to be set in to Input box
	 */
	public void SetTextAfterLabelandList(String strLabel, String strValue) throws Exception {
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		Log("Setting Text Into " + strLabel + " - " + strValue, "DONE", false);
		WebElement element = driver
				.findElement(By.xpath("//label[text()='" + strLabel + "']//following::span[2]//input[1]"));
		element.clear();
		element.sendKeys(strValue);
	}

	/**
	 * Method to press the SHIFT + R key to refresh the current tab added on
	 * 06/08/2018
	 */

	public void pressrefreshrtab() throws Exception {
		Actions action = new Actions(driver);
		SwitchToFrame("Default");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		int intTabCount = driver.findElements(By.xpath("//div[contains(@class,'sd_primary_container')]")).size();
		// Log("Closing " + intTabCount + " Primary Tab(s)", "DONE", false);
		for (int i = 0; i < intTabCount; i++) {
			SwitchToFrame("Default");
			action.sendKeys(Keys.ESCAPE).build().perform();
			action.sendKeys(Keys.SHIFT).sendKeys("R").build().perform();
		}
	}

	/**
	 * Method to Edit a case using shortcut ESC + e
	 */
	public void Editcaseshortcut() throws Exception {
		Log("Opening SFDC Menu", "DONE", false);
		Actions action = new Actions(driver);
		action.sendKeys(Keys.ESCAPE).build().perform();
		mainPage.sendKeys("e");
		WaitForPageToLoad(120);
		SwitchToFrame("Default");
		SwitchToFrame("Content");
	}

	/**
	 * Method to get Label Eg: //span[text()='CASE SUMMARY']
	 * 
	 * @param strLabel - Name of the Label to be verified
	 */
	public void VerifyLabel(String strLabel) throws Exception {
		Log("Verifying the Label is displayed or not - " + strLabel, "DONE", true);
		try {
			WaitForPageToLoad(30);
			if (driver.findElement(By.xpath("//span[text()='" + strLabel + "']")).isDisplayed()) {
				Log("Label is displayed - " + strLabel, "PASS", true);
			} else {
				Log("Label is not displayed - " + strLabel, "FAIL", true);
			}
		} catch (Exception e) {
			Log(strLabel + " Label is not displayed", "FAIL", false);
		}
	}

	public void VerifyLabelByTableName(String strTableHeader, int intRow, int intColumn) throws Exception {
		Log("Getting Cell Header from " + strTableHeader + " Column " + intColumn, "DONE", false);
		if (driver.findElement(By.xpath(
				"//h3[text()='" + strTableHeader + "']//following::tbody//tr[" + intRow + "]//th[" + intColumn + "]"))
				.isDisplayed()) {
			String strLabel = driver.findElement(By.xpath("//h3[text()='" + strTableHeader + "']//following::tbody//tr["
					+ intRow + "]//th[" + intColumn + "]")).getText().trim();
			Log("Label is displayed - " + strLabel, "PASS", true);
		} else {
			Log("Label is not displayed ", "FAIL", true);
		}
	}

	/**
	 * Method to sort a column identified by text
	 * 
	 * @param strColumn - Column value of HTML table identified by text
	 * @author PS7PTSO added on - 07/24/2018
	 */
	public void sortQueueByText(String strColumn) throws Exception {
		Log("Sorting Queue by " + strColumn, "DONE", false);
		Thread.sleep(5000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(By.xpath("//a[.='" + strColumn + "']"));
		js.executeScript("arguments[0].click();", element);
		WaitForPageToLoad(30);

	}

	/**
	 * Verifying whether the table is present or not in a form
	 * 
	 * @param strformaction - @action contains of the form added on 07/21/2018
	 */
	public void isTableDisplayedinform(String strformaction) throws Exception {
		Log("Verifying the link is displayed or not - " + strformaction, "DONE", true);
		try {
			WaitForPageToLoad(30);
			if (driver.findElement(By.xpath("//form[contains(@action,'" + strformaction + "')]//following::table"))
					.isDisplayed()) {
				Log("Table is displayed - " + strformaction, "PASS", true);
			} else {
				Log("Table is not displayed - " + strformaction, "FAIL", true);
			}
		} catch (Exception e) {
			Log(strformaction + " Link is not displayed", "FAIL", false);
		}
	}

	/**
	 * Method to click on an Image having @title following a Div
	 * 
	 * @param strLabel - Div after which Image is present
	 * @param strTitle - Image title identified by @title
	 */
	public void ClickOnImageAfterDivByTitle(String strLabel, String strTitle) throws Exception {
		Log("Clicking on " + strTitle + " - " + strLabel, "DONE", true);
		driver.findElement(By.xpath("//div[text()='" + strLabel + "']//following::img[@title='" + strTitle + "']"))
				.click();
	}

	/**
	 * Method to Get check box status following a Label text in a Read only form
	 * e.g. Active
	 * 
	 * @param strLabel - Label (Table cell) after which check box is present
	 */
	public void SelectListItemAfterLabelinaTable(String strLabel, String strValue) throws Exception {
		Log("Clicking on Checkbox - " + strLabel, "DONE", false);
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		Log("Selecting " + strLabel + " - " + strValue, "DONE", false);
		WebElement element = driver.findElement(By.xpath("//td[text()='" + strLabel + "']//following::select[1]"));
		Select dropdown = new Select(element);
		dropdown.selectByVisibleText(strValue);
		WaitForPageToLoad(30);
	}

	/**
	 * Method to Minimize the Phone Pop-up Window
	 */
	public void MinimizePhonepop_up() throws Exception {
		try {
			if (driver
					.findElement(
							By.xpath("(//div[@class='sd_widget_header_tool right_aligned_icon minimize_icon'])[4]"))
					.isDisplayed()) {
				driver.findElement(
						By.xpath("(//div[@class='sd_widget_header_tool right_aligned_icon minimize_icon'])[4]"))
						.click();
			}

		} catch (Exception e) {

			Log("Minimize icon is not diplaying", "Pass", true);

		}
	}

	public void UserMenu() throws Exception {
		SwitchToFrame("Default");
		WaitForPageToLoad(30);
		ClickOnLinkByTitle("Setup");
		WaitForPageToLoad(30);
		try {
			if (driver.findElement(By.xpath("//a[contains(@title,'Setup')]")).isEnabled()) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				WebElement element = driver.findElement(By.xpath("//a[contains(@title,'Setup')]"));
				js.executeScript("arguments[0].click();", element);
			}
		} catch (Exception e) {
			Log("Clicking on the setup link failed or already succeeded", "DONE", false);
		}
	}

	public void captureuserinformation() throws Exception {
//		FileInputStream filename = new FileInputStream("I:\\status\\Asra Aafreen\\Test.xls");
//		FileInputStream filename = new FileInputStream("D:\\Jenkins\\automation\\builds\\SFDC\\cloned\\resources\\testdata\\UserinfoExtract.xls");
		FileInputStream filename = new FileInputStream(DSNPConfig.TDP + "\\UserinfoExtract.xls");

		HSSFWorkbook workbook = new HSSFWorkbook(filename);
		// Get Sheet At index 0 - firstsheet
		HSSFSheet sheet = workbook.getSheetAt(0);
		// Get the first row which contains Queue names
		HSSFRow firstRow = sheet.getRow(0);
		int firstColumnCount = firstRow.getPhysicalNumberOfCells();
		int rowCount = sheet.getPhysicalNumberOfRows();
		String userEmail = "";
		// Loop through all the rows with cell index 0 for getting usernames (Links)
		for (int i = 1; i < rowCount; i++) {
			HSSFRow row = sheet.getRow(i);
//			String userEmail = "";
			if (row != null) {
				if (row.getCell(0) != null) {
					userEmail = row.getCell(0).getStringCellValue();
				}
			}
			boolean useridexists = searchforuserbyusername(userEmail);
			if (!useridexists) {
				Log("Searched username does not exist - " + userEmail, "DONE", true);
				continue;
			}
			// capturing the username from the application to compare
			String appusername = GetTextFromReadOnlyFormAfterLabel("Username");
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			if (userEmail.length() > 0) {
				if (appusername.equalsIgnoreCase(userEmail)) {
					System.out.println("UserName Exist - " + userEmail);

					// clicking on the queue membership

					driver.findElement(By.xpath("//span[text()='Queue Membership']")).click();
					// Get the queue names of particular username after clicking queue membership
					List<WebElement> QueueName = driver
							.findElements(By.xpath("//div[contains(@id,'RelatedQueueMemberList_body')]//tr//td//a"));
					if (QueueName.size() > 0) {
						// Looping through all the quenames existing in the particular username in
						// webtable
						for (int k = 0; k < QueueName.size(); k++) {
							System.out.println("Queue Exist @ " + k + " : " + QueueName.get(k).getText());
							// looping through the columns of the first row in excel containing queue names
							for (int l = 0; l < firstColumnCount; l++) {
								if (firstRow.getCell(l) != null) {
									if (QueueName.get(k).getText().equals(firstRow.getCell(l).getStringCellValue())) {
										HSSFRow markRow = sheet.getRow(i);
										markRow.createCell(l).setCellValue("Y");
									}
								}
							}
						}
					}
					// end of queue membership
//					FileOutputStream fileOut = new FileOutputStream("I:\\status\\Asra Aafreen\\Test.xls");
					FileOutputStream fileOut = new FileOutputStream(DSNPConfig.TDP + "\\UserinfoExtract.xls");
					workbook.write(fileOut);

					// clicking on the public Group membership

					HSSFSheet publicgroupsheet = workbook.getSheetAt(1);
					// Get the first row which contains Queue names
					HSSFRow publicgroupfirstRow = publicgroupsheet.getRow(0);
					int publicgroupfirstColumnCount = publicgroupfirstRow.getPhysicalNumberOfCells();
//						int rowCount = publicgroupsheet.getPhysicalFileOutputStream fileOut = new FileOutputStreamNumberOfRows();
					driver.findElement(By.xpath("//span[text()='Public Group Membership']")).click();
					// Get the queue names of particular username after clicking queue membership
					List<WebElement> PublicGroup = driver.findElements(
							By.xpath("//div[contains(@id,'RelatedPublicGroupMemberList_body')]//tr//td//a"));
					// Looping through all the PublicGroups existing in the particular username in
					// webtable
					if (PublicGroup.size() > 0) {
						for (int k = 0; k < PublicGroup.size(); k++) {
							System.out.println("PublicGroup Exist @ " + k + " : " + PublicGroup.get(k).getText());
							// looping through the columns of the first row in excel containing queue names
							for (int l = 0; l < publicgroupfirstColumnCount; l++) {
								if (publicgroupfirstRow.getCell(l) != null) {
									if (PublicGroup.get(k).getText()
											.equals(publicgroupfirstRow.getCell(l).getStringCellValue())) {
										HSSFRow markRow = publicgroupsheet.getRow(i);
										markRow.createCell(l).setCellValue("Y");
									}
								}

							}
						}
					}
//					FileOutputStream fileOut1 = new FileOutputStream("I:\\status\\Asra Aafreen\\Test.xls");
					FileOutputStream fileOut1 = new FileOutputStream(DSNPConfig.TDP + "\\UserinfoExtract.xls");
					workbook.write(fileOut1);
					fileOut1.close();
					// end of public groups

					// Clicking on the permission sets

					// selecting the sheet with index 2 - permission sets
					HSSFSheet permissionsetssheet = workbook.getSheetAt(2);
					// Get the first row which contains permission set names
					HSSFRow permissionsetsfirstRow = permissionsetssheet.getRow(0);
					int permissionsetsfirstColumnCount = permissionsetsfirstRow.getPhysicalNumberOfCells();

					driver.findElement(By.xpath("//span[text()='Permission Set Assignments']")).click();
					// Get the Permissions of particular username after clicking queue membership
					List<WebElement> Permission = driver.findElements(
							By.xpath("//div[contains(@id,'RelatedPermsetAssignmentList_body')]//tr//th//a"));
					// Looping through all the Permissions existing in the particular username in
					// webtable
					if (Permission.size() > 0) {
						for (int k = 0; k < Permission.size(); k++) {
							System.out.println("Permission Exist @ " + k + " : " + Permission.get(k).getText());
							// looping through the columns of the first row in excel containing queue names
							for (int l = 0; l < permissionsetsfirstColumnCount; l++) {
								if (permissionsetsfirstRow.getCell(l) != null) {
									if (Permission.get(k).getText()
											.equals(permissionsetsfirstRow.getCell(l).getStringCellValue())) {
										HSSFRow markRow = permissionsetssheet.getRow(i);
										markRow.createCell(l).setCellValue("Y");
									}
								}
							}
						}
					}
//					FileOutputStream fileOut2 = new FileOutputStream("I:\\status\\Asra Aafreen\\Test.xls");
					FileOutputStream fileOut2 = new FileOutputStream(DSNPConfig.TDP + "\\UserinfoExtract.xls");
					workbook.write(fileOut2);
					fileOut2.close();
					// end of permission sets
				}
				// end of one user
			}
		}
		// end of all the users

		System.out.println("Your excel file has been marked as Y!");
	}

	/**
	 * Method to capture the message text and retrun the same.
	 * 
	 * @return messagetext - message captured in the screen and returned
	 */
	public String readmessagetxt() throws Exception {
		String messagetext = "";
		try {
			if (driver.findElement(By.xpath("//div[@class='messageText']")).isDisplayed()) {
				messagetext = driver.findElement(By.xpath("//div[@class='messageText']")).getText();
			}

		} catch (Exception e) {

			Log("Message Text is not diplaying", "Done", true);

		}
		return messagetext;
	}

	/**
	 * Method to Select a List Item preceding a Button
	 * 
	 * @param strbtnname - Value of the button before which Select box is present
	 * @param strValue   - Text value of the option to be selected
	 */
	public void SelectListItemBeforeButton(String strbtnname, String strValue) throws Exception {
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		Log("Selecting - " + strValue, "DONE", false);

		for (int i = 0; i < 2; i++) {
			try {
				WebElement element = driver
						.findElement(By.xpath("//input[@value='" + strbtnname + "']//preceding::select[1]"));
				Select dropdown = new Select(element);
				dropdown.selectByVisibleText(strValue);
				break;
			} catch (StaleElementReferenceException e) {
				Log("Caught stale element! Will try two more times at max.", "DONE", false);
				continue;
			}
		}
	}

	public boolean searchforuserbyusername(String userEmail) throws Exception {
		try {
			if (userEmail.length() > 0) {
				searchtopInput.clear();
				searchtopInput.sendKeys(userEmail.trim());
				Log("Searched for the username - " + userEmail, "DONE", true);
				WaitForPageToLoad(10);
				ClickOnButtonByValue("Search");
				WaitForPageToLoad(10);
				// clicking on the name
				driver.findElement(By.xpath("//div[@class='peopleInfoContent']//a[1]")).click();
				WaitForPageToLoad(10);
				// clicking on the dropdown
				driver.findElement(By.xpath("//a[@title='User Action Menu']//b[@class='zen-selectArrow']")).click();
				ClickOnLinkByText("User Detail");
				WaitForPageToLoad(10);
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Method to select Menutab
	 * 
	 * @param strMenutab - Menu tab
	 */
	public void SelectMenuTab(String strMenutab) throws Exception {
		WaitForPageToLoad(30);
		Log("Selecting Menu Tab - " + strMenutab, "DONE", true);
		ClickOnLinkByText(strMenutab);
		WaitForPageToLoad(30);
	}

	/**
	 * Method to click on a Drop down Button type - Input identified by text value
	 * 
	 * @param strButtonName - text of the Button
	 */
	public void ClickOndropdownButtonByText(String strButtonName) throws Exception {
		Log("Clicking on Button - " + strButtonName, "DONE", true);
		WebElement element = driver.findElement(By.xpath("//span[text()='" + strButtonName + "']"));
		try {
			element.click();
		} catch (Exception e) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		}
	}

	public void EscapeForCalendar() throws Exception {

		Actions action = new Actions(driver);
		action.sendKeys(Keys.ESCAPE).build().perform();
		WaitForPageToLoad(5);
//		WebDriverWait wait = new WebDriverWait(driver, 20);
//		System.out.println("Waiting for the calendar to disappear");
////		WebElement element=driver.findElement(By.cssSelector("calDays"));
//		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("table[@class='calDays']")));
//		
//		wait.until(ExpectedConditions.invisibilityOfElementLocated(element));
	}

	public void clickOnSearchClaimButton(String strButtonName) throws Exception {
		SwitchToFrame("searchClaims");
		Log("Clicking on Button - " + strButtonName, "DONE", true);
		WebElement element = driver.findElement(By.xpath("(//input[@title='Search Claims'])[1]"));
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		} catch (StaleElementReferenceException e) {
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		} catch (Exception e) {

		}

	}
}
