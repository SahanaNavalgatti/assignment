package org.bcbsri.dsnp.framework;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dell.acoe.framework.selenium.By;
import com.dell.acoe.framework.selenium.FrameworkDriver;
import com.dell.acoe.framework.selenium.verify.Assert;


public class ElemIDUtil {
	public static WebDriver driver = FrameworkDriver.driver;

	public static void boxFrames(){
		try{
			driver.switchTo().defaultContent();
			List<org.openqa.selenium.WebElement> iframes = driver.findElements(By.tagName("iframe"));
			int x = 0;
			for(org.openqa.selenium.WebElement i : iframes){
				System.out.println(x);
				((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", i);
				Thread.sleep(5000);
				x++;
			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public static void boxElement(WebElement elem){
		try{
			((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public static void waitForDomToLoad(WebDriver driver , int sec) {
		Boolean state=new WebDriverWait(driver,120).until((ExpectedCondition<Boolean>) wd ->
		((JavascriptExecutor) wd).executeScript("return document.readyState").toString().equals("complete"));
		System.out.println("DOM state----------->"+state);        
	}
	public static void domElementClick(WebElement element)
	{
		try 
		{
			if (element.isEnabled() && element.isDisplayed())
			{
				//System.out.println("Clicking on element with using java script click");
				Assert.done("Clicking on element with using java script click");
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
			} 
			else 
			{
				System.out.println("Unable to click on element");
				Assert.done("Unable to click on element");
			}
		}
		catch (StaleElementReferenceException e)
		{
			System.out.println("Element is not attached to the page document "+ e.getStackTrace());
		} 
		catch (NoSuchElementException e) 
		{
			System.out.println("Element was not found in DOM "+ e.getStackTrace());
		}
		catch (Exception e) 
		{
			System.out.println("Unable to click on element "+ e.getStackTrace());
		}
		//return element;
	}

	public static void driver_MoveToElement(WebElement weElement) throws Exception 
	{
		//JavascriptExecutor js =(JavascriptExecutor)driver;
		//          js.executeScript("window.scrollTo(0,"+ weElement.getLocation().y +")");
		//          js.executeScript("window.scrollTo(0,"+ weElement.getLocation().x +")");
		Thread.sleep(5000);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", weElement);

		//js.executeScript("document.getElementById('" + weElement +"').focus();");
	}
	static String sParentWindow;
	public static void switchwindow() {
		try
		{
			Thread.sleep(5000);
			sParentWindow = driver.getWindowHandle();
			Thread.sleep(2000);
			ArrayList<String> newBrowser = new ArrayList<String>(driver.getWindowHandles());
			System.out.println("Window size ->"+newBrowser.size());
			// change focus to new browser
			if(newBrowser.size()>1)
			{
				driver.switchTo().window(newBrowser.get(1));
				System.out.println("switched to new window");
				Assert.done("Switch to new  Window!!");
				driver.manage().window().maximize();
				Thread.sleep(5000);

			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}



	public static void closeChildWindow() {
		try
		{

			sParentWindow = driver.getWindowHandle();
			ArrayList<String> sAvailableWindows = new ArrayList<String>(driver.getWindowHandles());
			System.out.println("Windows count---->"+sAvailableWindows.size());
			if(sAvailableWindows.size() > 1)
			{
				for(int i=1;i<sAvailableWindows.size();i++)
				{
					driver.switchTo().window(sAvailableWindows.get(i));
					System.out.println("Child window");
					driver.close();

				}

				driver.switchTo().window(sAvailableWindows.get(0));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.err.println("Chlild window is not closed");
		}


	}

	public static int countdaysfromStartEndDatesSLA(String StartDate ,String EndDate) throws ParseException{
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy hh:mm a", Locale.US);
		Date date1 = format.parse(StartDate);
		Date date2 = format.parse(EndDate);
		format = new SimpleDateFormat("MMddyyyy");
		String dateBeforeString = format.format(date1);
		String dateAfterString = format.format(date2);
		System.out.println("Changed 1 to  :" +dateBeforeString);
		System.out.println("Changed 2 to  :" +dateAfterString);
		Date dateBeforet = format.parse(dateBeforeString);
		Date dateAfteret1 = format.parse(dateAfterString);
		long difference = dateAfteret1.getTime() - dateBeforet.getTime();
		int daysBetween = (int) (difference / (1000*60*60*24));
		//System.out.println("Number of Days between dates: "+strExpectedSLA);
		//String strExpectedSLA = String.valueOf(daysBetween) + "d remaining";
		return daysBetween;

	}

}
