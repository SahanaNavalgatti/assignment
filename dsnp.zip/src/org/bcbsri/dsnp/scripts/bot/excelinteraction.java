package org.bcbsri.dsnp.scripts.bot;

import com.dell.acoe.framework.selenium.testdata.DataTable;

public class excelinteraction {
	public static void exceloperations() throws InterruptedException{
		DataTable dsnpday1bot = new DataTable("C:\\Users\\l14ptso\\OneDrive - Blue Cross and Blue Shield of Rhode Island\\GIT\\SFDCAutomation\\resources\\testdata\\prod\\DSNP.xlsx", "Day1", "D11092021");
		String strtrackingfromday1 = dsnpday1bot.getValue("270TrackingID");
		System.out.println("Look up of Tracking ID - for  D11092021 "+strtrackingfromday1);
		
		DataTable dsnpday2bot = new DataTable("C:\\Users\\l14ptso\\OneDrive - Blue Cross and Blue Shield of Rhode Island\\GIT\\SFDCAutomation\\resources\\testdata\\prod\\DSNP.xlsx", "Day1", "D11152021");
		dsnpday2bot.setValue("270TrackingID", 1,"APPLE");
		
		DataTable dsnpday2bot2 = new DataTable("C:\\Users\\l14ptso\\OneDrive - Blue Cross and Blue Shield of Rhode Island\\GIT\\SFDCAutomation\\resources\\testdata\\prod\\DSNP.xlsx", "Day1", "D11152021");
		String strtrackingday2 = dsnpday2bot2.getValue("270TrackingID");
		System.out.println("Look up of Tracking ID - for  D11152021 after reloading datatable"+strtrackingday2);
		
		
		String strtrackingday2old = dsnpday2bot.getValue("270TrackingID");
		System.out.println("Look up of Tracking ID - for  D11152021 without reloading datatable "+strtrackingday2old);
	
	}
}
