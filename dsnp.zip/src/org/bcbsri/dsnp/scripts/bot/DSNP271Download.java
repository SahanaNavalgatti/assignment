/*********************************************************************/
//Test Case Name- 	Day1_270_upload_999_download_271_download_daily_weekly
//Test Case Desc-	DSNP 270 file upload and 999 download and 271 download for both daily and weekly files
//Test Suit Name-	DSNP Eligibility BOT
//Business Area -	DSNP Eligibility
/*********************************************************************/

package org.bcbsri.dsnp.scripts.bot;

import java.io.File;


import org.bcbsri.dsnp.framework.RIProviderportal;
import org.bcbsri.dsnp.reusables.init.BrowserSetup;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.selenium.FrameworkDriver;
import com.dell.acoe.framework.selenium.testdata.DataTable;
import com.dell.acoe.framework.selenium.verify.Assert;



public class DSNP271Download {
	private static WebDriver driver = null;
	static String host1_exit = Environment.get("snow.host1_exit");
	static String host2_exit =Environment.get("snow.host2_exit");
	static String oid_exit = Environment.get("snow.oid_exit");
    static String community_exit = Environment.get("snow.group_exit");
    static String msgEXIT_exit =Environment.get("snow.EXITmsg_exit");
    static String severity_exit =Environment.get("snow.severity_exit");
	
    

	public static void dsnpday1bot() throws Exception {
		// Initialize all Page Objects
		BrowserSetup.loadChromeBrowser();
		driver = FrameworkDriver.driver;
		RIProviderportal riProviderportal = PageFactory.initElements(driver, RIProviderportal.class);
		String currentDate = riProviderportal.GetSimpleCurrentDate();
		String strTestDataDir = riProviderportal.GetExecutionEnvironment("Environment");
		/*
		 * DataTable dsnpdailybot = new DataTable(strTestDataDir + "DSNP.xlsx", "Daily",
		 * "D" + currentDate); DataTable dsnpweeklybot = new DataTable(strTestDataDir +
		 * "DSNP.xlsx", "Weekly", "D" + currentDate);
		 */
		//String ODSuploadpath = Environment.get("RIproviderportal.fileuploadpathODS");

	
		/*
		 * String str271dailydownloadfilepath = ODSuploadpath +
		 * "Daily\\Inbound\\271_Daily_";
		 * 
		 * String str271weeklydownloadfilepath = ODSuploadpath +
		 * "Daily\\Inbound\\271_Weekly_" + currentDate; String strtrackingID = "";
		 */
		
		/*
		 * boolean file271dailydownloadflag = false; boolean file271weeklydownloadflag =
		 * false;
		 */ 
		boolean executeflag = true;
		 
	// Checking whether there are any 271 file(s) to be download as a part of the Daily schedule
		
		try {
			
			  if (executeflag) { 
				  
				  // Launching the URL
				  riProviderportal.Launch("url");
				  //  Login to RIProviderportal 
				  riProviderportal.Login(); 
				  // Verifying whether the Home page is displayed 
				  riProviderportal.IsHomePageDisplayed();
				  
				  RIProviderportal. Log("271 - Starting 271 Download(s)" ,"DONE", true);
				  riProviderportal.file271download();
				  
				  }
				  
				  
				  
				  // Downloading the 271 daily files if (file271dailydownloadflag) {
				   
				  
				  
			
			
			/*
			 * for (int i = 0; i < 8; i++) { String requiredDateprecheck =
			 * riProviderportal.GetCurrentDateAndAddDays(-i); DataTable dsnpdailybotprecheck
			 * = new DataTable(strTestDataDir + "DSNP.xlsx", "Daily", "D" +
			 * requiredDateprecheck); String downloadeddate271dailyprecheck =
			 * dsnpdailybotprecheck.getValue("271DownloadedDate"); String
			 * trackingID271dailyprecheck = dsnpdailybotprecheck.getValue("270TrackingID");
			 * if (downloadeddate271dailyprecheck.equals("")) { if
			 * (trackingID271dailyprecheck.equals("")) { } else { file271dailydownloadflag =
			 * true; } } }
			 * 
			 * // Checking whether there are any 271 file(s) to be download as a part of the
			 * Weekly schedule for (int i = 0; i < 8; i++) { String requiredDateprecheck =
			 * riProviderportal.GetCurrentDateAndAddDays(-i); DataTable
			 * dsnpweeklybotprecheck = new DataTable(strTestDataDir + "DSNP.xlsx", "Weekly",
			 * "D" + requiredDateprecheck); String downloadeddate271weeklyprecheck =
			 * dsnpweeklybotprecheck.getValue("271DownloadedDate"); String
			 * trackingID271weeklyprecheck =
			 * dsnpweeklybotprecheck.getValue("270TrackingID"); if
			 * (downloadeddate271weeklyprecheck.equals("")) { if
			 * (trackingID271weeklyprecheck.equals("")) { } else { file271weeklydownloadflag
			 * = true; } } }
			 * 
			 * if (( file271dailydownloadflag == true|| file271weeklydownloadflag == true))
			 * { executeflag = true;
			 * riProviderportal.Log("There is some activity to be done by the BOT","DONE",
			 * true); } else {
			 * riProviderportal.Log("There is NO activity to be done by the BOT","DONE",
			 * true); }
			 * 
			 * if (executeflag) { // Launching the URL riProviderportal.Launch("url"); //
			 * Login to RIProviderportal riProviderportal.Login(); // Verifying whether the
			 * Home page is displayed riProviderportal.IsHomePageDisplayed(); }
			 * 
			 * 
			 * 
			 * // Downloading the 271 daily files if (file271dailydownloadflag) {
			 * riProviderportal.
			 * Log("271 - Daily file download - There is activity related to this task to be done by the BOT"
			 * ,"DONE", true); riProviderportal.file271download("Daily"); } else {
			 * riProviderportal.
			 * Log("271 - Daily file download - There is NO activity related to this task to be done by the BOT"
			 * ,"DONE", true); }
			 * 
			 * // Downloading the 271 weekly files if (file271weeklydownloadflag) {
			 * riProviderportal.
			 * Log("271 - Weekly file download - There is activity related to this task to be done by the BOT"
			 * ,"DONE", true); riProviderportal.file271download("Weekly"); } else {
			 * riProviderportal.
			 * Log("271 - Weekly file download - There is NO activity related to this task to be done by the BOT"
			 * ,"DONE", true); }
			 * 
			 * // Checking whether there are any daily tracking ID for which the 271 is not
			 * available post 7 days of wait time. ////
			 * riProviderportal.find271defaulters("Daily");
			 * 
			 * // Checking whether there are any weekly tracking ID for which the 271 is not
			 * available post 7 days of wait time.
			 * riProviderportal.find271defaulters("Weekly");
			 * 
			 * 
			 * 
			 * 
			 * riProviderportal.Log("Completed DSNP BOT activities", "DONE", true);
			 */
		} 
	       catch (Exception e) {
	    	   RIProviderportal.snowtrigger(community_exit,host1_exit,oid_exit,severity_exit,msgEXIT_exit);
	    	   //RIProviderportal.snowtrigger(community_exit,host2_exit,oid_exit,severity_exit,msgEXIT_exit);
	    	   RIProviderportal.Log ("Incident Requested","DONE",true);
	    	   
			Assert.error(e, "There is an exception while performing the DSNP BOT tasks");
			
		
		}
	}

}