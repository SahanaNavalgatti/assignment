/*********************************************************************/
//Test Case Name- 	DSNP270upload999download_daily_weekly
//Test Case Desc-	DSNP 270 file upload and 999 download for both daily and weekly files
//Test Suit Name-	DSNP Eligibility BOT
//Business Area -	DSNP Eligibility
/*********************************************************************/

package org.bcbsri.dsnp.scripts.bot;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.bcbsri.dsnp.framework.RIProviderportal;
import org.bcbsri.dsnp.reusables.init.BrowserSetup;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.selenium.FrameworkDriver;
import com.dell.acoe.framework.selenium.testdata.DataTable;
import com.dell.acoe.framework.selenium.testdata.ExcelMethods;
import com.dell.acoe.framework.selenium.verify.Assert;

public class DSNP270upload999download {
	private static WebDriver driver = null;
	public static boolean zero270file;
    public static ArrayList<String> trackingids;
    public static String ODSuploadpath = Environment.get("RIproviderportal.fileuploadpathODS");
	public static void dsnpday1bot() throws Exception {
		// Initialize all Page Objects
		BrowserSetup.loadChromeBrowser();
		driver = FrameworkDriver.driver;
		RIProviderportal riProviderportal = PageFactory.initElements(driver, RIProviderportal.class);
		String currentDate = riProviderportal.GetSimpleCurrentDate();
		//String strTestDataDir = riProviderportal.GetExecutionEnvironment("Environment");
		//String fpath = strTestDataDir + "DSNP.xlsx";
	   

		String host1_270 = Environment.get("snow.host1_270");
		String host2_270 =Environment.get("snow.host2_270");
		String oid_270 = Environment.get("snow.oid_270");
		String msg270_270 = String.format(Environment.get("snow.270msg_270"), currentDate);
        String community_270 = Environment.get("snow.group_270");
        String severity_270 =Environment.get("snow.severity_270");
		
        
        String host1_exit = Environment.get("snow.host1_exit");
		String host2_exit =Environment.get("snow.host2_exit");
		String oid_exit = Environment.get("snow.oid_exit");
        String community_exit = Environment.get("snow.group_exit");
        String msgEXIT_exit =Environment.get("snow.EXITmsg_exit");
        String severity_exit =Environment.get("snow.severity_exit");
		
	
		
		
	//	String strtrackingID = "";
	    
		boolean executeflag = false;
		 zero270file = false;
		trackingids = new ArrayList<String>();
    
		// Start the Test

		// Initialize test status

		// Start of the Test
     
     
		try {
			//Zero file check and Checking whether there is a 270_Dailly_MMDDYYYY for current date is present or not
			ArrayList<String> outboundfiles = RIProviderportal.Filecheck();
			RIProviderportal.Log("The boolean value is "+zero270file,"DONE",true);
			if (outboundfiles.isEmpty() & !zero270file)
			//if (outboundfiles.isEmpty())
			
			
			{
					RIProviderportal.snowtrigger(community_270,host1_270, oid_270, severity_270,msg270_270);
					//RIProviderportal.snowtrigger(community_270,host2_270, oid_270,severity_270 ,msg270_270);
					RIProviderportal.Log("No 270 File Found -Incident Requested","DONE",true);
					RIProviderportal.Log("There is NO activity to be done by the BOT","DONE", true);
			}
					
			else if(!outboundfiles.isEmpty())
			{
				
				executeflag = true;
				RIProviderportal.Log("There are 270 File(s)to be uploaded by the BOT","DONE", true);
			}
			
			
			
			

			 if (executeflag) {
				// Launching the URL
				riProviderportal.Launch("url");
				// Login to RIProviderportal
				riProviderportal.Login();
				// Verifying whether the Home page is displayed
				riProviderportal.IsHomePageDisplayed();
		

		     	// Uploading the 270 file(s)
				int dailyfileid = 0;
				int weeklyfileid =0;
				for (String file270 : outboundfiles)
				{
					if(file270.contains("Daily")) {
					dailyfileid+=1;}
					if(file270.contains("Weekly")) {
					weeklyfileid+=1;}
					
					RIProviderportal.Log("Uploading File"+ file270, "DONE", true);
					
				    riProviderportal.file270upload(file270 ,dailyfileid, weeklyfileid);
				}
				
				// Downloading 999 file(s)
				/*for (String file999 : trackingids)
				{
			
				       
			
				}*/
			}
		}
	
			
		 catch (Exception e) {
			 RIProviderportal.snowtrigger(community_exit,host1_exit,oid_exit,severity_exit,msgEXIT_exit);
			 //RIProviderportal.snowtrigger(community_exit,host2_exit,oid_exit,severity_exit,msgEXIT_exit);
			 RIProviderportal.Log("Incident Requested","DONE",true);
			Assert.error(e, "There is an exception while performing the DSNP BOT tasks");
		}
		}
	
}
	