package org.bcbsri.dsnp.testsuits;

import com.dell.acoe.framework.run.TestRunner;

public class DSNPBOT270upload999download {

	public static void main(String[] args) {
		System.out.println("Starting Test Runner!!");
		TestRunner.runTests("C:\\Users\\A152TSO\\OneDrive - Blue Cross and Blue Shield of Rhode Island\\Documents\\dsnp\\resources\\config\\DSNPBOT270upload999download_ref.xls");
	}

}
