# esbservices

This repository will host all the test scripts related to ESB services (Both SOAP & REST).