package org.bcbsri.sfdc.reusables.config;

import com.dell.acoe.framework.config.Environment;

public class SFDCConfig {

	//public static String DRIVER_PATH_IE = "I:\\status\\BCBSRITransformationQA\\Softwares\\java\\jars\\selenium\\drivers\\IEDriverServer_Win32.exe";
	public static String DRIVER_PATH_IE = "";
	public static String DRIVER_PATH_CHROME = "";
	public static String SFDC_WEB_URL = "";
	public static int BROWSER_STATUS = 0;
	public static String BASE_DIR = "";
	public static String TDP = "";
	
	// Sprint1 Test Data Files
	public static String TDF_S1 = "SFDC-Automation-TestData.xlsx";
	public static String TDS_S1_FindCustomer = "FindCustomer";
	public static String TDS_S1_ClaimsSearch = "ClaimsSearch";
	public static String TDS_S1_LoginAgent = "LoginAgent";
	public static String TDS_S1_NewCase = "NewCase";
	public static String TDS_S1_NewGAUCase = "NewGAUCase";
	public static String TDS_S1_CaseClose = "CaseClose";
	public static String TDS_S1_MemberProfile = "MemberProfile";
	public static String TDS_S1_Reports = "Reports";
	public static String TDS_S1_Task = "Task";
	public static String TDS_S1_Dashboard="Dashboard";
	
	
	//Sprint 2 Test Data Sheets
	public static String TDS_S1_Account = "Account";
	public static String TDS_S1_EditCase = "EditCase";
	public static String TDS_S1_Contact="Contact";
	public static String TDS_S1_Address ="Address";
	public static String TDS_S1_Letters="Letters";
	public static String TDS_S1_Article="Article";
	public static String TDS_S1_SearchAuthorisation = "SearchAuthorisation";
	
	//Contact Center Test Data files
	public static String TDF_CC1 = "SFDC-ContactCenter1.xlsx";
	public static String TDF_CC2 = "SFDC-ContactCenter2.xlsx";
	public static String TDF_CC2_TestArticle = "TestArticle.txt";
	public static String TDS_CC1_SearchMember = "SearchMember";
	public static String TDS_CC1_CaseCreation = "CaseCreation";
	public static String TDS_CC2_CaseCreation = "CaseCreation";
	public static String TDS_CC2_CaseClose = "CaseClose";
	public static String TDS_CC2_NewCase = "NewCase";
	public static String TDS_CC2_Letter = "Letter";
	public static String TDS_CC2_ProviderSearch = "ProviderSearch";
	public static String TDS_CC2_PCPSwitch = "PCPSwitch";
	public static String TDS_CC2_SearchMember = "SearchMember";
	
	//GAU Test Data files
	public static String TDF_GAU = "SFDC-GAU.xlsx";
	public static String TDS_GAU_GAUTC1 = "GAUTC1";

	//QPI Test Data files
	public static String TDF_QPI1 = "SFDC-QPI1.xlsx";
	public static String TDF_QPI_Article = "TestArticle.txt";
	public static String TDS_QPI1_QPICase = "QPICase";
	public static String TDS_QPI1_CaseClose = "CaseClose";
	public static String TDS_QPI1_Letter = "Letter";

	//Back office Test Data files
	
	public static String TDF_BO = "SFDC-BO-Shariq.xlsx";
	public static String TDS_BO_NewCase = "NewCase";
	public static String TDS_BO_CaseClose = "CaseClose";
	public static String TDS_BO_MemberSearch = "MemberSearch";
	
			
	
	public static void init(){
		SFDCConfig.DRIVER_PATH_IE = Environment.get("DRIVER_PATH_IE");
		SFDCConfig.DRIVER_PATH_CHROME = Environment.get("DRIVER_PATH_CHROME");
		SFDCConfig.SFDC_WEB_URL = Environment.get("SFDC_WEB_URL");
		SFDCConfig.BASE_DIR = Environment.get("BASE_DIR");
		SFDCConfig.TDP =  Environment.get("BASE_DIR")+"/testdata/";
	}
}
