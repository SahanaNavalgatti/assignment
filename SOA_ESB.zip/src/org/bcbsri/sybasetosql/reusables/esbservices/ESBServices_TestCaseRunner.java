package org.bcbsri.sybasetosql.reusables.esbservices;

import java.io.File;

import org.bcbsri.sybasetosql.cmd_prompt.Testrunner;
import org.bcbsri.sybasetosql.reusables.config.ESBConfig;

import com.dell.acoe.framework.selenium.verify.Assert;
import com.eviware.soapui.impl.wsdl.WsdlProject;
import com.eviware.soapui.model.testsuite.TestCase;
import com.eviware.soapui.model.testsuite.TestStep;
import com.eviware.soapui.model.testsuite.TestSuite;

public class ESBServices_TestCaseRunner {
	public static void runESBWSDL(String projectname,String endpoint, String filePath, String foldername)
	{
			WsdlProject project = null;
			ESBConfig.init();
			File directory = new File(filePath+foldername);
			if(!directory.exists()) {
				directory.mkdir();
			}
			Assert.done("Start->Web Service Testing ");	
			try {
			project = new WsdlProject(ESBConfig.TDP+""+projectname+""+".xml");
	        for (TestSuite testSuite : project.getTestSuiteList()) {
	    	Assert.done("TestSuiteProject size......" + project.getTestSuiteList().size()); 
	    	Assert.done("TestSuiteProject......" + testSuite.getName()); 
			for (TestCase testCase : testSuite.getTestCaseList()) { 
				Assert.done("TestCases........." + testCase.getName()); 
				
					Testrunner.launchRunner(""+foldername+"",""+endpoint+"",""+projectname+"","SIT","SIT");
					for (TestStep teststep : testCase.getTestStepList()) { 
						Assert.done("TestStep........." + teststep.getName());
					}
					String files_path = ""+filePath+""+""+foldername+"";
					System.out.println("files_path ::"+files_path);
					File folder = new File(files_path);
					ValidateContent.readContent(folder);
			}
	        }
	        
		} catch (Exception e) {
			e.printStackTrace();
		}
			
	}
	
}
