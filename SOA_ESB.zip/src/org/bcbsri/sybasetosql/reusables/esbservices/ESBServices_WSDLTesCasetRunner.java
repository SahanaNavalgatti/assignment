package org.bcbsri.sybasetosql.reusables.esbservices;

import java.io.FileWriter;
import java.io.IOException;

import org.apache.xmlbeans.XmlException;
import org.bcbsri.sybasetosql.reusables.config.ESBConfig;





import com.dell.acoe.framework.selenium.verify.Assert;
import com.eviware.soapui.impl.wsdl.WsdlProject;
import com.eviware.soapui.impl.wsdl.support.MessageExchangeModelItem;
import com.eviware.soapui.impl.wsdl.support.MessageExchangeResponseMessageEditor;
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCase;
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner;
import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestRequestStepResult;
import com.eviware.soapui.model.iface.MessageExchange;
import com.eviware.soapui.model.testsuite.MessageExchangeTestStepResult;
import com.eviware.soapui.model.testsuite.TestCase;
import com.eviware.soapui.model.testsuite.TestRunner.Status;
import com.eviware.soapui.model.testsuite.TestStep;
import com.eviware.soapui.model.testsuite.TestStepResult;
import com.eviware.soapui.model.testsuite.TestStepResult.TestStepStatus;
import com.eviware.soapui.model.testsuite.TestSuite;
import com.eviware.soapui.support.SoapUIException;
import com.eviware.soapui.support.types.StringToObjectMap;


public class ESBServices_WSDLTesCasetRunner {

	public static void runUpdatedESBWSDL(String testxml,String service) throws Exception {
		WsdlProject project = null;
        StringBuffer strMessage = new StringBuffer();
        try {
			ESBConfig.init();
			Assert.done("Start->Web Service Testing ");
            project = new WsdlProject(ESBConfig.TDP+testxml+".xml");
            for (TestSuite testSuite : project.getTestSuiteList()) {
        	Assert.done("TestSuiteProject size......" + project.getTestSuiteList().size()); 
        	Assert.done("TestSuiteProject......" + testSuite.getName()); 
			for (TestCase testCase : testSuite.getTestCaseList()) { 
				Assert.done("TestCases........." + testCase.getName()); 
				for (TestStep teststep : testCase.getTestStepList()) { 
					Assert.done("TestStep........." + teststep.getName());
					WsdlTestCaseRunner runner = new WsdlTestCaseRunner((WsdlTestCase) testCase, new StringToObjectMap());
					TestStepResult stepResult = runner.runTestStep(teststep);
					//TestStepResult stepResult = runner.runTestStep(teststep);
                    String EStatus=stepResult.getStatus().toString();
                    System.out.println(testCase.getName()+":"+EStatus);
                    if(EStatus.equals("OK"))
					//TestStepStatus EStatus=TestStepStatus.OK;
					//System.out.println(testCase.getName()+":"+EStatus);
					//if(EStatus.toString().equals("OK"))
						  {
							  Assert.pass("Test Case :"+testCase.getName()+": Pass");
						  }
						  else
						  {
							  Assert.fail("Test Case :"+testCase.getName()+": Fail"); 
						  }
            String[] messages = stepResult.getMessages();
            for (int i = 0; i < messages.length; i++) {
                strMessage.append("Message[" + i + "]" + messages[i]);
            }
            System.out.println(" stepResult " + stepResult.getStatus() + " Message :"
                    + strMessage.toString() + " Error :" + stepResult.getError());
            WsdlTestRequestStepResult eventWSDL = (WsdlTestRequestStepResult) stepResult;
            System.out.println("eventWSDL 1= " + eventWSDL.getResponseContent());
            FileWriter filewrite = new FileWriter("I:\\status\\TestingAutomation\\ProjectTestAutomation\\Pravisha\\SybaseToSQL_OutputFiles\\"+service+"\\"+teststep.getName()+".txt");
            filewrite.write(eventWSDL.getResponseContent());
            filewrite.close();
            }
            }
            }
          
        } catch (XmlException e) {
            System.out.println("Exception thrown :" + e);
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("Exception thrown :" + e);
        } catch (SoapUIException e) {
            System.out.println("Exception thrown :" + e);
        }

	}
}