package org.bcbsri.sybasetosql.reusables.config;

import com.dell.acoe.framework.config.Environment;

public class ESBConfig {
	
	//public static int BROWSER_STATUS = 0;
	public static String BASE_DIR = "";
	
	public static String TDP = "";
	public static String TDR="";

	
	/*public static void init(){
		
		ESBConfig.BASE_DIR = Environment.get("BASE_DIR");
		ESBConfig.TDP =  Environment.get("BASE_DIR")+"/testdata/";
		ESBConfig.TDR=Environment.get("BASE_DIR")+"/reports/";
		}
	*/
	public static void init(){
		
		ESBConfig.BASE_DIR = Environment.get("BASE_DIR");
		ESBConfig.TDP =  Environment.get("XML_test_data_path");
		ESBConfig.TDR=Environment.get("BASE_DIR")+"/reports/";
		}

}
