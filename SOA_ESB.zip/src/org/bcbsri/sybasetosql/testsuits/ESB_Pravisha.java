package org.bcbsri.sybasetosql.testsuits;

import com.dell.acoe.framework.run.TestRunner;

public class ESB_Pravisha {

	public static void main(String[] args) 
	{
		System.out.println("Starting Test Runner!!");

        String path = System.getProperty("user.dir");   

        String Fullpath = path+"\\resources\\config\\SybaseToSQL_Environment_Sheet_Jenkins_Minor.xls";

        System.out.println("Config path : "+Fullpath);

        TestRunner.runTests(Fullpath);
	
		
	}
}
