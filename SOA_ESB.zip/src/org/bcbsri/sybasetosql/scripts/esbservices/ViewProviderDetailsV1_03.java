package org.bcbsri.sybasetosql.scripts.esbservices;

import org.bcbsri.sybasetosql.reusables.esbservices.ESBServices_TestCaseRunner;

import com.dell.acoe.framework.config.Environment;

public class ViewProviderDetailsV1_03 {
	public static void runTest()
	{
		String files_path = Environment.get("Output_FilesPath");
		String testMajorRun = Environment.get("TestMajorRun");
		String endpoint = "";
		try {	
				if(testMajorRun.equalsIgnoreCase("Yes")) {
					endpoint = "http://esbmajorservices/";
				}
				else {
					endpoint = "http://esbminorservices/";
				}
					ESBServices_TestCaseRunner.runESBWSDL("ViewProviderDetailsV1-03-soapui-project", endpoint+"ViewProviderDetailsV1.03/ViewProviderDetailsPortTypeBndPort",files_path, "ViewProviderDetailsV1_03");

		} catch (Exception e) {
			e.printStackTrace();
		}
			
}
}
