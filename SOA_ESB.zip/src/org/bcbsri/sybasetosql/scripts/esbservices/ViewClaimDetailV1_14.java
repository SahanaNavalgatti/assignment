package org.bcbsri.sybasetosql.scripts.esbservices;

import java.io.File;

import org.bcbsri.sybasetosql.reusables.esbservices.ESBServices_TestCaseRunner;

import com.dell.acoe.framework.config.Environment;

public class ViewClaimDetailV1_14 {
	public static void runTest()
	{
		String files_path = Environment.get("Output_FilesPath");
		String testMajorRun = Environment.get("TestMajorRun");
		String endpoint = "";
		try {	
				if(testMajorRun.equalsIgnoreCase("Yes")) {
					endpoint = "http://esbmajorservices/";
				}
				else {
					endpoint = "http://esbminorservices/";
				}
			ESBServices_TestCaseRunner.runESBWSDL("ViewClaimDetailV1-14-soapui-project", endpoint+"ViewClaimDetailsV1.14/ViewClaimDetailsPortTypeBndPort",files_path, "ViewClaimDetailV1_14");

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
