package org.bcbsri.sybasetosql.scripts.esbservices;

import org.bcbsri.sybasetosql.reusables.esbservices.ESBServices_TestCaseRunner;

import com.dell.acoe.framework.config.Environment;

public class GetPrefixAccountID {
	public static void runTest()
	{
		String files_path = Environment.get("Output_FilesPath");
		//http://esbmajorservices/
		String testMajorRun = Environment.get("TestMajorRun");
		String endpoint = "";
		try {	
				if(testMajorRun.equalsIgnoreCase("Yes")) {
					endpoint = "http://esbmajorservices/";
				}
				else {
					endpoint = "http://esbminorservices/";
				}
					ESBServices_TestCaseRunner.runESBWSDL("GetPrefixAccountID-soapui-project", endpoint+"blue2_plan_integration_web/services/IPPPlanIntegrationService",files_path, "GetPrefixAccountID");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
