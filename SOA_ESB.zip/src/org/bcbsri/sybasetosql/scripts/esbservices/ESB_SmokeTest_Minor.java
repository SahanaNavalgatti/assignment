package org.bcbsri.sybasetosql.scripts.esbservices;

import org.bcbsri.sybasetosql.reusables.esbservices.ESBServices_TestCaseRunner;

import com.dell.acoe.framework.config.Environment;

public class ESB_SmokeTest_Minor {
	public static void runTest() {
	   
		String files_path = Environment.get("Output_FilesPath");
		String testMinorRun = Environment.get("TestMinorRun");
		String endpoint = "http://10.50.208.118:8011/";
        String endpoint1 = "http://10.50.208.119:8011/";
	    String module = System.getenv("module_name");
	    
	    try {
	    if(module.matches(".*ViewClaimDetailV1_14.*"))	
	    {
	    	ESBServices_TestCaseRunner.runESBWSDL("ViewClaimDetailV1-14-soapui-project", endpoint+"ViewClaimDetailsV1.14/ViewClaimDetailsPortTypeBndPort",files_path, "ViewClaimDetailV1_14");
			ESBServices_TestCaseRunner.runESBWSDL("ViewClaimDetailV1-14-soapui-project", endpoint1+"ViewClaimDetailsV1.14/ViewClaimDetailsPortTypeBndPort",files_path, "ViewClaimDetailV1_14");
	    }
	    
	    else if(module.matches(".*MemberPCPHistoryV1.01.*")) 
	    
	    {
	    	
	    	   ESBServices_TestCaseRunner.runESBWSDL("MemberPCPHistoryV1-01-soapui-project", endpoint+"MemberPCPHistoryServiceV1.01/MemberPCPHistoryPortTypeBndPort",files_path, "MemberPCPHistoryV1_01");
			   ESBServices_TestCaseRunner.runESBWSDL("MemberPCPHistoryV1-01-soapui-project", endpoint1+"MemberPCPHistoryServiceV1.01/MemberPCPHistoryPortTypeBndPort",files_path, "MemberPCPHistoryV1_01");
	    }
	    
	    else if (module.matches(".*MedicareMDRAuthValidation.*")) 
	    	
	    {
	    	ESBServices_TestCaseRunner.runESBWSDL("MedicareMDRAuthValidation-soapui-project", endpoint+"MedicareMDRAuthValidationV1.00/MedicareMDRAuthPortTypeBndPort",files_path, "MedicareMDRAuthValidation");
			ESBServices_TestCaseRunner.runESBWSDL("MedicareMDRAuthValidation-soapui-project", endpoint1+"MedicareMDRAuthValidationV1.00/MedicareMDRAuthPortTypeBndPort",files_path, "MedicareMDRAuthValidation");
			  
	    }
	    
	    else if (module.matches(".*ClaimSearchV1.05.*"))
	    	
	    {
	    	ESBServices_TestCaseRunner.runESBWSDL("ClaimSearchV1-05-soapui-project", endpoint+"ClaimSearchV1.05/ClaimSearchPortTypeBndPort",files_path, "ClaimSearchV1_05"); 
			ESBServices_TestCaseRunner.runESBWSDL("ClaimSearchV1-05-soapui-project", endpoint1+"ClaimSearchV1.05/ClaimSearchPortTypeBndPort",files_path, "ClaimSearchV1_05"); 
	    }
	   
        else if (module.matches(".*SearchGroupMember.*"))
	    	
	    {
        	ESBServices_TestCaseRunner.runESBWSDL("SearchGroupMemberV2-02-soapui-project", endpoint+"SearchGroupMembersV2.02/SearchGroupMembersPortTypeBndPort",files_path, "SearchGroupMemberV2_02");
            ESBServices_TestCaseRunner.runESBWSDL("SearchGroupMemberV2-02-soapui-project", endpoint1+"SearchGroupMembersV2.02/SearchGroupMembersPortTypeBndPort",files_path, "SearchGroupMemberV2_02");
	    }
        
        else if (module.matches(".*SearchGroupV1_00.*"))
        	
        {
        	
        	ESBServices_TestCaseRunner.runESBWSDL("SearchGroupV1-00-soapui-project", endpoint+"SearchGroupV1.00/SearchGroupPortTypeBndPort",files_path, "SearchGroupV1_00");
            ESBServices_TestCaseRunner.runESBWSDL("SearchGroupV1-00-soapui-project", endpoint1+"SearchGroupV1.00/SearchGroupPortTypeBndPort",files_path, "SearchGroupV1_00");
           
        }
        else if (module.matches(".*AccumulatorV2.07.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("AccumulatorV2-07-soapui-project", endpoint+"AccumulatorsV2.07/AccumulatorsPortTypeBndPort",files_path, "AccumulatorV2_07");
            ESBServices_TestCaseRunner.runESBWSDL("AccumulatorV2-07-soapui-project", endpoint1+"AccumulatorsV2.07/AccumulatorsPortTypeBndPort",files_path, "AccumulatorV2_07");
        	
        }
	    
        else if (module.matches(".*EDIClaimStatusOrchV2.03.*"))	
        {
        	
        	ESBServices_TestCaseRunner.runESBWSDL("EDIClaimStatusOrchV2-03-soapui-project", endpoint+"EDIClaimStatusOrchestrationV2.03/EDIClaimStatusOrchPortTypeBndPort",files_path, "EDIClaimStatusOrchV2.03");
            ESBServices_TestCaseRunner.runESBWSDL("EDIClaimStatusOrchV2-03-soapui-project", endpoint1+"EDIClaimStatusOrchestrationV2.03/EDIClaimStatusOrchPortTypeBndPort",files_path, "EDIClaimStatusOrchV2.03");
       
 	    }
	    
        else if (module.matches(".*SearchMemberV3.10.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("SearchMemberV3-10-soapui-project", endpoint+"SearchMemberV3.10/SearchMemberPortTypeBndPort",files_path, "SearchMemberV3.10");
            ESBServices_TestCaseRunner.runESBWSDL("SearchMemberV3-10-soapui-project", endpoint1+"SearchMemberV3.10/SearchMemberPortTypeBndPort",files_path, "SearchMemberV3.10");
          
        }
        else if (module.matches(".*ActiveMemberSearchV1-06.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ActiveMemberSearchV1-06-soapui-project", endpoint+"ActiveMemberSearchV1.06.02/ActiveMemberSearchPortTypeBndPort",files_path, "ActiveMemberSearchV1-06");
            ESBServices_TestCaseRunner.runESBWSDL("ActiveMemberSearchV1-06-soapui-project", endpoint1+"ActiveMemberSearchV1.06.02/ActiveMemberSearchPortTypeBndPort",files_path, "ActiveMemberSearchV1-06");
          
        }
        else if (module.matches(".*EDIEligibiltyOrchV2-07.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("EDIEligibiltyOrchV2-07-soapui-project", endpoint+"EDIEligibilityOrchestrationV2.07/EDIEligibilityOrchPortTypeBndPort",files_path, "EDIEligibiltyOrchV2");
            ESBServices_TestCaseRunner.runESBWSDL("EDIEligibiltyOrchV2-07-soapui-project", endpoint1+"EDIEligibilityOrchestrationV2.07/EDIEligibilityOrchPortTypeBndPort",files_path, "EDIEligibiltyOrchV2");
          
        }
	    
        else if (module.matches(".*IDCardStatus.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("IDCardStatus-soapui-project", endpoint+"IDCardStatusService/IDCardStatusPortTypeBndPort",files_path, "IDCardStatus");
            ESBServices_TestCaseRunner.runESBWSDL("IDCardStatus-soapui-projectt", endpoint1+"IDCardStatusService/IDCardStatusPortTypeBndPort",files_path, "IDCardStatus");
          
        }
        else if (module.matches(".*PCPValidationProcessV1.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("PCPValidationProcessV1-01-soapui-project", endpoint+"PCPValidationProcessV1.01/PCPValidationProcessPortTypeBndPort",files_path, "PCPValidationProcessV1");
            ESBServices_TestCaseRunner.runESBWSDL("PCPValidationProcessV1-01-soapui-project", endpoint1+"PCPValidationProcessV1.01/PCPValidationProcessPortTypeBndPort",files_path, "PCPValidationProcessV1");
          
        }
	    
        else if (module.matches(".*SearchGroupMemberV2.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("SearchGroupMemberV2-02-soapui-project", endpoint+"SearchGroupMembersV2.02/SearchGroupMembersPortTypeBndPort",files_path, "SearchGroupMemberV2");
            ESBServices_TestCaseRunner.runESBWSDL("SearchGroupMemberV2-02-soapui-project", endpoint1+"SearchGroupMembersV2.02/SearchGroupMembersPortTypeBndPort",files_path, "SearchGroupMemberV2");
          
        }
        else if (module.matches(".*SearchProviderV4-09-soapui-project.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("SearchProviderV4-09-soapui-project", endpoint+"SearchProviderV4.05/SearchProviderServicePortTypeBndPort",files_path, "SearchProviderV4");
            ESBServices_TestCaseRunner.runESBWSDL("SearchProviderV4-09-soapui-project", endpoint1+"SearchProviderV4.05/SearchProviderServicePortTypeBndPort",files_path, "SearchProviderV4");
          
        }
        else if (module.matches(".*ViewAuthorizationServiceV2-02.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ViewAuthorizationServiceV2-02-soapui-project", endpoint+"ViewAuthorizationStatusV2.02/ViewAuthorizationStatusPortTypeBndPort",files_path, "ViewAuthorizationServiceV2");
            ESBServices_TestCaseRunner.runESBWSDL("ViewAuthorizationServiceV2-02-soapui-project", endpoint1+"ViewAuthorizationStatusV2.02/ViewAuthorizationStatusPortTypeBndPort",files_path, "ViewAuthorizationServiceV2");
          
        }
        else if (module.matches(".*ViewBenefitsV3-15.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ViewBenefitsV3-15-soapui-project", endpoint+"ViewBenefitsV3.15/ViewBenefitsPortTypeBndPort",files_path, "ViewBenefitsV3-15");
            ESBServices_TestCaseRunner.runESBWSDL("ViewBenefitsV3-15-soapui-project", endpoint1+"ViewBenefitsV3.15/ViewBenefitsPortTypeBndPort",files_path, "ViewBenefitsV3-15");
          
        }
        else if (module.matches(".*ViewClaimDetailV1-14.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ViewClaimDetailV1-14-soapui-project", endpoint+"ViewClaimDetailsV1.14/ViewClaimDetailsPortTypeBndPort",files_path, "ViewClaimDetailV1-14");
            ESBServices_TestCaseRunner.runESBWSDL("ViewClaimDetailV1-14-soapui-project", endpoint1+"ViewClaimDetailsV1.14/ViewClaimDetailsPortTypeBndPort",files_path, "ViewClaimDetailV1-14");
          
        }
        else if (module.matches(".*ViewDocs.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ViewDocs-soapui-project", endpoint+"ViewDocsV2.00/ViewDocsPortTypeBndPort",files_path, "ViewDocs");
            ESBServices_TestCaseRunner.runESBWSDL("ViewDocs-soapui-project", endpoint1+"ViewDocsV2.00/ViewDocsPortTypeBndPort",files_path, "ViewDocs");
          
        }
        else if (module.matches(".*ViewDocumentV1-05.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ViewDocumentV1-05-soapui-project", endpoint+"ViewDocumentsV1.05/ViewDocumentsPortTypeBndPort",files_path, "ViewDocumentV1");
            ESBServices_TestCaseRunner.runESBWSDL("ViewDocumentV1-05-soapui-project", endpoint1+"ViewDocumentsV1.05/ViewDocumentsPortTypeBndPort",files_path, "ViewDocumentV1");
          
        }
        else if (module.matches(".*ViewGroupCrossReferenceV1.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ViewGroupCrossReferenceV1-04-soapui-project", endpoint+"ViewDocumentsV1.05/ViewDocumentsPortTypeBndPort",files_path, "ViewGroupCrossReferenceV1");
            ESBServices_TestCaseRunner.runESBWSDL("ViewGroupCrossReferenceV1-04-soapui-project", endpoint1+"ViewDocumentsV1.05/ViewDocumentsPortTypeBndPort",files_path, "ViewGroupCrossReferenceV1"); 
        }
        else if (module.matches(".*ViewGroupDetailsV1-08.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ViewGroupDetailsV1-08-soapui-project", endpoint+"ViewGroupDetailsV1.08/ViewGroupDetailsPortTypeBndPort",files_path, "ViewGroupDetailsV1");
            ESBServices_TestCaseRunner.runESBWSDL("ViewGroupDetailsV1-08-soapui-project", endpoint1+"ViewGroupDetailsV1.08/ViewGroupDetailsPortTypeBndPort",files_path, "ViewGroupDetailsV1"); 
        }
        else if (module.matches(".*ViewGroupPaymentV1.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ViewGroupPaymentV1-04-soapui-project", endpoint+"ViewGroupPaymentsV1.04/ViewGroupPaymentsPortTypeBndPort",files_path, "ViewGroupPaymentV1");
            ESBServices_TestCaseRunner.runESBWSDL("ViewGroupPaymentV1-04-soapui-project", endpoint1+"ViewGroupPaymentsV1.04/ViewGroupPaymentsPortTypeBndPort",files_path, "ViewGroupPaymentV1"); 
        }
        else if (module.matches(".*ViewGroupProductV1.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ViewGroupProductV1-10-soapui-project", endpoint+"ViewGroupProductsV1.10/ViewGroupProductsPortTypeBndPort",files_path, "ViewGroupProductV1");
            ESBServices_TestCaseRunner.runESBWSDL("ViewGroupProductV1-10-soapui-project", endpoint1+"ViewGroupProductsV1.10/ViewGroupProductsPortTypeBndPort",files_path, "ViewGroupProductV1"); 
        }
        else if (module.matches(".*ViewIdCardBenefitV1.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ViewIdCardBenefitV1-06-soapui-project", endpoint+"ViewIdCardBenefitsV1.04/ViewIDCardBenefitsPortTypeBndPort",files_path, "ViewIdCardBenefitV1");
            ESBServices_TestCaseRunner.runESBWSDL("ViewIdCardBenefitV1-06-soapui-project", endpoint1+"ViewIdCardBenefitsV1.04/ViewIDCardBenefitsPortTypeBndPort",files_path, "ViewIdCardBenefitV1"); 
        }
	    
        else if (module.matches(".*ViewMedicareInfoV1.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ViewMedicareInfoV1-00-soapui-project", endpoint+"ViewMedicareInfoV1.00/ViewMedicareInfoPortTypeBndPort",files_path, "ViewMedicareInfoV1");
            ESBServices_TestCaseRunner.runESBWSDL("ViewMedicareInfoV1-00-soapui-project", endpoint1+"ViewMedicareInfoV1.00/ViewMedicareInfoPortTypeBndPort",files_path, "ViewMedicareInfoV1"); 
        }
	    
        else if (module.matches(".*ViewMemberAccount.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ViewMemberAccountV3-19-soapui-project", endpoint+"ViewMemberAccountV3.19/ViewMemberAccountPortTypeBndPort",files_path, "ViewMemberAccountV3");
            ESBServices_TestCaseRunner.runESBWSDL("ViewMemberAccountV3-19-soapui-project", endpoint1+"ViewMemberAccountV3.19/ViewMemberAccountPortTypeBndPort",files_path, "ViewMemberAccountV3"); 
        }
        else if (module.matches(".*ViewMemberPayment.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ViewMemberPaymentV2-05-soapui-project", endpoint+"ViewMemberPaymentsV2.05/ViewMemberPaymentsPortTypeBndPort",files_path, "ViewMemberPayment");
            ESBServices_TestCaseRunner.runESBWSDL("ViewMemberPaymentV2-05-soapui-project", endpoint1+"ViewMemberPaymentsV2.05/ViewMemberPaymentsPortTypeBndPort",files_path, "ViewMemberPayment"); 
        }
	    
        else if (module.matches(".*ViewProviderCrossReference.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ViewProviderCrossReference-soapui-project", endpoint+"ViewProviderCrossReferenceService/ViewProviderCrossReferencePortTypeBndPort",files_path, "ViewProviderCrossReference");
            ESBServices_TestCaseRunner.runESBWSDL("ViewProviderCrossReference-soapui-project", endpoint1+"ViewProviderCrossReferenceService/ViewProviderCrossReferencePortTypeBndPort",files_path, "ViewProviderCrossReference"); 
        }
	    
        else if (module.matches(".*ViewProviderDetailsV1.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ViewProviderDetailsV1-03-soapui-project", endpoint+"ViewProviderDetailsV1.03/ViewProviderDetailsPortTypeBndPort",files_path, "ViewProviderDetailsV1");
            ESBServices_TestCaseRunner.runESBWSDL("ViewProviderDetailsV1-03-soapui-project", endpoint1+"ViewProviderDetailsV1.03/ViewProviderDetailsPortTypeBndPort",files_path, "ViewProviderDetailsV1"); 
        }
	    
	    
        else if (module.matches(".*ViewReferralStatusService.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ViewReferralStatusService-soapui-project", endpoint+"ViewReferralStatusService/ViewReferralStatusPortTypeBndPort",files_path, "ViewReferralStatusService");
            ESBServices_TestCaseRunner.runESBWSDL("ViewReferralStatusService-soapui-project", endpoint1+"ViewReferralStatusService/ViewReferralStatusPortTypeBndPort",files_path, "ViewReferralStatusService"); 
        }
	    
        else if (module.matches(".*ViewRelatedGroupV1.*"))	
        {
        	ESBServices_TestCaseRunner.runESBWSDL("ViewRelatedGroupV1-00-soapui-project", endpoint+"ViewRelatedGroupsV1.00/ViewRelatedGroupsPortTypeBndPort",files_path, "ViewProviderDetailsV1");
            ESBServices_TestCaseRunner.runESBWSDL("ViewRelatedGroupV1-00-soapui-project", endpoint1+"ViewRelatedGroupsV1.00/ViewRelatedGroupsPortTypeBndPort",files_path, "ViewProviderDetailsV1"); 
        }
	    
        else if (module.matches(".*GetIDCard.*"))	
        {
        	
        	  GetIDCard.runTest();	
        }
	    
        else if (module.matches(".*GetUsername.*"))	
        {
        
        	GetUsername.runTest();
        	
        }
        else if (module.matches(".*GetBenefitsList.*"))	
        {
        
        	GetBenefitsList.runTest();
        	
        }
	    
        else if (module.matches(".*GetAccumulatorBreakdown.*"))	
        {
        
        	GetAccumulatorBreakdown.runTest();
        	
        }
	    
        else if (module.matches(".*GetCommunicationPreference.*"))	
        {
        
        	GetCommunicationPreference.runTest();
        	
        }
	    
        else if (module.matches(".*GetCDHPTransaction.*"))	
        {
        
        	GetCDHPTransaction.runTest();
        	
        }
	    
        else if (module.matches(".*GetMemberBenefits.*"))	
        {
        
        	GetMemberBenefits.runTest();
        	
        }
        else if (module.matches(".*UpdateMemberDemographics.*"))	
        {
        
        	UpdateMemberDemographics.runTest();
        	
        }
        else if (module.matches(".*GetClaimDetails.*"))	
        {
        
        	GetClaims.runTest();
        	
        }
	    
        else if (module.matches(".*GetPCPDetails.*"))	
        {
        
        	GetPCPDetails.runTest();
        	
        }
	    
        else if (module.matches(".*FindClaims.*"))	
        {
        
        	FindClaims.runTest();
        	
        }
	    
        else if (module.matches(".*FindPCP.*"))	
        {
        
        	FindPCP.runTest();
        	
        }
	    
        else if (module.matches(".*UpdatePCP.*"))	
        {
        
        	UpdatePCP.runTest();
        	
        }
	   
        else if (module.matches(".*UpdateCommunicationPreference.*"))
        {
        
        	UpdateCommunicationPreference.runTest();
        	
        }
	    
        else if (module.matches(".*SelectUsername.*"))
        {
        
        	SelectUsername.runTest();
        	
        }
	    
        else if (module.matches(".*GetRegistrationFlag.*"))
        {
        
        	GetRegistrationFlag.runTest();
        	
        }
	    
        else if (module.matches(".*UpdateRegistrationFlag.*"))
        {
        
        	UpdateRegistrationFlag.runTest();
        	
        }
	    
        else if (module.matches(".*ViewIDCardStatus.*"))
        {
        
        	ViewIDCardStatus.runTest();
        	
        }
	    
        else if (module.matches(".*ValidateAndOrderIDCard.*"))
        {
        
        	ValidateAndOrderIDCard.runTest();
        	
        }
	    
       
	   else if (module.matches(".*GetAccumulator.*"))
        {
        
        	GetAccumulator.runTest();
        	
        }
	    
        else if (module.matches(".*GetCDHPTransaction.*"))
        {
        
        	GetCDHPTransaction.runTest();
        	
        }
	    
        else if (module.matches(".*GetCDHPSummary.*"))
        {
        
        	GetCDHPSummary.runTest();
        	
        }
	    
	   else 
        {
       	
         System.out.println("Service Not Found");
         
        } 

	     		   
	} catch (Exception e) {
		e.printStackTrace();	
	} 
	}

	}
	   

	    
