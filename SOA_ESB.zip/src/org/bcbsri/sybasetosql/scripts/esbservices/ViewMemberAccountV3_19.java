package org.bcbsri.sybasetosql.scripts.esbservices;

import org.bcbsri.sybasetosql.reusables.esbservices.ESBServices_TestCaseRunner;
import org.bcbsri.sybasetosql.reusables.esbservices.ESBServices_WSDLTesCasetRunner;

import com.dell.acoe.framework.config.Environment;

public class ViewMemberAccountV3_19 {
	public static void runTest()
	{
		String files_path = Environment.get("Output_FilesPath");
		String testMajorRun = Environment.get("TestMajorRun");
		String endpoint = "";
		try {	
				if(testMajorRun.equalsIgnoreCase("Yes")) {
					endpoint = "http://esbmajorservices/";
				}
				else {
					endpoint = "http://esbminorservices/";
				}		
					ESBServices_TestCaseRunner.runESBWSDL("ViewMemberAccountV3-19-soapui-project", endpoint+"ViewMemberAccountV3.19/ViewMemberAccountPortTypeBndPort",files_path, "ViewMemberAccountV3_19");

		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
