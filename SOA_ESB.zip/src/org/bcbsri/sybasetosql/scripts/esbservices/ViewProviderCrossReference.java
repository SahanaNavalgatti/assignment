package org.bcbsri.sybasetosql.scripts.esbservices;

import java.io.File;

import org.bcbsri.sybasetosql.reusables.esbservices.ESBServices_TestCaseRunner;

import com.dell.acoe.framework.config.Environment;

public class ViewProviderCrossReference {
	public static void runTest()
	{
		String files_path = Environment.get("Output_FilesPath");
		try {
			ESBServices_TestCaseRunner.runESBWSDL("ViewProviderCrossReference-soapui-project", "http://esbminorservices/ViewProviderCrossReferenceService/ViewProviderCrossReferencePortTypeBndPort",files_path, "ViewProviderCrossReference");

		} catch (Exception e) {
			e.printStackTrace();
		}
			
}
}
