package org.bcbsri.sybasetosql.scripts.esbservices;

import org.bcbsri.sybasetosql.reusables.esbservices.ESBServices_TestCaseRunner;

import com.dell.acoe.framework.config.Environment;


public class ViewGroupPaymentV1_04 {
	public static void runTest()
	{
		String files_path = Environment.get("Output_FilesPath");
		String testMajorRun = Environment.get("TestMajorRun");
		String endpoint = "";
		try {	
				if(testMajorRun.equalsIgnoreCase("Yes")) {
					endpoint = "http://esbmajorservices/";
				}
				else {
					endpoint = "http://esbminorservices/";
				}
				ESBServices_TestCaseRunner.runESBWSDL("ViewGroupPaymentV1-04-soapui-project", endpoint+"ViewGroupPaymentsV1.04/ViewGroupPaymentsPortTypeBndPort",files_path, "ViewGroupPaymentV1_04");

		} catch (Exception e) {
			e.printStackTrace();
		}
}
}
