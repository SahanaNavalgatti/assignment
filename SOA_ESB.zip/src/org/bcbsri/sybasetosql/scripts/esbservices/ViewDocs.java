package org.bcbsri.sybasetosql.scripts.esbservices;

import java.io.File;

import org.bcbsri.sybasetosql.reusables.esbservices.ESBServices_TestCaseRunner;

import com.dell.acoe.framework.config.Environment;

public class ViewDocs {
	public static void runTest()
	{
		String files_path = Environment.get("Output_FilesPath");
		try {
			
			
			ESBServices_TestCaseRunner.runESBWSDL("ViewDocs-soapui-project", "http://esbminorservices/ViewDocsV2.00/ViewDocsPortTypeBndPort",files_path, "ViewDocs");

		} catch (Exception e) {
			e.printStackTrace();
		}
			
	}

}
