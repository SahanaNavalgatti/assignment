package org.bcbsri.sybasetosql.scripts.esbservices;

import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.bcbsri.selfservice.cmd_prompt.Testrunner;
import org.bcbsri.selfservice.commonMethods.Config;
import org.bcbsri.selfservice.commonMethods.UtilMethod;

import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.run.TestRunner;
import com.dell.acoe.framework.selenium.report.Soap;

public class UpdateMemberDemographics {
	public static void runTest() throws Exception {
		Config.init_updateMemberDemographics();
		String files_path =UtilMethod.createNewReportPath();
		String endpointMinor = Config.endpointMinor;
		String endpointMajor = Config.endpointMajor;
		String xmlFile = Config.xmlFile;
		String testSuite = Config.testSuite;
		String testCase = Config.testCase;
		String testMinorExecute = Environment.get("Test_Minor_Execution");
		String testMajorExecute = Environment.get("Test_Major_Execution");
		String env = "testMinor";
		String fileDelete = "";
		String testfilename = "Member";
		
		
		xmlFile = Environment.get("test_data_path")+"/"+env+"/"+xmlFile;	
		Testrunner.launchRunner(files_path,endpointMinor,xmlFile,testSuite,testCase);
		
		String dir = Environment.get("report_path")+"/responsedata"; 
		System.out.println("Dir: "+dir);
		String[] filename = UtilMethod.Allfiles(dir);
		for (int k = 0; k < filename.length; k++) {
			Soap.done(filename[k]);
		}	
		File folder = new File(files_path);
		UtilMethod listFiles = new UtilMethod();
		String testID;
		String service = "Member";
		int i=0;
		//String ExcelFilePath = Environment.get("Member_testData_Path");
		String testdatapath = Environment.get("test_data_path")+"\\"+env+"\\"+testfilename+".xls";
		FileInputStream inputStream = new FileInputStream(testdatapath);
		HSSFWorkbook wb = new HSSFWorkbook(inputStream);
		HSSFSheet sheet = wb.getSheet("UpdateMember_Input");
		int rowcount = sheet.getLastRowNum();
		fileDelete = sheet.getRow(1).getCell(0).getStringCellValue();
		fileDelete = fileDelete.replaceAll("^*[0-9]|[0-9][0-9]|[0-9][0-9][0-9]", "");
		fileDelete = fileDelete + rowcount;
		UtilMethod.removeFiles(folder,fileDelete);
		for (i = 1; i <= rowcount; i++) {

		testID = sheet.getRow(i).getCell(0).getStringCellValue();
		listFiles.listUpdateMemberFiles(folder, testID,service, env); 
		
		}
		wb.close();
}
}
