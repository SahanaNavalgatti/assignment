package org.bcbsri.sybasetosql.scripts.esbservices;

import java.io.File;

import org.bcbsri.sybasetosql.reusables.esbservices.ESBServices_TestCaseRunner;

import com.dell.acoe.framework.config.Environment;

public class ViewDocumentV1_05 {
	public static void runTest()
	{
		String files_path = Environment.get("Output_FilesPath");
		String testMajorRun = Environment.get("TestMajorRun");
		String endpoint = "";
		try {	
				if(testMajorRun.equalsIgnoreCase("Yes")) {
					endpoint = "http://esbmajorservices/";
				}
				else {
					endpoint = "http://esbminorservices/";
				}				
					ESBServices_TestCaseRunner.runESBWSDL("ViewDocumentV1-05-soapui-project", endpoint+"ViewDocumentsV1.05/ViewDocumentsPortTypeBndPort",files_path, "ViewDocumentV1_05");

		} catch (Exception e) {
			e.printStackTrace();
		}
			
	}
}
