package org.bcbsri.sybasetosql.scripts.esbservices;

import org.bcbsri.sybasetosql.reusables.esbservices.ESBServices_WSDLTesCasetRunner;

public class EDIClaimStatusOrchV2_03 {

	public static void runTest()
	{
		try {
			ESBServices_WSDLTesCasetRunner.runUpdatedESBWSDL("EDIClaimStatusOrchV2-03-soapui-project","EDIClaimStatusOrchV2");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
