package org.bcbsri.sybasetosql.scripts.esbservices;

import java.io.File;

import org.bcbsri.sybasetosql.reusables.esbservices.ESBServices_TestCaseRunner;

import com.dell.acoe.framework.config.Environment;

public class MemberPCPHistoryV1_01 {
	public static void runTest()
	{
		String files_path = Environment.get("Output_FilesPath");
		String testMajorRun = Environment.get("TestMajorRun");
		String endpoint = "";
		try {	
				if(testMajorRun.equalsIgnoreCase("Yes")) {
					endpoint = "http://esbmajorservices/";
				}
				else {
					endpoint = "http://esbminorservices/";
				}			
					ESBServices_TestCaseRunner.runESBWSDL("MemberPCPHistoryV1-01-soapui-project", endpoint+"MemberPCPHistoryServiceV1.01/MemberPCPHistoryPortTypeBndPort",files_path, "MemberPCPHistoryV1_01");

		} catch (Exception e) {
			e.printStackTrace();
		}
		
}
}
