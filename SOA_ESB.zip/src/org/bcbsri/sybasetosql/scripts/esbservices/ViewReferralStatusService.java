package org.bcbsri.sybasetosql.scripts.esbservices;

import org.bcbsri.sybasetosql.reusables.esbservices.ESBServices_TestCaseRunner;

import com.dell.acoe.framework.config.Environment;

public class ViewReferralStatusService {
	
	public static void runTest()
	{
		String files_path = Environment.get("Output_FilesPath");
		try {
					ESBServices_TestCaseRunner.runESBWSDL("ViewReferralStatusService-soapui-project", "http://esbminorservices/ViewReferralStatusService/ViewReferralStatusPortTypeBndPort",files_path, "ViewReferralStatusService");

		} catch (Exception e) {
			e.printStackTrace();
		}
			
	}
}
