package org.bcbsri.sybasetosql.scripts.esbservices;

import java.io.File;

import org.bcbsri.sybasetosql.reusables.esbservices.ESBServices_TestCaseRunner;

import com.dell.acoe.framework.config.Environment;

public class SearchGroupV1_00 {

	public static void runTest()
	{
		String files_path = Environment.get("Output_FilesPath");
		String testMajorRun = Environment.get("TestMajorRun");
		String endpoint = "";
		try {	
				if(testMajorRun.equalsIgnoreCase("Yes")) {
					endpoint = "http://esbmajorservices/";
				}
				else {
					endpoint = "http://esbminorservices/";
				}
			
			ESBServices_TestCaseRunner.runESBWSDL("SearchGroupV1-00-soapui-project", endpoint+"SearchGroupV1.00/SearchGroupPortTypeBndPort",files_path, "SearchGroupV1_00");

		} catch (Exception e) {
			e.printStackTrace();
		}
			
	}
}
