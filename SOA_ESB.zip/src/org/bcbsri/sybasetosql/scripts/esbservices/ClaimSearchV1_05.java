package org.bcbsri.sybasetosql.scripts.esbservices;



import org.bcbsri.sybasetosql.reusables.esbservices.ESBServices_TestCaseRunner;

import com.dell.acoe.framework.config.Environment;

public class ClaimSearchV1_05 {
	public static void runTest()
	{
		String files_path = Environment.get("Output_FilesPath");
		String testMajorRun = Environment.get("TestMajorRun");
		String endpoint = "";
		try {	
				if(testMajorRun.equalsIgnoreCase("Yes")) {
					endpoint = "http://esbmajorservices/";
				}
				else {
					endpoint = "http://esbminorservices/";
				}
					ESBServices_TestCaseRunner.runESBWSDL("ClaimSearchV1-05-soapui-project", endpoint+"ClaimSearchV1.05/ClaimSearchPortTypeBndPort",files_path, "ClaimSearchV1_05");

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
