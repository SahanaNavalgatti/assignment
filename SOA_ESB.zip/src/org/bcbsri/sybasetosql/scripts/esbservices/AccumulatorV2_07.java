package org.bcbsri.sybasetosql.scripts.esbservices;





import org.bcbsri.sybasetosql.reusables.esbservices.ESBServices_TestCaseRunner;

import com.dell.acoe.framework.config.Environment;


public class AccumulatorV2_07 {
	public static void runTest()
	{
		String files_path = Environment.get("Output_FilesPath");
		String testMajorRun = Environment.get("TestMajorRun");
		String endpoint = "";
		try {	
				if(testMajorRun.equalsIgnoreCase("Yes")) {
					endpoint = "http://esbmajorservices/";
				}
				else {
					endpoint = "http://esbminorservices/";
				}
					ESBServices_TestCaseRunner.runESBWSDL("AccumulatorV2-07-soapui-project", endpoint+"AccumulatorsV2.07/AccumulatorsPortTypeBndPort",files_path, "AccumulatorV2_07");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
