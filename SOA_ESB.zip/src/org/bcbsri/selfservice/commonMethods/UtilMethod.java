package org.bcbsri.selfservice.commonMethods;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.bcbsri.selfservice.dbutility.ViewClaimsDBS;
import org.bcbsri.selfservice.validation.ValidateMethods;
import org.bcbsri.sybasetosql.scripts.esbservices.GetClaims;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.selenium.report.Reporting;
import com.dell.acoe.framework.selenium.testdata.DataTable;
import com.dell.acoe.framework.selenium.testdata.DataTable1;
import com.dell.acoe.framework.selenium.verify.Assert;

public class UtilMethod {

	public static String sheetTabName = null;

	/**
	 * Method will Convert json response into key and value
	 */
	public static Map<String, Object> readJsonData(Object jsonValue) {
		Map<String, Object> map = new HashMap<>();
		if (jsonValue instanceof JSONObject) {
			JSONObject value2 = (JSONObject) jsonValue;
			for (Object key1 : value2.keySet()) {
				String key = (String) key1;
				Object value = value2.get(key);

				if (value instanceof JSONObject) {
					readJsonData((JSONObject) value);
				} else if (value instanceof JSONArray) {
				} else {
					map.put(key, value);
				}
			}

		} else if (jsonValue instanceof org.json.JSONObject) {
			org.json.JSONObject value2 = (org.json.JSONObject) jsonValue;
			for (Object key1 : value2.keySet()) {
				String key = (String) key1;
				Object value = value2.get(key);

				if (value instanceof JSONObject) {
					readJsonData((JSONObject) value);
				} else if (value instanceof JSONArray) {
				} else {
					map.put(key, value);
				}
			}
		}
		return map;
	}

	/**
	 * Method to log results to HTML report and to console
	 * 
	 * @param strStepName
	 *            - Step description
	 * @param strResult
	 *            - PASS/FAIL/DONE
	 * @blnScreenshot - Attach screenshot? true/false
	 */
	public static void Log(String strStepName, String strResult, Boolean blnScreenshot) throws Exception {

		switch (strResult) {
		case "PASS":
			Assert.pass(strStepName);
			break;
		case "FAIL":
			Assert.fail(strStepName);
			break;
		case "DONE":
			Assert.done(strStepName);
			break;

		default:
			break;
		}
	}

	/**
	 * This method will validate one DB Value with one JSON Response
	 * 
	 * @param db_data
	 * @param tagname
	 * @param Value
	 * @return
	 */
	public static void validateJSONObject(Map<String, Object> db_data, String tagname, Object Value, int colNum,
			String ReportFilePath) {

		boolean flag = false;
		boolean flag1 = true;
		String dbValue = null;
		String value = null;
		try {

			if (db_data.containsKey(tagname)) {
				if (Value != null) {
					value = Value.toString().trim();
					if (value.length() >= 2 && value.charAt(value.length() - 2) == '.'
							&& value.charAt(value.length() - 1) == '0') {
						
						value = value.concat("0");
						}

					if ((tagname.equalsIgnoreCase("amountBilled")))
					{
						if(!(value.contains(".00"))) {
							 String[] displayRemainingValue =  value.split("\\.");
							int a =  displayRemainingValue[1].length();										
						if(a<2)
						{
							value = value+0;	
						}}}
					//tagname = tagname.toUpperCase();
					UtilMethod.setCellData(tagname, value, colNum, ReportFilePath);
					if (db_data.get(tagname).toString().trim().equalsIgnoreCase(value)) {
						flag = true;
						dbValue = db_data.get(tagname).toString().trim();
					} else {
						dbValue = db_data.get(tagname).toString().trim();
					}

				} else {

					dbValue = db_data.get(tagname).toString();
					if (dbValue.equalsIgnoreCase("null")) {
						Log(tagname + " tag with DB  is having null value", "PASS", true);
						flag1 = false;

					}
					// Assert.done("Cannot validate this " + tagname + " tag with DB as it is having
					// null value");
					else {
						Log("Cannot  this " + tagname + " tag with DB as it is having null value", "FAIL", true);
						flag1 = false;
					}
				}

			} else {
				Assert.done(tagname + " is not available in the dbdata, so we are not validating this tag");
				flag1 = false;

			}

			if (flag1) {

				if (dbValue.contains("$")) {
					dbValue = dbValue.replace("$", "#");
				}
				if (value.toString().contains("$")) {
					value = value.toString().replace("$", "#");
				}
				if (flag) {

					Log(tagname + " is matching " + " [ " + " Expected Result is " + dbValue + " " + " AND "
							+ "Actual Result is" + " " + value + " ] ", "PASS", true);
				} else {

					Log(tagname + "  is not matching " + " [ " + "Expected Result is " + dbValue + " AND "
							+ "Actual Result is" + " " + value + " ] ", "FAIL", true);
				}

			}
		} catch (Exception e) {
			Assert.fail("Exception occured while validating the response with DB data" + e.getMessage());
		}

	}

	/**
	 * 
	 * This method will hold all the DB value and verify with json
	 * 
	 * @param db_data
	 * @param tagname
	 * @param Value
	 */
	public static void validateTag(org.json.JSONArray map, String tagname, Object Value, String ReportFilePath) {

		boolean flag = false;
		boolean flag1 = true;
		String dbValue = null;

		try {
			outerloop: for (int i = 0; i < map.length(); i++) {
				org.json.JSONObject elements = map.getJSONObject(i);
				Iterator key = elements.keys();
				while (key.hasNext()) {
					if (elements.has(tagname)) {
						if (Value != null) {
							String value = Value.toString().trim();
							if (!(tagname.equalsIgnoreCase("Accrual") | tagname.equalsIgnoreCase("Remaining")
									| tagname.equalsIgnoreCase("Maximum")
									| tagname.equalsIgnoreCase("DisplayAccrual"))) {
								if (value.length() >= 2 && value.charAt(value.length() - 2) == '.') {
									if (!elements.has("lastLoginDate")) {
										value = value.concat("0");
									}
								}

							}

							UtilMethod.setCellData(tagname, elements.getString(tagname), 2, ReportFilePath);
							if (elements.getString(tagname).trim().equalsIgnoreCase(value)) {
								flag = true;
								dbValue = elements.getString(tagname).trim();
								break outerloop;
							} else {
								dbValue = elements.getString(tagname).trim();
								break outerloop;
							}
						} else {
							dbValue = elements.get(tagname).toString();
							if (dbValue.equalsIgnoreCase("null")) {
								Log(tagname + " tag with DB  is having null value", "PASS", true);
								flag1 = false;
								break outerloop;
							} else {
								// Assert.done("Cannot validate this " + tagname + " tag with DB as it is having
								// null value");
								Log("Cannot validate this " + tagname + " tag with DB as it is having null value",
										"FAIL", true);
								flag1 = false;
								break outerloop;
							}
						}

					} else {
						Assert.done(tagname + " is not available in the dbdata, so we are not validating this tag");
						flag1 = false;
						break outerloop;
					}
				}
			}
			if (flag1) {
				if (dbValue.contains("$")) {
					dbValue = dbValue.replace("$", "#");
				}
				if (Value.toString().contains("$")) {
					Value = Value.toString().replace("$", "#");
				}
				if (flag) {

					Log(tagname + " is matching  " + "[" + "Expected Result is " + dbValue + " " + " AND "
							+ "Actual Result is" + " " + Value + "]", "PASS", true);

				} else {
					Log(tagname + "  is not matching " + "[" + "Expected Result is " + dbValue + " " + " AND "
							+ "Actual Result is" + " " + Value + "]", "FAIL", true);

				}

			}
		} catch (Exception e) {
			Assert.fail("Exception occured while validating the response with DB data" + e.getMessage());
		}
	}

	/**
	 * list all files in the folder
	 * 
	 * @param folder
	 * @param testID
	 * @throws Exception
	 */

	public void listAllFiles(File folder, String testID, String service,String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listAllFiles(file, testID, service,env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						sheetTabName = testID;
						jsonVal = readContent(file, service);
						if (!(jsonVal.contains("errorCode"))) {
							jsonVal = jsonVal.replace(" \",", "\",");
							jsonVal = jsonVal.replace("\"claimLineReasonDetails\" : [ {", "");
							jsonVal = jsonVal.replace("     } ]},", "");
							// jsonVal = jsonVal.replace(" ", "");
							// jsonVal = jsonVal.replace(" ", "");
							// jsonVal = jsonVal.replace(" ", "");
							// jsonVal = jsonVal.replace(" ", "");

						}
						ValidateMethods.validateViewClaims(jsonVal, testID, env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
		// return jsonVal;
	}

	/**
	 * Read only the response from the file
	 * 
	 * @param file
	 * @return
	 * @throws Exception
	 */

	public static String readContent(File file, String service) throws Exception {
		String line = null;
		String str = null;
		String json1 = null;
		int lineNumber = 0;
		String word = "---------------- Response --------------------------";
		int num = 0;
		int lineNo = 0;
		ArrayList<String> fileContent = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			// Read lines from the file, returns null when end of stream
			// is reached
			while ((line = br.readLine()) != null) {
				lineNumber++;
				if (word.equals(line)) {
					num = lineNumber;

				}
			}
			br.close();
		}
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			// Read lines from the file, returns null when end of stream
			// is reached
			while ((str = br.readLine()) != null) {
				lineNo++;
				if (lineNo >= num) {
					fileContent.add(str);

				}
			}
			String sub = fileContent.toString();
			// fileContent.clear();
			 if(service.equalsIgnoreCase("EDIEligibility")) {
					json1 = sub.substring(sub.indexOf('<'), sub.lastIndexOf("Envelope>"));
				}
			 else if (!((service.equalsIgnoreCase("PCP")) ||(service.equalsIgnoreCase("FindPCP")) || (service.equalsIgnoreCase("Communication"))
					|| (service.equalsIgnoreCase("Username")) || service.equalsIgnoreCase("Registration")
					|| service.equalsIgnoreCase("IDCard") || service.equalsIgnoreCase("Benefits"))) {
				json1 = sub.substring(sub.indexOf('{'), sub.lastIndexOf(' '));

			} else if ((service.equalsIgnoreCase("Username")) || (service.equalsIgnoreCase("Registration"))
					|| service.equalsIgnoreCase("IDCard")) {
				json1 = sub.substring(sub.lastIndexOf('{'), sub.lastIndexOf(']'));
			} else if (service.equalsIgnoreCase("Benefits")) {
				json1 = sub.substring(sub.indexOf('{'), sub.lastIndexOf(']'));
			}
			

			else {
				if (!(sub.contains("rrorCode"))) {
					json1 = sub.substring(sub.lastIndexOf('['), sub.lastIndexOf(']'));
				} else {
					json1 = sub.substring(sub.indexOf('{'), sub.lastIndexOf(' '));
				}
			}
			json1 = json1.replace("],", "]}");
			json1 = json1.replaceAll(",,", ",");
			json1 = json1.replace("{,", "{");
			json1 = json1.replaceAll(",   }", "}");
			json1 = json1.replaceAll("\\s+$", "");
			json1 = json1.replace(", }", "}");

			br.close();
		}
		return json1;
	}

	/**
	 * Read all files in the directory
	 * 
	 * @param directoryName
	 * @return files
	 * @throws IOException
	 */

	public static String[] Allfiles(String directoryName) throws IOException {
		Stream<Path> walk = Files.walk(Paths.get(directoryName));

		List<String> result = walk.map(x -> x.toString()).filter(f -> f.endsWith(".txt")).collect(Collectors.toList());

		ArrayList<String> Filename = new ArrayList<String>();
		Filename.addAll(result);
		String[] Files = Filename.toArray(new String[Filename.size()]);
		return Files;
	}

	/**
	 * Method to Set Test Data File
	 * 
	 * @param strFile
	 *            - Test Data File name with out extension
	 */
	public static boolean bErrorfound;
	static DataTable1 dt;

	public static void SetTestDataFile(DataTable1 dttestdata) throws Exception {

		try {
			// Log("Setting Test Data File - " + dttestdata, "DONE", false);
			dt = dttestdata;
		} catch (Exception e) {
			e.printStackTrace();
			Log("Could not Set Test Data File - " + dttestdata, "FAIL", false);
		}
	}

	/**
	 * This method is used to Remove the files
	 * 
	 * @param folder
	 *            = file path
	 * @throws Exception
	 */

	public static void removeFiles(File folder, String filename) throws Exception {
		String temp = "";
		File[] fileNames = folder.listFiles();
		int size = fileNames.length;
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				removeFiles(file,filename);
			} else {
					temp = file.getName();
					if (temp.contains(filename+"-")) {
						file.delete();
						}

			}
		}
	}

	/**
	 * This method is used to create a report path
	 * 
	 * @return
	 */
	public static String createNewReportPath() {
		// Create report path if does not exist
		File reportPath = new File(Environment.get("report_path"));
		String path = "";
		if (reportPath.exists()) {
			if (!reportPath.isDirectory()) {
				try {
					reportPath.mkdir();
				} catch (SecurityException se) {
					Reporting.report("FAIL",
							"Security exception while creating report path.  Please check if the user has valid rights!");
				}
			}
		} else {
			try {
				reportPath.mkdir();
			} catch (SecurityException se) {
				Reporting.report("FAIL",
						"Security exception while creating report path.  Please check if the user has valid rights!");
			}
		}

		path = createNewScreenPath();
		return path;

	}

	/**
	 * This method is used to create new screen path inside the report folder
	 */
	public static String createNewScreenPath() {
		// Create report path if does not exist
		File reportPath = new File(Environment.get("report_path") + "/responsedata");
		String path = "";
		if (reportPath.exists()) {
			if (!reportPath.isDirectory()) {
				try {
					reportPath.mkdir();
					path = reportPath.getPath();
				} catch (SecurityException se) {
					Reporting.report("FAIL",
							"Security exception while creating report path.  Please check if the user has valid rights!");
				}
			}
		} else {
			try {
				reportPath.mkdir();
				path = reportPath.getPath();
			} catch (SecurityException se) {
				Reporting.report("FAIL",
						"Security exception while creating report path.  Please check if the user has valid rights!");
			}
		}
		return path;

	}

	/**
	 * 
	 * @param parameterKey
	 *            = Key name
	 * @param object
	 *            = Object value
	 * @param colNum
	 *            = column number
	 * @param ReportFilePath
	 *            = Excel report file path
	 * @throws IOException
	 */
	public static void setCellData(String parameterKey, Object object, int colNum, String ReportFilePath)
			throws IOException {

		File src = new File(ReportFilePath);
		FileInputStream fis = new FileInputStream(src);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet Sheet1 = wb.getSheet(sheetTabName);
		
		int rowLenth = Sheet1.getLastRowNum() - Sheet1.getFirstRowNum();

		for (int i = 0; i < rowLenth + 1; i++) {
			Row row = Sheet1.getRow(i);
			for (int j = 0; j < row.getLastCellNum(); j++) {
				if (row.getCell(0).getStringCellValue().equalsIgnoreCase(parameterKey)) {

					Sheet1.getRow(i).createCell(colNum).setCellValue(object.toString());

				}

			}
		}
		FileOutputStream fout = new FileOutputStream(src);
		wb.write(fout);
		fout.flush();
		fout.close();
	}

	/**
	 * This method is used to read only the JSON response data from the notepad
	 * files
	 * 
	 * @param folder
	 *            = file path of the notepad files
	 * @param testID
	 *            = TestCase ID
	 * @param service
	 *            = service name
	 * @throws Exception
	 */
	public void listPCPFiles(File folder, String testID, String service, String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listPCPFiles(file, testID, service,env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						sheetTabName = testID;
						jsonVal = readContent(file, service);
						if (!(jsonVal.contains("errorCode"))) {
							jsonVal = jsonVal.replace("[", "{\"PCP\":[");
							jsonVal = jsonVal.replace("]", "] }");
							// jsonVal = jsonVal.replaceAll("\t", "");
							jsonVal = jsonVal.replace("\" \"", "\"\"");
							jsonVal = jsonVal.replaceAll("          ", "");
						}
						System.out.println(jsonVal);
						ValidateMethods.validateGetPCP(jsonVal, testID,env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
	}

	/**
	 * This method is used to read only the JSON response data from the notepad
	 * files
	 * 
	 * @param folder
	 *            = file path of the notepad files
	 * @param testID
	 *            = TestCase ID
	 * @param service
	 *            = service name
	 * @throws Exception
	 */
	public void listAllFindClaimsFiles(File folder, String testID, String service,String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listAllFindClaimsFiles(file, testID, service,env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						sheetTabName = testID;
						jsonVal = readContent(file, service);
						if (!(jsonVal.contains("errorCode"))) {
							jsonVal = jsonVal.replace(" \",", "\",");
						}
						ValidateMethods.validateFindClaims(jsonVal, testID,env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
		// return jsonVal;
	}

	/**
	 * This method is used to read only the JSON response data from the notepad
	 * files
	 * 
	 * @param folder
	 *            = file path of the notepad files
	 * @param testID
	 *            = TestCase ID
	 * @param service
	 *            = service name
	 * @throws Exception
	 */
	public void listFindPCPFiles(File folder, String testID, String service, String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listFindPCPFiles(file, testID, service,env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						sheetTabName = testID;
						jsonVal = readContent(file, service);
						
						  if(!(jsonVal.contains("errorCode"))) { 
							  jsonVal = jsonVal.replace("[","{\"PCP\":[");
							  jsonVal = jsonVal.replace("]", "] }"); 
							  jsonVal = jsonVal.replace("\t", ""); 
							  jsonVal = jsonVal.replace(": \" \"",":\"\"");
							  jsonVal = jsonVal.replace("}} ","");
							  }
						 
						System.out.println(jsonVal);
						ValidateMethods.validateFindPCP(jsonVal, testID, env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
	}

	public void listEDIEligOrchFiles(File folder, String testID, String service, String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listEDIEligOrchFiles(file, testID, service,env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						sheetTabName = testID;
						jsonVal = readContent(file, service);
						
						jsonVal = jsonVal.replace("<![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
						jsonVal = jsonVal.replace("]]>", "");
						jsonVal = jsonVal.replace("</soapenv:", "</soapenv:Envelope>");
						  /*if(!(jsonVal.contains("errorCode"))) { 
							  jsonVal = jsonVal.replace("[","{\"PCP\":[");
							  jsonVal = jsonVal.replace("]", "] }"); 
							  jsonVal = jsonVal.replace("\t", ""); 
							  jsonVal = jsonVal.replace(": \" \"",":\"\"");
							  jsonVal = jsonVal.replace("}} ","");
							  }*/
						 
						System.out.println(jsonVal);
						ValidateMethods.validateEDIEligibilityOrch(jsonVal, testID, env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
	}

	/**
	 * This method is used to read only the JSON response data from the notepad
	 * files
	 * 
	 * @param folder
	 *            = file path of the notepad files
	 * @param testID
	 *            = TestCase ID
	 * @param service
	 *            = service name
	 * @throws Exception
	 */
	public void listUpdatePCPFiles(File folder, String testID, String service, String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listUpdatePCPFiles(file, testID, service, env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						jsonVal = readContent(file, service);
						ValidateMethods.validateUpdatePCP(jsonVal, testID, env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
	}

	/**
	 * This method is used to read only the JSON response data from the notepad
	 * files
	 * 
	 * @param folder
	 *            = file path of the notepad files
	 * @param testID
	 *            = TestCase ID
	 * @param service
	 *            = service name
	 * @throws Exception
	 */
	public void listGetMemberFiles(File folder, String testID, String service, String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listGetMemberFiles(file, testID, service, env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						sheetTabName = testID;
						jsonVal = readContent(file, service);
						if (jsonVal.endsWith(",")) {

							jsonVal = jsonVal.substring(0, jsonVal.length() - 1) + "}";
							jsonVal = jsonVal.replace("]}", "]");
						}
						jsonVal = jsonVal.replace(": \" \"", ":\"\"");
						System.out.println("JSOn : " + jsonVal);
						ValidateMethods.validateGetMember(jsonVal, testID, env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
	}

	/**
	 * This method is used to read only the JSON response data from the notepad
	 * files
	 * 
	 * @param folder
	 *            = file path of the notepad files
	 * @param testID
	 *            = TestCase ID
	 * @param service
	 *            = service name
	 * @throws Exception
	 */
	public void listUpdateMemberFiles(File folder, String testID, String service, String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listUpdateMemberFiles(file, testID, service, env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						jsonVal = readContent(file, service);
						ValidateMethods.validateUpdateMember(jsonVal, testID, env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
	}

	/**
	 * This method is used to read only the JSON response data from the notepad
	 * files
	 * 
	 * @param folder
	 *            = file path of the notepad files
	 * @param testID
	 *            = TestCase ID
	 * @param service
	 *            = service name
	 * @throws Exception
	 */

	public void listGetCommunicationFiles(File folder, String testID, String service,String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listGetCommunicationFiles(file, testID, service,env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						sheetTabName = testID;
						jsonVal = readContent(file, service);
						if (!(jsonVal.contains("errorCode"))) {
							jsonVal = jsonVal.replace("[", "{\"COMM\":[");
							jsonVal = jsonVal.replace("]", "] }");
							// jsonVal = jsonVal.replace("\" \"", "\"\"");
							// jsonVal = jsonVal.replaceAll(" ", "");
							jsonVal = jsonVal.replace(", }", " }");
							jsonVal = jsonVal.replace("    ", "");
							jsonVal = jsonVal.replace(" \",", "\",");
						}
						ValidateMethods.validateGetCommunication(jsonVal, testID,env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
		// return jsonVal;
	}

	/**
	 * This method will validate one DB Value with one JSON Response for different
	 * keys
	 * 
	 * @param db_data
	 *            = DB data
	 * @param tagname
	 *            = key name
	 * @param Value
	 *            = value of the object
	 * @return
	 */

	public static void validateTag1(org.json.JSONArray map, String tagname, Object Value, String ReportFilePath,
			Map<String, String> map1, org.json.JSONArray mapCount) {

		boolean flag = false;
		boolean flag1 = true;
		String dbValue = null;

		try {
			org.json.JSONObject elements1 = mapCount.getJSONObject(0);
			for (int i = 0; i < map.length(); i++) {
				org.json.JSONObject elements = map.getJSONObject(i);
				Iterator key = elements.keys();
				while (key.hasNext()) {
					if (elements.has(tagname) || elements1.has(tagname)) {
						if (Value != null) {
							String value = Value.toString().trim();
							if (value.length() >= 2 && value.charAt(value.length() - 2) == '.') {
								value = value.concat("0");
							}
							if (!tagname.contains("claimsCount")) {
							UtilMethod.setCellData(tagname, elements.getString(tagname), 2, ReportFilePath);
							} else {
								UtilMethod.setCellData(tagname, elements1.getString(tagname), 2, ReportFilePath);
							}
							if (!tagname.equalsIgnoreCase("claimsCount")) {
								if (elements.getString(tagname).trim().equalsIgnoreCase(value)) {
									
									flag = true;
									dbValue = elements.getString(tagname).trim();
									break;
								} else {
									dbValue = elements.getString(tagname).trim();
									break;
								}
							} else {
								if (elements1.getString(tagname).trim().equalsIgnoreCase(value)) {
									flag = true;
									dbValue = elements1.getString(tagname).trim();
									break;
								} else {
									dbValue = elements1.getString(tagname).trim();
									break;
								}

							}
						} else {
							Log("Cannot validate this " + tagname + " tag with DB as it is having null value", "FAIL",
									true);
							flag1 = false;
							break;
						}
					} else {
						if (map1.containsKey(tagname)) {
							if (map1.containsKey("claimType")) {
								String xyz = map1.get("claimType").replace("','", ",");
								map1.put("claimType", xyz);
							}
							if (Value.toString().trim().equalsIgnoreCase(map1.get(tagname))) {
			                  UtilMethod.setCellData(tagname,  map1.get(tagname), 2, ReportFilePath);			
								flag = true;
								dbValue = map1.get(tagname).trim();
								break;
							} else {
								dbValue = map1.get(tagname).trim();
								break;
							}
						} else {
							Assert.done(tagname + " is not available in the dbdata, so we are not validating this tag");
							flag1 = false;
							break;
						}

					}
				}
			}
			if (flag1) {
				if (flag) {
					Log(tagname + " is matching  " + "[" + "Expected Result is " + dbValue + " " + " AND "
							+ "Actual Result is" + " " + Value + "]", "PASS", true);

				} else {
					Log(tagname + "  is not matching " + "[" + "Expected Result is " + dbValue + " " + " AND "
							+ "Actual Result is" + " " + Value + "]", "FAIL", true);

				}

			}
		} catch (Exception e) {
			Assert.fail("Exception occured while validating the response with DB data" + e.getMessage());
		}
	}

	/**
	 * This method is used to read only the JSON response data from the notepad
	 * files
	 * 
	 * @param folder
	 *            = file path of the notepad files
	 * @param testID
	 *            = TestCase ID
	 * @param service
	 *            = service name
	 * @throws Exception
	 */
	public void listUpdateCommunicationFiles(File folder, String testID, String service,String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listUpdateCommunicationFiles(file, testID, service,env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						jsonVal = readContent(file, service);
						ValidateMethods.validateUpdateCommunication(jsonVal, testID,env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
	}

	/**
	 * This method is used to read only the JSON response data from the notepad
	 * files
	 * 
	 * @param folder
	 *            = file path of the notepad files
	 * @param testID
	 *            = TestCase ID
	 * @param service
	 *            = service name
	 * @throws Exception
	 */

	public void listGetUsernameFiles(File folder, String testID, String service,String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listGetUsernameFiles(file, testID, service,env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						sheetTabName = testID;
						jsonVal = readContent(file, service);
						if (!(jsonVal.contains("errorCode"))) {
							jsonVal = jsonVal.replace(" \",", "\",");
						}
						ValidateMethods.validateGetUsername(jsonVal, testID,env);
					}
				} catch (IOException e) {
					Assert.fail("No File Found");
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * This method is used to read only the JSON response data from the notepad
	 * files
	 * 
	 * @param folder
	 *            = file path of the notepad files
	 * @param testID
	 *            = TestCase ID
	 * @param service
	 *            = service name
	 * @throws Exception
	 */

	public void listSelectUsernameFiles(File folder, String testID, String service,String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listSelectUsernameFiles(file, testID, service,env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						jsonVal = readContent(file, service);
						ValidateMethods.validateSelectUsername(jsonVal, testID,env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
	}

	/**
	 * 
	 * This method is used to read only the JSON response data from the notepad
	 * files
	 * 
	 * @param folder
	 *            = file path of the notepad files
	 * @param testID
	 *            = TestCase ID
	 * @param service
	 *            = service name
	 * @throws Exception
	 */
	public void listGetRegistrationFiles(File folder, String testID, String service, String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listGetRegistrationFiles(file, testID, service, env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						sheetTabName = testID;
						jsonVal = readContent(file, service);
						jsonVal = jsonVal.replace(", }", "}");
						System.out.println(jsonVal);
						ValidateMethods.validateGetRegistrationFlag(jsonVal, testID, env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
	}

	/**
	 * This method is used to read only the JSON response data from the notepad
	 * files
	 * 
	 * @param folder
	 *            = file path of the notepad files
	 * @param testID
	 *            = TestCase ID
	 * @param service
	 *            = service name
	 * @throws Exception
	 */
	public void listUpdateRegistrationFiles(File folder, String testID, String service, String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listUpdateRegistrationFiles(file, testID, service, env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						jsonVal = readContent(file, service);
						System.out.println(jsonVal);
						ValidateMethods.validateUpdateRegistrationFlag(jsonVal, testID, env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
	}

	/**
	 * Random number generator
	 * 
	 * @param aStart
	 *            = start range
	 * @param aEnd
	 *            = end range
	 * @return
	 */
	// Get Random Integer
	public static int getRandomInteger(final long aStart, final long aEnd) {

		final Random aRandom = new Random();
		if (aStart > aEnd) {
			throw new IllegalArgumentException("Start cannot exceed End.");
		}
		// get the range ,casting to long to avoid overflow problems
		final long range = aEnd - aStart + 1;
		// Compute a fraction of the range , 0 <= frac < range
		final long fraction = (long) (range * aRandom.nextDouble());
		final int randomNumber = (int) (fraction + aStart);
		return randomNumber;
	}

	/**
	 * This method is used to read only the JSON response data from the notepad
	 * files
	 * 
	 * @param folder
	 *            = file path of the notepad files
	 * @param testID
	 *            = TestCase ID
	 * @param service
	 *            = service name
	 * @throws Exception
	 */
	public void listGetIDCard(File folder, String testID, String service, String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listGetIDCard(file, testID, service,env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						jsonVal = readContent(file, service);
						// jsonVal= jsonVal.replace("{", "ID : {");
						System.out.println("JSOn : " + jsonVal);
						ValidateMethods.validateGetIDCard(jsonVal, testID, folder, env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
	}

	/**
	 * This method is used to read only the JSON response data from the notepad
	 * files
	 * 
	 * @param folder
	 *            = file path of the notepad files
	 * @param testID
	 *            = TestCase ID
	 * @param service
	 *            = service name
	 * @throws Exception
	 */
	public void listViewIDCardStatus(File folder, String testID, String service, String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listViewIDCardStatus(file, testID, service, env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						sheetTabName = testID;
						jsonVal = readContent(file, service);
						System.out.println("JSOn : " + jsonVal);
						ValidateMethods.validateViewIDCardStatus(jsonVal, testID, env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
	}

	/**
	 * Method is used to read Static Json Response and validate it with Db data
	 * using Hash Map
	 * 
	 * @param map
	 * @param tagname
	 * @param Value
	 * @param ReportFilePath
	 * @param map1
	 */
	public static boolean compareJsonAndDbValueUsingMap(org.json.JSONArray map, String tagname, Object Value,
			String ReportFilePath, Map<String, String> map1) {

		boolean flag = false;
		boolean flag1 = true;
		String dbValue = null;

		try {
			Outerloop: for (int i = 0; i < map.length(); i++) {
				org.json.JSONObject elements = map.getJSONObject(i);
				Iterator key = elements.keys();
				while (key.hasNext()) {
					if (map1.containsKey(tagname)) {
						if (tagname.contains("Timestamp")) {

							DateFormat formatter = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");
							Date date = (Date) formatter.parse((String) Value);
							// System.out.println(date);

							DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
							String formatedDate = dateFormat.format(date);
							Value = formatedDate;
						}
						if (Value.toString().trim().equalsIgnoreCase(map1.get(tagname))) {
							flag = true;
							dbValue = map1.get(tagname).trim();
							break Outerloop;
						} else {
							dbValue = map1.get(tagname).trim();
							break Outerloop;
						}
					} else {
						flag1 = false;
						break;
					}
				}
			}
			if (flag1) {
				if (flag) {
					Log(tagname + " is matching  " + "[" + "Expected Result is " + dbValue + " " + " AND "
							+ "Actual Result is" + " " + Value + "]", "PASS", true);

				} else {
					Log(tagname + "  is not matching " + "[" + "Expected Result is " + dbValue + " " + " AND "
							+ "Actual Result is" + " " + Value + "]", "FAIL", true);
				}
			}
		} catch (Exception e) {
			Assert.fail("Exception occured while validating the response with DB data" + e.getMessage());
		}
		return flag;
	}

	/**
	 * This method is used to read only the JSON response data from the notepad
	 * files
	 * 
	 * @param folder
	 *            = file path of the notepad files
	 * @param testID
	 *            = TestCase ID
	 * @param service
	 *            = service name
	 * @throws Exception
	 */

	public void listValidateAndOrderIDCard(File folder, String testID, String service,String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listValidateAndOrderIDCard(file, testID, service,env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						jsonVal = readContent(file, service);
						ValidateMethods.ValidateAndOrderIDCard(jsonVal, testID,env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.done("No File Found");
					e.printStackTrace();
				}

			}
		}
	}

	/**
	 * This method is used to read only the JSON response data from the notepad
	 * files
	 * 
	 * @param folder
	 *            = file path of the notepad files
	 * @param testID
	 *            = TestCase ID
	 * @param service
	 *            = service name
	 * @throws Exception
	 */

	public void listGetMemberBenefitsFiles(File folder, String testID, String service, String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listGetMemberBenefitsFiles(file, testID, service, env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						sheetTabName = testID;
						jsonVal = readContent(file, service);
						jsonVal = jsonVal.replace("} ]}", "}]");
						System.out.println(jsonVal);
						ValidateMethods.validateGetMemberBenefits(jsonVal, testID, env);

					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
	}

	/**
	 * This method is used to read only the JSON response data from the notepad
	 * files
	 * 
	 * @param folder
	 *            = file path of the notepad files
	 * @param testID
	 *            = TestCase ID
	 * @param service
	 *            = service name
	 * @throws Exception
	 */
	public void listGetBenefitsListFiles(File folder, String testID, String service, String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listGetBenefitsListFiles(file, testID, service, env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						sheetTabName = testID;
						jsonVal = readContent(file, service);
						jsonVal = jsonVal.replace("]}", "]");
						System.out.println(jsonVal);

						ValidateMethods.validateGetBenefitsList(jsonVal, testID,env); 
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
	}

	public static void validateDynamicTag(org.json.JSONArray map, String tagname, Object Value, int col,
			String ReportFilePath) {

		boolean flag = false;
		boolean flag1 = true;
		String dbValue = null;
		String value = null;

		try {
			outerloop: for (int i = 0; i < map.length(); i++) {
				org.json.JSONObject elements = map.getJSONObject(i);
				Iterator key = elements.keys();
				while (key.hasNext()) {
					if (elements.has(tagname)) {
						if (Value != null) {
							value = Value.toString().trim();
							if (!(tagname.equalsIgnoreCase("Accrual") | tagname.equalsIgnoreCase("Remaining")
									| tagname.equalsIgnoreCase("Maximum")
									| tagname.equalsIgnoreCase("DisplayAccrual"))) {
								if (value.length() >= 2 && value.charAt(value.length() - 2) == '.') {
									if (!elements.has("lastLoginDate")) {
										value = value.concat("0");
									}
								}

							}

							UtilMethod.setCellData(tagname, elements.getString(tagname), col, ReportFilePath);
							if (elements.getString(tagname).trim().equalsIgnoreCase(value)) {
								flag = true;
								dbValue = elements.getString(tagname).trim();
								break outerloop;
							} else {
								dbValue = elements.getString(tagname).trim();
								break outerloop;
							}
						} else {
							dbValue = elements.get(tagname).toString();
							if (dbValue.equalsIgnoreCase("null")) {
								Log(tagname + " tag with DB  is having null value", "PASS", true);
								flag1 = false;
								break outerloop;
							} else {
								// Assert.done("Cannot validate this " + tagname + " tag with DB as it is having
								// null value");
								Log("Cannot validate this " + tagname + " tag with DB as it is having null value",
										"FAIL", true);
								flag1 = false;
								break outerloop;
							}
						}

					} else {
						Assert.done(tagname + " is not available in the dbdata, so we are not validating this tag");
						flag1 = false;
						break outerloop;
					}
				}
			}
			if (flag1) {
				if (dbValue.contains("$")) {
					dbValue = dbValue.replace("$", "#");
				}
				if (value.toString().contains("$")) {
					value = value.toString().replace("$", "#");
				}
				if (flag) {

					Log(tagname + " is matching  " + "[" + "Expected Result is " + dbValue + " " + " AND "
							+ "Actual Result is" + " " + value + "]", "PASS", true);

				} else {
					Log(tagname + "  is not matching " + "[" + "Expected Result is " + dbValue + " " + " AND "
							+ "Actual Result is" + " " + value + "]", "FAIL", true);

				}

			}
		} catch (Exception e) {
			Assert.fail("Exception occured while validating the response with DB data" + e.getMessage());
		}
	}

	/*
	 * list all files in the folder
	 * 
	 * @param folder
	 * 
	 * @param testID
	 * 
	 * @throws Exception
	 */

	public void listGetAccumulator(File folder, String testID, String service,String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listGetAccumulator(file, testID, service,env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						sheetTabName = testID;
						jsonVal = readContent(file, service);
						if (!(jsonVal.contains("errorCode"))) {
							jsonVal = jsonVal.replace(" \",", "\",");
							jsonVal = jsonVal.replace("\"DisplayTypeOutputSet\" : {", "");
							jsonVal = jsonVal.replace("}} ]}", "} ]}");
						}
						ValidateMethods.validateGetAccumulator(jsonVal, testID,env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
		// return jsonVal;
	}

	/**
	 * This method will validate one DB Value with one JSON Response for different
	 * keys
	 * 
	 * @param db_data
	 *            = DB data
	 * @param tagname
	 *            = key name
	 * @param Value
	 *            = value of the object
	 * @return
	 */

	public static void validateStaticFieldWithDbUsingMap(org.json.JSONArray map, String tagname, Object Value,
			String ReportFilePath, Map<String, String> map1) {

		boolean flag = false;
		boolean flag1 = true;
		String dbValue = null;
		String value = null;
		try {
			outerloop: for (int i = 0; i < map.length(); i++) {
				org.json.JSONObject elements = map.getJSONObject(i);
				Iterator key = elements.keys();
				while (key.hasNext()) {
					if (elements.has(tagname)) {
						if (Value != null) {
							value = Value.toString().trim();
							if (value.length() >= 2 && value.charAt(value.length() - 2) == '.') {
								value = value.concat("0");
							}

							UtilMethod.setCellData(tagname, elements.getString(tagname), 2, ReportFilePath);

							if (elements.getString(tagname).trim().equalsIgnoreCase(value)) {
								flag = true;
								dbValue = elements.getString(tagname).trim();
								break;
							} else {
								dbValue = elements.getString(tagname).trim();
								break;
							}
						} else {
							Log("Cannot validate this " + tagname + " tag with DB as it is having null value", "FAIL",
									true);
							flag1 = false;
							break;
						}
					} else {
						if (map1.containsKey(tagname)) {
							value = Value.toString().trim();
							if (value.length() >= 2 && value.charAt(value.length() - 2) == '.') {
								value = value.concat("0");
							}
							 UtilMethod.setCellData(tagname, map1.get(tagname), 2, ReportFilePath);
							if (value.toString().trim().equalsIgnoreCase(map1.get(tagname))) {
								flag = true;
								dbValue = map1.get(tagname).trim();
								break;
							} else {
								dbValue = map1.get(tagname).trim();
								break;
							}
						} else {
							Assert.done(tagname + " is not available in the dbdata, so we are not validating this tag");
							flag1 = false;
							break;
						}

					}
				}
			}
			if (flag1) {
				if (flag) {
					Log(tagname + " is matching  " + "[" + "Expected Result is " + dbValue + " " + " AND "
							+ "Actual Result is" + " " + value + "]", "PASS", true);

				} else {
					Log(tagname + "  is not matching " + "[" + "Expected Result is " + dbValue + " " + " AND "
							+ "Actual Result is" + " " + value + "]", "FAIL", true);

				}

			}
		} catch (Exception e) {
			Assert.fail("Exception occured while validating the response with DB data" + e.getMessage());
		}
	}

	/**
	 * This method will validate one DB Value with one JSON Response
	 * 
	 * @param db_data
	 * @param tagname
	 * @param Value
	 * @param map1
	 * @return
	 */
	public static void validateJSONObjectUsingMaps(Map<String, Object> db_data, String tagname, Object Value,
			int colNum, String ReportFilePath, Map<String, String> map1) {

		boolean flag = false;
		boolean flag1 = true;
		String dbValue = null;
		String value = null;
		try {

			if (db_data.containsKey(tagname)) {
				if (Value != null) {
					value = Value.toString().trim();
					if (value.length() >= 2 && value.charAt(value.length() - 2) == '.') {
						value = value.concat("0");
					}
					UtilMethod.setCellData(tagname, value, colNum, ReportFilePath);
					if (db_data.get(tagname).toString().trim().startsWith(value)) {
						flag = true;
						dbValue = db_data.get(tagname).toString().trim();
					}

				} else {
					// Assert.done("Cannot validate this " + tagname + " tag with DB as it is having
					// null value");
					Log("Cannot validate this " + tagname + " tag with DB as it is having null value", "FAIL", true);
					flag1 = false;
				}

			} else {

				if (map1.containsKey(tagname)) {

					UtilMethod.setCellData(tagname, Value, colNum, ReportFilePath);
					if (Value.toString().trim().equalsIgnoreCase(map1.get(tagname))) {
						flag = true;
						dbValue = map1.get(tagname).trim();
						value = Value.toString().trim();
					} else {
						dbValue = map1.get(tagname).trim();
						value = Value.toString().trim();
					}

				} else {
					Assert.done(tagname + " is not available in the dbdata, so we are not validating this tag");
					flag1 = false;

				}
			}

			if (flag1) {
				if (dbValue.contains("$")) {
					dbValue = dbValue.replace("$", "#").trim();
				}
				if (value.toString().contains("$")) {
					value = value.toString().replace("$", "#").trim();
				}
				if (flag) {

					Log(tagname + " is matching " + " [ " + " Expected Result is " + dbValue + " " + " AND "
							+ "Actual Result is" + " " + value + " ] ", "PASS", true);
				} else {

					Log(tagname + "  is not matching " + " [ " + "Expected Result is " + dbValue + " AND "
							+ "Actual Result is" + " " + value + " ] ", "FAIL", true);
				}

			}
		} catch (Exception e) {

			Assert.fail("Exception occured while validating the response with DB data" + e.getMessage());
		}

	}

	/*
	 * list all files in the folder
	 * 
	 * @param folder
	 * 
	 * @param testID
	 * 
	 * @throws Exception
	 */

	public void listGetAccumulatorBreakdown(File folder, String testID, String service,String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listGetAccumulator(file, testID, service,env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						sheetTabName = testID;
						jsonVal = readContent(file, service);
						if (!(jsonVal.contains("errorCode"))) {
							jsonVal = jsonVal.replace(" \",", "\",");
						}
						ValidateMethods.validateGetAccumulatorBreakdown(jsonVal, testID,env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
		// return jsonVal;
	}

	/**
	 * This method will validate one DB Value with one JSON Response
	 * 
	 * @param db_data
	 * @param tagname
	 * @param Value
	 * @return
	 */
	public static void validateJSONObjectAccum(Map<String, Object> db_data, String tagname, Object Value, int colNum,
			String ReportFilePath, String showSensitivityIndicator, String accumulatorMethodology,
			String isSensitiveIndicator) {

		boolean flag = false;
		boolean flag1 = true;
		String dbValue = null;
		String value = null;
		try {

			if (db_data.containsKey(tagname) && !(tagname.equalsIgnoreCase("ClaimServiceProviderName"))) {
				if (Value != null) {
					value = Value.toString().trim();
					if (!(tagname.equalsIgnoreCase("ClaimStartDateOfService")
							|| tagname.equalsIgnoreCase("ClaimEndDateOfService")
							|| tagname.equalsIgnoreCase("ClaimAdjudicationDate"))) {
						if (value.length() >= 2 && value.charAt(value.length() - 2) == '.') {
							value = value.concat("0");
						}

					}
					if ((tagname.equalsIgnoreCase("ClaimStartDateOfService")
							|| tagname.equalsIgnoreCase("ClaimEndDateOfService")
							|| tagname.equalsIgnoreCase("ClaimAdjudicationDate"))) {

						// String[] date = { "ClaimStartDateOfService", "ClaimEndDateOfService",
						// "ClaimAdjudicationDate" };

						// for (int i = 0; i < date.length; i++) {
						if (db_data.get(tagname).equals(null)) {
							db_data.replace(tagname, "");
						} else {
							if (db_data.get(tagname).equals(" ")) {
								db_data.replace(tagname, "");
							} else {
								Object oldDate = db_data.get(tagname);
								String changedDate = oldDate.toString();
								String finalDate = changedDate.substring(0, 10);
								db_data.replace(tagname, finalDate);
							}
						}
						// }

					}

					/*
					 * String[] date = { "ClaimStartDateOfService", "ClaimEndDateOfService",
					 * "ClaimAdjudicationDate" };
					 * 
					 * // for (int i = 0; i < date.length; i++) { if
					 * (db_data.get(tagname).equals(null)) { db_data.replace(tagname, ""); } else {
					 * Object oldDate = db_data.get(tagname); String changedDate =
					 * oldDate.toString(); String finalDate = changedDate.substring(0,10);
					 * db_data.replace(tagname, finalDate); } // }
					 * 
					 * }
					 */

					if (tagname.equalsIgnoreCase("ResponseValue")) {
						Object firstResponse = db_data.get("ResponseValue");
						double doubleResponse = Double.parseDouble((String) firstResponse);
						DecimalFormat sksks = new DecimalFormat("##.00");
						String finalResponse = sksks.format(doubleResponse);
						db_data.replace("ResponseValue", finalResponse);
					}

					if (!(tagname.equalsIgnoreCase("DisplayResponseValue")

							|| (tagname.equalsIgnoreCase("DisplayResponseDescription"))
									&& (isSensitiveIndicator.equalsIgnoreCase("Y"))
									&& (showSensitivityIndicator.equalsIgnoreCase("L")))) {
						UtilMethod.setCellData(tagname, value, colNum, ReportFilePath);
						if (db_data.get(tagname).toString().trim().equalsIgnoreCase(value)) {
							flag = true;
							dbValue = db_data.get(tagname).toString().trim();
						} else {
							dbValue = db_data.get(tagname).toString().trim();
						}
					} else {

						if (!(showSensitivityIndicator.equalsIgnoreCase("L")
								&& (isSensitiveIndicator.equalsIgnoreCase("Y"))
								&& (tagname.equalsIgnoreCase("DisplayResponseDescription")))) {
							dbValue = db_data.get(tagname).toString().trim();
							if (!((accumulatorMethodology.equalsIgnoreCase("ACQTY"))
									|| (showSensitivityIndicator.equalsIgnoreCase("Y"))
											&& (accumulatorMethodology.equalsIgnoreCase("2PER"))
									|| (showSensitivityIndicator.equalsIgnoreCase("Y"))
											&& (accumulatorMethodology.equalsIgnoreCase("3PER")))) {

								double dbValues = Double.parseDouble(dbValue);
								NumberFormat formatter = NumberFormat.getCurrencyInstance();
								dbValue = formatter.format(dbValues);
							}

							if (accumulatorMethodology.equalsIgnoreCase("ACQTY")
									&& (tagname.equalsIgnoreCase("DisplayResponseValue"))) {
								if (!(showSensitivityIndicator.equalsIgnoreCase("N"))
										&& (isSensitiveIndicator.equalsIgnoreCase("Y"))) {
									double dbValues = Double.parseDouble(dbValue);
									DecimalFormat newValue = new DecimalFormat("#");
									dbValue = newValue.format(dbValues);
								}
							}
						} else {
							dbValue = "NA";
						}
						UtilMethod.setCellData(tagname, value, colNum, ReportFilePath);
						if (dbValue.equalsIgnoreCase(value)) {
							flag = true;
						} else {
							String dbNewValue = dbValue;
							dbValue = dbNewValue;
						}

					}

				} else {

					Log("Cannot validate this " + tagname + " tag with DB as it is having null value", "FAIL", true);
					flag1 = false;
				}

			} else {
				Assert.done(tagname + " is not available in the dbdata, so we are not validating this tag");
				flag1 = false;

			}

			if (flag1) {

				if (dbValue.contains("$")) {
					dbValue = dbValue.replace("$", "#").trim();
				}
				if (value.toString().contains("$")) {
					value = value.toString().replace("$", "#").trim();
				}

				if (flag) {

					Log(tagname + " is matching " + " [ " + " Expected Result is " + dbValue + " " + " AND "
							+ "Actual Result is" + " " + value + " ] ", "PASS", true);

				} else {
					// dbValue = db_data.get(tagname).toString().trim();
					Log(tagname + "  is not matching " + " [ " + "Expected Result is " + dbValue + " AND "
							+ "Actual Result is" + " " + value + " ] ", "FAIL", true);
				}

			}
		} catch (Exception e) {
			Assert.fail("Exception occured while validating the response with DB data" + e.getMessage());
		}

	}
	public void listGetCDHPSummary(File folder, String testID, String service, String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		String JSONResponse[]=null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listGetCDHPSummary(file, testID, service, env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID+"-")) {
						sheetTabName = testID;
						jsonVal = readContent(file,service);
						if(jsonVal.endsWith(","))
						{                           

							jsonVal = jsonVal.substring(0, jsonVal.length()-1)+"}";
						//	JSONResponse=jsonVal.split("TotalDisbursableBal");
							} 
						//jsonVal=JSONResponse[0];
							ValidateMethods.validateGetCDHPSummary(jsonVal,testID, env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}}}
	public void listGetCDHPTransaction(File folder, String testID, String service, String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		String JSONResponse[]=null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listGetCDHPTransaction(file, testID, service, env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID+"-")) {
						sheetTabName = testID;
						jsonVal = readContent(file,service);
						if(jsonVal.endsWith(","))
						{                           

							jsonVal = jsonVal.substring(0, jsonVal.length()-1)+"}";
							jsonVal = jsonVal.replace("]}", "]");
						//	JSONResponse=jsonVal.split("TotalDisbursableBal");
							} 
						//jsonVal=JSONResponse[0];
							ValidateMethods.validateGetCDHPTransaction(jsonVal,testID, env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}}}
	public static String readXMLContent(File file, String service) throws Exception {
		String line = null;
		String str = null;
		String json1 = null;
		int lineNumber = 0;
		String word = "---------------- Response --------------------------";
		int num = 0;
		int lineNo = 0;
		ArrayList<String> fileContent = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			// Read lines from the file, returns null when end of stream
			// is reached
			while ((line = br.readLine()) != null) {
				lineNumber++;
				if (word.equals(line)) {
					num = lineNumber;

				}
			}
			br.close();
		}
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			// Read lines from the file, returns null when end of stream
			// is reached
			while ((str = br.readLine()) != null) {
				lineNo++;
				if (lineNo >= num) {
					fileContent.add(str);

				}
			}
			String sub = fileContent.toString();
			json1 = sub.substring(sub.indexOf('<'), sub.lastIndexOf("Envelope>"));
			json1 = json1.replaceAll("\\s+$", "");
			json1 = json1.replace("]]>", "");
			json1 = json1.replace("</soapenv:", "</soapenv:Envelope>");
			if(service.equalsIgnoreCase("ViewIDCardBenefits")) {
				if(json1.contains("<Body>")) {
			json1 = json1.substring(json1.indexOf("<Body>"),json1.indexOf("</Body>"));
			json1 = json1 + "</Body>";
				}
			}
			else if(service.equalsIgnoreCase("ViewMemberAccount")){
				json1 = json1.substring(json1.indexOf("<tns:FacetsBody>"),json1.indexOf("</tns:ViewMemberAccountOutput>"));
				//json1 = json1 + "</tns:FacetsBody>";
				json1 = json1.replace("tns:", "");
				
			}
			br.close();
		}
		return json1;
	}
	
	public void listViewIDCardBenefitsFiles(File folder, String testID, String service, String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listViewIDCardBenefitsFiles(file, testID, service,env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						sheetTabName = testID;
						jsonVal = readXMLContent(file, service);
												 						 
						System.out.println(jsonVal);
						ValidateMethods.validateViewIDCardBenefits(jsonVal, testID, env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
	}
	
	public void listViewMemberAccountFiles(File folder, String testID, String service, String env) throws Exception {
		String temp = "";
		String jsonVal = null;
		File[] fileNames = folder.listFiles();
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				listViewIDCardBenefitsFiles(file, testID, service,env);
			} else {
				try {
					temp = file.getName();
					if (temp.contains(testID + "-")) {
						sheetTabName = testID;
						jsonVal = readXMLContent(file, service);
												 						 
						System.out.println(jsonVal);
						ValidateMethods.validateViewMemberAccount(jsonVal, testID, env);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Assert.fail("No File Found");
					e.printStackTrace();
				}

			}
		}
	}

}
