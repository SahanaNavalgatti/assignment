package org.bcbsri.selfservice.commonMethods;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;

import com.dell.acoe.framework.config.Environment;

import org.apache.poi.ss.usermodel.*;

	 
	
public class TestDataGenerator {
	     
	    public static void export(String SubscriberID, String productID) {
	        String jdbcURL = "jdbc:sqlserver://bmdctwvsqldb13;databaseName=EDR_Data_Minor";
	        String username = "svctstsqldb";
	        String password = "Selfproj123#";
	 
	        //String excelFilePath = "I:\\status\\TestingAutomation\\ProjectTestAutomation\\Pravisha\\resources\\testdata\\BenefitsTestdata\\MemberBenefits.xls";
	        String excelFilePath = Environment.get("Benefits_testData_Path");
	        
	        try (Connection connection = DriverManager.getConnection(jdbcURL, username, password)) {
	            //String sql = "SELECT top 10 * from SS_SQL.MEMBER_PROFILE";
	            String sql = "SELECT DISTINCT top 10 Test_Description = 'View the Category Level benfits of the subscriber',UserID = 'CHNLESBMEP',MP.SUBSCRIBER_ID AS SubscriberID," + 
	            		"MP.DEPENDENT_ID AS DependentID, MP.LEGACY_MEME_CK AS MemberContrivedKey, ProductType = 'MEDICAL'," + 
	            		"PR.PDPD_ID AS ProductID,ViewAsDate = Convert(DATE,MPE.BENEFIT_START_DATE),SensitivityIndicator = 'N', InternalMessages ='Y'," + 
	            		"ProcessType = 'C',ServiceReferenceID = '',BenefitPackageDisplayID = '',BCR.CATEGORY_REF_ID AS ServiceCategoryID, " + 
	            		"RequestedNetwork = 'A',CoverageTier = 'A',AccumulatorIndicator = '' " + 
	            		"FROM " + 
	            		"SS_SQL.MEMBER_PLAN_ELIGIBILITY MPE, SS_SQL.MEMBER_PROFILE MP, " + 
	            		"SS_SQL.MEMBER_PLAN_PACKAGES MPP, SS_SQL.PRODUCTS_REF PR," + 
	            		"SS_SQL.BR_CATEGORY_SERVICE_XREF BCSX, SS_SQL.BR_SERVICE_REF BSR, " + 
	            		"SS_SQL.BENEFIT_SERVICES_DISPLAY BSD, SS_SQL.BR_CATEGORY_REF BCR " + 
	            		"WHERE " + 
	            		"MPE.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID " + 
	            		"AND MP.MEMBER_PROFILE_ID =  MPP.MEMBER_PROFILE_ID " + 
	            		"AND MPP.LEGACY_PRODUCT_ID = PR.PDPD_ID " + 
	            		"AND MPP.BR_PACKAGE_ID = BSD.BR_PACKAGE_ID " + 
	            		"AND BCSX.SERVICE_REF_ID = BSR.SERVICE_REF_ID " + 
	            		"AND BCSX.SERVICE_REF_ID = BSD.SERVICE_REF_ID  " + 
	            		"AND BCSX.CATEGORY_REF_ID = BCR.CATEGORY_REF_ID " + 
	            		"AND MP.SUBSCRIBER_ID = '"+SubscriberID+"' " + 
	            		"AND MPE.BENEFIT_START_DATE BETWEEN MPE.BENEFIT_START_DATE AND MPE.BENEFIT_END_DATE " + 
	            		"AND MPE.BENEFIT_START_DATE BETWEEN BSD.EFFECTIVE_DATE AND BSD.TERM_DATE " + 
	            		"AND PR.PDPD_ID = '"+productID+"'";
	 
	            Statement statement = connection.createStatement();
	 
	            ResultSet result = statement.executeQuery(sql);
	 
	            HSSFWorkbook workbook = new HSSFWorkbook();
	            HSSFSheet sheet = workbook.createSheet("GetMemberBenefits");
	 
	            writeHeaderLine(sheet);
	 
	            writeDataLines(result, workbook, sheet);
	 
	            FileOutputStream outputStream = new FileOutputStream(excelFilePath);
	            workbook.write(outputStream);
	            workbook.close();
	 
	            statement.close();
	 
	        } catch (SQLException e) {
	            System.out.println("Datababse error:");
	            e.printStackTrace();
	        } catch (IOException e) {
	            System.out.println("File IO error:");
	            e.printStackTrace();
	        }
	    }
	 
	    private static void writeHeaderLine(HSSFSheet sheet) {
	 
	        Row headerRow = sheet.createRow(0);
	 
	        Cell headerCell = headerRow.createCell(0);
	        headerCell.setCellValue("TestID");
	        headerCell = headerRow.createCell(1);
	        headerCell.setCellValue("Test_Description");
	 
	        headerCell = headerRow.createCell(2);
	        headerCell.setCellValue("UserID");
	 
	        headerCell = headerRow.createCell(3);
	        headerCell.setCellValue("SubscriberID");
	 
	        headerCell = headerRow.createCell(4);
	        headerCell.setCellValue("DependentID");
	        
	        headerCell = headerRow.createCell(5);
	        headerCell.setCellValue("MemberContrivedKey");
	        
	        headerCell = headerRow.createCell(6);
	        headerCell.setCellValue("ProductType");
	        
	        headerCell = headerRow.createCell(7);
	        headerCell.setCellValue("ProductID");
	        
	        headerCell = headerRow.createCell(8);
	        headerCell.setCellValue("ViewAsDate");

	        headerCell = headerRow.createCell(9);
	        headerCell.setCellValue("SensitivityIndicator");
	        	        
	        headerCell = headerRow.createCell(10);
	        headerCell.setCellValue("InternalMessages");

	        headerCell = headerRow.createCell(11);
	        headerCell.setCellValue("ProcessType");
	        
	        headerCell = headerRow.createCell(12);
	        headerCell.setCellValue("ServiceReferenceID");

	        headerCell = headerRow.createCell(13);
	        headerCell.setCellValue("BenefitPackageDisplayID");
	        
	        headerCell = headerRow.createCell(14);
	        headerCell.setCellValue("ServiceCategoryID");

	        headerCell = headerRow.createCell(15);
	        headerCell.setCellValue("RequestedNetwork");
	        
	        headerCell = headerRow.createCell(16);
	        headerCell.setCellValue("CoverageTier");

	        headerCell = headerRow.createCell(17);
	        headerCell.setCellValue("AccumulatorIndicator");
	 
	    }
	 
	    private static void writeDataLines(ResultSet result, HSSFWorkbook workbook,
	            HSSFSheet sheet) throws SQLException {
	        int rowCount = 1;
	        int i =0;
	        String testID = "";
	       
	        	
	        while (result.next()) {
	        	 
	        	testID = "GetMemberBenefits-"+i;
	        	String testDesc =  result.getString("Test_Description");
	        	String userID = result.getString("UserID");
	            String subscriberID = result.getString("SubscriberID");
	            String dependentID = result.getString("DependentID");
	            String memeCK = result.getString("MemberContrivedKey");
	            String productType = result.getString("ProductType");
	            String productID = result.getString("ProductID");
	            String viewAsDate = result.getString("ViewAsDate");
	            String sensitivityIndicator = result.getString("SensitivityIndicator");
	            String internalMessages = result.getString("InternalMessages");
	            String processType = result.getString("ProcessType");
	            String serviceReferenceID = result.getString("ServiceReferenceID");
	            String benefitPackageDisplayID = result.getString("BenefitPackageDisplayID");
	            String categoryID = result.getString("ServiceCategoryID");
	            String requestedNetwork = result.getString("RequestedNetwork");
	            String coverageTier = result.getString("CoverageTier");
	            String accumulatorIndicator = result.getString("AccumulatorIndicator");
	 
	            Row row = sheet.createRow(rowCount++);
	 
	            int columnCount = 0;
	            Cell cell = row.createCell(columnCount++);
	            cell.setCellValue(testID);
	            
	            cell = row.createCell(columnCount++);
	            cell.setCellValue(testDesc);
	            
	            cell = row.createCell(columnCount++);
	            cell.setCellValue(userID);
	            
	            cell = row.createCell(columnCount++);
	            cell.setCellValue(subscriberID);
	            
	            cell = row.createCell(columnCount++);
	            cell.setCellValue(dependentID);
	            
	            cell = row.createCell(columnCount++);
	            cell.setCellValue(memeCK);
	            
	            cell = row.createCell(columnCount++);
	            cell.setCellValue(productType);
	            
	            cell = row.createCell(columnCount++);
	            cell.setCellValue(productID);
	            
	            cell = row.createCell(columnCount++);
	            cell.setCellValue(viewAsDate);
	            
	            cell = row.createCell(columnCount++);
	            cell.setCellValue(sensitivityIndicator);
	            
	            cell = row.createCell(columnCount++);
	            cell.setCellValue(internalMessages);
	            
	            cell = row.createCell(columnCount++);
	            cell.setCellValue(processType);
	            
	            cell = row.createCell(columnCount++);
	            cell.setCellValue(serviceReferenceID);
	            
	            cell = row.createCell(columnCount++);
	            cell.setCellValue(benefitPackageDisplayID);
	            
	            cell = row.createCell(columnCount++);
	            cell.setCellValue(categoryID);
	            
	            cell = row.createCell(columnCount++);
	            cell.setCellValue(requestedNetwork);
	            
	            cell = row.createCell(columnCount++);
	            cell.setCellValue(coverageTier);
	            
	            cell = row.createCell(columnCount++);
	            cell.setCellValue(accumulatorIndicator);
	            i++;
	 
	 
	    }
	        System.out.println("Completed");
	 
	}
	   

}
