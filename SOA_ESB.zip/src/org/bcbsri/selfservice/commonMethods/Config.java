package org.bcbsri.selfservice.commonMethods;

import com.dell.acoe.framework.config.Environment;
/**
 * 
 * @author prm4tso
 * 
 * endpointDev = Dev endpoint
 * endpointMinor = Minor endpoint
 * endpointMajor = Major endpoint
 * xmlFile = SoapUI XML File path
 * testSuite = Service name
 * testCase = Environment name ( Ex: Dev, Minor or Major)
 *
 */
public class Config {

	public static String endpointDev = "";
	public static String endpointMinor = "";
	public static String endpointMajor = "";
	public static String xmlFile = "";
	public static String MinorXmlFile="";
	public static String testSuite = "";
	public static String testCase = "";
	
	public static void init_GetClaims(){			
		
		Config.endpointDev = Environment.get("Test_Dev_Endpoint");
		Config.endpointMinor = Environment.get("Test_Minor_Endpoint");
		Config.endpointMajor = Environment.get("Test_Major_Endpoint");
		Config.MinorXmlFile = Environment.get("Claims_minor_XML");
		Config.xmlFile = Environment.get("GetClaims_XML");
        Config.testSuite = "GetClaimDetails"; // should update the service name
        Config.testCase = "Minor";  //should update the Environment name
        
	}
	public static void init_getPCPDetails() {
		
		Config.endpointDev = Environment.get("Test_Dev_Endpoint");
		Config.endpointMinor = Environment.get("Test_Minor_Endpoint");
		Config.endpointMajor = Environment.get("Test_Major_Endpoint");
        Config.xmlFile = Environment.get("GetPCP_XML");
        Config.testSuite = "GetPCPDetails"; // should update the service name
        Config.testCase = "Minor";
		
	}
	public static void init_findClaims(){			
		
		Config.endpointDev = Environment.get("Test_Dev_Endpoint");
		Config.endpointMinor = Environment.get("Test_Minor_Endpoint");
		Config.endpointMajor = Environment.get("Test_Major_Endpoint");
		Config.MinorXmlFile = Environment.get("Find_Claims_minor_XML");
		Config.xmlFile = Environment.get("FindClaims_XML");
        Config.testSuite = "FindClaims"; // should update the service name
        Config.testCase = "Minor";  //should update the Environment name
        
	}
	public static void init_findPCP() {
	
		Config.endpointDev = Environment.get("Test_Dev_Endpoint");
		Config.endpointMinor = Environment.get("Test_Minor_Endpoint");
		Config.endpointMajor = Environment.get("Test_Major_Endpoint");
	    Config.xmlFile = Environment.get("FindPCP_XML");
	    Config.testSuite = "FindPCP"; 
	    Config.testCase = "Minor";
	
	}
	public static void init_updatePCP() {
		
		Config.endpointDev = Environment.get("Test_Dev_Endpoint");
		Config.endpointMinor = Environment.get("Test_Minor_Endpoint1");
		Config.endpointMajor = Environment.get("Test_Major_Endpoint");
	    Config.xmlFile = Environment.get("UpdatePCP_XML");
	    Config.testSuite = "UpdatePCP"; 
	    Config.testCase = "Minor";
		
	}
	
public static void init_getMemberDemographics() {
		
		Config.endpointDev = Environment.get("Test_Dev_Endpoint");
		Config.endpointMinor = Environment.get("Test_Minor_Endpoint");
		Config.endpointMajor = Environment.get("Test_Major_Endpoint");
        Config.xmlFile = Environment.get("GetMember_XML");
        Config.testSuite = "GetMemberDemo"; // should update the service name
        Config.testCase = "Minor";
		
	}

public static void init_updateMemberDemographics() {
	
	Config.endpointDev = Environment.get("Test_Dev_Endpoint");
	Config.endpointMinor = Environment.get("Test_Minor_Endpoint");
	Config.endpointMajor = Environment.get("Test_Major_Endpoint");
    Config.xmlFile = Environment.get("UpdateMemberDemoMinor_XML");
    Config.testSuite = "UpdateMemberDemo"; 
    Config.testCase = "Minor";
	
}
public static void init_getCommunicationPreference() {
	
	Config.endpointDev = Environment.get("Test_Dev_Endpoint");
	Config.endpointMinor = Environment.get("Test_Minor_Endpoint1");
	Config.endpointMajor = Environment.get("Test_Major_Endpoint");
    Config.xmlFile = Environment.get("GetCommunication_XML");
    Config.testSuite = "GetCommunication"; // should update the service name
    Config.testCase = "Minor";
	
}


public static void init_updateCommunication() {
	
	Config.endpointDev = Environment.get("Test_Dev_Endpoint");
	Config.endpointMinor = Environment.get("Test_Minor_Endpoint1");
	Config.endpointMajor = Environment.get("Test_Major_Endpoint");
    Config.xmlFile = Environment.get("UpdateCommunication_XML");
    Config.testSuite = "UpdateCommunication"; 
    Config.testCase = "Minor";
	
}

public static void init_GetUsername() {
	
	Config.endpointDev = Environment.get("Test_Dev_Endpoint");
	Config.endpointMinor = Environment.get("Test_Minor_Endpoint1");
	Config.endpointMajor = Environment.get("Test_Major_Endpoint");
    Config.xmlFile = Environment.get("GetUsername_XML");
    Config.testSuite = "GetUsername"; 
    Config.testCase = "Minor";
	
}

public static void init_SelectUsername() {
	
	Config.endpointDev = Environment.get("Test_Dev_Endpoint");
	Config.endpointMinor = Environment.get("Test_Minor_Endpoint1");
	Config.endpointMajor = Environment.get("Test_Major_Endpoint");
    Config.xmlFile = Environment.get("SelectUsername_XML");
    Config.testSuite = "SelectUsername"; 
    Config.testCase = "Minor";
	
}

public static void init_getRegistrationFlag() {
	
	Config.endpointDev = Environment.get("Test_Dev_Endpoint");
	Config.endpointMinor = Environment.get("Test_Minor_Endpoint1");
	Config.endpointMajor = Environment.get("Test_Major_Endpoint");
    Config.xmlFile = Environment.get("GetRegistration_XML");
    Config.testSuite = "GetRegistrationFlag"; 
    Config.testCase = "Minor";
	
}

public static void init_updateRegistrationFlag() {
	
	Config.endpointDev = Environment.get("Test_Dev_Endpoint");
	Config.endpointMinor = Environment.get("Test_Minor_Endpoint");
	Config.endpointMajor = Environment.get("Test_Major_Endpoint");
    Config.xmlFile = Environment.get("UpdateRegistration_XML");
    Config.testSuite = "UpdateRegistrationFlag"; 
    Config.testCase = "Minor";
	
}

public static void init_getIDCard() {
	
	Config.endpointDev = Environment.get("Test_Dev_Endpoint");
	Config.endpointMinor = Environment.get("Test_Minor_Endpoint1");
	Config.endpointMajor = Environment.get("Test_Major_Endpoint");
    Config.xmlFile = Environment.get("GetIDCard_XML");
    Config.testSuite = "GetIDCard"; 
    Config.testCase = "Minor";
	
}

public static void init_viewIDCardStatus() {
	
	Config.endpointDev = Environment.get("Test_Dev_Endpoint");
	Config.endpointMinor = Environment.get("Test_Minor_Endpoint");
	Config.endpointMajor = Environment.get("Test_Major_Endpoint");
    Config.xmlFile = Environment.get("ViewIDCardStatus_XML");
    Config.testSuite = "ViewIDCardStatus"; 
    Config.testCase = "Minor";
	
}

public static void init_ValidateAndOrderIDCard() {
	
	Config.endpointDev = Environment.get("Test_Dev_Endpoint");
	Config.endpointMinor = Environment.get("Test_Minor_Endpoint1");
	Config.endpointMajor = Environment.get("Test_Major_Endpoint");
    Config.xmlFile = Environment.get("ValidateAndOrderIDCard_XML");
    Config.testSuite = "ValidateAndOrderIDCard"; 
    Config.testCase = "Minor";
	
}

public static void init_getMemberBenefits() {
	
	Config.endpointDev = Environment.get("Test_Dev_Endpoint");
	Config.endpointMinor = Environment.get("Test_Minor_Endpoint1");
	Config.endpointMajor = Environment.get("Test_Major_Endpoint");
    Config.xmlFile = Environment.get("GetMemberBenefits_XML");
    Config.testSuite = "GetMemberBenefits"; // should update the service name
    Config.testCase = "Minor";
	
}

public static void init_getBenefitsList() {
	
	Config.endpointDev = Environment.get("Test_Dev_Endpoint");
	Config.endpointMinor = Environment.get("Test_Minor_Endpoint1");
	Config.endpointMajor = Environment.get("Test_Major_Endpoint");
    Config.xmlFile = Environment.get("GetBenefitsList_XML");
    Config.testSuite = "GetBenefitsList"; // should update the service name
    Config.testCase = "Minor";
	
}


public static void init_getAccumulator() {
	
	Config.endpointDev = Environment.get("Test_Dev_Endpoint");
	Config.endpointMinor = Environment.get("Test_Minor_Endpoint1");
	Config.endpointMajor = Environment.get("Test_Major_Endpoint");
    Config.xmlFile = Environment.get("GetAccumulator_XML");
    Config.testSuite = "GetAccumulator"; 
    Config.testCase = "Minor";
	
}


public static void init_getAccumulatorBreakdown() {
	
	Config.endpointDev = Environment.get("Test_Dev_Endpoint");
	Config.endpointMinor = Environment.get("Test_Minor_Endpoint1");
	Config.endpointMajor = Environment.get("Test_Major_Endpoint");
    Config.xmlFile = Environment.get("GetAccumulatorBreakdown_XML");
    Config.testSuite = "GetAccumulatorBreakdown"; 
    Config.testCase = "Minor";
	
}

public static void init_getCDHPSummary() {

Config.endpointDev = Environment.get("Test_Dev_Endpoint");
Config.endpointMinor = Environment.get("Test_Minor_Endpoint1");
Config.endpointMajor = Environment.get("Test_Major_Endpoint");
Config.xmlFile = Environment.get("GetCDHPSummary_XML");
Config.testSuite = "GetCDHPSummary"; // should update the service name
Config.testCase = "Minor";

}
public static void init_getCDHPTransaction() {

Config.endpointDev = Environment.get("Test_Dev_Endpoint");
Config.endpointMinor = Environment.get("Test_Minor_Endpoint1");
Config.endpointMajor = Environment.get("Test_Major_Endpoint");
Config.xmlFile = Environment.get("GetCDHPTransaction_XML");
Config.testSuite = "GetCDHPTransaction"; // should update the service name
Config.testCase = "Minor";

}


}
