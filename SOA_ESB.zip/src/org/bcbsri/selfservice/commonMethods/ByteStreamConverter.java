package org.bcbsri.selfservice.commonMethods;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Base64;

import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.selenium.verify.Assert;
public class ByteStreamConverter {
/** This method is used to convert the byteStream data to respective image format files.
 * 
 * @param testID = TestCase ID
 * @param byteStream = byteStream Array
 * @param folder = File path of the PDF files
 * @param imgFormat = Image format
 */
      
      public static void imgformatConverter(String testID,String byteStream,File folder, String imgFormat){
    	  //The File  Name should be  on  Scenario ID name  
    	 // String file_path = Environment.get("RedCard.PDFFileCopiedTo");
        File file = new File(folder+"/"+testID+"."+imgFormat);

        try ( FileOutputStream fos = new FileOutputStream(file); ) {

          byte[] decoder = Base64.getDecoder().decode(byteStream);
          fos.write(decoder);
          Assert.pass(imgFormat +" Format File Saved!!!");
        } catch (Exception e) {
          e.printStackTrace();
        }
      }


}
