package org.bcbsri.selfservice.commonMethods;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;

import com.dell.acoe.framework.selenium.verify.Assert;

public class PDFIDPages {

	public static ArrayList<Integer> getIDPages(String pdfFile, String section) throws InvalidPasswordException, IOException {
		ArrayList<Integer> IDPages = new ArrayList<Integer>();
		
		PDDocument document = PDDocument.load(new File(pdfFile));
		int pageCount = document.getNumberOfPages();
		PDFTextStripper stripper = new PDFTextStripper();
		for(int i=0; i<pageCount; i++) {
			stripper.setSortByPosition( true );
			stripper.setStartPage(i);
			stripper.setEndPage(i);
			String content = stripper.getText(document);
			if(content.contains(section)) {
				IDPages.add(Integer.valueOf(i));
			}
		}
		
		return IDPages;
	}
	public static int getIDPagesNumber(String pdfFile, String section , String subsection) throws InvalidPasswordException, IOException {
//		ArrayList<Integer> IDPages = new ArrayList<Integer>();
		int pagenumber = 0;
		int flag=0;
		PDDocument document = PDDocument.load(new File(pdfFile));
		int pageCount = document.getNumberOfPages();
		PDFTextStripper stripper = new PDFTextStripper();
		for(int i=0; i<pageCount; i++) {
			stripper.setSortByPosition( true );
			stripper.setStartPage(i);
			stripper.setEndPage(i);
			String content = stripper.getText(document);
			content = content.replaceAll("\\n", " ");
			if(content.contains(subsection.toUpperCase())) {
//				IDPages.add(Integer.valueOf(i));
				flag=1;
				pagenumber=i;
				break;
			}
		}
		if(flag==0)
			Assert.fail(section+" was not not generated");
		else
			Assert.pass(section+"  was generated in the card ");
		return pagenumber;
	}
	
	public static int getIDPageForSection(ArrayList<Integer> claimPages, int sectionPage) {
		int summaryPageNumber = 0;
		for(int i=0; i<claimPages.size(); i++) {
			if(claimPages.get(i) < sectionPage) {
				summaryPageNumber = claimPages.get(i);
			}else {
				break;
			}
			
		}
		return summaryPageNumber;
	}	
}
