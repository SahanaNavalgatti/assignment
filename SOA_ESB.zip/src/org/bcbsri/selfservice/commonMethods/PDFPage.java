package org.bcbsri.selfservice.commonMethods;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentInformation;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;

public class PDFPage {
String pdfCoumentWithPath;
	
	public PDFPage(String pdfCoumentWithPath) {
		this.pdfCoumentWithPath = pdfCoumentWithPath;
	}	

	public int getPageCount() {
		int pageCount = -1;
		try {
			PDDocument document = PDDocument.load(new File(pdfCoumentWithPath));
			PDFTextStripper stripper = new PDFTextStripper();
			stripper.setSortByPosition( true );
			pageCount = document.getNumberOfPages();
		} catch (InvalidPasswordException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}		
		return pageCount;
	}
	
	public String getTextContent() {
		String content = "Exception Occured while reaading PDF";
		try {
			PDDocument document = PDDocument.load(new File(pdfCoumentWithPath));
			PDFTextStripper stripper = new PDFTextStripper();
			stripper.setSortByPosition( true );
			content = stripper.getText(document);
		} catch (InvalidPasswordException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return content;
	}
	

	public String getTextContent(int pageNumber) {
		String content = "Exception Occured while reaading PDF";
		try {
			PDDocument document = PDDocument.load(new File(pdfCoumentWithPath));
			PDFTextStripper stripper = new PDFTextStripper();
			stripper.setSortByPosition( true );
			stripper.setStartPage(pageNumber);
	        stripper.setEndPage(pageNumber);
			content = stripper.getText(document);
		} catch (InvalidPasswordException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return content;
	}
	

	public String getTextContent(int pageNumberFrom, int pageNumberTo) {
		String content = "Exception Occured while reaading PDF";
		try {
			PDDocument document = PDDocument.load(new File(pdfCoumentWithPath));
			PDFTextStripper stripper = new PDFTextStripper();
			stripper.setSortByPosition( true );
			stripper.setStartPage(pageNumberFrom);
	        stripper.setEndPage(pageNumberTo);
			content = stripper.getText(document);
		} catch (InvalidPasswordException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return content;
	}	
	
	public PDDocumentInformation getDocumentInformation() {
		PDDocument document = null;
		try {
			document = PDDocument.load(new File(pdfCoumentWithPath));
		} catch (InvalidPasswordException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return document.getDocumentInformation();
	}
}
