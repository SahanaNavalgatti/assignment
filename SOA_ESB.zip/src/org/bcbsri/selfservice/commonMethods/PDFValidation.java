package org.bcbsri.selfservice.commonMethods;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.selenium.verify.Assert;

public class PDFValidation {

	public static void runPDFValidation(String testcasedID,String SubID, String ProductValue, File folder,String fullname, String firstname ) {
		try {
			 System.out.println("SubscriberID "+SubID);
			 int IDPageNumber ;
			String dir=folder.getPath();
			//File folder = new File(filePath);
			File[] fList = folder.listFiles();
			System.out.println("File Lenght:"+fList.length);
			int j = 0;
			int IDPagenumber = 0;
			for (int i = 0; i < fList.length; i++) {
                File pes = fList[i];
                String Filename=pes.getName();
                if(Filename.contains(testcasedID))
                {
                String filepath = dir+"/"+Filename;
                System.out.println("Filename:"+Filename);
			PDFPage p = new PDFPage(filepath);
			
			ArrayList<Integer> IDPages = PDFIDPages.getIDPages(filepath, firstname);
			try
			{ 
			//IDPageNumber = PDFIDPages.getIDPageForSection(IDPages, IDPages.get(0));
			
			IDPagenumber=PDFIDPages.getIDPagesNumber(filepath, fullname,firstname);
			IDPagenumber=PDFIDPages.getIDPagesNumber(filepath, SubID,SubID);
				
			}
			catch(IndexOutOfBoundsException e)
			{
				continue;
			}
			


			//ProofIDCardPageDetails.VerifyCardType(filepath, IDPagenumber,CardType);
			VerifyProductType(filepath, IDPagenumber,ProductValue);

			}
               
                else
                	continue;
                }
			
		} catch (Exception e) {
			Assert.done("FO File Validation");
			e.printStackTrace();
		}
		Assert.done("End -> File Validation Completed");
	
}
public static  void VerifyProductType(String pdfFile, int pageNumber,String card ) throws  IOException {
	Assert.done("Getting ID page data from:"+pageNumber);
	HashMap<String, String> summaryData = new HashMap<String, String>();
	PDFPage p = new PDFPage(pdfFile);
	String sPage1Content = p.getTextContent(pageNumber);
	
	String[] sPage1ContentLines = sPage1Content.split("\n", -1); 
	summaryData.put("Creation Date", sPage1ContentLines[0]);
	
try {
	sPage1Content = sPage1Content.replaceAll("\\r\\n", " ");
		if(sPage1Content.contains(card)) {
			Assert.done("Valid Product Type: "+card);

			}
//							
		}


			
		catch(Exception e){
				e.printStackTrace();
		}
	
}
}
