package org.bcbsri.selfservice.dbutility;

import java.sql.*;

import org.json.JSONArray;
import org.json.JSONObject;

import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.selenium.util.DBUtil;
import com.ntt.cryptic.aesTest;

public class ViewClaimsDBS {
	
	/**
     * Method will make DB Connection and will fetch value from data sql sever and will return it
    **/

	public static JSONArray getMemberInfofromDBS(String strQuery,String DB) throws SQLException {
		
		//org.json.simple.JSONArray json1=new JSONArray();	

		JSONArray json = new JSONArray();
		String username= "";
		String password = "";
		String pass = "";
		String devdbURL ="";
		String dbURL = "";
		String jdbcDriver= "";
		String testMinor  = Environment.get("Test_Minor_Execution");
		String testMajor = Environment.get("Test_Major_Execution");
		
		try {
			if(DB.equalsIgnoreCase("Microsoft")) {
				username = Environment.get("DB.Microsoft.SQL.Username");
				password = Environment.get("DB.Microsoft.SQL.Password");
				pass = aesTest.decrypt(password);
				devdbURL = Environment.get("DB.DevURL");
				if(testMinor.equalsIgnoreCase("Yes")) {
				dbURL = Environment.get("DB.MinorURL");
				}
				else if(testMajor.equalsIgnoreCase("Yes")){
					dbURL = Environment.get("DB.MajorURL");
				}
				jdbcDriver = Environment.get("DB.JdbcDriver");
				}
			else if(DB.equalsIgnoreCase("Sqldbx")) {
				if(testMinor.equalsIgnoreCase("Yes")) {
					username = Environment.get("DB.Sqldbx.Minor.Username");
					password = Environment.get("DB.Sqldbx.Minor.Password");
					pass = aesTest.decrypt(password);
					jdbcDriver = Environment.get("DB.Minor.JdbcDriver");
					dbURL = Environment.get("DB.MinorURL");
					
				}
				else if(testMajor.equalsIgnoreCase("Yes")){
					username = Environment.get("DB.Sqldbx.Major.Username");
					password = Environment.get("DB.Sqldbx.Major.Password");
					pass = aesTest.decrypt(password);
					jdbcDriver = Environment.get("DB.Major.JdbcDriver");
					dbURL = Environment.get("DB.MajorURL");	
				}
			}		
			else if(DB.equalsIgnoreCase("Sybase")){
				/*if(testMinor.equalsIgnoreCase("Yes")) {
				username = Environment.get("DB.Sybase.Username");
				password = Environment.get("DB.Sybase.Password");
				pass = aesTest.decrypt(password);
				dbURL = Environment.get("Sybase.MinorURL");
				jdbcDriver = Environment.get("Sybase.JdbcDriver");
				}*/
				if(testMinor.equalsIgnoreCase("Yes")) {
					username = Environment.get("DB.SSMS.Username");
					password = Environment.get("DB.SSMS.Password");
					pass = aesTest.decrypt(password);
					dbURL = Environment.get("DB.SSMS.URL");
					jdbcDriver = Environment.get("DB.SSMS.JDBCDriver");
					}
				else if(testMajor.equalsIgnoreCase("Yes")){
					username = Environment.get("DB.Sybase.Major.Username");
					password = Environment.get("DB.Sybase.Major.Password");
					pass = aesTest.decrypt(password);
					dbURL = Environment.get("Sybase.MajorURL");
					jdbcDriver = Environment.get("Sybase.JdbcDriver");	
				}
			}
			else if(DB.equalsIgnoreCase("Oracle")) {
				
				username = Environment.get("Oracle.SQL.Username");
                password = Environment.get("Oracle.SQL.Password");
                pass = aesTest.decrypt(password);
                if(testMinor.equalsIgnoreCase("Yes")) {
                	dbURL = Environment.get("Oracle.MinorURL");
               
				}
				else if(testMajor.equalsIgnoreCase("Yes")){
					
	                dbURL = Environment.get("Oracle.MajorURL");
				}
				 jdbcDriver = Environment.get("Oracle.OdbcDriver");
			}
			DBUtil.getConnection(jdbcDriver, dbURL, username, pass);
			System.out.println("SQL Query "+strQuery);
			if(strQuery.contains("Update")) {
				Connection conn = null;

				try {
					Class.forName(jdbcDriver);
					conn = DriverManager.getConnection(dbURL, username, pass);
					Statement stmt = conn.createStatement();
					stmt.executeUpdate(strQuery);
					System.out.println("Executed Query");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			else {
			ResultSet rs = DBUtil.getResultSet(jdbcDriver, dbURL, username, pass, strQuery);
			System.out.println("Executed Query");

			ResultSetMetaData metadata = rs.getMetaData();
			while (rs.next()) {
				int columnCount = metadata.getColumnCount();
				JSONObject obj = new JSONObject();

				for (int i = 1; i <= columnCount; i++) {
					String columnName = metadata.getColumnLabel(i);
					if(null != rs.getObject(columnName))
					{
						obj.put(columnName, rs.getObject(columnName).toString());
					}
					else
					{
						obj.put(columnName, JSONObject.NULL);
					}
					
				}
				json.put(obj);
				

			}

			if (json.length() > 0) {
			//System.out.println("Json String from DB:" + json.toString());
			}
			rs.close();
		}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return json;

	}
}
