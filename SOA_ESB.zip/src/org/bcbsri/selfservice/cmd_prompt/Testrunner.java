package org.bcbsri.selfservice.cmd_prompt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.bcbsri.selfservice.commonMethods.UtilMethod;

import com.dell.acoe.framework.config.Environment;

public class Testrunner {

	public static void launchRunner(String files_path,String endpoint,String xmlFile,String testSuite, String testCase) {
		String path="";
		String testdatapath="";
		String testfilename="";
		String env = "";
		if(Environment.get("Test_Minor_Execution").equalsIgnoreCase("Yes")) {
			env = "testMinor";
			//xmlFile = Environment.get("test_data_path")+"\\"+env+"\\"+xmlFile;	
		
		}
		else if(Environment.get("Test_Major_Execution").equalsIgnoreCase("Yes")) {
			env = "testMajor";
		//	xmlFile = Environment.get("test_data_path")+"/"+env+xmlFile;
		}
		
		if (testSuite.equalsIgnoreCase("getclaimdetails")||testSuite.equalsIgnoreCase("findclaims")) {
			testfilename = "Claims";
		}
		else if (testSuite.equalsIgnoreCase("GetBenefitsList")) {
			testfilename = "GetBenefitsList";
		}
		else if(testSuite.equalsIgnoreCase("getpcpdetails")||testSuite.equalsIgnoreCase("findpcp")||testSuite.equalsIgnoreCase("UpdatePCP")) {
			testfilename = "PCP";
		}
		else if(testSuite.equalsIgnoreCase("GetIDCard")|| testSuite.equalsIgnoreCase("ViewIDCardStatus")) {
			testfilename = "IDCard";
		}
		else  if(testSuite.equalsIgnoreCase("ValidateAndOrderIDCard")) {
			testfilename = "ValidateAndOrderIDCard";
		}
		else if(testSuite.equalsIgnoreCase("GetCommunication")|| testSuite.equalsIgnoreCase("UpdateCommunication")) {
			testfilename = "Communication";
		}
		else if(testSuite.equalsIgnoreCase("GetUsername")||testSuite.equalsIgnoreCase("SelectUsername")) {
			testfilename = "Username_Latest";
		}
		else if(testSuite.equalsIgnoreCase("GetRegistrationFlag") || testSuite.equalsIgnoreCase("UpdateRegistrationFlag")) {
			testfilename = "RegistrationFlag";
		}
		else if(testSuite.equalsIgnoreCase("GetMemberBenefits")) {
			testfilename = "MemberBenefits";
		}
		else if(testSuite.equalsIgnoreCase("GetAccumulator")|| testSuite.equalsIgnoreCase("GetAccumulatorBreakdown")) {
			testfilename = "GetAccumulator";
		}
		else if(testSuite.equalsIgnoreCase("GetCDHPSummary")) {
			testfilename = "CDHPSummary";
		}
		else if(testSuite.equalsIgnoreCase("GetCDHPTransaction")) {
			testfilename = "CDHPTransaction";
		}
		else if(testSuite.equalsIgnoreCase("GetMemberDemo")|| testSuite.equalsIgnoreCase("UpdateMember")) {
			testfilename = "Member";
		}
		
		testdatapath = Environment.get("test_data_path")+"/"+env+"/"+testfilename+".xls";
		
		//testdatapath = "C:\\Users\\svc-user-auto\\Documents\\selfserviceautomation\\SelfService\\resources\\testdata\\claimsTestData\\Claims.xls";
		String[] command =
	    {
	        "cmd",
	    };
	    Process p;{
		try {
			p = Runtime.getRuntime().exec(command);
		        new Thread(new SyncPipe(p.getErrorStream(), System.err)).start();
	                new Thread(new SyncPipe(p.getInputStream(), System.out)).start();
	                PrintWriter stdin = new PrintWriter(p.getOutputStream());
	                stdin.println("cd /d C:\\Windows");
	                //stdin.println("cd C:\\Program Files (x86)\\SmartBear\\SoapUI-5.5.0\\bin");
	                //stdin.println("cd C:\\Program Files\\SmartBear\\SoapUI-5.5.0\\SoapUI-5.5.0\\bin");
					stdin.println("cd C:\\Users\\svc-user-auto\\Documents\\SmartBear\\SoapUI-5.5.0\\bin");
	                
	                
	                stdin.println("testrunner.bat -e"+endpoint+" -s"+testSuite+" -c"+testCase+" -r -a -I -f"+files_path+" "+"-Ptestdatapath="+testdatapath+" "+xmlFile+"");
	                //stdin.println("testrunner.bat -e"+endpoint+" -s"+testSuite+" -c"+testCase+" -r -a -I -f"+files_path+" "+xmlFile+"");
	                stdin.close();
	                p.waitFor();
	               
	              
	    	} catch (Exception e) {
	 		
		}
		//return path;
}
}
}

