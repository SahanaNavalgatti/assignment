package org.bcbsri.ITSHost.dbutility;
import com.dell.acoe.framework.config.Environment;
public class Grid_Config 
{
	
	public static String Grid_TestData =Environment.get("test_data_path");
	public static String DRIVER_PATH_IE = "";
	public static String DRIVER_PATH_CHROME = "";
	public static int BROWSER_STATUS = 0;
	public static String BASE_DIR = "";
	public static String BASE_DIR_BOXI = "";
	public static String TDP = "";
	//public static String TestcaseName="TC001_Claims_Adjustment_Professional";
	public static String Grid_Mappingdata =Environment.get("test_data_path");
	public static String Grid_ReceiverPath =Environment.get("Test_Data_Receiverpath");
	//public static String TestDataSheet ="C:\\Users\\malptso\\GitLocalReposit\\BenefitGrid\\Mapping.xls";
	
	public static String TestcaseName1=Environment.get("TestcaseNo");
	public static void init()
	{
		//OracleSOA_Config.DRIVER_PATH_IE = Environment.get("DRIVER_PATH_IE");
		//OracleSOA_Config.DRIVER_PATH_CHROME = Environment.get("DRIVER_PATH_CHROME");
		Grid_Config.BASE_DIR = Environment.get("BASE_DIR");
		
		Grid_Config.TDP = Environment.get("BASE_DIR") + "/testdata/";
		
		//OracleSOA_Config.OracleSOA_TestData = OracleSOA_Config.TDP+"OracleSOA_TestData.xlsx";
		
		Grid_Config.Grid_TestData=Environment.get("Grid_Mappingdata"); 
	}


}