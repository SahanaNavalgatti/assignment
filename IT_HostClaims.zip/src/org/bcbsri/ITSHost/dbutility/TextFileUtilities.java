package org.bcbsri.ITSHost.dbutility;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.dell.acoe.framework.selenium.util.LineUtilities;
import com.dell.acoe.framework.selenium.verify.Assert;

public class TextFileUtilities {
	
	public static ArrayList<String> getDetailLines(String filePath) throws Exception {

		ArrayList<String> arrlist = null;
		try {

			Assert.done("Start->Reading files LineByLine");
			arrlist = new ArrayList<String>();
			File f = new File(filePath);
			FileReader fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);
			String s;

			while ((s = br.readLine()) != null) {
				arrlist.add(s);
				System.out.println("\n");
			}

			/*
			 * try { al.remove(al.size() - 1); } catch (Exception e) { //
			 * e.printStackTrace(); }
			 */
			br.close();
			Assert.done("End->Reading files LineByLine is done Successfully");
		} catch (Exception e) {
			Assert.error(e, "Unable to read the file");
			Log("getDetailLines", "Pass");
		}
		return arrlist;
	}

	/**
	 * Method to read text file ans store it in ArrayList
	 * 
	 * @param filePath
	 * @return
	 * @throws IOException
	 */
	public static ArrayList<String> getAllLines(String filePath) throws IOException {
		ArrayList<String> al = new ArrayList<String>();
		File f = new File(filePath);
		FileReader fr = new FileReader(f);
		BufferedReader br = new BufferedReader(fr);
		String s;

		while ((s = br.readLine()) != null) {
			al.add(s);
		}

		br.close();
		return (al);
	}

	/**
	 * Method to log results to HTML report and to console
	 * 
	 * @param strStepName
	 *            - Step description
	 * @param strResult
	 *            - PASS/FAIL/DONE
	 * @blnScreenshot - Attach screenshot? true/false
	 */
	public static void Log(String strStepName, String strResult) throws Exception {

		switch (strResult) {
		case "PASS":
			Assert.pass(strStepName);
			break;
		case "FAIL":
			Assert.fail(strStepName);
		default:
			Assert.done(strStepName);
			break;
		}
	}

}
