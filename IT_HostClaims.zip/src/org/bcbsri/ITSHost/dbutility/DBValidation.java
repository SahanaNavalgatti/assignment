package org.bcbsri.ITSHost.dbutility;

import java.sql.ResultSet;
import java.text.SimpleDateFormat;

import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.selenium.testdata.DataTable;
import com.dell.acoe.framework.selenium.testdata.DataTable1;
import com.dell.acoe.framework.selenium.util.DBUtil;
import com.dell.acoe.framework.selenium.verify.Assert;

public class DBValidation {
	private static final boolean Y = false;
	
	public static boolean ActualAgainstExpectedAccumulation(DataTable1 dt,int rownum,String ActualfromQuery,String MaximumAccumulationLimit) throws Exception
	{
		String SubscriberMetAccumsType =null;
		boolean flag = false;
		try {
			Assert.done("Start->Start ActualAgainstExpectedAccumulation validation");
				//String ActualvaluefromQuery=ActualfromQuery.trim().replace(".0000", "");
				float ActualvalueFromQuery=Float.parseFloat(ActualfromQuery);
				int ExpectedValueFromGrid=Integer.parseInt((dt.getValue(MaximumAccumulationLimit)));
			    if(MaximumAccumulationLimit.equalsIgnoreCase("Deductibles"))
			    {
			    	SubscriberMetAccumsType = "SubscriberMetDED";
			    }
			    else {
			    	SubscriberMetAccumsType = "SubscriberMetOOP";
			    }
				if(ExpectedValueFromGrid==ActualvalueFromQuery)
				{
					Assert.pass("Member has already reached the required maximum Expected Amount for "+MaximumAccumulationLimit+": where Expected Amount is :"+ExpectedValueFromGrid+" and Actual Amount : "+ActualvalueFromQuery);//Matches the expected amount ExpectedAmount 
					//boolean Returnflag=true; // Change 
					flag=true;
					dt.setValue(SubscriberMetAccumsType,rownum , "Y");
				}
				else if(ExpectedValueFromGrid>ActualvalueFromQuery)
				{
					Assert.pass("Member yet to reach the required maximum limit for "+MaximumAccumulationLimit+" : current value is : "+ActualvalueFromQuery+" out of the maximum limit of : "+ExpectedValueFromGrid);//Change
				    Float YetToReachvalue=ExpectedValueFromGrid-ActualvalueFromQuery;
					Assert.done("Member needs to Accumalate "+YetToReachvalue+ " to reach the maximum : "+MaximumAccumulationLimit);	
				//	boolean Returnflag=false;
					flag=false;
					dt.setValue(SubscriberMetAccumsType, rownum, "N");
					Assert.done("No "+MaximumAccumulationLimit+" was acculmated for the service as expected");
			}
				else if(ExpectedValueFromGrid<ActualvalueFromQuery) {
					Assert.pass("Member has already met the requirement and exceed the limit for "+MaximumAccumulationLimit+" : where Expected Amount : "+ExpectedValueFromGrid+"Actual Amount : "+ActualvalueFromQuery);//Change
					//boolean Returnflag=true;
					flag=true;
					dt.setValue(SubscriberMetAccumsType,rownum , "Y");
								}
				
			Assert.done("End-> ActualAgainstExpectedAccumulation for "+SubscriberMetAccumsType);
		}
		
		catch(Exception e)
		{
			//TextFileUtilities.Log("ValidateExcelToDatabase", "Fail");
			//e.printStackTrace();
			Assert.fail("ActualAgainstExpectedAccumulation Fail "+e.getMessage());//Change
		}
		return flag;
	}
	
	public static boolean OOPValidation(String OOPType,float BeforeOOPAmount,float MaxOOPAmount,
			float OOPAmount,float PostProcessOOPAmount,int PostprocessCopay,
			int PostprocessCoins) throws Exception///Check variables
	//OOPValidation(OOPType,PreProcessOOPAmount,MaxOOPAmount,
	//OOPAmount,PostProcessOOPAmount,MaxOOPAmount,
	//PostprocessCopay,PostprocessCoins);
	{
		boolean flag=false;
		if(BeforeOOPAmount==MaxOOPAmount) 
		{
			 Assert.done("The subscriber has already met OOP maximum amount");	
			 if(PostprocessCopay>0 && PostprocessCoins>0)//&&
	    	 {
	    		 Assert.fail("Since member has already meet limit for Expected OOP : "+MaxOOPAmount+" with Actual Amount : "+BeforeOOPAmount+" the service should not have any OOP"); 
	    	     flag=false;
	    		 return flag;
	    	 }
			 else if (PostprocessCopay==0 && PostprocessCoins==0)
	    	 {
	    		 Assert.pass("Since member has already meet limit for Actual Amount : "+MaxOOPAmount+" with Expected Amount : "+BeforeOOPAmount+ " the service should not have any OOP");
	    		 flag=true;
	    		 return flag;
	    	 } 
			 
			 else
			 {
				 Assert.fail("Since member has already meet limit for Expected OOP : "+MaxOOPAmount+" with Actual Amount : "+BeforeOOPAmount+" the service should not have any OOP but there's OOP which is not expected in form of CoPay : "+PostprocessCopay+" or CoInsurance : "+PostprocessCoins); 
	    	     flag=false;
	    		 return flag;
			 }
		}
		else if(PostprocessCopay<MaxOOPAmount || PostprocessCoins<MaxOOPAmount) //Check TotalOOPAmount
		{
			OOPAmount=PostProcessOOPAmount+PostprocessCopay+PostprocessCoins;
			if(OOPType.equalsIgnoreCase("Y"))
	    	 {
	    		 if(PostprocessCopay>0 || PostprocessCoins>0==true)
		    	 {
		    		 Assert.pass("OOP was accumulated as expected"); 
		    		 flag=true;
		    		 return flag;
		    	 }
	    		 else if (PostprocessCopay==0 && PostprocessCoins==0)
		    	 {
	    			 Assert.pass("OOP was not accumulated as expected"); 
		    		 flag=true;
		    		 return flag;
		    	 }
	    		 else
		    	 {
		    		 Assert.fail("OOP was not accumulated as expected");
		    		 flag=false;
		    		 return flag;
		    	 } 
	    	 }
	    	 else if(OOPType.equalsIgnoreCase("N"))
	    	 {
	    		 if(PostprocessCopay==0 || PostprocessCoins==0)//equal to zero
		    	 {
		    		 Assert.pass("No OOP was accumulated as expected"); 
		    	 }
	    		 else
	    		 {
	    			 Assert.fail("OOP was accumulated and is not as expected");
	    		 }
	    	 }
		}
		return flag;
	}
	/**
	 * Validation for Excel to database for Initial enrollment
	 * @param dt
	 * @param rs
	 * @throws Exception
	 */
	public static void IE_ValidateExcelToDatabase(DataTable dt,ResultSet rs) throws Exception
	{
		try {
			Assert.done("Start->Start validation");
			while(rs.next()) {
				if(dt.getValue("SubscriberID").equals(rs.getString(1)))
				{
					Assert.done("SubscriberID:"+dt);
				}
				else {
					Assert.done("Not matched");
				}
				if(dt.getValue("FirstName").equals(rs.getString(3)))
				{
					Assert.done("First name:"+dt);
				}
				if(dt.getValue("LastName").equals(rs.getString(2)))
				{
					Assert.done("Last name:"+dt);
				}

				if(dt.getValue("ProviderID").equals(rs.getString(5)))
				{
					Assert.done("ProviderID:"+dt);
				}
				if(dt.getValue("Claim_Amount").equals(rs.getString(12)))
				{
					Assert.done("ClaimAmt:"+dt);
				}

			}
			Assert.done("End->Validation Done");
		}
		catch(Exception e)
		{
			TextFileUtilities.Log("ValidateExcelToDatabase", "Fail");

		}

	}
	/**
	 * Validation for Excel to database for Commercial Enrollment
	 * @param dt
	 * @param rs
	 * @throws Exception
	 */
	public static void Commercial_ValidateExcelToDatabase(DataTable1 dt,ResultSet rs) throws Exception
	{
		
		
		
		
		
		try {
			Assert.done("Start->Validate the values from excel to database");
			if (rs.next() == false)
			{ 
				System.out.println("ResultSet in empty in Java");
			} 
			else
			{ 
				do

				{ 

					if(dt.getValue("First_Name").replaceAll("\\s","").equalsIgnoreCase(rs.getString(1).replaceAll("\\s","")))
					{
						Assert.pass("First_Name:"+dt.getValue("First_Name"));
					}
					else {
						Assert.fail("Not matched first name ");
						throw new Exception("Validation failed");
					}
					
					if(dt.getValue("Last_Name").replaceAll("\\s","").equals(rs.getString(2).replaceAll("\\s","")))
					{
						Assert.pass("Last_Name :"+dt.getValue("Last_Name"));
					}
					else {
						Assert.fail("Not matched Last name ");
						throw new Exception("Validation failed");
					}
					if(dt.getValue("Gender").replaceAll("\\s","").equals(rs.getString(3).replaceAll("\\s","")))
					{
						Assert.pass("Gender:"+dt.getValue("Gender"));
					}
					else {
						Assert.fail("Not matched Gender ");
						throw new Exception("Validation failed");
					}
					java.sql.Date dbSqlDate = rs.getDate(4);
					SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");  
					String strDate = formatter.format(dbSqlDate);
					

					if(dt.getValue("DateOfBirth").equals(strDate))
					{
						Assert.pass("DateOfBirth:"+dt.getValue("DateOfBirth"));
					}
					else {
						Assert.fail("Not matched Date of birth ");
						throw new Exception("Validation failed");
						
					}
					if(dt.getValue("Martial_Status").replaceAll("\\s","").equals(rs.getString(5).replaceAll("\\s","")))
					{
						Assert.pass("Martial_Status:"+dt.getValue("Martial_Status"));
					}
					else {
						Assert.fail("Not matched Martial status ");
						throw new Exception("Validation failed");
					}
					if(dt.getValue("Address1").replaceAll("\\s","").equals(rs.getString(6).replaceAll("\\s","")))
					{
						Assert.pass("Address1:"+dt.getValue("Address1"));
					}
					else {
						Assert.fail("Not matched Address ");
						throw new Exception("Validation failed");
					}
					if(dt.getValue("City").replaceAll("\\s","").equals(rs.getString(7).replaceAll("\\s","")))
					{
						Assert.pass("City:"+dt.getValue("City"));
					}
					else {
						Assert.fail("Not matched City");
						throw new Exception("Validation failed");
					}
					if(dt.getValue("State").replaceAll("\\s","").equals(rs.getString(8).replaceAll("\\s","")))
					{
						Assert.pass("State:"+dt.getValue("State"));
					}
					else {
						Assert.fail("Not matched State ");
						throw new Exception("Validation failed");
					}

					int zip=rs.getInt(9);
					String dbZip=Integer.toString(zip);
					String ZipCode=String.format("%05d", Integer.parseInt(dbZip));
					
					if(dt.getValue("Zip").equals(ZipCode))
					{
						Assert.pass("Zip Code:"+dt.getValue("Zip"));
					}
					else {
						Assert.fail("Not matched Zip code ");
						throw new Exception("Validation failed");
					}
					if(dt.getValue("County").replaceAll("\\s","").equals(rs.getString(10).replaceAll("\\s","")))
					{
						Assert.pass("County:"+dt.getValue("County"));
					}
					else {
						Assert.fail("Not matched County ");
						throw new Exception("Validation failed");
					}
					java.sql.Date dbEffectiveDate = rs.getDate(11);
					SimpleDateFormat formatter1 = new SimpleDateFormat("MM/dd/yyyy");  
					String EffectiveDate = formatter1.format(dbEffectiveDate);
					if(dt.getValue("Effective date").equals(EffectiveDate))
					{
						Assert.pass("Effective date:"+dt.getValue("Effectivedate"));
					}
					else {
						Assert.fail("Not matched Effective date");
						throw new Exception("Validation failed");
					}

				}
				while (rs.next());


			}
			Assert.pass("End->Validate the values from excel to database");
		}
		catch(Exception e)
		{
			Assert.fail("Validation failed as both excel sheet and database value didnt match");
			TextFileUtilities.Log("ValidateExcelToDatabase", "Fail");

		}
		finally {
			if (rs != null)
				rs.close();
		}
	}

	public static void getDetails_From_Mapping(DataTable1 dt2,String tos,String tosid) throws Exception
	{
	try {
		
	Assert.done("Current TOS Code matched from DB-> " + tos);
	String tos1 = dt2.getValue("TOS_DESC");
	
	Assert.done("Current Servivce mapped to TOS -> " + tos1);
	String proccode = dt2.getValue("PROC_CODE");
	
	Assert.done("Current procedure code mapped to TOS -> " + proccode);
	String Diagcode = dt2.getValue("DIAGNOSIS_CODE");

	Assert.done("Current Diagnosis code mapped to TOS -> " + Diagcode);
	String Revenuecode = dt2.getValue("RCRC_ID");

	
	
	
/*		String CoInsurance = dt2.getValue("CoInsurance");
	System.out.println("CoInsurance -> " + CoInsurance);
	Assert.done("Current CoInsurance mapped to TOS-> " + CoInsurance);*/
	Assert.pass("Type Of Service is present in the mapping sheet -> " + tosid);
	
	}catch(Exception e) {
		
	}

	}
	public static void Sybase_Connection() throws Exception {
		  Assert.done("Start->Sybase Execution");
		  String username = Environment.get("DB.Minor.pbm.Username");
			String password = Environment.get("DB.Minor.pbm.Password");
			String dbURL = Environment.get("DB.MinorURL");
			String jdbcDriver = Environment.get("DB.JdbcDriver");
			 
			DBUtil.getConnection(jdbcDriver, dbURL, username, password);
			System.out.println("Connection Established");
		
	}
	public static ResultSet DbExecute(String Query) throws Exception {
		ResultSet rs=null;
		try {
			String username = Environment.get("DB.Minor.pbm.Username");
			String password = Environment.get("DB.Minor.pbm.Password");
			String dbURL = Environment.get("DB.MinorURL");
			String jdbcDriver = Environment.get("DB.JdbcDriver");
			Assert.done(Query);
			rs = DBUtil.getResultSet(jdbcDriver, dbURL, username, password, Query);
			System.out.println(rs);
	    boolean value=rs.next();
	    System.out.println("Result set value " +value);
		Assert.pass( "Query executed Succesfully");
		}
		catch(Exception e)
		{
			Assert.fail("Unable to Connect to the database");
			Assert.error(e, "Unable to Connect to the database");
			TextFileUtilities.Log("DbExecute", "Fail");
		}
		return rs;
	}

}
