package org.bcbsri.ITSHost.dbutility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.dell.acoe.framework.selenium.testdata.DataTable1;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.dell.acoe.framework.config.Environment;

import com.dell.acoe.framework.selenium.util.DBUtil;
import com.dell.acoe.framework.selenium.verify.Assert;
import com.ntt.cryptic.aesTest;



public class DbUtilityConfig {
	static int count1 =0;
	public static String sheetTabName = null;
	/**
	 * Method to Fetch the data from the Sybase Database by establishing the connection
	 * @return-Returns the resultset rs
	 * @throws Exception 
	 */
	public static ResultSet DbExecute(String sqlQuery) throws Exception {
		ResultSet rs = null;
		try {
	   Assert.done("Start->Sybase Execution");
		
		  String username = Environment.get("DB.Minor.pbm.Username"); 
		  String password = Environment.get("DB.Minor.pbm.Password"); 
		  String pass=aesTest.decrypt(password);
		 
	   
		String dbURL = Environment.get("DB.MinorURL");
		String jdbcDriver = Environment.get("DB.JdbcDriver");

		
		DBUtil.getConnection(jdbcDriver, dbURL, username, pass);
		System.out.println("Connection Established");
		
		rs = DBUtil.getResultSet(jdbcDriver, dbURL, username, pass, sqlQuery);
		
		 Assert.done("JDBC Driver:"+jdbcDriver);
		 Assert.done("DB URL:"+dbURL);
		 Assert.done("SQL Query:"+sqlQuery);
		
		Assert.pass( "Connected to the database Succesfully");
		Assert.done("End->Sybase Execution");
		}
		catch(Exception e)
		{
			System.out.println(e);
			Assert.fail( "Unable to Connect to the database");
			TextFileUtilities.Log("DbExecute", "Fail");
		}
		return rs;
	}
	
	
	
	/**
	 * Method to  connect to the db and Execute Drop and Create Query
	 * @return 
	 */
	public static  String[] DbCred() throws Exception {
		ResultSet rs = null;
		
		String jdbcDriver = Environment.get("DB.JdbcDriver");
		
		
		
		
		String DB = Environment.get("Environment");
		
		String username = null;
		String pass = null;
		String dbURL = null;
		if (DB.equalsIgnoreCase("Minor")) {
			
			
			
			
			username = Environment.get("DB.Minor.pbm.Username");
			pass = Environment.get("DB.Minor.pbm.Password");
			dbURL = Environment.get("DB.MinorURL");
			try {
				pass = aesTest.decrypt(pass);
			} catch (Exception e) {
				Assert.fail("Failed to encrypt the password" + e.getMessage());
			}
			
		}else if (DB.equalsIgnoreCase("Major")) {
			
		}else if (DB.equalsIgnoreCase("DEV")) {
			
			username = Environment.get("DB.SqlDBx.Username");
			pass = Environment.get("DB.SqlDBx.Password");
			pass=aesTest.decrypt(pass);
			dbURL = Environment.get("SqlDBx.DEV2");
			
			
		}else if (DB.equalsIgnoreCase("PROD")) {
			
			username = Environment.get("DB.Prod.Username");
			pass = Environment.get("DB.Prod.Password");
			pass=aesTest.decrypt(pass);
			dbURL = Environment.get("DB.ProdURL");
		}
		
		return new String[] {dbURL, username, pass};
		
		
		
		}
	/**
	 * Method to validate Excel to database for backend validation
	 * @param sqlQuery
	 * @param SubScriberID
	 * @return
	 * @throws Exception
	 */
	/*public static ResultSet Day2_DbExecute(String Query) throws Exception {
		ResultSet rs=null;
		try {
	    Assert.done("Start->Sybase Execution");
		String username = Environment.get("DB.Minor.pbm.Username");
		String password = Environment.get("DB.Minor.pbm.Password");
		//String pass=aesTest.decrypt(password);
		String dbURL = Environment.get("DB.MinorURL");
		String jdbcDriver = Environment.get("DB.JdbcDriver");
		 

		
      
		//Query = "SELECT SBSB_ID,SBSB_LAST_NAME,SBSB_FIRST_NAME , A.CLCL_ID,A.PRPR_ID ,RCRC_ID AS Revencode,SESE_ID AS TOS, IPCD_ID AS proc_code,CDML_FROM_DT,CDML_TO_DT,CDML_CHG_AMT,CLCL_TOT_CHG FROM CMC_CDML_CL_LINE A INNER JOIN CMC_CLCL_CLAIM B ON A.CLCL_ID =B.CLCL_ID INNER JOIN CMC_SBSB_SUBSC C ON B.SBSB_CK = C.SBSB_CK WHERE SBSB_ID = '"+SubScriberID+"'";
		Assert.done(Query);
		 
		DBUtil.getConnection(jdbcDriver, dbURL, username, password);
		System.out.println("Connection Established");
		//int i = 0;
		rs = DBUtil.getResultSet(jdbcDriver, dbURL, username, password, Query);
		//ResultSet rs=null;
		
        System.out.println(rs);
        boolean value=rs.next();
        System.out.println(value);

		Assert.pass( "Connected to the database Succesfully");
		Assert.done("End->Sybase Execution");
		}
		catch(Exception e)
		{
			Assert.fail("Unable to Connect to the database");
			Assert.error(e, "Unable to Connect to the database");
			TextFileUtilities.Log("DbExecute", "Fail");
		}
		return rs;
	}
*/
	
public static DataTable1 ResultSetWriteIntoExcelSheet(ResultSet rs,DataTable1 dt) throws Exception {

		

		try {
			Assert.done("Start->Write values Into ExcelSheet from database");
do
			 {

				int rowNo =dt.rowCount;
				System.out.println("Result Set from db table:" + rs.toString());
				String Charges = rs.getString(7);
				//String CHG_AMT = Charges.replaceAll(" ", "");
				System.out.println("Charges:" + Charges);
				String Copay = rs.getString(10);
				String COP_AMT = Copay.replaceAll(" ", "");
				System.out.println("CoPay:" + COP_AMT);
				String CoIns = rs.getString(11);
				String COINS = CoIns.replaceAll(" ", "");
				System.out.println("CoInsurance :" + COINS);
				String Deductible = rs.getString(12);
				String TOT_CHG = Deductible.replaceAll(" ", "");
				System.out.println("Expected Deductibles :" + TOT_CHG);
				
				/*Assert.done("Values from database:" + "Charges:" + CHG_AMT + " " + "Copay:" + COP_AMT + " "
						+ "CoInsurance:" + COINS + "Expected Deductibles :" + TOT_CHG+"");*/

				dt.setValue("CopayAfterDeductibles", rowNo, COP_AMT);
				dt.setValue("CoInsuranceAfterDeductibles", rowNo, COINS);
				dt.setValue("ExpectedDeductibles", rowNo, TOT_CHG);

			}
while (rs.next());
			Assert.done("End->Write values Into ExcelSheet from database");
			Assert.pass("Values written into excel sheet from database successfully");

		} catch (Exception e) {
			Assert.fail("Values written into excel sheet from database fail");
			 Assert.error(e, "Unable to Write in excel Sheet");
			TextFileUtilities.Log("TextFile", "Fail");
		}
		return dt;
	}



	public static String[] ReadExcel(String ExcelFilePath,String Sheetname)  {
		String[] rowvalues = null;
		try {
		
		/*FileInputStream inputStream = new FileInputStream(ExcelFilePath);
		HSSFWorkbook wb = new HSSFWorkbook(inputStream);
		// SXSSFWorkbook wb = new SXSSFWorkbook(workbook);
		HSSFSheet sheet = wb.getSheetAt(0);*/
			
		FileInputStream inputStream = new FileInputStream(new File(ExcelFilePath));
		XSSFWorkbook wb = new XSSFWorkbook(inputStream);
		XSSFSheet sheet = wb.getSheet(Sheetname);
		int rowcount = sheet.getLastRowNum();
		String arr = null;
		for (int i = 1; i <= rowcount; i++) {
			String array;
			array = sheet.getRow(i).getCell(0).getStringCellValue();
			arr = arr + "," + array;
		}
		System.out.println("arr" + arr);
		rowvalues= arr.split(",");
		System.out.println("rowvalues" + rowvalues);
		return rowvalues;
		}catch(Exception e) {
			return rowvalues;
		}
		
	}
	
	
	public static void setCellData(String parameterKey, Object object, int colNum, String ReportFilePath)
			throws IOException {

		File src = new File(ReportFilePath);
		FileInputStream fis = new FileInputStream(src);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		
		XSSFSheet Sheet1 = wb.getSheet(sheetTabName);
		
		int rowLenth = Sheet1.getLastRowNum() - Sheet1.getFirstRowNum();

		for (int i = 0; i < rowLenth + 1; i++) {
			Row row = Sheet1.getRow(i);
			for (int j = 0; j < row.getLastCellNum(); j++) {
				if (row.getCell(0).getStringCellValue().equalsIgnoreCase(parameterKey)) {

					Sheet1.getRow(i).createCell(colNum).setCellValue(object.toString());

				}

			}
		}
		FileOutputStream fout = new FileOutputStream(src);
		wb.write(fout);
		fout.flush();
		fout.close();
	}
	
	
	//The Below Method is to write the query output to Excel sheet in specified path
			public static  void WriteToExcelFacetsdb(String ReportFilePath, String sheetName, ResultSet rs) throws Exception

			{

				FileInputStream fis = new FileInputStream(ReportFilePath);
				XSSFWorkbook wb = new XSSFWorkbook(fis);
				//CellStyle style;
				DataFormat format = wb.createDataFormat();
				ResultSetMetaData rsmd = rs.getMetaData();
				List<String> columns = new ArrayList<String>();
				for (int i = 1; i <= rsmd.getColumnCount(); i++) {
					columns.add(rsmd.getColumnLabel(i));
				}

				XSSFSheet sheet = wb.getSheet(sheetName);
				if (sheet == null)
					sheet = wb.createSheet(sheetName);
				Row header = sheet.createRow(0);
				for (int i = 0; i < columns.size(); i++) {
					header.createCell(i).setCellValue(columns.get(i));
				}
				count1=count1+1;
				while (rs.next()) {
					Row row = sheet.createRow(count1);
					for (int i = 0; i < columns.size(); i++) {
						Cell cell = row.createCell(i);
						// System.out.println("Column "+columns.get(i));
						String val = Objects.toString(rs.getObject(columns.get(i)), "");
						
				
							cell.setCellValue(val);
						
					}
				}

				FileOutputStream fout = new FileOutputStream(ReportFilePath);
				wb.write(fout);
				wb.close();


			}


}