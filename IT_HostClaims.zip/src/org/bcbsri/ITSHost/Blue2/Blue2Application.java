package org.bcbsri.ITSHost.Blue2;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.bcbsri.ITSHost.dbutility.TextFileUtilities;
import org.bcbsri.configvalidation.Readexcel;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.testng.Reporter;

import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.selenium.testdata.DataTable;
import com.dell.acoe.framework.selenium.verify.Assert;
import com.ntt.cryptic.aesTest;

public class Blue2Application {

	static WebDriver driver;
	static File testdata;
	static File testoutput;
	static File testenvdata;
	static File testenvironment;
	static DataTable dt;
	static String strTestEnvironment;
	static DataTable environment;
	
	public Blue2Application(WebDriver driver) {
		this.driver = driver;

	}

	// Using FindBy for locating elements
	@FindBy(how = How.XPATH, using = "//body")
	WebElement mainPage;
	@FindBy(how = How.XPATH, using = "//div[@class='navLinks']")
	WebElement consoleTab;
	@FindBy(how = How.XPATH, using = "//input[@title='Search Salesforce']")
	WebElement salesforceSearchBox;
	@FindBy(how = How.XPATH, using = "//span[text()='SCCF Search']")
	WebElement blue2Applicationmyprofile;
	@FindBy(how = How.XPATH, using = "//input[contains(@id,'LogoutStandardPopupConfirmation') and contains(@id,'OKButton')]")
	//WebElement riprovidererrorpage;
	WebElement LogOutPopUp;
	//@FindBy(how = How.XPATH, using = "//label[contains(@title,'Error')]")
	//WebElement riprovidererrorpage;
	//WebElement LogOutPopUp;
	@FindBy(how = How.XPATH, using = "//input[contains(@id,'RedirectCmnPopupConfirmation') and contains(@id,'OKButton')]")
	WebElement UploadPopUp;

	@FindBy(how = How.XPATH, using = "//div[@id='navigatortab']//descendant::iframe[1]")
	WebElement leftFrame;
	@FindBy(how = How.XPATH, using = "//frame[@title='Search']")
	WebElement searchFrame;
	@FindBy(how = How.XPATH, using = "//div[@id='servicedesk']//descendant::iframe[1]")
	WebElement firstSubTab;
	@FindBy(how = How.XPATH, using = "//div[@id='servicedesk']//descendant::iframe[2]")
	WebElement secondSubTab;
	@FindBy(how = How.XPATH, using = "//div[@id='servicedesk']//descendant::iframe[3]")
	WebElement thirdSubTab;
	@FindBy(how = How.XPATH, using = "//div[@id='servicedesk']//descendant::iframe[4]")
	WebElement FourthSubTab;
	@FindBy(how = How.XPATH, using = "//div[@id='servicedesk']//descendant::iframe[5]")
	WebElement FifthSubTab;
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'sd_primary_container')][last()]//div[contains(@class,'sd_secondary_container')][last()]//div[contains(@class,'x-border-panel')][1]//iframe[last()]")
	WebElement contentTab;
	@FindBy(how = How.XPATH, using = "//iframe[@title='CC_CaseMileStoneTracker']")
	WebElement milestoneFrame;
	@FindBy(how = How.XPATH, using = "//iframe[@title='CC_GAU_QPI_SIUCasesOnAccount']")
	WebElement ccgauqpisiucasesFrame;
	@FindBy(how = How.XPATH, using = "//iframe[@id='ext-comp-1005']")
	WebElement BaseFrame;
	@FindBy(how = How.XPATH, using = "//iframe[@title='HomePageCustomLinks']")
	WebElement HomeFrame;
	@FindBy(how = How.XPATH, using = "//iframe[@title='ViewHomePageNotification']")
	WebElement NotificationFrame;
	@FindBy(how = How.XPATH, using = "//span[@class='listViewTitle']")
	WebElement pagelistTitle;
//	@FindBy(how=How.XPATH, using="//*[@id='refresh']") WebElement refresh;
	@FindBy(how = How.XPATH, using = "//*[@id='refreshButton']")
	WebElement refresh;
	@FindBy(how = How.XPATH, using = "//*[@id='db_ds_quickfindInput']")
	WebElement datasourcequickfind;
	@FindBy(how = How.XPATH, using = "//*[@id='runMuttonButton']")
	WebElement runReportbtn;
//	@FindBy(how=How.XPATH, using="//input[@value='Run Report']")WebElement runReportbtn;
//	@FindBy(how=How.XPATH, using="//button[text()='Run Report']")WebElement runReportbtn;
	@FindBy(how = How.XPATH, using = "//*[@id='runMuttonLabel']")
	WebElement runReportbtndrpdwn;

	@FindBy(how = How.XPATH, using = "//div[@id='servicedesk']//following::iframe[1]")
	WebElement mainTab;
	@FindBy(how = How.XPATH, using = "//frame[@title='Results']")
	WebElement resultsFrame;
	@FindBy(how = How.XPATH, using = "//iframe[@title='CC_GAU_QPI_SIUCasesOnPolicy']")
	WebElement ccgauqpisiucasesPolicyFrame;
	@FindBy(how = How.XPATH, using = "//head[@id='Head']//title[1]")
	WebElement pageTitle;
	@FindBy(how = How.XPATH, using = "//h1[contains(@class,'pageType')]")
	WebElement pageType;
	@FindBy(how = How.XPATH, using = "//button[text()=\"Don't Save\"]")
	WebElement dontSaveButton;
	@FindBy(how = How.XPATH, using = "//div[@class='filterLinks']//preceding::select[1]")
	WebElement selQueue;
	@FindBy(how = How.XPATH, using = "//select[@name='fcf']")
	WebElement selMenuQueue;
	@FindBy(how = How.XPATH, using = "//span[@id='userNavLabel']")
	WebElement icnProfile;
	@FindBy(how = How.XPATH, using = "//a[@id='app_logout']")
	WebElement lnkLogOut;

	@FindBy(how = How.XPATH, using = "//*[@id='tsidLabel']")
	WebElement appMenu;

	@FindBy(how = How.XPATH, using = "//iframe[@title='CC_PolicyTabs']")
	WebElement ccpolicytabs;
	@FindBy(how = How.XPATH, using = "//iframe[contains(@src,'CC_PolicyAccumulators')]")
	WebElement ccpolicyaccumulators;
	@FindBy(how = How.XPATH, using = "//iframe[contains(@src,'CC_ViewPolicybenefits')]")
	WebElement ccviewpolicybenefits;
	@FindBy(how = How.XPATH, using = "//iframe[contains(@src,'CC_SearchMemberPolicyCoverage')]")
	WebElement ccsearachmemberpolicycoverage;
	@FindBy(how = How.XPATH, using = "//iframe[contains(@src,'CC_PolicyPlanSubsidyHistory')]")
	WebElement ccpolicyplansubsidyhistory;

	@FindBy(how = How.XPATH, using = "//iframe[contains(@src,'CC_PolicyViewAuthorizationStatus')]")
	WebElement ccpolicyviewauthorizationstatus;
	@FindBy(how = How.XPATH, using = "//iframe[contains(@src,'CC_PolicyAuthorization_CCMS')]")
	WebElement ccpolicyauthorizationccms;

	@FindBy(how = How.XPATH, using = "//iframe[contains(@id,'ext-comp-1056')]")
	WebElement sdhistoryframe;
	@FindBy(how = How.XPATH, using = "//*[@id='phSearchInput']")
	WebElement globalsearchtxtbox;

	String oldTab = null;
	// @FindBy(how=How.XPATH, using="//h3[.='Contact History']/following::tbody")
	// List<org.openqa.selenium.WebElement> tableElement;
	@FindBy(how = How.XPATH, using = "//h3[.='Contact History']/following::tbody")
	public List<org.openqa.selenium.WebElement> tableElement;
	@FindBy(how = How.XPATH, using = "//h3[.='Case History']/following::tbody")
	public List<org.openqa.selenium.WebElement> tablecaseElement;
	@FindBy(how = How.XPATH, using = "//h3[.='Priority Notes History']/following::tbody")
	public List<org.openqa.selenium.WebElement> tablePriorityNotesHistory;
	@FindBy(how = How.XPATH, using = "//h3[.='Contact History']/following::tbody/tr[2]")
	public List<org.openqa.selenium.WebElement> tableContactHistory;

	// Defining all the user actions (Methods) that can be performed in the Main
	// Page

	// elements used for user info extract
	@FindBy(how = How.XPATH, using = "//*[@id='phSearchInput']")
	WebElement searchtopInput;
	@FindBy(how = How.XPATH, using = "//*[@id='phSearchButton']")
	WebElement searchtopButton;

	/**
	 * Method to open SFDC menu using shortcut ESC + v
	 */
	public void OpenMenu() throws Exception {
		TextFileUtilities.Log("Opening SFDC Menu", "DONE");
		// Thread.sleep(10000);

		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[@class=' x-btn-text'])[4]")));
		WebElement element = driver.findElement(By.xpath("(//button[@class=' x-btn-text'])[4]"));
		Actions action = new Actions(driver);
		action.sendKeys(Keys.ESCAPE).build().perform();
		Thread.sleep(2000);
		mainPage.sendKeys("v");
		action.moveToElement(element, 20, 23).click().build().perform();
	}

	/**
	 * Method to select SFDC menu item by text
	 * 
	 * @param strMenuItem - Menu Item text
	 */
	public void SelectMenuItem(String strMenuItem) throws Exception {
		WaitForPageToLoad(30);
		TextFileUtilities.Log("Selecting Menu Item - " + strMenuItem, "DONE");
		Actions action = new Actions(driver);
		action.moveToElement(
				driver.findElement(By.xpath("//span[@class='x-menu-item-text' and text()='" + strMenuItem + "']")))
				.click().perform();
		WaitForPageToLoad(30);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();",
				driver.findElement(By.xpath("//span[@class='x-menu-item-text' and text()='" + strMenuItem + "']")));
	}

	/**
	 * Method to select SFDC menu item by text (Overloaded Method)
	 * 
	 * @param strMenuItem    - Menu Item text
	 * @param strTag-TagName of the WebElement
	 */
	public void SelectMenuItem(String strTag, String strMenuItem) throws Exception {
		WaitForPageToLoad(30);
		TextFileUtilities.Log("Selecting Menu Item - " + strMenuItem, "DONE");
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//" + strTag + "[text()='" + strMenuItem + "']"))).click()
				.perform();
		WaitForPageToLoad(30);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();",
				driver.findElement(By.xpath("//" + strTag + "[text()='" + strMenuItem + "']")));
	}

	/**
	 * Method to close primary tabs using SFDC shortcut ESC + c
	 * 
	 * @param intTabCount - Number of tabs to close
	 */
	// Dhruv 14 jan 2020
	public void CloseAllPrimaryTabs() throws Exception {
		Actions action = new Actions(driver);
		SwitchToFrame("Default");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		int intTabCount = driver.findElements(By.xpath("//div[contains(@class,'sd_primary_container')]")).size();
		TextFileUtilities.Log("Closing " + intTabCount + " Primary Tab(s)", "DONE");
		for (int i = 0; i < intTabCount; i++) {
			SwitchToFrame("Default");
			action.sendKeys(Keys.ESCAPE).build().perform();
			mainPage.sendKeys("c");
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			try {
				if (dontSaveButton.isDisplayed()) {
					Thread.sleep(2000);
					dontSaveButton.click();
				}
			} catch (NoSuchElementException ex) {
				continue;
			} finally {
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			}
		}
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * Method to close all sub tabs
	 */
	public void CloseAllSubTabs() throws Exception {
		TextFileUtilities.Log("Closing all subtabs", "DONE");
		SwitchToFrame("Default");
		ClickOnSubtabsDropdown();
		SelectMenuItem("Close all subtabs");
		WaitForPageToLoad(30);
		SwitchToFrame("Default");
		SwitchToFrame("Content");
	}

	/**
	 * Method to refresh all subtabs
	 */
	public void RefreshAllSubTabs() throws Exception {
		TextFileUtilities.Log("Refreshing all subtabs", "DONE");
		SwitchToFrame("Default");
		ClickOnSubtabsDropdown();
		SelectMenuItem("Refresh all subtabs");
		WaitForPageToLoad(30);
		SwitchToFrame("Default");
		SwitchToFrame("Content");
	}

	/**
	 * Method to close all sub tabs
	 */
	public void ClickOnSubtabsDropdown() throws Exception {
		SwitchToFrame("Default");
		WaitForPageToLoad(30);
		TextFileUtilities.Log("Selecting Subtabs Dropdown", "DONE");
		WebElement element = driver.findElement(
				By.xpath("//div[@class='x-tab-tabmenu-right']//following::div[@class='x-tab-tabmenu-right']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		Thread.sleep(500);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
		// element.click();
		WaitForPageToLoad(30);
	}

	/**
	 * Method to click on a Button type - Input identified by @title tag
	 * 
	 * @param strButtonName - @title of the Button
	 */
	public void ClickOnButtonByTitle(String strButtonName) throws Exception {
		
		//button[contains(text(),Login)]
		
		
		WebElement element = driver.findElement(By.xpath("//button[contains(text()," + strButtonName + ")]"));
		//System.out.println(element);
		
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
			Thread.sleep(5000);
			TextFileUtilities.Log("Clicking on Button - " + strButtonName, "DONE");
			
		} catch (StaleElementReferenceException e) {
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
			TextFileUtilities.Log("Clicking on Button - " + strButtonName, "DONE");
		
		} catch (Exception e) {
			TextFileUtilities.Log("Clicking on Button - " + strButtonName, "FAIL");
		}
	
	}
	public void ClickOnButtonByTitleTab(String strButtonName) throws Exception {
		
		//button[contains(text(),Login)]
		
		
		WebElement element = driver.findElement(By.xpath("//a[contains(text(),'" + strButtonName + "')]"));
		//System.out.println(element);
	
		////a[contains(text(),'SCCF History')]
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
			TextFileUtilities.Log("Clicking on Tab - " + strButtonName, "DONE");
		} catch (StaleElementReferenceException e) {
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
			TextFileUtilities.Log("Clicking on Tab - " + strButtonName, "DONE");
		} catch (Exception e) {
			TextFileUtilities.Log("Clicking on Button - " + strButtonName, "FAIL");
		}
	
	}
	
	/**
	 * Method to click on button tab 
	 */
	public void ClickonTab(String strButtonName) throws Exception {
		TextFileUtilities.Log("Clicking on Tab - " + strButtonName, "DONE");
		//button[contains(text(),Login)]
		//a[text()='Claim']
		
		WebElement element = driver.findElement(By.xpath("//a[text()='" + strButtonName + "']"));
		//System.out.println(element);
	
		////a[contains(text(),'SCCF History')]
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		} catch (StaleElementReferenceException e) {
			Thread.sleep(2000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		} catch (Exception e) {
			TextFileUtilities.Log("Clicking on Button - " + strButtonName, "FAIL");
		}
	
	}
	/**
	 * Method to click on button tab 
	 */
	public void ClickOnButtonByButtonTab(String strButtonName) throws Exception {
		TextFileUtilities.Log("Clicking on Tab - " + strButtonName, "DONE");
		//button[contains(text(),Login)]
		
		
		WebElement element = driver.findElement(By.xpath("//span[contains(text(),'" + strButtonName + "')]"));
		//System.out.println(element);
	
		////a[contains(text(),'SCCF History')]
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		} catch (StaleElementReferenceException e) {
			Thread.sleep(2000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		} catch (Exception e) {
			TextFileUtilities.Log("Clicking on Button - " + strButtonName, "FAIL");
		}
	
	}
	
	
	/**
	 * Method to click on button tab 
	 */
	public void ClickOnButtonByButtonLogout(String strButtonName) throws Exception {
		TextFileUtilities.Log("Clicking on Tab - " + strButtonName, "DONE");
		//button[contains(text(),Login)]
		//a[@id='logout']
		
		WebElement element = driver.findElement(By.xpath("//a[@id='" + strButtonName + "']"));
		//System.out.println(element);
	
		////a[contains(text(),'SCCF History')]
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		} catch (StaleElementReferenceException e) {
			Thread.sleep(2000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		} catch (Exception e) {
			TextFileUtilities.Log("Clicking on Button - " + strButtonName, "FAIL");
		}
	
	}

	/**
	 * Method to click on tab
	 */

	/**
	 * Method to click on a Button type - Input identified by @title tag
	 * 
	 * @param strButtonName - @title of the Button and clear the text
	 */
	public void ClickOnButtonByTitleSendKeys(String strButtonName, String strValue) throws Exception {
		TextFileUtilities.Log("Clicking on Button - " + strButtonName, "DONE");
		WebElement element = driver.findElement(By.xpath("//input[@title='" + strButtonName + "']"));
		element.click();
		try {
			element.clear();
		} catch (Exception e) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		}
		WaitForPageToLoad(30);
	}

	


	/**
	 * Method to click on a Button type - Input identified by @value tag
	 * 
	 * @param strButtonValue - @value of the Button
	 */
	public void ClickOnButtonByValue(String strButtonValue) throws Exception {
		TextFileUtilities.Log("Clicking on Button - " + strButtonValue, "DONE");
		WebElement element = driver.findElement(By.xpath("//input[@value='" + strButtonValue + "']"));
		element.click();
		/*
		 * if (element.isEnabled()) { JavascriptExecutor js =
		 * (JavascriptExecutor)driver; js.executeScript("arguments[0].click();",
		 * element); driver.findElement(By.xpath("//input[@value='" + strButtonValue +
		 * "']")).click(); WaitForPageToLoad(30); } else { element.click();
		 * Log(strButtonValue + " Button is not enabled", "FAIL", false); }
		 */
	}

	/**
	 * Method to click on a Button type - Following Input tag
	 * 
	 * @param strButtonValue - @value of the Button
	 * @param strButtonTitle - @Title of the Button
	 */
	public void ClickOnButtonByValueorTitle(String strButtonValue, String strButtonTitle) throws Exception {
		TextFileUtilities.Log("Clicking on Button - " + strButtonValue, "DONE");
		WebDriverWait wd = new WebDriverWait(driver, 30);
		wd.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//input [contains(@value,' "
				+ strButtonValue + " ') or contains(@title,'" + strButtonTitle + "')]"))));
		WebElement elem = driver.findElement(By.xpath(
				"//input [contains(@value,' " + strButtonValue + " ') or contains(@title,'" + strButtonTitle + "')]"));
		if (driver instanceof JavascriptExecutor) {
			((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px solid red'", elem);
		}
		WebElement ele = driver.findElement(By.xpath(
				"//input [contains(@value,' " + strButtonValue + " ') or contains(@title,'" + strButtonTitle + "')]"));
		// ElemIDUtil.domElementClick(ele);
		ele.click();
		AcceptAlert();
		Thread.sleep(5000);
		TextFileUtilities.Log("Clicked on Button - " + strButtonValue, "DONE");
		WaitForPageToLoad(30);
	}

	/**
	 * Method to click on a Button type - Having any tag
	 * 
	 * @param strButtonValue - @value of the Button
	 * @param strButtonTitle - @Title of the Button
	 */
	public void ClickOnButtonByText(String tagName, String strText) throws Exception {
		TextFileUtilities.Log("Clicking on Button - " + strText, "DONE");
		WebDriverWait wd = new WebDriverWait(driver, 60);
		wd.until(ExpectedConditions
				.visibilityOf(driver.findElement(By.xpath("//" + tagName + "[contains(text(),'" + strText + "')]"))));
		WebElement elem = driver.findElement(By.xpath("//" + tagName + "[contains(text(),'" + strText + "')]"));
		if (driver instanceof JavascriptExecutor) {
			((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px solid red'", elem);
		}
		WebElement ele = driver.findElement(By.xpath("//" + tagName + "[contains(text(),'" + strText + "')]"));
		//ElemIDUtil.domElementClick(ele);
		ele.click();
		TextFileUtilities.Log("Clicked on Button - " + strText, "DONE");
		WaitForPageToLoad(30);
	}

	/**
	 * Method to wait for a Button by Title to be enabled
	 * 
	 * @param strButtonValue - @value of the Button
	 */
	public boolean WaitForButtonByTitle(String strButtonTitle) throws Exception {
		try {
			if (driver.findElement(By.xpath("//input[@title='" + strButtonTitle + "']")).isEnabled()) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Method to click on a Tab identified by tag-td
	 * 
	 * @param strTabText - @value of the Button
	 */
	public void ClickOnTabByText(String strTabText) throws Exception {
		TextFileUtilities.Log("Clicking on Tab - " + strTabText, "DONE");
		driver.findElement(By.xpath("//td[text()='" + strTabText + "']")).click();
		WaitForPageToLoad(5);
	}
/**
 * Click of tab
 */
	public void ClickOnTab(String strTabText) throws Exception {
		TextFileUtilities.Log("Clicking on Tab - " + strTabText, "DONE");
		driver.findElement(By.xpath("//td[text()='" + strTabText + "']")).click();
		WaitForPageToLoad(30);
	}
	/**
	 * Method to click on a Button type - Input identified by text
	 * 
	 * @param strMenuButtonText - Text of the Button
	 */
	public void ClickOnMenuButtonByText(String strMenuButtonText) throws Exception {
		TextFileUtilities.Log("Clicking on Menu Button - " + strMenuButtonText, "DONE");
		driver.findElement(By.xpath("//span[@class='menuButtonLabel' and text()='" + strMenuButtonText + "']")).click();
	}

	/**
	 * Method to click on a Check Box having type - Input following a Label
	 * containing text
	 * 
	 * @param strLabel - Text of the Label after which the element is present
	 */
	public void SelectCheckBoxAfterLabel(String strLabel) throws Exception {
		TextFileUtilities.Log("Clicking on Checkbox - " + strLabel, "DONE");
		WebElement element = driver
				.findElement(By.xpath("//label[contains(.,'" + strLabel + "')]//following::input[1]"));
		if (element.isEnabled()) {
			element.click();
			Thread.sleep(3000);
		} else {
			TextFileUtilities.Log(strLabel + " Checkbox is not enabled", "FAIL");

		}
	}

	/**
	 * Method to click on a Radio Button having type - Input preceding a Label
	 * containing text
	 * 
	 * @param strLabel - Text of the Label before which the Radio button is present
	 */
	public void SelectRadioButtonBeforeLabel(String strLabel) throws Exception {
		TextFileUtilities.Log("Clicking on Checkbox - " + strLabel, "DONE");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element = driver
				.findElement(By.xpath("//label[contains(.,'" + strLabel + "')]//preceding::input[1]"));
		if (element.isEnabled()) {
			js.executeScript("arguments[0].click();", element);
//			element.click();
			Thread.sleep(3000);
		} else {
			TextFileUtilities.Log(strLabel + " Radio Button is not enabled", "FAIL");

		}
	}

	/**
	 * Method to click on a Check Box having type - Input preceding a Label
	 * containing text
	 * 
	 * @param strLabel - Text of the Label before which the Check box is present
	 */
	public void SelectCheckBoxBeforeLabel(String strLabel) throws Exception {
		TextFileUtilities.Log("Clicking on Checkbox - " + strLabel, "DONE");
		WaitForPageToLoad(30);
		WebElement element = driver
				.findElement(By.xpath("//label[contains(.,'" + strLabel + "')]//preceding::input[1]"));
		if (element.isEnabled()) {
			element.click();
			WaitForPageToLoad(30);
		} else {
			TextFileUtilities.Log(strLabel + " Checkbox is not enabled", "FAIL");

		}
	}

	/**
	 * Method to click on a Check Box having type - Input preceding a Link
	 * containing text
	 * 
	 * @param strLinkText - Text of the Link before which the Check box is present
	 */
	public void SelectCheckBoxBeforeLinkText(String strLinkText) throws Exception {
		if (strLinkText.substring(0, 2).equals("dt")) {
			strLinkText = GetTestData(strLinkText);
		}
		TextFileUtilities.Log("Selecting Checkbox - " + strLinkText, "DONE");
		WaitForPageToLoad(30);
		WebElement element = driver
				.findElement(By.xpath("//a[contains(.,'" + strLinkText + "')]//preceding::input[1]"));
		if (element.isEnabled()) {
			try {
				element.click();
			} catch (Exception e) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].click();", element);
//			element.click();
				WaitForPageToLoad(30);
			}
		} else {
			TextFileUtilities.Log(strLinkText + " Checkbox is not enabled", "FAIL");

		}
	}

	/**
	 * Method to click on a Radio Button having type - Input preceding a Link
	 * containing text
	 * 
	 * @param strLinkText - Text of the Link before which the Radio button is
	 *                    present
	 */
	public void SelectRadioButtonBeforeLinkText(String strLinkText) throws Exception {
		if (strLinkText.substring(0, 2).equals("dt")) {
			strLinkText = GetTestData(strLinkText);
		}
		TextFileUtilities.Log("Selecting Radio Button - " + strLinkText, "DONE");
		WaitForPageToLoad(30);
		WebElement element = driver
				.findElement(By.xpath("//a[contains(.,'" + strLinkText + "')]//preceding::input[1]"));
		if (element.isEnabled()) {
			element.click();
			WaitForPageToLoad(30);
		} else {
			TextFileUtilities.Log(strLinkText + " Radio Button is not enabled", "FAIL");

		}
	}

	/**
	 * Method to click on a Radio Button having type - Input in a Table Row
	 * 
	 * @param strTableHeader - Text of the Header having tag
	 *                       <h3>preceding the Radio button
	 * @param intRow         - Row of the Table where the Radio button is present
	 */
	public void SelectRadioButtonFromTable(String strTableHeader, int intRow) throws Exception {
		TextFileUtilities.Log("Clicking on Checkbox - " + strTableHeader + "Row " + intRow, "DONE");
		WaitForPageToLoad(30);
		WebElement element = driver
				.findElement(By.xpath("//h3[text()='" + strTableHeader + "']/../../descendant::input[" + intRow + "]"));
		element.click();
		Thread.sleep(3000);
	}

	/**
	 * Method to verify on a Radio Button having type - Input in a Table Row
	 * 
	 * @param strTableHeader - Text of the Header having tag
	 *                       <h3>preceding the Radio button
	 * @param intRow         - Row of the Table where the Radio button is present
	 * @return
	 */
	public boolean IsRadioButtonFromTableDisplays(String strTableHeader, int intRow) throws Exception {
		TextFileUtilities.Log("Clicking on Checkbox - " + strTableHeader + "Row " + intRow, "DONE");
		WaitForPageToLoad(30);
		WebElement element = driver
				.findElement(By.xpath("//h3[text()='" + strTableHeader + "']/../../descendant::input[" + intRow + "]"));
		if (element.isDisplayed()) {
			return true;
		} else {
			return false;
		}

	}
	
	/**
	 * Method to verfiy if DF is present
	 */
	public boolean IsDFdisplyed(String strFormat) throws Exception {
		TextFileUtilities.Log("Verfying if DF is present", "DONE");
		WaitForPageToLoad(30);
		WebElement element =driver.findElement(By.xpath("//td[text()='" + strFormat + "']"));
		if (element.isDisplayed()) {
			return true;
		} else {
			return false;
		}

	}
	/**
	 * Method to verify if Next button is displayed
	 */
	public boolean IsNextdisplyed(String strFormat) throws Exception {
		TextFileUtilities.Log("Verfying if DF is present", "DONE");
		WaitForPageToLoad(30);
		WebElement element =driver.findElement(By.xpath("//a[contains(text(),'Next')]"));
		if (element.isDisplayed()) {
			return true;
		} else {
			return false;
		}

	}
	/**
	 * Method to Verify if Create Adjacent Message tab is present
	 */
	public boolean IsCreateAdjacentMessageDisdplayed(String strFormat) throws Exception {
		
		Thread.sleep(1000);
		
		try{
			WebElement element =driver.findElement(By.xpath("//span[text()='" + strFormat + "']"));
			if (element.isDisplayed()) {
				TextFileUtilities.Log("Create Adjustment message button is displayed", "PASS");
				return true;
			} else {
				
				return false;
			}
		}catch(Exception e){
			Assert.error(e, "Error at finding create Adjustment message button");
			return false;
		}
		

	}
	/**
	 * Method to click on (x) icon next to Member Filed to clear the input data
	 */

	public void clearMemberdata(String strLabel) throws Exception {
		WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::img[1]"));
		element.click();
	}

	/**
	 * Method to Modify Policy Details for already created case
	 */
	public void ModifyPolicyDetails(String strLabel, String strValue) throws Exception {
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::input[7]"));
		element.clear();
		element.sendKeys(strValue);

		/*
		 * driver.findElement(By.xpath("//label[text()='Policy']//following::input[7]"))
		 * .clear();
		 * driver.findElement(By.xpath("//label[text()='Policy']//following::input[7]"))
		 * .sendKeys("200100124-001");
		 */
	}

	/**
	 * Method to Select a List Item following a Label
	 * 
	 * @param strList  - Text of the Label after which Select box is present
	 * @param strValue - Text value of the option to be selected
	 */
	public void SelectListItemAfterLabel(String strList, String strValue) throws Exception {

		for (int i = 0; i < 3; i++) {
			try {
				//usage of time
				driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
				//Thread.sleep(1000);
				WebElement element = driver
						.findElement(By.xpath("//label[text()='" + strList + "']//following::select[1]"));
				Select dropdown = new Select(element);
				dropdown.selectByVisibleText(strValue);
				TextFileUtilities.Log("Selecting " + strList + " - " + strValue, "DONE");
				break;
			} catch (StaleElementReferenceException e) {
				TextFileUtilities.Log("Caught stale element! Will try two more times at max.", "FAIL");
				continue;
			}
		}
	}
	/**
	 * Method when to select the value from drop down edited
	 */
	//remove unwanted lines
	public void SelectListItemAfterLabel1(String strList, String strValue) throws Exception {
		
       //for loop usage 
		for (int i = 0; i < 5; i++) {
			try {
				
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				Thread.sleep(1000);
				WebElement element = driver
						.findElement(By.xpath("//*[@id='" + strList + "']"));
				//("//*[@id='userNameFld']")
				////*[@id="userStateSel"]
				Select dropdown = new Select(element);
				dropdown.selectByVisibleText(strValue);
				TextFileUtilities.Log("Selecting " + strList + " - " + strValue, "DONE");
				break;
			} catch (StaleElementReferenceException e) {
				TextFileUtilities.Log("Caught stale element! Will try two more times at max.", "FAIL");
				continue;
			}
		}
	}
	
	/**
	 * Method to Select a List Item following a Label (Overloaded)
	 * 
	 * @param strList  - Text of the Label after which Select box is present
	 * @param strValue - Text value of the option to be selected
	 * @param strMatch - Use any text for partial match e.g. "Partial"
	 */
	public void SelectListItemAfterLabel(String strList, String strValue, String strMatch) throws Exception {
		
		TextFileUtilities.Log("Selecting " + strList + " - " + strValue, "DONE");
		WebElement element = driver
				.findElement(By.xpath("//label[contains(text(),'" + strList + "')]//following::select[1]"));
		Select dropdown = new Select(element);
		dropdown.selectByVisibleText(strValue);
	}

	/**
	 * Method to Select a List Item following a Label (Overloaded)
	 * 
	 * @param strList  - Text of the Label after which Select box is present
	 * @param strValue - Text value of the option to be selected
	 * @param strMatch - Use any text for partial match e.g. "Partial"
	 * @param intvalue - Value of the index
	 */
	public void SelectListItemAfterLabel(String strList, String strValue, String strMatch, int index) throws Exception {
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		TextFileUtilities.Log("Selecting " + strList + " - " + strValue, "DONE");
		WebElement element = driver
				.findElement(By.xpath("//label[contains(text(),'" + strList + "')]//following::select[" + index + "]"));
		Select dropdown = new Select(element);
		dropdown.selectByVisibleText(strValue);
	}

	/**
	 * Method to Select an option from Option group following a Label
	 * 
	 * @param strLabel - Label after which Option group is present
	 * @param strValue - Text value of the option to be selected
	 */
	public void SelectOptionFromOptionGroupAfterLabel(String strLabel, String strValue) throws Exception {
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		TextFileUtilities.Log("Selecting " + strLabel + " - " + strValue, "DONE");
		WebElement element = driver.findElement(By.xpath(
				"//label[text()='" + strLabel + "']//following::optgroup[1]//option[text()='" + strValue + "']"));
		element.click();
	}

	/**
	 * Method to Select an Item from SFDC Queue
	 * 
	 * @param strItem - Link text before which the Check box is present e.g. Check
	 *                box before Case Number
	 */
	public void SelectItemFromQueue(String strItem) throws Exception {
		Thread.sleep(2000);
		TextFileUtilities.Log("Selecting " + strItem + " from Queue", "DONE");
		WebElement element = driver.findElement(By.xpath("//a[text()='" + strItem + "']//preceding::input[1]"));
		element.click();
		WaitForPageToLoad(30);
	}

	/**
	 * Method to Select a SFDC Queue
	 * 
	 * @param strQueue - Queue item identified by text
	 */
	public void SelectQueue(String strQueue) throws Exception {
		WaitForPageToLoad(30);
		if (strQueue.substring(0, 2).equals("dt")) {
			strQueue = GetTestData(strQueue);
		}
		TextFileUtilities.Log("Selecting Queue - " + strQueue, "DONE");
		for (int i = 0; i < 2; i++) {
			try {
				Select dropdown = new Select(selQueue);
				dropdown.selectByVisibleText(strQueue);
				break;
			} catch (StaleElementReferenceException e) {
				TextFileUtilities.Log("Caught stale element! Will try two more times at max.", "DONE");
				continue;
			}
		}
	}

	/**
	 * Method to Select a SFDC Queue say My Cases, My Open Cases etc.
	 * 
	 * @param strQueue - Queue item identified by text
	 */
	public void SelectMenuQueue(String selQueueMenu) throws Exception {
		if (selQueueMenu.substring(0, 2).equals("dt")) {
			selQueueMenu = GetTestData(selQueueMenu);
		}
		TextFileUtilities.Log("Selecting Queue - " + selQueueMenu, "DONE");
		Select sel = new Select(selMenuQueue);
		sel.selectByVisibleText(selQueueMenu);
	}

	/**
	 * Method to Click on a lookup icon following a Label
	 * 
	 * @param strLabel - Label text after which the lookup icon is present
	 */
	public void ClickOnLookupAfterLabel(String strLabel) throws Exception {
		TextFileUtilities.Log("Clicking on " + strLabel + " Lookup", "DONE");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::a[1]"));
		js.executeScript("arguments[0].click();", element);
		Thread.sleep(2000);
	}

	/**
	 * Method to Click on a lookup icon following a Label
	 * 
	 * @param strLabel - Label text after which the lookup icon is present Provide
	 *                 StringLabe2 as User, Customer Portal User or Partner User The
	 *                 text box is developed with input Tag instead of Label tag
	 */
	public void ClickOnLookupAfterLabel(String strLabel, int value) throws Exception {
		TextFileUtilities.Log("Clicking on " + strLabel + " Lookup", "DONE");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element = driver
				.findElement(By.xpath("//label[text()='" + strLabel + "']//following::span['" + value + "']/input"));
		js.executeScript("arguments[0].click();", element);
		Thread.sleep(2000);
	}

	/**
	 * Method to sort a column identified by @title tag
	 * 
	 * @param strColumn - Column value of HTML table identified by @title tag
	 */
	public void SortQueueByTitle(String strColumn) throws Exception {
		TextFileUtilities.Log("Sorting Queue by " + strColumn, "DONE");
		Thread.sleep(5000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(By.xpath("//div[@title='" + strColumn + "']"));
		js.executeScript("arguments[0].click();", element);
		WaitForPageToLoad(30);

	}

	/**
	 * Method to set text in to a Input box following a Label with partial match
	 * (Overloaded)
	 * 
	 * @param strLabel      - Label after which Input box is present
	 * @param strValue      - Text value to be set in to Input box
	 * @param strSearchType - Use any text for partial match e.g. "Partial"
	 */
	public void SetTextAfterLabel(String strLabel, String strValue, String strSearchType) throws Exception {
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		
		WebElement element = driver
				.findElement(By.xpath("//label[contains(.,'" + strLabel + "')]//following::input[1]"));
		element.clear();
		TextFileUtilities.Log("Setting Text Into " + strLabel + " - " + strValue, "PASS");
		element.sendKeys(strValue);
	}

	/**
	 * Method to set text in to a Input box following a Label with Full Match
	 * 
	 * @param strLabel - Label after which Input box is present
	 * @param strValue - Text value to be set in to Input box
	 */
	public void SetTextAfterLabel(String strLabel, String strValue) throws Exception {
		WaitForPageToLoad(30);
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		if (strLabel.equalsIgnoreCase("Password")) {
			
			WebElement element = driver.findElement(By.xpath("//*[@id='passwordFld']"));
			element.sendKeys(strValue);
			TextFileUtilities.Log("Setting Text Into " + strLabel + "", "DONE");
		} else {
			
		//WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::input[1]"));
		WebElement element = driver.findElement(By.xpath("//*[@id='userNameFld']"));
		element.sendKeys(strValue);
		TextFileUtilities.Log("Setting Text Into " + strLabel + " - " + strValue, "DONE");
		}
	}
	
	/**
	 * Method to enter ssscf id
	 */
	//update the method
	public void SetTextAfterLabel1(String strLabel, String strValue) throws Exception {
		WaitForPageToLoad(15);
		
		//WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::input[1]"));
		WebElement element = driver.findElement(By.xpath("//*[@id='sccfFld']"));
		element.sendKeys(strValue);
		TextFileUtilities.Log("Setting Text Into " + strLabel + " - " + strValue, "DONE");
	}
	
	/**
	 * Set Text After label 
	 *
	 */
	public void SetTextAreaAfterLabeltext(String strLabel, String strValue) throws Exception {
		
		
		WebElement element = driver.findElement(By.xpath("//label[contains(text(),'" + strLabel + "')]//following::input[1]"));
		element.sendKeys(strValue);  
		TextFileUtilities.Log("Setting Text Into " + strLabel + " - " + "", "DONE");//("//span[contains(text(),'" + strButtonName + "')]")
	}
	/**
	 * Method to set date in to a Input box following a Label with Full Match
	 * 
	 * @param strLabel - Label after which Input box is present
	 * @param strValue - Text value of date to be set in to Input box
	 */
	public void SetDateAfterLabel(String strLabel, String strValue) throws Exception {
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		if (strValue.equals("NULL")) {
			return;
		}
		TextFileUtilities.Log("Setting Text Into " + strLabel + " - " + strValue, "DONE");
		WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::input[1]"));
		element.clear();
		Thread.sleep(1000);
		element.sendKeys(strValue);
	}

	/**
	 * Method to set text in to a Text Area following a Label with Full Match
	 * 
	 * @param strLabel - Label after which Text Area is present
	 * @param strValue - Text value of date to be set in to Input box
	 */
	public void SetTextAreaAfterLabel(String strLabel, String strValue) throws Exception {
		
		TextFileUtilities.Log("Setting Text Into " + strLabel + " - " + strValue, "DONE");
		WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::textarea[1]"));
		element.sendKeys(strValue);
	}
	
	/**
	 * Setting up the message note after text
	 */
	public void SetTextAreaAfterLabelNotes(String strLabel, String strValue) throws Exception {
		TextFileUtilities.Log("Setting Text Into " + strLabel + " - " + strValue, "DONE");
		WebElement element = driver.findElement(By.xpath("//span[@id='" + strLabel + "']//following::textarea[1]"));
		element.sendKeys(strValue);
	}

	/**
	 * Method to set text in to a input field following a Label with Full Match
	 * 
	 * @param strLabel - Label after which input is present
	 * @param strValue - Input value of ChangeOwner to be set in to Input box
	 * @author XPXSTSO:Prasanta
	 */
	public void SetInputValueAfterLabel(String strLabel, String strValue) throws Exception {
		if (strValue.substring(0, 2).equals("dt")) {
			strValue = GetTestData(strValue);
		}
		TextFileUtilities.Log("Setting Text Into " + strLabel + " - " + strValue, "DONE");
		WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::input[7]"));
		element.sendKeys(strValue);
	}

	/**
	 * Method to click on a Link with Partial Match
	 * 
	 * @param strLinkText - Link Text
	 */
	public void ClickOnLinkByText(String strLinkText) throws Exception {
		try {
			strLinkText = strLinkText.trim();
			if (strLinkText.substring(0, 2).equals("dt")) {
				strLinkText = GetTestData(strLinkText);
			}

			TextFileUtilities.Log("Clicking on Link - " + strLinkText, "DONE");
			WaitForPageToLoad(30);
			WebElement element = driver.findElement(By.xpath("//a[contains(.,'" + strLinkText + "')]"));
			if (driver.findElement(By.xpath("//a[contains(.,'" + strLinkText + "')]")).isEnabled()) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].click();", element);
			}
		} catch (Exception e) {
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			WebElement element = driver.findElement(By.xpath("//a[contains(.,'" + strLinkText + "')]"));
			if (driver.findElement(By.xpath("//a[contains(.,'" + strLinkText + "')]")).isEnabled()) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].click();", element);
			}
		}
	}

	/**
	 * Method to click on a Link following a Label
	 * 
	 * @param strLabel - Label after which Link is present
	 */
	public void ClickOnLinkAfterLabel(String strLabel) throws Exception {
		TextFileUtilities.Log("Clicking on Link - " + strLabel, "DONE");
		driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::a[1]")).click();
	}

	/**
	 * Method to click on a Link following a Label
	 * 
	 * @param strLabel - Label after which Link is present
	 */
	public void ClickOnLinkAfterLabel(String strLabel, String StrTag, int index) throws Exception {
		TextFileUtilities.Log("Clicking on Link - " + strLabel, "DONE");
		driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::" + StrTag + "[" + index + "]"))
				.click();
	}

	/**
	 * Method to click get text value following a Label
	 * 
	 * @param strLabel - Label after which Link is present
	 */
	public String GetAttributeValuefollowingLabel(String strTag, String attribute, String Text, String strTag2)
			throws Exception {
		String attributevalue = "";
		WaitForPageToLoad(30);
		for (int i = 0; i < 2; i++) {
			try {
				TextFileUtilities.Log("Getting the text of - " + Text, "DONE");
				// driver.switchTo().frame("(//*[contains(@class,'sd_secondary_container
				// x-border-layout-ct')]//iframe)[4]");
				// WebDriverWait wait =new WebDriverWait(driver,45);
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//"+strTag+"["+attribute+"='"+Text+"']//following::"+strTag2+"[1]")));
				attributevalue = driver
						.findElement(By.xpath(
								"//" + strTag + "[" + attribute + "='" + Text + "']//following::" + strTag2 + "[1]"))
						.getText();
				System.out.println("attributevalue ->" + attributevalue);
			} catch (StaleElementReferenceException e) {
				TextFileUtilities.Log("Caught stale element! Will try two more times at max.", "DONE");
				continue;
			}
		}
		WaitForPageToLoad(30);
		return attributevalue;
	}

	/**
	 * Method to click get text value following a Label
	 * 
	 * @param strLabel - Label after which Link is present Overloading above method
	 *                 to fetch the attribute value
	 */
	public String GetAttributeValuefollowingLabel(String strTag, String attribute, String attributevalue,
			String strTag2, String attributeValue2) throws Exception {
		TextFileUtilities.Log("Clicking on Link - " + strTag, "DONE");
		String value = driver
				.findElement(By.xpath(
						"//" + strTag + "[" + attribute + "='" + attributevalue + "']//following::" + strTag2 + ""))
				.getAttribute(attributeValue2);
		return value;
	}

	/**
	 * Method to click on a Check Box following a Label
	 * 
	 * @param strLabel - Label after which Link is present
	 */
	public void ClickOncheckboxAfterLabel(String strLabel) throws Exception {
		TextFileUtilities.Log("Clicking on Link - " + strLabel, "DONE");
		driver.findElement(By.xpath("//input[@name='" + strLabel + "']")).click();
	}

	/**
	 * Method to click on a Check Box following a Label
	 * 
	 * @param strLabel - Label after which Link is present
	 */
	public void ClickOncheckboxAfterLabelText(String strLabel) throws Exception {
		TextFileUtilities.Log("Clicking on Checkbox - " + strLabel, "DONE");
		WebElement element = driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::input[1]"));
		if (!element.isSelected()) {
			element.click();
		}
	}

	/**
	 * Method to click on a Link following a Label
	 * 
	 * @param strLabel - Label after which Link is present
	 * @author XPXSTSO
	 */
	public void ClickOnLinkAfterTablecolumnvalue(String strLabel) throws Exception {
		TextFileUtilities.Log("Clicking on Link - " + strLabel, "DONE");
		driver.findElement(By.xpath("//td[text()='" + strLabel + "']//following::a[1]")).click();
	}

	

	

	/**
	 * Method to click on an Image having @title following a Label
	 * 
	 * @param strLabel - Label after which Image is present
	 * @param strTitle - Image title identified by @title
	 */
	public void ClickOnImageAfterLabelByTitle(String strLabel, String strTitle) throws Exception {
		TextFileUtilities.Log("Clicking on " + strTitle + " - " + strLabel, "DONE");
		driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::img[@title='" + strTitle + "']"))
				.click();
	}



	/**
	 * Method to click on a Link following a Label
	 * 
	 * @param strLabel - Label after which Link is present
	 */
	public void ClickOnLinkByTitle(String strTitle) throws Exception {
		TextFileUtilities.Log("Clicking on Link - " + strTitle, "DONE");
		try {
			driver.findElement(By.xpath("//a[contains(@title,'" + strTitle + "')]")).click();
		} catch (Exception e) {
			TextFileUtilities.Log("Clicking on Link - js invoked - " + strTitle, "DONE");
			WebElement element = driver.findElement(By.xpath("//a[contains(@title,'" + strTitle + "')]"));
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		}
	}

	/**
	 * Method to click on a List Title Link e.g. Links present in Case Page - Case
	 * History[5], Notes[2], Nature-Subnature[0] etc.
	 * 
	 * @param strLinkText - Text of the Link
	 */
	public void ClickListTitleByText(String strLinkText) throws Exception {
		TextFileUtilities.Log("Clicking on Link - " + strLinkText, "DONE");
		WebElement element = driver
				.findElement(By.xpath("//span[contains(text(),'" + strLinkText + "') and @class='listTitle']"));
		try {

			element.click();
		} catch (Exception e) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		}
	}




	/**
	 * Method to click on a Link in a Table Row
	 * 
	 * @param strTableHeader - Heading of the Table identified by
	 *                       <h3>tag
	 * @param intRow         - Table row in which the link is present
	 * @param strLinkText    - Link Text
	 */
	public void ClickOnLinkInGridTableRowColumn(int intRow, int intCol) throws Exception {
		TextFileUtilities.Log("Clicking on Link in Grid Table - Row " + intRow + " Column " + intCol, "DONE");
		Actions action = new Actions(driver);
		action.moveToElement(driver
				.findElement(By.xpath("//div[contains(@class,'x-grid3-body')]//div[contains(@class,'x-grid3-row')]["
						+ intRow + "]//table//td[" + intCol + "]//a[1]")))
				.perform();
		WaitForPageToLoad(30);
		driver.findElement(By.xpath("//div[contains(@class,'x-grid3-body')]//div[contains(@class,'x-grid3-row')]["
				+ intRow + "]//table//td[" + intCol + "]//a[1]")).click();
	}

	/**
	 * Method to get Cell Data with html tag
	 * <th>from a Table
	 * 
	 * @param strTableHeader - Heading of the Table
	 * @param intRow         - Table Row number
	 * @param intCol         - Table Column number
	 * @return String in the specified row and column
	 */
	public String GetMainCellDataFromTableByName(String strTableHeader, int intRow, int intColumn) throws Exception {
		TextFileUtilities.Log("Getting Cell Data from " + strTableHeader + " - Row " + intRow + " Column " + intColumn, "DONE");
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//h3[text()='" + strTableHeader
				+ "']//following::tbody//tr[contains(@class,'dataRow')][" + intRow + "]//th[" + intColumn + "]")))
				.perform();
		WaitForPageToLoad(30);
		return driver.findElement(By.xpath("//h3[text()='" + strTableHeader
				+ "']//following::tbody//tr[contains(@class,'dataRow')][" + intRow + "]//th[" + intColumn + "]"))
				.getText();
	}

	

	/**
	 * Method to get Cell Data with html tag
	 * <td>from a Table
	 * 
	 * @param strTableHeader - Heading of the Table
	 * @param intRow         - Table Row number
	 * @param intCol         - Table Column number
	 * @return String in the specified row and column
	 */
	public String GetCellDataFromTableByName(String strTableHeader, int intRow, int intColumn) throws Exception {
		TextFileUtilities.Log("Getting Cell Data from " + strTableHeader + " - Row " + intRow + " Column " + intColumn, "DONE");
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//h3[text()='" + strTableHeader
				+ "']//following::tbody//tr[contains(@class,'dataRow')][" + intRow + "]//td[" + intColumn + "]")))
				.perform();
		WaitForPageToLoad(30);
		return driver.findElement(By.xpath("//h3[text()='" + strTableHeader
				+ "']//following::tbody//tr[contains(@class,'dataRow')][" + intRow + "]//td[" + intColumn + "]"))
				.getText();
	}

	


	/**
	 * Method to get Cell Header Data with html tag
	 * <td>from a Table
	 * 
	 * @param strTableHeader - Heading of the Table
	 * @param intRow         - Table Row number
	 * @param intCol         - Table Column number
	 * @return String in the specified row and column
	 */
	public String GetCellHeaderFromTableByName(String strTableHeader, int intColumn) throws Exception {
		TextFileUtilities.Log("Getting Cell Header from " + strTableHeader + " Column " + intColumn, "DONE");
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//h3[text()='" + strTableHeader
				+ "']//following::tbody//tr[contains(@class,'headerRow')][1]//th[" + intColumn + "]"))).perform();
		WaitForPageToLoad(30);
		return driver
				.findElement(By.xpath("//h3[text()='" + strTableHeader
						+ "']//following::tbody//tr[contains(@class,'headerRow')][1]//th[" + intColumn + "]"))
				.getText();
	}

	/**
	 * Method to get Cell Data with html tag
	 * <td>from a Table
	 * 
	 * @param strTableHeader - Heading of the Table
	 * @param intRow         - Table Row number
	 * @param intCol         - Table Column number
	 * @return String in the specified row and column
	 */
	public String GetCellDataFromTableRowContainingLinkText(String strLinkText, int intColumn) throws Exception {
		if (strLinkText.substring(0, 2).equals("dt")) {
			strLinkText = GetTestData(strLinkText);
		}
		TextFileUtilities.Log("Getting Cell Data from Table containing Link Text " + strLinkText + " - Column " + intColumn, "DONE");
		// Actions action = new Actions(driver);
		// action.moveToElement(driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//td[contains(.,'"
		// + strLinkText + "')]//following::td["+ intColumn + "]"))).perform();
		WaitForPageToLoad(30);
		try {
			return driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//td[contains(.,'" + strLinkText
					+ "')]//following::td[" + intColumn + "]")).getText();
		} catch (Exception e) {
			return driver.findElement(By.xpath("//table[contains(@class,'list pagination')]//td[contains(.,'"
					+ strLinkText + "')]//following::td[" + intColumn + "]")).getText();
		}
	}

	/**
	 * Method to click on a Drown down icon present inside a button
	 * 
	 * @param strLinkText - Link Text in the drop down list of button
	 */
	public void ClickOnMenuButtonDropdownLinkByText(String strLinkText) throws Exception {
		TextFileUtilities.Log("Clicking on Link - " + strLinkText, "DONE");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//a[text()='" + strLinkText + "']")));
		WaitForPageToLoad(30);
	}

	/**
	 * Method to click on a Link in Reports Table Row
	 * 
	 * @param strTableHeader - Heading of the Table
	 * @param intRow         - Row in which Report link is present
	 */
	public void ClickOnReportInTableRow(String strTableHeader, int intRow) throws Exception {
		TextFileUtilities.Log("Clicking on Report in " + strTableHeader + " - Row " + intRow, "DONE");
		WaitForPageToLoad(30);
		driver.findElement(By.xpath("//span[text()='" + strTableHeader
				+ "']//following::div[contains(@class,\"x-grid3-body\")]//div[contains(@class,'x-grid3-row')][" + intRow
				+ "]//a[1]")).click();
	}

	/**
	 * Method to click on a Date link present after a Label
	 * 
	 * @param strLabel - Label after which Date link is present
	 */
	public void ClickOnDateAfterLabel(String strLabel) throws Exception {
		TextFileUtilities.Log("Selecting " + strLabel, "DONE");
		driver.findElement(By.xpath("//label[text()='" + strLabel + "']//following::a[contains(@href,'DatePicker')]"))
				.click();
	}

	/**
	 * Method to accept a popup alert
	 */
	public void AcceptAlert() throws Exception {
		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.switchTo().alert().accept();
			TextFileUtilities.Log("Accepting Popup Alert", "DONE");
		} catch (Exception e) {
		}
	}

	/**
	 * Method to switch to a Frame - Refer to WebElement list initialized in SFDC
	 * Class
	 * 
	 * @param strFrame - Frame Name e.g. Default, Menu, Content
	 */
	public void SwitchToFrame(String strFrame) throws InterruptedException {
		switch (strFrame) {
		case "Menu":
			Thread.sleep(1000);
			driver.switchTo().frame(leftFrame);
			break;
		case "Content":
			Thread.sleep(1000);
			driver.switchTo().frame(contentTab);
			break;
		case "Milestone":
			Thread.sleep(1000);
			driver.switchTo().frame(milestoneFrame);
			break;
		case "CC GAU QPI SIU Cases":
			Thread.sleep(1000);
			driver.switchTo().frame(ccgauqpisiucasesFrame);
			break;
		case "Main":
			Thread.sleep(1000);
			driver.switchTo().frame(mainTab);
			break;
		case "First":
			Thread.sleep(5000);
			driver.switchTo().frame(firstSubTab);
			break;
		case "Second":
			Thread.sleep(5000);
			driver.switchTo().frame(secondSubTab);
			break;
		case "Third":
			Thread.sleep(5000);
			driver.switchTo().frame(thirdSubTab);
			break;
		case "Fourth":
			Thread.sleep(5000);
			driver.switchTo().frame(FourthSubTab);
			break;
		case "Fifth":
			Thread.sleep(5000);
			driver.switchTo().frame(FifthSubTab);
			break;
		case "Search":
			Thread.sleep(5000);
			driver.switchTo().frame(searchFrame);
		case "Results":
			Thread.sleep(5000);
			driver.switchTo().frame(resultsFrame);
		case "Policy CC GAU QPI SIU Cases":
			Thread.sleep(5000);
			driver.switchTo().frame(ccgauqpisiucasesPolicyFrame);
			break;
		case "Base":
			Thread.sleep(5000);
			driver.switchTo().frame(BaseFrame);
			break;
		case "Base to Home":
			Thread.sleep(5000);
			driver.switchTo().frame(BaseFrame).switchTo().frame(HomeFrame);
			break;
		case "Base to Notification":
			Thread.sleep(5000);
			driver.switchTo().frame(BaseFrame).switchTo().frame(NotificationFrame);
			break;
		case "Default":
			Thread.sleep(1000);
			driver.switchTo().defaultContent();
			break;
		case "PolicyTabs":
			Thread.sleep(1000);
			driver.switchTo().frame(ccpolicytabs);
			break;
		case "PolicyAccumulators":
			Thread.sleep(1000);
			driver.switchTo().frame(ccpolicyaccumulators);
			break;
		case "ViewPolicyBenefits":
			Thread.sleep(1000);
			driver.switchTo().frame(ccviewpolicybenefits);
			break;
		case "SearchMemberPolicyCoverage":
			Thread.sleep(1000);
			driver.switchTo().frame(ccsearachmemberpolicycoverage);
			break;
		case "PolicyPlanSubsidyHistory":
			Thread.sleep(1000);
			driver.switchTo().frame(ccpolicyplansubsidyhistory);
			break;
		case "PolicyViewAuthorizationStatus":
			Thread.sleep(1000);
			driver.switchTo().frame(ccpolicyviewauthorizationstatus);
			break;
		case "PolicyAuthorizationCCMS":
			Thread.sleep(1000);
			driver.switchTo().frame(ccpolicyauthorizationccms);
		case "searchClaims":
			Thread.sleep(1000);
			driver.switchTo().frame(sdhistoryframe);
			break;
		default:
			break;
		}
	}

	/**
	 * Method to Verify whether Console Tab is displayed or not
	 * 
	 * @return true or false
	 */
	public boolean VerifySCCFPageIsDisplayed() throws Exception {
		try {
			return blue2Applicationmyprofile.isDisplayed();
		} catch (Exception e) {
			WaitForPageToLoad(30);
			return blue2Applicationmyprofile.isDisplayed();
		}
	}
	

	public boolean VerifyErrorPageIsDisplayed() throws Exception{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		try {
			
			if(driver.findElement(By.xpath("//label[contains(@title,'Error')]")).isDisplayed());{
				
					
				return true;
			}
			
		}
		catch(Exception e) {
			
			return false;
		}
		
		
	}
	
	/*
	 * To read file as string
	 */
	// To read data from notepad
		public static String readFileAsString(String fileName) throws Exception {
			String data = "";
			data = new String(Files.readAllBytes(Paths.get(fileName)));
			return data;
		}
	/**
	 * verfiy if we are able to create message 
	 */
	
	public boolean IfabletoCraetemessage() throws Exception{
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		try {
			//add the text conatins
			//Thread.sleep(2000);
			if(driver.findElement(By.xpath("//*[@id='validationError']")).isDisplayed());{
				return true;
			}
		}
		catch(Exception e) {
			return false;
		}
		
	}
	/**
	 * Method to verfiy if sccf exists
	 */
	public boolean VerifySCCF() throws Exception{
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		try {
			if(driver.findElement(By.xpath("//*[@id='errorDisplay']/ul")).isDisplayed());{
				return true;
			}
		}
		catch(Exception e) {
			return false;
		}
		
	}
	
	/**
	 * Method to Verify whether page is displayed or not
	 * 
	 * @param strTitle - Page title identified by @class-pageDescription and HTML
	 *                 tag-h2
	 * @return true or false Modified on 04/30/2018
	 */
	public boolean IsPageDisplayed(String strTitle) throws Exception {
		
		String strActualTitle = driver.getTitle();

		if (strActualTitle.contains(strTitle)) {
			TextFileUtilities.Log("Verifying Page Title - " + strTitle, "DONE");
			return true;
			
		} else {
			TextFileUtilities.Log("Verifying Page Title - " + strTitle, "FAIL");
			return false;
		}
	}

	/**
	 * Method to Verify whether page type is displayed or not
	 * 
	 * @param strTitle - Page type identified by @class-pageDescription and HTML
	 *                 tag-h1
	 * @return true or false
	 */
	public boolean IsPageTypeDisplayed(String strTitle) throws Exception {
		TextFileUtilities.Log("Verifying Menu Page Title - " + strTitle, "DONE");
		String strActualTitle = pageType.getText();
		if (strActualTitle.toLowerCase().contains(strTitle.toLowerCase())) {
			return true;

		} else {
			return false;
		}
	}

	/**
	 * Method to Get page title
	 * 
	 * @param strTitleForReporting - Title to be used for logging the step in report
	 * @return strTitle - Page title identified by @class-pageDescription and HTML
	 *         tag-h2
	 */
	public String GetPageTitle(String strTitleForReporting) throws Exception {
		TextFileUtilities.Log("Getting " + strTitleForReporting, "DONE");
		WaitForPageToLoad(30);
		String strActualTitle = pageTitle.getText();
		return strActualTitle;
	}

	/**
	 * Method to Get page type
	 * 
	 * @param strTitleForReporting - Title to be used for logging the step in report
	 * @return strTitle - Page type identified by @class-pageDescription and HTML
	 *         tag-h1
	 */
	public String GetPageType(String strTitleForReporting) throws Exception {
		TextFileUtilities.Log("Getting " + strTitleForReporting, "DONE");
		WaitForPageToLoad(30);
		String strActualTitle = pageType.getText();
		return strActualTitle;
	}

	/**
	 * Method to Get check box status following a TD text in a Read only form e.g.
	 * View Case
	 * 
	 * @param strLabel - Label (Table cell) after which check box is present
	 * @return strStatus - Check box status (Checked/Unchecked)
	 */
	public String GetCheckboxStatusFromReadOnlyFormAfterLabel(String strLabel) throws Exception {
		TextFileUtilities.Log("Getting status of Checkbox - " + strLabel, "DONE");
		WaitForPageToLoad(30);
		String strStatus = driver.findElement(By.xpath("//td[text()='" + strLabel + "']//following::div[1]//img[1]"))
				.getAttribute("title");
		return strStatus;
	}





	/**
	 * Method to Get title from a label after a label
	 * 
	 * @param strLabel - Label before which Label is present
	 * @return strTitle - title of the label after label
	 */
	public String GetTitleFromLabelafterLabel(String strLabel) throws Exception {
		TextFileUtilities.Log("Getting Title of the label after the label - " + strLabel, "DONE");
		String strValue;
		try {
			WaitForPageToLoad(30);
			String strLabelid = strLabel.replaceAll(" ", "");
			strValue = driver.findElement(By.xpath(
					"//label[text()='" + strLabel + "' and contains(@id,'" + strLabelid + "') ]//following::label[1]"))
					.getAttribute("title");
		} catch (Exception e) {
			return "";
		}
		return strValue;
	}

	/**
	 * Method to Get Error text following a Label
	 * 
	 * @param strLabel - Label after which Error message is present
	 * @return strMessage - Error message text
	 */
	public String GetErrorTextAfterLabel(String strLabel) throws Exception {
		TextFileUtilities.Log("Getting Error Message related to - " + strLabel, "DONE");
		String strMessage;
		try {
			WaitForPageToLoad(30);
			strMessage = driver
					.findElement(By.xpath("//label[text()='" + strLabel + "']//following::div[@class='errorMsg']"))
					.getText();
		} catch (Exception e) {
			return "";
		}
		return strMessage;
	}

	/**
	 * Method to Get Error text displayed on top of the form
	 * 
	 * @param strForm - Form in which Error is present - Dummy value used for
	 *                reporting ONLY
	 * @return strErrorMessage - Error message text
	 */
	public String GetErrorAfterAction(String strForm) throws Exception {
		TextFileUtilities.Log("Getting Error Message from Form - " + strForm, "DONE");
		String strErrorMessage;
		try {
			WaitForPageToLoad(30);
			strErrorMessage = driver.findElement(By.xpath("//div[@class='pbError']")).getText();
		} catch (Exception e) {
			return "";
		}
		return strErrorMessage;
	}



	/**
	 * Method to Get text following a TD text in a Read only form e.g. View Case
	 * 
	 * @param strLabel - Label (Table cell) after which check box is present
	 * @return strValue - Text
	 */
	public String GetTextFromReadOnlyFormAfterLabel(String strLabel) throws Exception {
		TextFileUtilities.Log("Getting value of - " + strLabel, "DONE");
		WaitForPageToLoad(30);
		String strValue = driver.findElement(By.xpath("//td[text()='" + strLabel + "']//following::td[1]")).getText();
		return strValue;
	}

	/**
	 * Method to Get Current Date and Time
	 * 
	 * @return Date in M/d/yyyy h:mm aaa format e.g. 4/3/2018 11:29 PM
	 */
	public String GetCurrentDateTime() throws InterruptedException {
		SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy h:mm aaa");
		Date date = new Date();
		return formatter.format(date);
	}

	/**
	 * Method to Get Current Date and Time (Overloaded)
	 * 
	 * @param strDateTimeFormat - Dummy input
	 * @return Date in M/d/yyyy format e.g. 4/3/2018
	 */
	public String GetCurrentDateTime(String strDateTimeFormat) throws InterruptedException {
		SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy");
		Date date = new Date();
		return formatter.format(date);
	}

	/**
	 * Method to Get Date and Time offset by number of days
	 * 
	 * @param intOffsetDays - Offset days, Accepts both Positive and Negative
	 *                      integers
	 * @return Date in M/d/yyyy h:mm aaa format e.g. 4/3/2018 11:29 PM
	 */
	public String GetDateTime(String intOffsetDays) throws InterruptedException {
		if (intOffsetDays.substring(0, 2).equals("dt")) {
			intOffsetDays = GetTestData(intOffsetDays);
		}
		if (intOffsetDays.equals("NULL")) {
			return "NULL";
		}
		SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy h:mm aaa");
		Date date = new Date();
		date = addDays(date, Integer.parseInt(intOffsetDays));
		return formatter.format(date);
	}

	/**
	 * Method to Get Current Date
	 * 
	 * @return Date in M/d/yyyy format e.g. 4/3/2018
	 */
	public String GetSimpleCurrentDateTime() throws InterruptedException {
		SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy");
		Date date = new Date();
		return formatter.format(date);
	}

	/**
	 * Method to Get Current Date in MMddyyyy
	 * 
	 * @return Date in MMddyyyy format e.g. 11042021
	 */
	public static String GetSimpleCurrentDate() throws InterruptedException {
		SimpleDateFormat formatter = new SimpleDateFormat("MMddyyyy");
		Date date = new Date();
		return formatter.format(date);
	}
	
	/**
	 * Method to Get passed Date in required format
	 * 
	 * @param format,required format eg.MMddyyy,yyMMdd.etc
	 * @date - required date.
	 * @return Date in requested format in format variable
	 */
	public static String dateFormatter( String date,String currentFormat ,String requiredFormat ) {
		LocalDate d2 = LocalDate.parse(date,DateTimeFormatter.ofPattern(currentFormat));
		return d2.format(DateTimeFormatter.ofPattern(requiredFormat));
		}

	/**
	 * Method to Get Date/Date Time offset by number of days
	 * 
	 * @param intDays - Offset days, Accepts both Positive and Negative integers
	 * @return Date/Date Time in input format
	 */
	public String GetCurrentDateAndAddDays(int intDays) throws InterruptedException {
		SimpleDateFormat formatter = new SimpleDateFormat("MMddyyyy");
		Date date = new Date();
		date = addDays(date, intDays);
		return formatter.format(date);
	}

	/**
	 * Method to add/subtract days from a given date
	 * 
	 * @param datDate - Date
	 * @param intDays - Offset days, Accepts both Positive and Negative integers
	 * @return Date in M/d/yyyy e.g. 4/3/2018
	 */
	public static Date addDays(Date datDate, int intDays) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(datDate);
		cal.add(Calendar.DATE, intDays); // minus number would decrement the days
		return cal.getTime();
	}

	/**
	 * Method to switch to a newly opened Browser Tab
	 */
	public void SwitchToNewTab() throws Exception {
		TextFileUtilities.Log("Switching focus to New Tab", "DONE");
		// Switch to new window opened
		Thread.sleep(5000);
		oldTab = driver.getWindowHandle();
		ArrayList<String> newTab = new ArrayList<String>(driver.getWindowHandles());
		newTab.remove(oldTab);
		// change focus to new tab
		driver.switchTo().window(newTab.get(0));

		// Do what you want here, you are in the new tab

		driver.close();
		// change focus back to old tab
		driver.switchTo().window(oldTab);
	}

	/**
	 * Method to switch to a old Tab after moving to a new Browser Tab
	 */
	public void SwitchToOldTab(String strValue) throws Exception {
		TextFileUtilities.Log("Switching back to Old Tab", "DONE");
		driver.close();
		// change focus back to old tab
		driver.switchTo().window(oldTab);
	}

	/**
	 * Method to wait for the java script in the page to load for the mentioned
	 * seconds before timing out
	 * 
	 * @param sec - Number of seconds to wait
	 * @throws InterruptedException
	 */
	public void WaitForPageToLoad(int sec) throws InterruptedException {
		new WebDriverWait(driver, 180).until((ExpectedCondition<Boolean>) wd -> ((JavascriptExecutor) wd)
				.executeScript("return document.readyState").toString().equals("complete"));
		Thread.sleep(1000);
	}

	public void ChangeownerStringLookup(String strValue) {
		String MainWindow = driver.getWindowHandle();
		// To handle all new opened window.
		Set<String> s1 = driver.getWindowHandles();
		Iterator<String> i1 = s1.iterator();
		while (i1.hasNext()) {
			String ChildWindow = i1.next();
			if (!MainWindow.equalsIgnoreCase(ChildWindow)) {
				// Switching to Child window
				driver.switchTo().window(ChildWindow);
			}
		}
		try {
			driver.manage().window().maximize();
			WaitForPageToLoad(30);
			driver.switchTo().frame(0);
			SetTextAfterLabel("Search", strValue);
			ClickOnButtonByTitle("Go!");
			Thread.sleep(2000);
			driver.switchTo().defaultContent();
			driver.manage().window().maximize();
			driver.switchTo().frame(1);
			WaitForPageToLoad(30);
			try {
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				ClickOnLinkByText("Show all results");
				Thread.sleep(1000);
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			} catch (Exception e) {
			}
			try {
				ClickOnLinkByText(strValue);
				Thread.sleep(3000);
				driver.switchTo().window(MainWindow);
				driver.switchTo().defaultContent();
			} catch (Exception e) {

				Assert.error(e, "There is an exception while Click");

			}
		} catch (Exception e) {
			Assert.error(e, "There is an exception while opening the page");
		}
	}

	
	/**
	 * Method to Launch URL
	 * 
	 * @param strURL - Dummy Value
	 */
	
	public void Launch(String strURL) throws Exception {
		Thread.sleep(3000);
		//chnage the name
		
		driver.get(strURL);
		boolean loginpage = IsPageDisplayed("Blue");
		if (loginpage) {
			//Pass/fail
			TextFileUtilities.Log("Log in page is displayed", "DONE");
		} else {
			TextFileUtilities.Log("Log in page is not displayed", "FAIL");
			throw new Exception("URL Launch Failed");
		}

		try {
			driver.switchTo().alert().accept();
		} catch (Exception e) {
		}
	}
	
	/**
	 * Method to get the trading Partner
	 */

	public static void dropDown(String select, String value)
	{

	Select sel = new Select(driver.findElement(By.xpath("//label[text()='"+ select + "']//following::select[1]")));
	sel.selectByVisibleText(value);



	}
	/**
	 * Method to Login to RIproviderportal
	 * 
	 * @param strUserName - UserID
	 * @param strPassword - Password
	 */
	public void Login(String Username,String Password) throws Exception {
		
		try {
		//explicit wait
		WaitForPageToLoad(30);
		
		// Entering the user ID in the text field.
		SetTextAfterLabel("User Name", Username);
		TextFileUtilities.Log("Entered username to login Blue2 - " + Username, "DONE");
		
		// Entering the Password in the text field.
		//SetTextAfterLabel("Password", strPwd);
		SetTextAfterLabel("Password", aesTest.decrypt(Password));
		// Click on the Login button with the title match
		ClickOnButtonByTitle("Login");
		
		WaitForPageToLoad(30);
		}catch  (Exception e) {
			Assert.error(e, "There is an exception to login to the application");
			
		}	
	

	}
/**
 * Method to pick the SCCF ID FROM TEST DATA SHEET
 * @throws Exception 
 */
	
	public void ClickonSCCFhistory() throws Exception {
		boolean Blue2home = IsPageDisplayed("Blue");
	try {	
		if (Blue2home) {
			
			//verify page title
			ClickOnButtonByTitleTab("SCCF History");
			//WaitForPageToLoad(10);
			IsSCCFPageDisplayed();

		}
	} catch (Exception e) {
		
		Assert.error(e, "There is an exception to login to the application");
	}
		
		
		
	}
	/**
	 * Method to fill the details to create adjacent message
	 */
	public void EnterAdjacetClaimDetails(String ReasonCode,String CashRefundIndicator, String Notes, String Name,String PhoneNumber,String State, String Date) throws Exception {
		
		//click on DF
		//ClickOnTabByText("DF");
		
		//click of create adjacent mesage tab
		//ClickOnButtonByButtonTab("Create Adjustment Message");
		
		//select the reason code
		SelectListItemAfterLabel1("reasonCodeSel",ReasonCode);
		
		// Get Recieved Date Value
		SetTextAreaAfterLabeltext("*Adjustment Receipt Date ", Date);
		
		//select the indicator
		SelectListItemAfterLabel("* Cash Refund Indicator ",CashRefundIndicator);
		
		// Notes
		SetTextAreaAfterLabelNotes("msgRequired", Notes);
		
		//Enter the phone Number
		SetTextAreaAfterLabeltext("* Phone",PhoneNumber);
		
		//Enter the User Name
		SetTextAreaAfterLabeltext("* Name ",Name);
		
		//select the state
		SelectListItemAfterLabel1("userStateSel",State);
		
	}
	
	/**
	 * Method to Verify Home page is displayed or not
	 */
	public void IsSCCFPageDisplayed() throws Exception {
		WaitForPageToLoad(10);
		System.out.println("Waiting for Page to Load!!");
		if (VerifySCCFPageIsDisplayed()) {
			TextFileUtilities.Log("SCCF History Page is displayed", "DONE");
			//WaitForPageToLoad(30);
		} else {
			TextFileUtilities.Log("SCCF History Page is not displayed", "FAIL");
			throw new Exception("EXIT TEST");
		}
	}
	

	/**
	 * Method to Set Test Data File
	 * 
	 * @param strFile - Test Data File name with out extension e.g. RQD0001741A for
	 *                RQD0001741A.properties file
	 */
	public void SetTestDataFile(DataTable strFileName) throws Exception {
		TextFileUtilities.Log("Setting Test Data File - " + strFileName, "DONE");
		dt = strFileName;
	}

	/**
	 * Method to Set Current Test Environment
	 */
	public void SetTestEnvironmentFile() throws Exception {
		testenvironment = new File(System.getProperty("user.dir") + "//src//data//config//environment.properties");
		//strTestEnvironment = GetExecutionEnvironment("Environment");
		testenvdata = new File(
				System.getProperty("user.dir") + "//src//data//config//" + strTestEnvironment + ".properties");
	}

	/**
	 * Method to Set Test Data File to an output file generated by another script
	 * 
	 * @param strFile - Test Data File name with out extension e.g. RQD0001741A for
	 *                RQD0001741A.properties file
	 */
	public void SetTestDataFileFromOutput(String strFileName) throws Exception {
		TextFileUtilities.Log("Setting Test Data File to an Ouput Data File - " + strFileName, "DONE");
		SetTestEnvironmentFile();
		//String strTestEnvironment = GetExecutionEnvironment("Environment");
		testdata = new File(System.getProperty("user.dir") + "//src//data//output//" + strTestEnvironment + "//"
				+ strFileName + ".properties");
	}

	/**
	 * Method to Set Test Data Output File to write data
	 * 
	 * @param strFile - Test Data File name with out extension e.g. RQO0001741A for
	 *                RQO0001741A.properties file
	 */
	public void SetTestOutputFile(String strFileName) throws Exception {
		TextFileUtilities.Log("Setting Test Ouput Data File - " + strFileName, "DONE");
		testoutput = new File(System.getProperty("user.dir") + "//src//data//output//" + strTestEnvironment + "//"
				+ strFileName + ".properties");
	}

	/**
	 * Method to Get value from current test data file by providing Key
	 * 
	 * @param strKey - Key of a Key-Value pair e.g. dtUsername=abc@xyz.com where
	 *               dtUsername is Key
	 * @return Value of the Key
	 */
	public String GetTestData(String strKey) {
		return dt.getValue(strKey);
	}

	/**
	 * Method to Get value from current environment file
	 * 
	 * @param strKey - Key of a Key-Value pair e.g. dtUsername=abc@xyz.com where
	 *               dtUsername is Key
	 * @return Value of the Key
	 */
	public String GetEnvironmentData(String strRowParam, String strColParam) {
		// String strTestConfigDir = System.getProperty("user.dir") +
		// "/resources/config/";
		//String strTestConfigDir = Environment.get("BASE_DIR") + "/config/";
		String strTestConfigDir = Environment.get("config_path");
		DataTable environment = new DataTable(strTestConfigDir + "Environment.xlsx", strTestEnvironment, strRowParam);
		return environment.getValue(strColParam);
	}

	/**
	 * Click on button by type
	 * @param strButtonName
	 * @throws Exception
	 */
	public void ClickOnButtonByType(String strButtonName) throws Exception {
		
		WebElement element = driver.findElement(By.xpath("//button[@type='" + strButtonName + "']"));
		//("//input[@title='" + strButtonName + "']"));
		System.out.println(element);
		
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
			Thread.sleep(5000);
			TextFileUtilities.Log("Clicking on Button - " + strButtonName, "PASS");
		} catch (StaleElementReferenceException e) {
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
			TextFileUtilities.Log("Clicking on Button - " + strButtonName, "PASS");
		} catch (Exception e) {
			TextFileUtilities.Log("Clicking on Button - " + strButtonName, "FAIL");
		}
	
	}
	

	/**
	 * Verifying whether the table is present or not in a form
	 * 
	 * @param strformaction - @action contains of the form added on 07/21/2018
	 */
	public void isTableDisplayedinform(String strformaction) throws Exception {
		TextFileUtilities.Log("Verifying the link is displayed or not - " + strformaction, "DONE");
		try {
			WaitForPageToLoad(30);
			if (driver.findElement(By.xpath("//form[contains(@action,'" + strformaction + "')]//following::table"))
					.isDisplayed()) {
				TextFileUtilities.Log("Table is displayed - " + strformaction, "PASS");
			} else {
				TextFileUtilities.Log("Table is not displayed - " + strformaction, "FAIL");
			}
		} catch (Exception e) {
			TextFileUtilities.Log(strformaction + " Link is not displayed", "FAIL");
		}
	}
	
	
	//public  void FetchPaymentdetails(String Total_Amount_Approved_for_Payment,String Total_Deductible_Amount,String Total_Coinsurance_Amount,String Total_Copay_Amount) {
	public static String[] 	FetchPaymentdetails(String strllabel1,String strllabel2,String strllabel3,String strllabel4,String strllabel5) {
	
	    String[] names = new String[5];
      
	      names[0] = driver.findElement(By.xpath("//label[text()='" + strllabel1 + "']//following::span[1]")).getText();
	      names[1] =driver.findElement(By.xpath("//label[text()='" + strllabel2 + "']//following::span[1]")).getText();
	      names[2]=driver.findElement(By.xpath("//label[text()='" + strllabel3 + "']//following::span[1]")).getText();
	      names[3]=driver.findElement(By.xpath("//label[text()='" + strllabel4 + "']//following::span[1]")).getText();
	      names[4]=driver.findElement(By.xpath("//label[text()='" + strllabel5 + "']//following::span[1]")).getText();
     
      return names;
	}
	
	public static String[] 	FetchPaymentdetailsLos(String strllabel1,String strllabel2,String strllabel3,String strllabel4) throws InterruptedException {
	
	    String[] names = new String[4];
//xpaths
	    WebDriverWait wait = new WebDriverWait(driver, 10);
	    Thread.sleep(10000);
	    names[0] = driver.findElement(By.xpath("//label[text()='" + strllabel1 + "']//following::span[1]")).getText();
	      names[1] =driver.findElement(By.xpath("//label[text()='" + strllabel2 + "']//following::span[1]")).getText();
	      names[2]=driver.findElement(By.xpath("//label[text()='" + strllabel3 + "']//following::span[1]")).getText();
	      names[3]=driver.findElement(By.xpath("//label[text()='" + strllabel4 + "']//following::span[1]")).getText();
	     
      
      
      return names;
	}


}
