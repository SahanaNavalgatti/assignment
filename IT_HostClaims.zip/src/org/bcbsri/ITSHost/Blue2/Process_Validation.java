package org.bcbsri.ITSHost.Blue2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.bcbsri.ITSHost.Comparison.ITS_Claims_Code;
import org.bcbsri.ITSHost.dbutility.TextFileUtilities;

import com.dell.acoe.framework.config.Environment;

public class Process_Validation {
	
	
	public static void Validate_CompletionStatus() throws Exception {
		
		//Variable Declaration
		String File_Name = "";
		String FileExist = "";
		String Comparison_Status = "";
		String Facets_Status = "";
		String Blue2_Status = "";
		String Blue2_Payment_Status= null;
		int TestData_Rowcount;
		int Comparison_Status_Col = 0;
		int Facets_Status_Col = 0;
		int Blue2_Status_Col = 0;
		int Final_Status_Col = 0; 
		int Blue2_Payment_Status_Col= 0;

		String File_Path = Environment.get("test_data_path");
		File folder = new File(File_Path);
		File[] fileList = folder.listFiles();
		
		String PreMove = Environment.get("Environment");
		
	    //Get the Test Data File Name through Partial Text
		for(File fileName:fileList) {
			//System.out.println(fileName.getName());
			if(fileName.getName().toUpperCase().contains("ITSHOST")) {
				
				File_Name = fileName.getName();
				FileExist = "True";
				break;
				
			}
			
		}
		
		if(FileExist=="True") {
			
			String Testdata_File = File_Path+"\\"+File_Name;
			
			FileInputStream fis = new FileInputStream(Testdata_File);
			XSSFWorkbook wbook_1 = new XSSFWorkbook(fis);
			String SheetName = wbook_1.getSheetName(0);
			Sheet sheet = wbook_1.getSheet(SheetName);
			TestData_Rowcount = sheet.getPhysicalNumberOfRows();
			
			FormulaEvaluator evaluator = wbook_1.getCreationHelper().createFormulaEvaluator();
			
			Row Head_row = null;
			
			for(int i = 1; i<=TestData_Rowcount-1; i++) {
				
				Comparison_Status = "";
				Facets_Status = "";
				Blue2_Status = "";
				
				Row row = sheet.getRow(i); 
				Head_row = sheet.getRow(0);
				
				int ColCount = Head_row.getPhysicalNumberOfCells();
				
				if(i==1) {
					
					//Comparison Notes
					for(int j=0;j<=ColCount-1;j++) {
						
						Cell cell = Head_row.getCell(j);
						
						if(cell.getStringCellValue().trim().equals("Comparison_Notes")) {
							Comparison_Status = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, i, j);
							Comparison_Status_Col = j;
							break;
						}
						
					}
					
					//Facets Status
					for(int j=0;j<=ColCount-1;j++) {
						
						Cell cell = Head_row.getCell(j);
						
						if(cell.getStringCellValue().trim().equalsIgnoreCase("Facets_Status")) {
							Facets_Status = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, i, j);
							Facets_Status_Col = j;
							break;
						}
						
					}
					
					//Blue2 Status
					for(int j=0;j<=ColCount-1;j++) {
						
						Cell cell = Head_row.getCell(j);
						
						if(cell.getStringCellValue().trim().equalsIgnoreCase("Blue2_ARM_Status")) {
							Blue2_Status = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, i, j);
							Blue2_Status_Col = j;
							break;
						}
						
					}
					
					//Blue2_Payment_Status
                    for(int j=0;j<=ColCount-1;j++) {
					
					Cell cell = Head_row.getCell(j);
					
					if(cell.getStringCellValue().trim().equalsIgnoreCase("Blue2_Payment_Status")) {
						Blue2_Payment_Status = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, i, j);
						Blue2_Payment_Status_Col = j;
						break;
					}
					
				}
					//Get ScriptExecutionStatus Column ID
					for(int j=0; j<=ColCount-1; j++) {

						Cell cell = Head_row.getCell(j);
						
						if(cell.getStringCellValue().trim().equals("ScriptExecutionStatus")) {
							Final_Status_Col = j;
							break;
						}
						
					}
					
					//Create ScriptExecutionStatus Column if not exist
					if(Final_Status_Col==0) {
						Head_row.createCell(Head_row.getPhysicalNumberOfCells()).setCellValue("ScriptExecutionStatus");
						Final_Status_Col = Head_row.getPhysicalNumberOfCells()-1;
					}
					
					
					//Validation & Create Final Status Message
					if((Comparison_Status.trim().toUpperCase().contains("PLEASE APPROVE"))) {
						
						//Facets Status
						if(Facets_Status.trim().toUpperCase().contains("SUCCESS")&&Blue2_Payment_Status.trim().toUpperCase().contains("NA")) {
							
							//Blue2 Status
							if(Blue2_Status.trim().toUpperCase().contains("SUCCESS")) {
								
								Cell Final_Status = row.createCell(Final_Status_Col);
								Final_Status.setCellValue("COMPLETED");
								
							}else {
								Cell Final_Status = row.createCell(Final_Status_Col);
								Final_Status.setCellValue("MOVED TO MANUAL");
							}
							
						}else {
							Cell Final_Status = row.createCell(Final_Status_Col);
							Final_Status.setCellValue("MOVED TO MANUAL");
						}
						
					}
					
	          else if((Comparison_Status.trim().toUpperCase().contains("NO CHANGES"))) {
						
						//Blue2_Payment_Status
						if(Blue2_Payment_Status.trim().toUpperCase().contains("SUCCESS")&&Blue2_Status.trim().toUpperCase().contains("NA")) {
							
							//Facets status
							if(Facets_Status.trim().toUpperCase().contains("SUCCESS")) {
								Cell Final_Status = row.createCell(Final_Status_Col);
								Final_Status.setCellValue("COMPLETED");
							}else {
								Cell Final_Status = row.createCell(Final_Status_Col);
								Final_Status.setCellValue("MOVED TO MANUAL");
							}
							
						}
						else {
							Cell Final_Status = row.createCell(Final_Status_Col);
							Final_Status.setCellValue("MOVED TO MANUAL");
						}
					
	          }
					
					else {
						Cell Final_Status = row.createCell(Final_Status_Col);
						Final_Status.setCellValue("MOVED TO MANUAL");
					}
					
				}else {
					
					//Comparison Status
					Cell cell = row.getCell(Comparison_Status_Col);
					
					if(!(cell==null)) {
						
						switch (evaluator.evaluateInCell(cell).getCellType()) {
						  
						  case Cell.CELL_TYPE_STRING: 
							  
							  Comparison_Status = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, i, Comparison_Status_Col);
							  break;
							  
						}
						
					}
					
					//Facets Status
					Cell cell_1 = row.getCell(Facets_Status_Col);
					
					if(!(cell_1==null)) {
						
						switch (evaluator.evaluateInCell(cell_1).getCellType()) {
						  
						  case Cell.CELL_TYPE_STRING: 
							  
							  Facets_Status = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, i, Facets_Status_Col);
							  break;
							  
						}
						
					}
					
					
					//Blue2 Status
					Cell cell_2 = row.getCell(Blue2_Status_Col);
					
					if(!(cell_2==null)) {
						
						switch (evaluator.evaluateInCell(cell_2).getCellType()) {
						  
						  case Cell.CELL_TYPE_STRING: 
							  
							  Blue2_Status = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, i, Blue2_Status_Col);
							  break;
							  
						}
						
					}
					//Blue2 Payment Status
                    Cell cell_3 = row.getCell(Blue2_Payment_Status_Col);
					
					if(!(cell_3==null)) {
						
						switch (evaluator.evaluateInCell(cell_3).getCellType()) {
						  
						  case Cell.CELL_TYPE_STRING: 
							  
							  Blue2_Payment_Status = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, i, Blue2_Payment_Status_Col);
							  break;
							  
						}
						
					}
					
					
					//Validation & Create Final Status Message
					if((Comparison_Status.toUpperCase().contains("PLEASE APPROVE"))) {
						
						//Facets Status
						if(Facets_Status.toUpperCase().trim().equals("SUCCESS")) {
							
							//Blue2 Status
							if(Blue2_Status.toUpperCase().trim().equals("SUCCESS")) {
								
								Cell Final_Status = row.createCell(Final_Status_Col);
								Final_Status.setCellValue("COMPLETED");
								
							}else {
								Cell Final_Status = row.createCell(Final_Status_Col);
								Final_Status.setCellValue("MOVED TO MANUAL");
							}
							
						}else {
							Cell Final_Status = row.createCell(Final_Status_Col);
							Final_Status.setCellValue("MOVED TO MANUAL");
						}
						
					} else if((Comparison_Status.trim().toUpperCase().contains("NO CHANGES"))) {
						
						//Blue2_Payment_Status
						if(Blue2_Payment_Status.trim().toUpperCase().contains("SUCCESS")) {
							
							//Facets status
							if(Facets_Status.trim().toUpperCase().contains("SUCCESS")) {
								Cell Final_Status = row.createCell(Final_Status_Col);
								Final_Status.setCellValue("COMPLETED");
							}else {
								Cell Final_Status = row.createCell(Final_Status_Col);
								Final_Status.setCellValue("MOVED TO MANUAL");
							}
							
						}
						else {
							Cell Final_Status = row.createCell(Final_Status_Col);
							Final_Status.setCellValue("MOVED TO MANUAL");
						}
					
	          }
				
					
					else {
						Cell Final_Status = row.createCell(Final_Status_Col);
						Final_Status.setCellValue("MOVED TO MANUAL");
					}
					
				}
				
			}
			
			FileOutputStream fout = new FileOutputStream(Testdata_File);
			wbook_1.write(fout);
			wbook_1.close();
			
		}else {
			TextFileUtilities.Log("Test Data Input file does not exist in Test data folder", "FAIL");
		}
		
	}
	
	
}
