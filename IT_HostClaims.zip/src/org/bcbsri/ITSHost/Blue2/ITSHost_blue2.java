package org.bcbsri.ITSHost.Blue2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.bcbsri.ITSHost.dbutility.TextFileUtilities;
import org.bcbsri.configvalidation.Readexcel;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.selenium.FrameworkDriver;
import com.dell.acoe.framework.selenium.verify.Assert;

public class ITSHost_blue2 {

	// Variable Declaration
	static String File_Name = "";
	static String FileExist = "";
	private static WebDriver driver = null;
	public static int SCCF_Col;
	public static int Notes_Col;
	public static int Date_Col;
	static boolean flag;
	static boolean status;
	static int counter = 0; 
	static String Prod_URL = Environment.get("Blue2Application_PROD_WEB_URL");
	static String Test_URL = Environment.get("Blue2Application_TEST_WEB_URL");
	static String Prod_strUser = Environment.get("Blue2Application.prod.Username");
	static String Test_strUser = Environment.get("Blue2Application.test.Username");
	static String Prod_strPwd = Environment.get("Blue2Application.prod.Password");
	static String Test_strPwd = Environment.get("Blue2Application.test.Password");
	static String Name = Environment.get("Blue2Application.Name");
	static String PhoneNumber = Environment.get("Blue2Application.PhoneNumber");
	static String State = Environment.get("Blue2Application.State");
	static String ReasonCode = Environment.get("Blue2Application.ReasonCode");
	static String CashRefundIndicator = Environment.get("Blue2Application.CashRefundIndicator");
	static int Status_Col = 0;
	static int Facets_Status_Col = 0;

	public static void blue2bot() throws Exception {

		String File_Path = Environment.get("test_data_path");
		File folder = new File(File_Path);
		File[] fileList = folder.listFiles();

		try {

			// Get the File name of Test Data Sheet
			for (File fileName : fileList) {
				// System.out.println(fileName.getName());
				if (fileName.getName().toUpperCase().contains("ITSHOST")) {

					File_Name = fileName.getName();
					FileExist = "True";

				}

			}

			// Read Test Data Sheet
			if (FileExist == "True") {

				BrowserSteup.loadChromeBrowser();
				driver = FrameworkDriver.driver;
				// Initialize all Page Objects
				// change the name and remove the unwanted methods
				Blue2Application blue2Application = PageFactory.initElements(driver, Blue2Application.class);

				// String Env = Environment.get("Blue2Application.Environment");
				String Env = Environment.get("Environment");

				if (Env.equalsIgnoreCase("PROD")) {
					// launch url
					blue2Application.Launch(Prod_URL);
					// Login to the page
					blue2Application.Login(Prod_strUser, Prod_strPwd);

				} else if (Env.equalsIgnoreCase("TEST") || Env.equalsIgnoreCase("MINOR")) {

					// launch URL
					blue2Application.Launch(Test_URL);
					// Login to the page
					blue2Application.Login(Test_strUser, Test_strPwd);

				} else {
					TextFileUtilities.Log("Environment Value provided in config sheet is not valid: " + Env, "FAIL");
				}

				// Click on SSCF ID Tab
				blue2Application.ClickonSCCFhistory();

				String Testdata_File = Environment.get("test_data_path")+"\\"+File_Name;
				FileInputStream fis = new FileInputStream(Testdata_File);
				XSSFWorkbook wbook = new XSSFWorkbook(fis);
				String SheetName = wbook.getSheetName(0);
				Sheet sheet = wbook.getSheetAt(0);
				int TestData_Rowcount = sheet.getPhysicalNumberOfRows();

				//Create a Column to Export Status of the Blue2 Execution Process
				Row Head_Row = sheet.getRow(0);
				int ColCount = Head_Row.getPhysicalNumberOfCells();
				int blue2_status_Col = 0;

				// Get the Status Column Value if Exists
				for (int col = 0; col <= ColCount - 1; col++) {

					Cell cell = Head_Row.getCell(col);

					if (cell.getStringCellValue().trim().equals("Blue2_ARM_Status")) {
						blue2_status_Col = col;
						break;
					}

				}

				// Create Status Column if not exists
				if (blue2_status_Col == 0) {
					Head_Row.createCell(Head_Row.getPhysicalNumberOfCells()).setCellValue("Blue2_ARM_Status");
					blue2_status_Col = Head_Row.getPhysicalNumberOfCells() - 1;
					FileOutputStream fos = new FileOutputStream(Testdata_File);
					wbook.write(fos);
				}

				// Read Test Data to create Adjustment Message
				start: for (int i = 0; i <= TestData_Rowcount - 1; i++) {

					Row row = sheet.getRow(i);
					Row Head_row = sheet.getRow(0);
					ColCount = Head_row.getPhysicalNumberOfCells();

					// Get the Column Id's in First Iteration
					if (i == 0) {

						// Notes Column
						for (int j = 0; j <= ColCount - 1; j++) {

							Cell cell = Head_row.getCell(j);

							if (cell.getStringCellValue().trim().equals("Comparison_Notes")) {
								Notes_Col = j;
								break;
							}

						}

						// Facets Status Column
						for (int j = 0; j <= ColCount - 1; j++) {

							Cell cell = Head_row.getCell(j);

							if (cell.getStringCellValue().trim().equals("Facets_Status")) {
								Facets_Status_Col = j;
								break;
							}

						}

						// SCCF Num Column
						for (int j = 0; j <= ColCount - 1; j++) {

							Cell cell = Head_row.getCell(j);

							if (cell.getStringCellValue().trim().equals("SCCF_Txt")) {
								SCCF_Col = j;
								break;
							}

						}

						// Recieved Date Column
						for (int j = 0; j <= ColCount - 1; j++) {

							Cell cell = Head_row.getCell(j);

							if (cell.getStringCellValue().trim().equals("Received_Date")
									|| cell.getStringCellValue().trim().equals("Received Date")) {
								Date_Col = j;
								break;
							}

						}

					} else {

						// From Second Iteration - Read Values to enter in Blue2 application

						// Get the Comparision Notes
						String Facets_Status = Readexcel.ReadCellData(Testdata_File, SheetName, i, Facets_Status_Col);
						String Notes = Readexcel.ReadCellData(Testdata_File, SheetName, i, Notes_Col);
						String Partial_Text = "Please approve".toLowerCase();
						String Partial_Text1 = "No Changes".toLowerCase();
						String Partial_Text2 = "Skipping".toLowerCase();
						//String Partial_Text1 = "No Changes".toLowerCase();
						// System.out.println(Notes);
						String SCCF = "";
						   String Notapplicable_Message = "NA";
						if(Notes.toLowerCase().startsWith(Partial_Text1)||Notes.toLowerCase().startsWith(Partial_Text2)) {
						
							
							Readexcel.setCellData4(Testdata_File, blue2_status_Col, i, Notapplicable_Message);
						}

						// Create Adjustment Message for Claims with correction Notes
						if (Notes.toLowerCase().startsWith(Partial_Text)) {

							String temp = Readexcel.ReadCellData(Testdata_File, SheetName, i, SCCF_Col);
							SCCF = temp.substring(0, temp.length() - 2);

							// Initiate Blue2 Flow based on Facets Override Status
							if (Facets_Status.trim().equalsIgnoreCase("SUCCESS")) {

								// Enter SCCF ID to Search
								blue2Application.SetTextAfterLabel1("SCCF", SCCF);
								blue2Application.SelectListItemAfterLabel("Format Type  ","DF");
								blue2Application.ClickOnButtonByTitle("Search");
								Thread.sleep(300);

								// Validate if SCCF Exists
								if (blue2Application.VerifySCCF()) {

									TextFileUtilities.Log("SCCF doesnot exists - " + SCCF, "FAIL");
									String ErrorMessage = driver.findElement(By.xpath("//*[@id='errorDisplay']/ul"))
											.getText();
									Readexcel.setCellData4(Testdata_File, blue2_status_Col, i, ErrorMessage);
									blue2Application.ClickonSCCFhistory();
									continue;

								}

								// Get Row Count of Search Results
								String element = driver.findElement(By.xpath("//div[@class='results']")).getText();
								String[] arrOfStr = element.split("of");
								String[] arrOfStr1 = arrOfStr[0].split("-");
								String[] arrOfStr2 = arrOfStr[1].split(" ");
								String CurrentPageRowCount = (arrOfStr1[1]);
								String TotalRowCount = (arrOfStr2[1]);

								// Navigate till Last page of search results
								while (!CurrentPageRowCount.trim().equals(TotalRowCount)) {

									status = true;
									blue2Application.WaitForPageToLoad(90);
									blue2Application.ClickOnButtonByTitleTab("Next");
									blue2Application.WaitForPageToLoad(30);
									counter = counter + 1;
									String element1 = driver.findElement(By.xpath("//div[@class='results']")).getText();
									String[] arrOfStr11 = element1.split("of");
									String[] arrOfStrnew = arrOfStr11[0].split("-");
									String[] arrOfStr22 = arrOfStr11[1].split(" ");
									CurrentPageRowCount = (arrOfStrnew[1]);
									TotalRowCount = (arrOfStr22[1]);
									blue2Application.WaitForPageToLoad(30);

								}

								// Below is the flow if search result row count is less than 25 rows
								if (status == false) {

									//blue2Application.WaitForPageToLoad(30);
									List<WebElement> Format = driver
											.findElements(By.xpath("//table[@id='resultsRecord']//tr//td[3]"));
									List<WebElement> Status = driver
											.findElements(By.xpath("//table[@id='resultsRecord']//tr//td[6]"));
									// variables i,j,k

									for (int j = Format.size() - 1; j >= 0; j--) {

										if (Format.get(j).getText().equals("DF")
												&& Status.get(j).getText().equals("Closed")) {

											Format.get(j).click();
											TextFileUtilities.Log("Clicked DF Record with Closed Status for SCCF - " + SCCF, "PASS");
											flag = true;
											break;
										}

										else if (Format.get(j).getText().equals("DF")
												&& Status.get(j).getText().equals("Open")) {

											TextFileUtilities
													.Log("Cannot Create Adjustment Message as Last DF record is in Open Status - "
															+ SCCF, "FAIL");

											Readexcel.setCellData4(Testdata_File, blue2_status_Col, i,
													"Last DF record is in Open Status - Cannot Create Adjustment Message");
											blue2Application.ClickonSCCFhistory();
											continue start;

										}

									}

									// Report if DF doesnt exist
									if (flag == false) {
										// Log when DF is in open status
										TextFileUtilities.Log("DF Record is not present for SCCF " + SCCF, "FAIL");

										Readexcel.setCellData4(Testdata_File, blue2_status_Col, i,
												"DF Record does not exist in search results");
										blue2Application.ClickonSCCFhistory();
										continue start;

									}

								} else {

									// Below Flow is after Finding the Last DF Record
									if (CurrentPageRowCount.trim().equals(TotalRowCount)) {

										// Get Status and Format Values for Last DF
										//blue2Application.WaitForPageToLoad(30);
										List<WebElement> Format = driver
												.findElements(By.xpath("//table[@id='resultsRecord']//tr//td[3]"));
										List<WebElement> Status = driver
												.findElements(By.xpath("//table[@id='resultsRecord']//tr//td[6]"));

										// Click Last DF
										for (int j = Format.size() - 1; j >= 0; j--) {

											if (Format.get(j).getText().equals("DF")
													&& Status.get(j).getText().equals("Closed")) {
												Format.get(j).click();
												TextFileUtilities.Log("Clicked DF Record with Closed Status - " + SCCF,
														"PASS");
												flag = true;
												break;
											}

										}

										if (flag == false) {

											// TextFileUtilities.Log("DF is not Present in the last page, navigating to
											// previous page", "PASS");
											for (int k = 0; k < counter; k++) {

												blue2Application.ClickOnButtonByTitleTab("Previous");
												blue2Application.WaitForPageToLoad(30);
												List<WebElement> Format1 = driver.findElements(
														By.xpath("//table[@id='resultsRecord']//tr//td[3]"));
												List<WebElement> Status1 = driver.findElements(
														By.xpath("//table[@id='resultsRecord']//tr//td[6]"));

												for (int l = Format1.size() - 1; l >= 0; l--) {

													if (Format1.get(l).getText().equals("DF")
															&& Status1.get(l).getText().equals("Closed")) {
														Format1.get(l).click();
														TextFileUtilities.Log(
																"Clicked DF Record with Closed Status - " + SCCF,
																"PASS");
														flag = true;
														break;
													} else if (Format1.get(l).getText().equals("DF")
															&& Status1.get(l).getText().equals("Open")) {

														Readexcel.setCellData4(Testdata_File, blue2_status_Col, i,
																"Last DF record is in Open Status - Cannot Create Adjustment Message");
														blue2Application.ClickonSCCFhistory();
														continue start;

													}

												}

											}

											// Report if DF Record is not available in any of the pages
											if (flag == false) {

												TextFileUtilities.Log("DF Record is not present for SCCF " + SCCF,
														"FAIL");
												Readexcel.setCellData4(Testdata_File, blue2_status_Col, i,
														"DF Record does not exist in search results");
												blue2Application.ClickonSCCFhistory();
												continue start;

											}
										}

									}

								}

								// Create Adjustment Message
								if (blue2Application.IsCreateAdjacentMessageDisdplayed("Create Adjustment Message")) {
									blue2Application.ClickOnButtonByButtonTab("Create Adjustment Message");
								} else {
									TextFileUtilities.Log(
											"Create Adjustment Message Button is not displayed for SCCF - " + SCCF,
											"FAIL");
									Readexcel.setCellData4(Testdata_File, blue2_status_Col, i,
											"Create Adjustment Message Button is not displayed");
									blue2Application.ClickonSCCFhistory();
									continue;
								}

								Thread.sleep(2000);
								
								//Verify Create New Message page is displayed
								if(blue2Application.IsPageDisplayed("Create New Message")) {
									
									// Get Recieved Date Value
									String Date = Readexcel.ReadCellData_Date(Testdata_File, SheetName, i, Date_Col);

									// Enter details
									blue2Application.EnterAdjacetClaimDetails(ReasonCode, CashRefundIndicator,Notes, Name,
											PhoneNumber, State, Date);
									
									//Thread.sleep(1000);

									//Send Message
									blue2Application.ClickOnButtonByType("submit");
									blue2Application.WaitForPageToLoad(30);
									//String Success_Msg = "SUCCESS";
									//Readexcel.setCellData4(Testdata_File, blue2_status_Col, i, Success_Msg);
									//TextFileUtilities.Log("Adjustment message is Created Successfully for SCCF: "+SCCF, "PASS");
									//Capture Message ID upon submit message
									if(driver.findElement(By.xpath("//*[@id='msgTypeTarget']")).isDisplayed()) {
										
										//String Success_Msg = "Adjustment message is Created Successfully";
										String Success_Msg = "SUCCESS";
										Readexcel.setCellData4(Testdata_File, blue2_status_Col, i, Success_Msg);
										TextFileUtilities.Log("Adjustment message is Created Successfully for SCCF: "+SCCF, "PASS");
										
									}else {
										
										//String Fail_Msg = "Adjustment Request submission success page is not displayed after clicked on submit";
										String Fail_Msg = "Failed to Create Adjustment Request";
										Readexcel.setCellData4(Testdata_File, blue2_status_Col, i, Fail_Msg);
										TextFileUtilities.Log("Confirmation screen not displayed upon submission of Adjustment request for SCCF: "+SCCF, "PASS");
										
									}	
									
									blue2Application.ClickonSCCFhistory();
									
								}else {
									
									// Validate Able to create Adjustment Message for Selected DF Record
									if (blue2Application.IfabletoCraetemessage()) {

										// status is open get text method
										TextFileUtilities.Log(
												"Error Message displayed when clicked Create Adjustment Message for SCCF - "
														+ SCCF,
												"FAIL");
										String Error_Message = driver.findElement(By.xpath("//*[@id='validationError']"))
												.getText();
										Readexcel.setCellData4(Testdata_File, blue2_status_Col, i, Error_Message);
										blue2Application.ClickonSCCFhistory();
										continue;

									}
									
								}

							} else {

								TextFileUtilities
										.Log("Facets Override Status is not Successful, Skipped Blue2 Flow for SCCF: "
												+ SCCF, "FAIL");
								String Skip_Blue2_Msg = "Skipped Blue2 as Facets Override Status is not successful";
								Readexcel.setCellData4(Testdata_File, blue2_status_Col, i, Skip_Blue2_Msg);

							}

						}

					}

				}

			} else {
				TextFileUtilities.Log("Test Data Sheet is not available in the Provided Path", "FAIL");
			}

		} catch (Exception e) {

			Assert.error(e, "There is an exception while performing the Blue2 BOT tasks");

		}

	}
}
