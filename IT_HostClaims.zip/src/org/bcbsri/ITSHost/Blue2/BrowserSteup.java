package org.bcbsri.ITSHost.Blue2;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
//import org.apache.commons.io.FileUtils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.selenium.FrameworkDriver;
import com.dell.acoe.framework.selenium.verify.Assert;

public class BrowserSteup {
	
	public static int BROWSER_STATUS = 0;
	
	public static void loadChromeBrowser(){
		Assert.done("Start --> BrowserSetup.loadChromeBrowser()");
		try{
			//Config.init();
			String DRIVER_PATH_CHROME = "";
			DRIVER_PATH_CHROME = Environment.get("DRIVER_PATH_CHROME");

			if(BROWSER_STATUS!=1){
				Assert.done("Loading Chrome browser with 60,100,100 as implicit wait, page load and script loading times");
				System.setProperty("webdriver.chrome.driver", DRIVER_PATH_CHROME);
				
				ChromeOptions options = new ChromeOptions();
				options.setExperimentalOption("useAutomationExtension", false);
				Map<String, Object> chromePrefs = new HashMap<String, Object>();
				options.setExperimentalOption("prefs", chromePrefs);
				chromePrefs.put("profile.default_content_settings.popups", 0);
				String downloadpath = Environment.get("RIproviderportal.filedownloadpath");
				chromePrefs.put("download.prompt_for_download", false);
				chromePrefs.put("download.default_directory", downloadpath);				
//				File fileDownloadPath = new File( downloadpath);
				//FileUtils.cleanDirectory(fileDownloadPath);
				
				options.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true); 
				options.setCapability(ChromeOptions.CAPABILITY, options);
				options.setCapability("applicationCacheEnabled", false);
				options.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
				
				WebDriver driver = new ChromeDriver(options);
				driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
				driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
				driver.manage().timeouts().setScriptTimeout(120, TimeUnit.SECONDS);
				FrameworkDriver.driver = driver;
				driver.manage().window().maximize();
				driver.manage().deleteAllCookies();
				//BROWSER_STATUS = 1;
			}else{
				Assert.done("Browser is already opened, so skipping this step: loadChromeBrowser");
			}
		}catch(Exception e){
			Assert.error(e, "Error --> BrowserSetup.loadChromeBrowser()");
		}
		Assert.done("End --> BrowserSetup.loadChromeBrowser()");
	}

	public static void sleep(long waitTime){
		try {
			Thread.sleep(waitTime);
		} catch (InterruptedException e) {
			Assert.error(e, "Exception occured while waiting for "+waitTime + " sec");
			// Restore interrupted state...
		    Thread.currentThread().interrupt();
		}
	}
}
