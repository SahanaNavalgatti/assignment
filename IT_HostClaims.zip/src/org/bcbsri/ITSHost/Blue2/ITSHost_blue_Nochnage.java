
package org.bcbsri.ITSHost.Blue2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.bcbsri.ITSHost.Comparison.ITS_Claims_Code;
import org.bcbsri.ITSHost.dbutility.DbUtilityConfig;
import org.bcbsri.ITSHost.dbutility.TextFileUtilities;
import org.bcbsri.configvalidation.ConfigValidation;
import org.bcbsri.configvalidation.Readexcel;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.selenium.FrameworkDriver;
import com.dell.acoe.framework.selenium.verify.Assert;

public class ITSHost_blue_Nochnage {

	private static final String String = null;
	//Variable Declaration
	static String File_Name = "";
	static String FileExist = "";
	private static WebDriver driver = null;
	public static int SCCF_Col;
	public static int Notes_Col;
	public static int Date_Col;
	public static int Last_DF_SCCFid;
	public static String Last_DF_sccf=null;
	public static int Claim_Col;
	public static int  PAID_AMT_Col;
	public static int COPAY_Col;
	public static int COINS_Col;
	public static int DED_Col;
	public static int Claim_Type_Col;
	public static String Facets_Payment;
	public static String Facets_Copay;
	public static String Facets_Coins;
	public static String Facets_Ded;
	public static String Facets_TotalAmount;
	public static String Facets_CoinsAmount;
	public static String Facets_DedAmount;
	public static String Facets_CopayAmount;
	public static String blue2_Total_Amount_paid;
	public static String blue2_coins;
	public static String blue2_copay;
	public static String blue2_ded;

	public static int Lineitemcount =0;
	public static int ClaimID=0;
	public static int PandC=0;
	public static int counters=0;
	public static int Claims_Col=0;
	public static int ProcandCharges=0;
	public static int Blue2_Payment_Status=0;
	public static String Los_path;
	static boolean flag;
	static boolean status;
	public static String ProcCode =null;
	public static String ChargesCode=null;
	public static String RevCode=null;
	public static String NumCode=null;
	static int counter = 0;
	//static String[] Payemt_Details;
	static String[] Payemt_Details = new String[5];
	static String Prod_URL = Environment.get("Blue2Application_PROD_WEB_URL");
	static String Test_URL = Environment.get("Blue2Application_TEST_WEB_URL");
	static String Prod_strUser = Environment.get("Blue2Application.prod.Username");
	static String Test_strUser = Environment.get("Blue2Application.test.Username");
	static String Prod_strPwd = Environment.get("Blue2Application.prod.Password");
	static String Test_strPwd = Environment.get("Blue2Application.test.Password");
	static String Name = Environment.get("Blue2Application.Name");
	static String PhoneNumber = Environment.get("Blue2Application.PhoneNumber");
	static String State = Environment.get("Blue2Application.State");
	static String ReasonCode = Environment.get("Blue2Application.ReasonCode");
	static String CashRefundIndicator = Environment.get("Blue2Application.CashRefundIndicator");
	static int Status_Col = 0;
	static int Facets_Status_Col = 0;
	static String Payment=null;
	static String Copay=null;
	static String Coins = null;
	static String Ded=null;
	static String Testdata_File=null;
	static int counter1 =0;
	static String tempfile=null;
	static int countzero=0;
	static List<WebElement> LosCol ;
	static WebElement q;
	static WebElement r;
	static WebElement s;
	static WebElement t;
	static String LOScolumn ;
	static List<String> Chargeslist = new ArrayList<>();
	static List<WebElement> Proc1 ;
	static List<String> PIDs = new ArrayList<>();
	static List<String> RIDs = new ArrayList<>();
	static List<String> NIDs = new ArrayList<>();
	static List<WebElement> Charges1 = new ArrayList<>();;
	static List<WebElement> Rev_Code ;
	static List<WebElement> Num_Svcs ;
	static  List<String> cIDs = new ArrayList<>();
	static List<String> Blue2PandC=new ArrayList<>();
	static List<String> TAP=new ArrayList<>();
	static List<String> DedLos=new ArrayList<>();
	static List<String> CopayLos=new ArrayList<>();
	static List<String> CoinsLos=new ArrayList<>();
	static List<String> TAPSeq=new ArrayList<>();
	static List<String> DedLosSeq=new ArrayList<>();
	static List<String> CopayLosSeq=new ArrayList<>();
	static List<String> CoinsLosSeq=new ArrayList<>();
	static List<String> NewIDs = new ArrayList<>();
	static  String CurrentPageRowCount1=null;
	static String  Firstpagecount1= null;
	static String  Firstpagecount= null;
	static String TotalRowCount1=null;



	static Workbook wb = new XSSFWorkbook();  

	//Db Credentials
	static String Dbcreds [];
	static String Dbcreds1 [];
	static Connection con ;
	static Connection conn;
	static java.sql.Statement stmt ;
	static java.sql.Statement stmt1 ;

	public static void blue2bot() throws Exception {

		BrowserSteup.loadChromeBrowser();
		driver = FrameworkDriver.driver;
		// Initialize all Page Objects
		// change the name and remove the unwanted methods
		Blue2Application blue2Application = PageFactory.initElements(driver, Blue2Application.class);

		String File_Path = Environment.get("test_data_path");

		File folder = new File(File_Path);
		Date d = new Date(); 
		DateFormat df = new SimpleDateFormat("HHmmss");
		String timeStamp = df.format(d);
		LocalDate dateObj = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddMMyyyy");
		String date = dateObj.format(formatter);
		System.out.println(date);
		Los_path=Environment.get("config_path");
		tempfile=Environment.get("test_data_path")+"\\TempLOS-"+date+"-"+timeStamp+".xlsx";
		File[] fileList = folder.listFiles();

		try {

			//Get the File name of Test Data Sheet
			for(File fileName:fileList) {
				//System.out.println(fileName.getName());
				if(fileName.getName().toUpperCase().contains("ITSHOST")) {

					File_Name = fileName.getName();
					FileExist = "True";

				}

			}

			Testdata_File = Environment.get("test_data_path")+"\\"+File_Name;
			FileInputStream fis = new FileInputStream(Testdata_File);
			XSSFWorkbook wbooknew = new XSSFWorkbook(fis);
			XSSFSheet sheet2  =wbooknew.createSheet("Blue2Payment");
			XSSFSheet sheet3  =wbooknew.createSheet("Los");
			
			XSSFSheet sheetone  =wbooknew.getSheetAt(0);
			Row Head_row_new = sheetone.getRow(0);
		    int ColCountnew = Head_row_new.getPhysicalNumberOfCells();
			sheet3.createRow(0);
			sheet3.getRow(0).createCell(0).setCellValue("Claimid");
			sheet3.getRow(0).createCell(1).setCellValue("Charge&Proc");	
			//create Blue2Payment status col in main test data sheet
			sheetone.getRow(0).createCell(ColCountnew).setCellValue("Blue2_Payment_Status");


			FileOutputStream fileOut11 = new FileOutputStream(Testdata_File); 
			wbooknew.write(fileOut11);
			wbooknew.close();

			//Read Test Data Sheet
			if(FileExist=="True") {

				String Env = Environment.get("Environment");

				if(Env.equalsIgnoreCase("PROD")) {
					// launch url
					blue2Application.Launch(Prod_URL);
					// Login to the page
					blue2Application.Login(Prod_strUser, Prod_strPwd);
					

				}else if(Env.equalsIgnoreCase("TEST")||Env.equalsIgnoreCase("MINOR")) {

					//launch URL
					blue2Application.Launch(Test_URL);
					// Login to the page
					blue2Application.Login(Test_strUser, Test_strPwd);

				}
				else {
					TextFileUtilities.Log("Environment Value provided in config sheet is not valid: "+Env, "FAIL");
				}

				// Click on SSCF ID Tab
				blue2Application.ClickonSCCFhistory();
				//Read the main test data sheet
				String Testdata_File1 = Environment.get("test_data_path")+"\\"+File_Name;
				FileInputStream fisnew= new FileInputStream(Testdata_File1);
				XSSFWorkbook wbook = new XSSFWorkbook(fisnew);
				String SheetName = wbook.getSheetName(0);
				Sheet sheet = wbook.getSheetAt(0);
				int TestData_Rowcount = sheet.getPhysicalNumberOfRows();

				
				

				// Read Main Test Data to get Payment details
				start: for (int i = 0; i <= TestData_Rowcount - 1; i++) {
					
					Row row = sheet.getRow(i);
					Row Head_row = sheet.getRow(0);
				    int ColCount = Head_row.getPhysicalNumberOfCells();

					// Get the Column Id's in First Iteration
					if (i == 0) {

						// Notes Column
						for (int j = 0; j <= ColCount - 1; j++) {

							Cell cell = Head_row.getCell(j);

							if (cell.getStringCellValue().trim().equals("Comparison_Notes")) {
								Notes_Col = j;
								break;
							}

						}

						// SCCF Num Column
						for (int j = 0; j <= ColCount - 1; j++) {

							Cell cell = Head_row.getCell(j);

							if (cell.getStringCellValue().trim().equals("SCCF_Txt")) {
								SCCF_Col = j;
								break;
							}

						}

						//Claim id 

						for (int j = 0; j <= ColCount-1; j++) {

							Cell cell = Head_row.getCell(j);

							if (cell.getStringCellValue().trim().equals("Claim_ID") || cell.getStringCellValue().trim().equals("Claim ID")) {
								Claim_Col = j;
								break;
							}

						}

						//Claim_Type

						for (int j = 0; j <= ColCount-1; j++) {

							Cell cell = Head_row.getCell(j);

							if (cell.getStringCellValue().trim().equals("Claim_Type") || cell.getStringCellValue().trim().equals("Claim Type")) {
								Claim_Type_Col = j;
								break;
							}

						}
						//Blue2_Payment_Status

						for (int j = 0; j <= ColCount-1; j++) {

							Cell cell = Head_row.getCell(j);

							if (cell.getStringCellValue().trim().equals("Blue2_Payment_Status")){
								Blue2_Payment_Status = j;
								break;
							}

						}



					}else {

						//From Second Iteration - Read Values to enter in Blue2 application

						String Notes = Readexcel.ReadCellData(Testdata_File, SheetName, i, Notes_Col);
						String Claim_ID  = Readexcel.ReadCellData(Testdata_File, SheetName, i, Claim_Col);
						String Partial_Text = "No Changes".toLowerCase();
						String SCCF = "";
						String Partial_Text1 = "Please approve".toLowerCase();
						String Partial_Text2 = "Skipping".toLowerCase();
						//String Partial_Text1 = "No Changes".toLowerCase();
						// System.out.println(Notes);
					
						   String Notapplicable_Message = "NA";
						if(Notes.toLowerCase().startsWith(Partial_Text1)||Notes.toLowerCase().startsWith(Partial_Text2)) {
						
							
							Readexcel.setCellData4(Testdata_File, Blue2_Payment_Status, i, Notapplicable_Message);
						}

						//Read Comparison Notes to get No Change Scenario
						if (Notes.toLowerCase().startsWith(Partial_Text)){
							System.out.println(Notes+"-->Scenario ");
							String SCCFtemp = Readexcel.ReadCellData(Testdata_File, SheetName, i, SCCF_Col);
							if(SCCFtemp.equals("")) {
								
								Readexcel.setCellData4(Testdata_File, Blue2_Payment_Status, i, "Error-Skipping as SCCF_Text is NULL");
								TextFileUtilities.Log("Error-Skipping as SCCF_Text is NULL", "FAIL");
								continue start;	
							}
							//Get the SCCF id
							SCCF = SCCFtemp.substring(0, SCCFtemp.length() - 2);
							//Enter SCCF ID to Search
							blue2Application.SetTextAfterLabel1("SCCF", SCCF);
							blue2Application.SelectListItemAfterLabel("Format Type  ","DF");
							blue2Application.ClickOnButtonByTitle("Search");
							Thread.sleep(300);

							//Validate if SCCF Exists
							if (blue2Application.VerifySCCF()) {

								TextFileUtilities.Log("SCCF doesnot exists - " + SCCF, "FAIL");
								String ErrorMessage = driver.findElement(By.xpath("//*[@id='errorDisplay']/ul")).getText();
								Readexcel.setCellData4(Testdata_File, Blue2_Payment_Status, i, "Error-"+ErrorMessage);
								
								blue2Application.ClickonSCCFhistory();
								continue;

							}

							//Get Row Count of Search Results
							String element = driver.findElement(By.xpath("//div[@class='results']")).getText();
							String[] arrOfStr = element.split("of");
							String b = (arrOfStr[0]);
							String c = (arrOfStr[1]);
							String[] arrOfStr1 = b.split("-");
							String[] arrOfStr2 = c.split(" ");
							String CurrentPageRowCount = (arrOfStr1[1]);
							String TotalRowCount = (arrOfStr2[1]);

							//Navigate till Last page of search results
							while (!CurrentPageRowCount.trim().equals(TotalRowCount)) {

								status=true;
								blue2Application.WaitForPageToLoad(90);
								blue2Application.ClickOnButtonByTitleTab("Next");
								blue2Application.WaitForPageToLoad(30);
								counter = counter + 1;
								String element1 = driver.findElement(By.xpath("//div[@class='results']")).getText();
								String[] arrOfStr11 = element1.split("of");
								String bb = (arrOfStr11[0]);
								String cc = (arrOfStr11[1]);
								String[] arrOfStrnew = bb.split("-");
								String[] arrOfStr22 = cc.split(" ");
								CurrentPageRowCount = (arrOfStrnew[1]);
								TotalRowCount = (arrOfStr22[1]);

							}

							//Below is the flow if search result row count is less than 25 rows
							if(status==false) {

								blue2Application.WaitForPageToLoad(30);
								List<WebElement> Format = driver.findElements(By.xpath("//table[@id='resultsRecord']//tr//td[3]"));
								List<WebElement> Last_DF_SCCF = driver.findElements(By.xpath("//table[@id='resultsRecord']//tr//td[2]"));
								// variables i,j,k

								for (int j = Format.size() - 1; j >= 0; j--) {

									if (Format.get(j).getText().equals("DF")) {
										
										Last_DF_sccf=Last_DF_SCCF.get(j).getText();
										Format.get(j).click();
										TextFileUtilities.Log("Clicked last DF Record - "+SCCF, "PASS");
										flag = true;
										break;
									}

									
								}

								//Report if DF doesnt exist
								if (flag == false) {
									// Log when DF is in open status
									TextFileUtilities.Log("DF Record is not present for SCCF "+SCCF, "FAIL");

									Readexcel.setCellData4(Testdata_File, Blue2_Payment_Status, i, "Error-DF Record does not exist in search results");
									blue2Application.ClickonSCCFhistory();
									continue start;

								}

							}else {

								//Below Flow is after Finding the Last DF Record
								if (CurrentPageRowCount.trim().equals(TotalRowCount)) {

									//Get Status and Format Values for Last DF
									blue2Application.WaitForPageToLoad(30);
									List<WebElement> Format = driver.findElements(By.xpath("//table[@id='resultsRecord']//tr//td[3]"));
									List<WebElement> Last_DF_SCCF = driver.findElements(By.xpath("//table[@id='resultsRecord']//tr//td[6]"));

									//Click Last DF
									for (int j = Format.size() - 1; j>= 0; j--) {

										if (Format.get(j).getText().equals("DF")) {
											Last_DF_sccf=Last_DF_SCCF.get(j).getText();
											Format.get(j).click();
											
											TextFileUtilities.Log("Clicked the last DF record - "+SCCF, "PASS");
											flag = true;
											break;
										}

									}

									if (flag==false) {

										//TextFileUtilities.Log("DF is not Present in the last page, navigating to previous page", "PASS");
										for (int k=0; k <counter; k++) {

											blue2Application.ClickOnButtonByTitleTab("Previous");
											blue2Application.WaitForPageToLoad(30);
											List<WebElement> Format1 = driver.findElements(By.xpath("//table[@id='resultsRecord']//tr//td[3]"));
											List<WebElement> Last_DF_SCCF1 = driver.findElements(By.xpath("//table[@id='resultsRecord']//tr//td[2]"));

											for (int l = Format1.size() - 1; l >= 0; l--) {

												if (Format1.get(l).getText().equals("DF")) {
													Last_DF_sccf=Last_DF_SCCF1.get(l).getText();
													Format1.get(l).click();
													
													TextFileUtilities.Log("Clicked the last DF Record - "+SCCF, "PASS");
													flag = true;
													break;
												}

											}

										}

										//Report if DF Record is not available in any of the pages
										if (flag==false) {

											TextFileUtilities.Log("DF Record is not present for SCCF "+SCCF, "FAIL");
											Readexcel.setCellData4(Testdata_File, Blue2_Payment_Status, i, "Error-DF Record does not exist in search results");
											blue2Application.ClickonSCCFhistory();
											continue start;

										}
									}

								}

							}

							//Phase2
							//To click on Claims tab

							//Click on Claims tab
							Thread.sleep(2000);
							blue2Application.ClickonTab("Claim");
							blue2Application.WaitForPageToLoad(30);

							//Fetch Payment Details
							//System.out.println("Fetching Blue2 Payments details ");
							Payemt_Details=Blue2Application.FetchPaymentdetails("Total Amount Approved for Payment ","Total Deductible Amount ","Total Coinsurance Amount ","Total Copay Amount ","DF Message Codes ");
							TextFileUtilities.Log("Fetched Payment Details from Blue2 ", "PASS");
							//System.out.println(Payemt_Details[0]);
							//Payment Details Claim level
							blue2_Total_Amount_paid = Payemt_Details[0];
							blue2_ded = Payemt_Details[1];
							blue2_coins = Payemt_Details[2];
							blue2_copay = Payemt_Details[3];

							//Reading Claim ID from Test data sheet
							String  ClaimID = Readexcel.ReadCellData(Testdata_File, SheetName, i, Claim_Col);
							//System.out.println(ClaimID);
							//Query to get Facets Payment Details
							String FacetsPaymentQuery =Blue2Application.readFileAsString(Environment.get("config_path") + "//FACETS_PAYEMNT_DETAILS_QUERY.txt");
							//Db Credentials
							Dbcreds=DbUtilityConfig.DbCred();
							con =DriverManager.getConnection(Dbcreds[0], Dbcreds[1], Dbcreds[2]);
							stmt  =con.createStatement();
							ResultSet rs=null;
							ResultSet rs2=null;
							
							//Passing Claim ID to query Dynamically
							rs=stmt.executeQuery(FacetsPaymentQuery+"'"+ClaimID+"'");
							TextFileUtilities.Log("Executed query to Fetch Facets Db Payment details", "PASS");
							DbUtilityConfig.WriteToExcelFacetsdb(Testdata_File, "Blue2Payment", rs);
							con.close();
							//rs2=stmt.executeQuery(query1+"'"+ClaimID+"'");
							//DbUtilityConfig.WriteToExcelFacetsdb(report, "FacetsDetails", rs2);
							
							TextFileUtilities.Log("Writing FacetsDb Payments deatils into excel", "DONE");
							//Reading the workbook and adding columns in sheet3
							FileInputStream fis1 = new FileInputStream(Testdata_File);
							XSSFWorkbook wbook1 = new XSSFWorkbook(fis1);
							String SheetName1 = wbook1.getSheetName(2);
							Sheet sheet1 = wbook1.getSheetAt(2);
							int TestData_Rowcount1 = sheet1.getPhysicalNumberOfRows();

							Row Head_Row1 = sheet1.getRow(0);
							int ColCount1 = Head_Row1.getPhysicalNumberOfCells();
							int TypeofPayment = 0;
							int Claimid =0;
							int DFCode =0;
							int Claim_Type =0;
							int Last_SCCF=0;
							//Get the Column Value if Exists
							for(int col=0; col<=ColCount1-1; col++) {

								Cell cell = Head_Row1.getCell(col);

								if(cell.getStringCellValue().trim().equals("TYPE_OF_PAYMENT")) {
									TypeofPayment = col;
									break;
								}

							}
							for(int col=0; col<=ColCount1-1; col++) {

								Cell cell = Head_Row1.getCell(col);

								if(cell.getStringCellValue().trim().equals("DFMC_CODE")) {
									DFCode = col;
									break;
								}

							}

							//Get Claim ID col value
							for(int col=0; col<=ColCount1-1; col++) {

								Cell cell = Head_Row1.getCell(col);

								if(cell.getStringCellValue().trim().equals("Claim_ID")) {
									Claimid = col;
									break;
								}

							}

							//Get Claim_Type ID col value
							for(int col=0; col<=ColCount1-1; col++) {

								Cell cell = Head_Row1.getCell(col);

								if(cell.getStringCellValue().trim().equals("Claim_Type")) {
									Claim_Type = col;
									break;
								}

							}
							
							//Get Last  DF SCCF Id
							for(int col=0; col<=ColCount1-1; col++) {

								Cell cell = Head_Row1.getCell(col);

								if(cell.getStringCellValue().trim().equals("LastDF_SCCFid")) {
									Last_SCCF = col;
									break;
								}

							}





							//Create  Columns if not exists
							if(TypeofPayment==0) {
								Head_Row1.createCell(Head_Row1.getPhysicalNumberOfCells()).setCellValue("TYPE_OF_PAYMENT");
								TypeofPayment = Head_Row1.getPhysicalNumberOfCells()-1;
								FileOutputStream fos1 = new FileOutputStream(Testdata_File);
								wbook1.write(fos1); 
							}
							if(DFCode==0) {
								Head_Row1.createCell(Head_Row1.getPhysicalNumberOfCells()).setCellValue("DFMC_CODE");
								DFCode = Head_Row1.getPhysicalNumberOfCells()-1;
								FileOutputStream fos1 = new FileOutputStream(Testdata_File);
								wbook1.write(fos1); 
							}
							//Claim_type
							if(Claim_Type==0) {
								Head_Row1.createCell(Head_Row1.getPhysicalNumberOfCells()).setCellValue("Claim_Type");
								Claim_Type = Head_Row1.getPhysicalNumberOfCells()-1;
								FileOutputStream fos1 = new FileOutputStream(Testdata_File);
								wbook1.write(fos1); 
							}
							//counter to get the row value    
							counter1=counter1+1;

							//Creat ClaimID col if not exists
							if(Claimid==0) {
								Head_Row1.createCell(Head_Row1.getPhysicalNumberOfCells()).setCellValue("Claim_ID");
								Claimid = Head_Row1.getPhysicalNumberOfCells()-1;
								FileOutputStream fos1 = new FileOutputStream(Testdata_File);
								wbook1.write(fos1); 
							}
							
							
							if(Last_SCCF==0) {
								Head_Row1.createCell(Head_Row1.getPhysicalNumberOfCells()).setCellValue("LastDF_SCCFid");
								Last_SCCF = Head_Row1.getPhysicalNumberOfCells()-1;
								FileOutputStream fos1 = new FileOutputStream(Testdata_File);
								wbook1.write(fos1); 
							}





							

							//Reading the column index of the payment details report from db
							Row Head_row1 = sheet1.getRow(0);
							ColCount = Head_row1.getPhysicalNumberOfCells();

							//CDML_PAID_AMT
							for (int j1 = 0; j1 <= ColCount-1; j1++) {

								Cell cell = Head_row1.getCell(j1);

								if (cell.getStringCellValue().trim().equals("CDML_PAID_AMT")) {
									PAID_AMT_Col = j1;
									break;
								}

							}


							//CDML_COPAY_AMT
							for (int j1 = 0; j1 <= ColCount-1; j1++) {

								Cell cell = Head_row1.getCell(j1);

								if (cell.getStringCellValue().trim().equals("CDML_COPAY_AMT")) {
									COPAY_Col = j1;
									break;
								}

							}


							//CDML_COINS_AMTCDML_COINS_AMT
							for (int j1 = 0; j1 <= ColCount-1; j1++) {

								Cell cell = Head_row1.getCell(j1);

								if (cell.getStringCellValue().trim().equals("CDML_COINS_AMT")) {
									COINS_Col = j1;
									break;
								}

							}


							//CDML_DED_AMT
							for (int j1 = 0; j1 <= ColCount-1; j1++) {

								Cell cell = Head_row1.getCell(j1);

								if (cell.getStringCellValue().trim().equals("CDML_DED_AMT")) {
									DED_Col = j1;
									break;
								}

							}


							//From Second Iteration - Read the values

							//Read the Facets payment details from excel report
							Facets_Payment = Readexcel.ReadCellData(Testdata_File, SheetName1, counter1, PAID_AMT_Col);
							Facets_Copay = Readexcel.ReadCellData(Testdata_File, SheetName1, counter1, COPAY_Col);
							Facets_Coins = Readexcel.ReadCellData(Testdata_File, SheetName1, counter1, COINS_Col);
							Facets_Ded= Readexcel.ReadCellData(Testdata_File, SheetName1, counter1, DED_Col);

							//appending dollar Sign to Facets payment details
							Facets_TotalAmount ="$"+Facets_Payment.substring(0, Facets_Payment.length()-2);
							Facets_CoinsAmount ="$"+Facets_Coins.substring(0, Facets_Coins.length()-2);
							Facets_DedAmount ="$"+Facets_Ded.substring(0, Facets_Ded.length()-2);
							Facets_CopayAmount ="$"+Facets_Coins.substring(0, Facets_Copay.length()-2);
							System.out.println("Facets Paymet deatils- Amount Approved :"+Facets_TotalAmount+ "Deductible :"+Facets_DedAmount +"Coinsurance :"+Facets_CoinsAmount+"Copay :"+Facets_CopayAmount);
							System.out.println("Blue2 Payment deatils- Amount Approved :"+blue2_Total_Amount_paid+"Deductible :"+ blue2_ded +"Coinsurance :"+blue2_coins +"Copay :"+blue2_copay);
							//Reading the claim_type value from test data sheet
							String Claim_Types_Value = Readexcel.ReadCellData(Testdata_File, SheetName, i, Claim_Type_Col);

							if(Facets_TotalAmount.equals(blue2_Total_Amount_paid)&&Facets_CoinsAmount.equals(blue2_coins)&&Facets_DedAmount.equals(blue2_ded)&&Facets_CopayAmount.equals(blue2_copay)) {
								Readexcel.setCellData(Testdata_File, TypeofPayment,counter1 , "Match");
								Readexcel.setCellData(Testdata_File,Claimid ,counter1 , ClaimID);
								Readexcel.setCellData(Testdata_File,Last_SCCF ,counter1 , Last_DF_sccf);
								Readexcel.setCellData(Testdata_File,Claim_Type ,counter1 , Claim_Types_Value);
								Readexcel.setCellData4(Testdata_File,Blue2_Payment_Status ,i , "SUCCESS");

								TextFileUtilities.Log("Facets and Blue2 Payment details matches--", "PASS");

								blue2Application.ClickonSCCFhistory();
							}

							else {
								//If Facets and Blue2 payment details doesn't match
								//System.out.println("Blue2 and Facets Payment details doesn't match-- ");
								TextFileUtilities.Log("Facets and Blue2 Payment doesnt matches--", "PASS");
								//If Total Amount approved at claim level is Zero DOllar- ZeroDollar Payment
								if(Payemt_Details[0].equals("$0.00")&&Payemt_Details[1].equals("$0.00")&&Payemt_Details[2].equals("$0.00")&&Payemt_Details[3].equals("$0.00")) {
									String Paymentype ="Zero Dollar Payment";
									//Get the DFMC Code from Blue2
									String DFcode=Payemt_Details[4];
									blue2_Total_Amount_paid = Payemt_Details[0].replace("$", "");
									blue2_copay = Payemt_Details[3].replace("$", "");
									blue2_coins = Payemt_Details[2].replace("$", "");;
									blue2_ded = Payemt_Details[1].replace("$", "");
									System.out.println("Total Amount Aprroved is :"+Payemt_Details[0]);
									System.out.println("Zero Dollar"+ "DFMC "+ " code is "+Payemt_Details[4]);
									//Over Writing the Blue2 Payment Details into Excel Report
									Readexcel.setCellData3(Testdata_File, PAID_AMT_Col, COPAY_Col, COINS_Col, DED_Col,counter1, blue2_Total_Amount_paid, blue2_copay, blue2_coins, blue2_ded);
									Readexcel.setCellData(Testdata_File, TypeofPayment,counter1 , Paymentype);
									Readexcel.setCellData(Testdata_File,Claimid ,counter1 , ClaimID);
									Readexcel.setCellData(Testdata_File, DFCode,counter1 , DFcode);
									Readexcel.setCellData(Testdata_File,Claim_Type ,counter1 , Claim_Types_Value);
									Readexcel.setCellData(Testdata_File,Last_SCCF ,counter1 , Last_DF_sccf);
									Readexcel.setCellData4(Testdata_File,Blue2_Payment_Status ,i , "SUCCESS");

									TextFileUtilities.Log("SCCF identified as Zero Dollar Payment and Fetched payment details--", "PASS");
									blue2Application.ClickonSCCFhistory();


								}

								else {
									//If Blue2 Totalamount approved in Non Zero Dollar
									String Paymentype=null;
									System.out.println("Total Amount Aprroved is :"+Payemt_Details[0]);
									TextFileUtilities.Log("SCCF identified as Non Zero Dollar Payment--", "PASS");
									blue2_Total_Amount_paid = Payemt_Details[0].replace("$", "");
									blue2_copay = Payemt_Details[3].replace("$", "");
									blue2_coins = Payemt_Details[2].replace("$", "");;
									blue2_ded = Payemt_Details[1].replace("$", "");
									//Over Writing the Blue2 Payment Details into Excel Report
									Readexcel.setCellData3(Testdata_File, PAID_AMT_Col, COPAY_Col, COINS_Col, DED_Col,counter1, blue2_Total_Amount_paid, blue2_copay, blue2_coins, blue2_ded);
									Readexcel.setCellData(Testdata_File,Claimid ,counter1 , ClaimID);
									Readexcel.setCellData(Testdata_File,Claim_Type ,counter1 , Claim_Types_Value);

									//Identify the Inclusive/Non_Incluive Payment types

									int row_Index=0;
									String NewString = null;
									String values =null;
									String new_values=null;
									String claims= null;
									String QueryFile_MemInfo = "PaymentInfo_QUERY";
									String PreMove = Environment.get("Environment");
									Readexcel re = new Readexcel();
									String Claim_Types = Readexcel.ReadCellData(Testdata_File, SheetName, i, Claim_Type_Col);
									//Execute the query to get the Procedure_Code and Charges and Sequence of Line items from FacetsDb

									/*String temp11 = re.TextFilename(Los_path+"/"+QueryFile_MemInfo+".txt").replace("REPLACE_TYPE", Claim_Types);
									String PaymentInfo_Query = temp11.replace("REPLACE_VALUE", ClaimID);
									ResultSet rs1 = ConfigValidation.Database(PreMove, PaymentInfo_Query); //Corrected claims data*/
                                    //start
									//Db Credentials
									Dbcreds1=DbUtilityConfig.DbCred();
									conn =DriverManager.getConnection(Dbcreds1[0], Dbcreds1[1], Dbcreds1[2]);
									stmt1  =conn.createStatement();
									ResultSet rs11=null;
									//ResultSet rs2=null;
									String temp11 = re.TextFilename(Los_path+"/"+QueryFile_MemInfo+".txt").replace("REPLACE_TYPE", Claim_Types);
									String PaymentInfo_Query = temp11.replace("REPLACE_VALUE", ClaimID);
									//Passing Claim ID to query Dynamically
									rs11=stmt1.executeQuery(PaymentInfo_Query);
									TextFileUtilities.Log("Executed query to Fetch Facets Db Payment details", "PASS");
									//DbUtilityConfig.WriteToExcelFacetsdb(Testdata_File, "Blue2Payment", rs11);
									
									//Writing the query results to ExcelReport
									ITS_Claims_Code.WriteToExcel1(Testdata_File,"Payment_Info",rs11,row_Index); 
									conn.close();
									//Reading the excel Report
									FileInputStream file1 = new FileInputStream(Testdata_File);
									XSSFWorkbook wbook11 = new XSSFWorkbook(file1);
									XSSFSheet sheet11 = wbook11.getSheet("Payment_Info");
									int rowcnt = sheet11.getPhysicalNumberOfRows();
									//Initializing the array to store sequential Procedure code and Charges from Facets
									ArrayList<String> Line_Payments = new ArrayList<String>();
									Map<String,ArrayList<String>> Payment_Mapping = new HashMap<String, ArrayList<String>>();

									for (int i1 = 1; i1<rowcnt; i1++) {

										String Value_c = "";
										String Value_r="";
										String Value_n = "";
										String Value_p = "";
										FormulaEvaluator evaluator = wbook11.getCreationHelper().createFormulaEvaluator();
										Row row12 = sheet11.getRow(i1);
										Cell cell_Charge = row12.getCell(2);

										switch (evaluator.evaluateInCell(cell_Charge).getCellType()) {

										case Cell.CELL_TYPE_STRING: 
											Value_c = cell_Charge.getStringCellValue().trim();
											if(Value_c.equals("")) {

												Value_c="--";

											}
											else{
												Value_c=Value_c.substring(0, Value_c.length()-2);
											}

											//System.out.println(CellValue);
											break;
										}

										Cell cell_Proc = row12.getCell(3);

										switch (evaluator.evaluateInCell(cell_Proc).getCellType()) {

										case Cell.CELL_TYPE_STRING: 
											Value_p = cell_Proc.getStringCellValue().trim();
											//System.out.println(Value_p.length());
											if(Value_p.length()>5) {
												Value_p=Value_p.substring(0, Value_p.length()-2);	
											}
											if(Value_p.equals("")) {

												Value_p="--";

											}
											//System.out.println(CellValue);
											break;
										}
										
										
										Cell cell_RevCode = row12.getCell(4);

										switch (evaluator.evaluateInCell(cell_RevCode).getCellType()) {

										case Cell.CELL_TYPE_STRING: 
											Value_r = cell_RevCode.getStringCellValue().trim();
											if(Value_r.equals("")) {

												Value_r="--";

											}
											//System.out.println(CellValue);
											break;
										}
										
										
										Cell cell_NumCode = row12.getCell(5);

										switch (evaluator.evaluateInCell(cell_NumCode).getCellType()) {

										case Cell.CELL_TYPE_STRING: 
											Value_n = cell_NumCode.getStringCellValue().trim();
											if(Value_n.equals("")) {

												Value_n="--";

											}
											

											//System.out.println(CellValue);
											break;
										}
										//Combing Proc code ,Charges,Num,Rev code and add it into the list
                                       if(Claim_Types.equals("H")) {
										NewString = Value_c + "||" + Value_p + "||" + Value_r + "||" + Value_n;
										}
                                       
                                       if(Claim_Types.equals("M")) {
   										NewString = Value_c + "||" + Value_p + "||" + Value_n;
   										}

										Line_Payments.add(NewString);



									}


									//Get Claimd and LineItem proc and Charges
									Payment_Mapping.put(ClaimID, Line_Payments);
									if(ClaimID.trim().equals("")) {
										claims="No values";

									}else {
										claims=ClaimID.toString();
									}
									if(Line_Payments.isEmpty()){
										new_values="No values";
									}
									else {
										values = Line_Payments.toString();
										new_values=values.replace(",","#");
									} 

									System.out.println("Getting sequential procedure code ,Charges,Rev.and Num Svcs from Facets for Calim Id "+ClaimID);
									//System.out.println("ClaimID: ");
									System.out.println("Line Item Count: "+Line_Payments.size());
									System.out.println(String.valueOf(Line_Payments.size()));
									//System.out.println("Charge & Proc Code "+Line_Payments.toString());
									int index = wbook11.getSheetIndex("Payment_Info");
									//Remove the temp sheet for Proc code and charges
									wbook11.removeSheetAt(index);
									FileOutputStream fout = new FileOutputStream(Testdata_File);
									wbook11.write(fout);

									counters=counters+1;


									//Writing Line item Proc code and Charges from Facets into different sheet
									FileInputStream fileIn = new FileInputStream(Testdata_File);
									XSSFWorkbook wbook4 = new XSSFWorkbook(fileIn);
									//Row row = sheet3.getRow(claim);
									Row Head_row2 = sheet3.getRow(0);
									int ColCount11 = Head_row2.getPhysicalNumberOfCells();
									int Testdatarowcount2 = sheet3.getPhysicalNumberOfRows();

									//Write and get the column index
									start1 : for(int p=0;p<TestData_Rowcount;p++) {

										if(p==0) {

											for(int k=0;k<=ColCount11-1;k++) {


												Cell cell3 = Head_row2.getCell(k);

												if (cell3.getStringCellValue().trim().equals("Claimid")) {


													//Readexcel.setCellData1(report, k,counters , List_ClaimID_Corrected);
													Claims_Col = k;
													break;

												}
											}




											for(int k=0;k<=ColCount11-1;k++) {


												Cell cell3 = Head_row2.getCell(k);

												if (cell3.getStringCellValue().trim().equals("Charge&Proc")) {


													//Readexcel.setCellData1(report, k,counters , List_ClaimID_Corrected);
													ProcandCharges = k;
													break;

												}
											}
										}else {


											//Write the  Facets Proc code and charges into excel sheet
											Readexcel.setCellData2(Testdata_File, Claims_Col,ProcandCharges,counters , claims,new_values);
											//Read the excel to get Proc code and charges and split them and add into list
											String ProcandChargess = Readexcel.ReadCellData(Testdata_File, "Los", counters,ProcandCharges );
											//System.out.println(ProcandChargess);
											String newpandc=ProcandChargess.replace("[","");
											String newpandc1=newpandc.replace("]","");
											String newpandc2= newpandc1.replace(" ", "");
											String[] Pandc= (newpandc2.split("#"));
											List<String> pIDs = new ArrayList<>();
											for (int i3 =0;i3<Pandc.length;i3++) {

												pIDs.add(Pandc[i3]);

												//System.out.println(Pandc[i3]);

											}
											//System.out.println("Procedure Code and Charges from Facets:"+pIDs);
											TextFileUtilities.Log("Fetched Procedure Code and Charges from Facets:--", "PASS");

											//To Fetch Line of Service details from Blue2 

											//Click on Line of Service Tab from Blue2
											blue2Application.ClickonTab("Line of Service");
											driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS); 
											//Get the Current page count and total pag4e count
											String element0 = driver.findElement(By.xpath("//div[@id='losQueryResults']")).getText();
											String[] arrOfStr0 = element0.split("of");
											String b1 = (arrOfStr0[0]);	
											String c1 = (arrOfStr0[1]);
											String[] arrOfStr01 = b1.split("-");
											String[] arrOfStr02 = c1.split(" ");
											
											CurrentPageRowCount1 = (arrOfStr01[1]);
											TotalRowCount1 = (arrOfStr02[1]);
											Firstpagecount =(arrOfStr01[0]);
											String[] arrOfStr011=Firstpagecount.split(" ");
											Firstpagecount1 =(arrOfStr011[1]);
											Integer.parseInt(Firstpagecount1);
											
											//If Facets Line item count doesn't matches with Blue2 Line item count move that Claim to Manual
											if(!(Integer.valueOf(TotalRowCount1).equals(Line_Payments.size()))) {
												Thread.sleep(200);
												blue2Application.ClickonSCCFhistory();
												TextFileUtilities.Log("Error-Skipping as Line item count mismatch with Facets and Blue2", "FAIL");
												Readexcel.setCellData4(Testdata_File, Blue2_Payment_Status, i, "Error-Skipping as Line item count mismatch with Facets and Blue2");
												Readexcel.setCellData(Testdata_File, TypeofPayment,counter1 , "Error-Skipping as Line item count mismatch with Facets and Blue2");	
												continue start;
											}
											
											
											//If current page count is not equal to total page count
											while(!CurrentPageRowCount1.trim().equals(TotalRowCount1)) {

												System.out.println("Line Items are greater than 25 ");
												LosCol =driver.findElements(By.xpath("//*[@id='losResultsRecord']/thead/tr/th")); 
												//System.out.println(LosCol.size());
												for(int a=1;a<=LosCol.size();a++) {
													String LOScolumn = driver.findElement(By.xpath("//*[@id='losResultsRecord']/thead/tr/th["+a+"]")).getText();
													if(LOScolumn.contains("Proc Code")) {
														Proc1 = driver.findElements(By.xpath("//table[@id='losResultsRecord']//th["+a+"]/following::tr//td[" +a+" ]"));
														//PIDs = new ArrayList<>();
														for (int j=0;j<Proc1.size();j++) {

															q= Proc1.get(j);
															Thread.sleep(100);
															ProcCode = q.getText();
															driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS); 
															System.out.println(ProcCode);
															Thread.sleep(100);
															PIDs.add(ProcCode);

														}
														//System.out.println(PIDs);
													}
													else if(LOScolumn.contains("Num Svcs")) {
														Num_Svcs = driver.findElements(By.xpath("//table[@id='losResultsRecord']//th["+a+"]/following::tr//td[" +a+" ]"));
														// PIDs = new ArrayList<>();
														for (int j=0;j<Num_Svcs.size();j++) {

															r= Num_Svcs.get(j);
															NumCode = r.getText();
															//System.out.println(ProcCode);

															NIDs.add(NumCode);

														}
														}
														
														else if(LOScolumn.contains("Rev Code")) {
															Rev_Code = driver.findElements(By.xpath("//table[@id='losResultsRecord']//th["+a+"]/following::tr//td[" +a+" ]"));
															// PIDs = new ArrayList<>();
															for (int j=0;j<Rev_Code.size();j++) {

																s= Rev_Code.get(j);
																RevCode = s.getText();
																//System.out.println(ProcCode);

																RIDs.add(RevCode);

															}
														//System.out.println(PIDs);
													}
													
													
													
													//else {


														else if(LOScolumn.equals("Service Charges")||LOScolumn.equals("Charges")) {
															Charges1 = driver.findElements(By.xpath("//table[@id='losResultsRecord']//th["+a+"]/following::tr//td[" +a+" ]"));
															
															for (int j=0;j<Charges1.size();j++) {
																//Thread.sleep(200);		      
																r= Charges1.get(j);
																ChargesCode = r.getText();
																Thread.sleep(100);
																//System.out.println(ChargesCode);
																String Blue2details = ProcCode+"||"+ChargesCode;
																cIDs.add(ChargesCode);
																Charges1.get(j).click();

																Thread.sleep(4000);

																Thread.sleep(3000);
																driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS); 
																Payemt_Details=Blue2Application.FetchPaymentdetailsLos("Amount Approved for Payment ","Deductible Amount ","Coinsurance Amount ","Copay Amount ");
																//System.out.println(Payemt_Details[0]);
																blue2_Total_Amount_paid = Payemt_Details[0].replace("$", "");
																blue2_copay = Payemt_Details[3].replace("$", "");
																blue2_coins = Payemt_Details[2].replace("$", "");;
																blue2_ded = Payemt_Details[1].replace("$", "");
																//non zero 
																if(blue2_Total_Amount_paid.equals("0.00")&&blue2_copay.equals("0.00")&&blue2_coins.equals("0.00")&&blue2_ded.equals("0.00")) {
																	countzero= countzero+1;

																}

																TAP.add(blue2_Total_Amount_paid);
																DedLos.add(blue2_ded);
																CopayLos.add(blue2_copay);
																CoinsLos.add(blue2_coins);
																System.out.println(Charges1.size());
																//Readexcel.setCellData(tempfile, a, j, new_values);
															}

															//System.out.println(TAP);
															blue2Application.WaitForPageToLoad(90);
															blue2Application.ClickOnButtonByTitleTab("Next");
															
															TextFileUtilities.Log("Clicking on Next Page--", "PASS");
															driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS); 
															String element00 = driver.findElement(By.xpath("//div[@id='losQueryResults']")).getText();
															String[] arrOfStr00 = element00.split("of");
															String bb1 = (arrOfStr00[0]);	
															String cc1 = (arrOfStr00[1]);
															String[] arrOfStr001 = bb1.split("-");
															String[] arrOfStr002 = cc1.split(" ");
															CurrentPageRowCount1 = (arrOfStr001[1]);
															TotalRowCount1 = (arrOfStr002[1]);


															System.out.println(cIDs);
															//System.out.println(Charges1.size());



														}


													//}

													continue;
												}


											}

											if(CurrentPageRowCount1.trim().equals(TotalRowCount1)) {
 
												System.out.println("Line items are less than 25");
												LosCol =driver.findElements(By.xpath("//*[@id='losResultsRecord']/thead/tr/th")); 

												
												//System.out.println(LosCol.size());
												//System.out.println(LosCol.size());

												for(int a=1;a<=LosCol.size();a++) {
													String LOScolumn = driver.findElement(By.xpath("//*[@id='losResultsRecord']/thead/tr/th["+a+"]")).getText();
													if(LOScolumn.contains("Proc Code")) {
														Proc1 = driver.findElements(By.xpath("//table[@id='losResultsRecord']//th["+a+"]/following::tr//td[" +a+" ]"));
														// PIDs = new ArrayList<>();
														for (int j=0;j<Proc1.size();j++) {

															q= Proc1.get(j);
															ProcCode = q.getText();
															//System.out.println(ProcCode);

															PIDs.add(ProcCode);

														}
														//System.out.println(PIDs);
													}													
													else if(LOScolumn.contains("Num Svcs")) {
														Num_Svcs = driver.findElements(By.xpath("//table[@id='losResultsRecord']//th["+a+"]/following::tr//td[" +a+" ]"));
														// PIDs = new ArrayList<>();
														for (int j=0;j<Num_Svcs.size();j++) {

															r= Num_Svcs.get(j);
															NumCode = r.getText();
															//System.out.println(ProcCode);

															NIDs.add(NumCode);

														}
														}
														
														else if(LOScolumn.contains("Rev Code")) {
															Rev_Code = driver.findElements(By.xpath("//table[@id='losResultsRecord']//th["+a+"]/following::tr//td[" +a+" ]"));
															// PIDs = new ArrayList<>();
															for (int j=0;j<Rev_Code.size();j++) {

																s= Rev_Code.get(j);
																RevCode = s.getText();
																//System.out.println(ProcCode);

																RIDs.add(RevCode);

															}
														//System.out.println(PIDs);
													}


														else if(LOScolumn.equals("Service Charges")||LOScolumn.equals("Charges")) {
															Charges1 = driver.findElements(By.xpath("//table[@id='losResultsRecord']//th["+a+"]/following::tr//td[" +a+" ]"));


															for (int j=0;j<Charges1.size();j++) {

																r= Charges1.get(j);
																ChargesCode = r.getText();
																//System.out.println(ChargesCode);

																cIDs.add(ChargesCode);

																Charges1.get(j).click();
																//blue2Application.WaitForPageToLoad(5);
																Thread.sleep(300);
																driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS); 
																Payemt_Details=Blue2Application.FetchPaymentdetailsLos("Amount Approved for Payment ","Deductible Amount ","Coinsurance Amount ","Copay Amount ");
																blue2_Total_Amount_paid = Payemt_Details[0].replace("$", "");
																blue2_copay = Payemt_Details[3].replace("$", "");
																blue2_coins = Payemt_Details[2].replace("$", "");;
																blue2_ded = Payemt_Details[1].replace("$", "");
																if(blue2_Total_Amount_paid.equals("0.00")) {

																	countzero= countzero+1;

																}
																TAP.add(blue2_Total_Amount_paid);
																DedLos.add(blue2_ded);
																CopayLos.add(blue2_copay);
																CoinsLos.add(blue2_coins);
															}
														}
																

													
												}
												//System.out.println(PIDs.size());
												for(int s=0;s<PIDs.size();s++) {

													
													if(Claim_Types.equals("H")) {
													String Pcode= PIDs.get(s);
													String  Code = cIDs.get(s);
													String RCode=RIDs.get(s);
													String Ncode=NIDs.get(s);
													String PandC =Code+"||"+Pcode+"||"+RCode+"||"+Ncode;
													Blue2PandC.add(PandC);
													}
												
													if(Claim_Types.equals("M")) {
														String Pcode= PIDs.get(s);
														String  Code = cIDs.get(s);
															
														String Ncode=NIDs.get(s);
														String PandC =Code+"||"+Pcode+"||"+Ncode;
														Blue2PandC.add(PandC);
														}
													


												}

												

												
												blue2Application.WaitForPageToLoad(90);
												//If  Blue2 procedure code and charges anre not same as Facets 
												if(!Blue2PandC.containsAll(pIDs)) {
													Thread.sleep(200);
													blue2Application.ClickonSCCFhistory();
													TextFileUtilities.Log("Error-Skipping as there is mismatch with Facets and Blue2 Proc Code,Charges,Num Svcs,Rev Code", "FAIL");
													Readexcel.setCellData4(Testdata_File, Blue2_Payment_Status, i, "Error-Skipping as there is mismatch with Facets and Blue2 Proc Code,Charges,Num Svcs,Rev Code");
													Readexcel.setCellData(Testdata_File, TypeofPayment,counter1 , "Error-Skipping as there is mismatch with Facets and Blue2 Proc Code,Charges,Num Svcs,Rev Code");	
													continue start;	
												}
												
												System.out.println("Mapping Blue2 line items with Facets to get the sequence");
												
												

												 lable1:for(int s=0;s<pIDs.size();s++) {
														String newpids= (pIDs.get(s)).replace(" ", "");
														
														for(int p1=0;p1<Blue2PandC.size();p1++) {
															String Blue2value =Blue2PandC.get(p1);
															
															///System.out.println(newpids);
															if(Blue2value.equals(newpids)) { 
															
															
															///click
															String Facetsvalue =pIDs.get(p1);
															int value = pIDs.indexOf(Facetsvalue);
															//NewIDs.add(value, Proc);
															//System.out.println("Index:" +value+ "Value is" + Facetsvalue );						
															String TAPseq=TAP.get(p1);
															String Dedseq=DedLos.get(p1);
															String Copayseq=CopayLos.get(p1);
															String Coinsseq=CoinsLos.get(p1);
															TAPSeq.add(TAPseq);
															DedLosSeq.add(Dedseq);
															CopayLosSeq.add(Copayseq);
															CoinsLosSeq.add(Coinsseq);
															Thread.sleep(3000);
															//Thread.sleep(2000);
															driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS); 
															continue lable1;

														}
														
														

													}

												}
												 
												 if(countzero==Integer.parseInt(TotalRowCount1)) {
														Paymentype="Inclusive Payment";
														Readexcel.setCellData(Testdata_File, TypeofPayment,counter1 , Paymentype);	
														TextFileUtilities.Log("SCCF identified as Inclusive Payment and Fetched payment details--", "PASS");
														Readexcel.setCellData(Testdata_File,Claimid ,counter1 , ClaimID);
														Readexcel.setCellData(Testdata_File,Claim_Type ,counter1 , Claim_Types_Value);
														Readexcel.setCellData(Testdata_File,Last_SCCF ,counter1 , Last_DF_sccf);
														Readexcel.setCellData4(Testdata_File,Blue2_Payment_Status ,i , "SUCCESS");
													    System.out.println("Toal number of Line Items: "+Integer.parseInt(TotalRowCount1)+"Total number of Zero Dollar count :"+countzero);
													
												
														//System.out.println(Charges1.size());
													}
												    

												else
												{
													
													String listStringTAP = String.join("|| ", TAPSeq);
													String listStringcopay = String.join("|| ", CopayLosSeq);
													String listStringcoins = String.join("|| ", CoinsLosSeq);
													String listStringded = String.join("|| ", DedLosSeq);
													Readexcel.setCellData3(Testdata_File, PAID_AMT_Col, COPAY_Col, COINS_Col, DED_Col,counter1, listStringTAP, listStringcopay, listStringcoins, listStringded);
													Readexcel.setCellData(Testdata_File,Claimid ,counter1 , ClaimID);
													Readexcel.setCellData(Testdata_File,Claim_Type ,counter1 , Claim_Types_Value);
													Readexcel.setCellData(Testdata_File,Last_SCCF ,counter1 , Last_DF_sccf);
													Readexcel.setCellData4(Testdata_File,Blue2_Payment_Status ,i , "SUCCESS");
												    System.out.println("Toal number of Line Items: "+Integer.parseInt(TotalRowCount1)+"Total number of Zero Dollar count:"+countzero);
												
												    
											    Paymentype="Non Inclusive Payment";
											   
												Readexcel.setCellData(Testdata_File, TypeofPayment,counter1 , Paymentype);	
												
												TextFileUtilities.Log("SCCF identified as Non Inclusive Payment and Fetched payment details--", "PASS");
												
												}
												


											
												blue2Application.ClickonSCCFhistory();
												Blue2PandC.clear();
												TAP.clear();
												TAPSeq.clear();
												DedLos.clear();
												DedLosSeq.clear();
												CopayLos.clear();
												//CopayLos.clear();
												CopayLosSeq.clear();

												CoinsLos.clear();
												CopayLosSeq.clear();
												CoinsLosSeq.clear();
												pIDs.clear();
												PIDs.clear();
												RIDs.clear();
												NIDs.clear();
												cIDs.clear();
												Charges1.clear();
												Proc1.clear();
												countzero=0;
												Num_Svcs.clear();
												LosCol.clear();
												NewIDs.clear();
												 if(Rev_Code!=null) {
													 Rev_Code.clear();
												 }
												
												Chargeslist.clear();
												
												
												
												continue start;

											}

										}

									}




									Thread.sleep(200);
									blue2Application.ClickonSCCFhistory();
									continue start;

								}

							}

						}

					}
				}

				//Open file
				FileInputStream inputStream = new FileInputStream(new File(Testdata_File));
				XSSFWorkbook workBook = new XSSFWorkbook(inputStream);

				//Delete Sheet
				workBook.removeSheetAt(workBook.getSheetIndex("Los"));

				//Save the file
				FileOutputStream outFile =new FileOutputStream(new File(Testdata_File));
				workBook.write(outFile);
				outFile.close();
				driver.close();


			}else {
				TextFileUtilities.Log("Test Data Sheet is not available in the Provided Path", "FAIL");
			}


		} catch (Exception e) {

			Assert.error(e, "There is an exception while performing the Blue2 BOT tasks");

		}


	}

}


