package org.bcbsri.ITSHost.Facetsoverride;

import org.bcbsri.ITSHost.Blue2.ITSHost_blue_Nochnage;

import com.dell.acoe.framework.selenium.report.uft.UFTXmlReport;
import com.dell.acoe.framework.selenium.verify.Assert;

public class ITS_HostClaim_Overrides {

	public static void ExecuteFacetsOverride_UFTScript() {
		
		
		
		try {
			//AEConfig.init();
			
			ITSConfig.init();
			Assert.done("QTP Start -> ITS_Host_Claim_Overrides_Phase2 : Facets Execution");
			Thread.sleep(200);

			//Execute Facets Override
			//String QTP_Receiver_File = Environment.get("Receiver_FilePath");
			CitrixQTPListener.executeQTPScript(ITSConfig.QTP_Receiver_File,"ITS_Host_Claim_Overrides_Phase2", 18000, 50);
			UFTXmlReport.updateSeO2Report("C:\\Receiver\\QTPResults\\Results.xml");			
			
			Assert.done("End->QTP End -> ITS_Host_Claim_Overrides_Facets : Facets Execution");
		} catch (Exception e) {
			Assert.error(e, "Error->ITS_Host_Claim_Overrides_Facets : Facets Execution");
		}

	}

}
