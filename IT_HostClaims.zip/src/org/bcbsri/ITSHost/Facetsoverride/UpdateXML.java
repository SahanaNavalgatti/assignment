package org.bcbsri.ITSHost.Facetsoverride;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class UpdateXML {

	public static void updateuploadxml(String envValue,String CitrixUsername,String CitrixPW,String TestdataPath,String TestDataFileName){
		try {
			String filepath = "C:\\Receiver\\QTPData\\loadxml_Phase2.xml";
			//String filepath = "Z:\\loadxml.xml";
			
			//String filepath = "I:\\status\\LoadXML\\loadxml.xml";

			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);

			// Get the root element
			Node rootNode = doc.getFirstChild();
			System.out.println("Root tag value"+rootNode);
			// getElementsByTagName() to get it directly.
			NodeList varNode = (NodeList) doc.getElementsByTagName("Variable");
			System.out.println("How many var nodes"+varNode.getLength());
			
			for (int i = 0; i < varNode.getLength(); i++) {
				
				System.out.println("entered loop"+i);
				Element el = (Element) varNode.item(i);
				System.out.println("Var tag Name:" + el.getNodeName());
				NodeList children = el.getChildNodes();
				System.out.println("How many child nodes"+children.getLength());
				Node Name = children.item(1);
				Node Value = children.item(3);
				System.out.println("Child tag Name:" + Name.getNodeName());
				System.out.println("Text of Child tag Name:" + Name.getTextContent());

				if(Name.getTextContent().equals("Environment")) {
					if ((Value.getNodeName().equals("Value"))) {
						Value.setTextContent(envValue);

					}
				}

				if(Name.getTextContent().equals("CitrixUsername")) {
					if ((Value.getNodeName().equals("Value"))) {
						Value.setTextContent(CitrixUsername);

					}
				}

				if(Name.getTextContent().equals("CitrixPassword")) {
					if ((Value.getNodeName().equals("Value"))) {
						Value.setTextContent(CitrixPW);

					}
				}

				if(Name.getTextContent().equals("TestDataPath")) {
					if ((Value.getNodeName().equals("Value"))) {
						Value.setTextContent(TestdataPath);

					}

				}
				
				if(Name.getTextContent().equals("TestdataFileName")) {
					if ((Value.getNodeName().equals("Value"))) {
						Value.setTextContent(TestDataFileName);

					}

				}

			}
			
			// write the content into xml file
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(filepath));
			transformer.transform(source, result);

		}
		catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (SAXException sae) {
			sae.printStackTrace();
		}
	}
}

