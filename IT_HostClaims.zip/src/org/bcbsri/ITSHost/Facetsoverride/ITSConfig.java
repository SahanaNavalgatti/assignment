package org.bcbsri.ITSHost.Facetsoverride;

import java.io.File;

import com.dell.acoe.framework.config.Environment;

public class ITSConfig {
	
		//public static String DRIVER_PATH_IE = "I:\\status\\BCBSRITransformationQA\\Softwares\\java\\jars\\selenium\\drivers\\IEDriverServer_Win32.exe";
		public static String DRIVER_PATH_IE = "";
		public static String DRIVER_PATH_CHROME="";
		public static String AE_WEB_URL = "";
		public static String FEPDirect_WEB_URL = "";
		public static String PLANCONNECTION_WEB_URL = "";
		public static int BROWSER_STATUS = 0;
		public static String BASE_DIR = "";
		public static String BASE_DIR_BOXI = "";
		public static String TDP = "";
		public static String TDP_BOXI = "";
		public static String QTP_Receiver_File = "";
		public static String QTP_AE_Member = "";
		public static String Facets_WelcomeKit = "";
		public static String Claims_FEP = "";
		public static String Claims_ITSHOST = "";
		public static String Claims_ITSHOME = "";
		public static String Facets_IDCard = "";
		public static String Facet_OutputFile="";
		public static String LSC189_DATAFILE="";
		public static String LSC210_DATAFILE="";
		public static String FEP_DATAFILE="";
		public static String NEHP_DATAFILE="";
		public static String BOXI_WEB_URL = "";
		public static String PDM_Practitioner="";
		public static String PBM_DATAFILE="";
		public static String EDR="";
		public static String FormattedOutput ="";
		public static String TDF_NewAppln = "FormattedOPTestData.xlsx";
		public static String TDS_NewAppln = "NewApplnForm";
		public static String TDS_RedCard = "RedCard";
		// Sprint1 Test Data Files
//		TDF = Environment.get("BASE_PATH")+"/testdata/";
		public static String TDF_S1 = "AE_Automation_Sprint1_TestData.xlsx";
		//public static String TDF_S2 = "FacetsMemberData2F.xlsx";
		public static String TDF_S2 = "AE_Members.xls";
		public static String TDF_S3 = "LSC189_C.txt";
		public static String TDF_S4 = "LSC189_F.txt";
		public static String TDF_S5 = "LSC188_C.xlsx";
		public static String TDF_S6 = "LSC210_C.txt";
		public static String TDF_S7 = "NEHP_AES.txt";
		public static String TDF_S8 = "SBIDC006_ID_Card_Processing_Totals_Plan_Daily_Maintenance_DAILY.xls";
		public static String TDF_S9 = "SBIDC017_Member_Listing.xlsx";
		public static String TDF_S10 = "SBIDC015_ID_Card_Transaction_Events_DAILY.xls";
		public static String TDF_S11 = "WelcomeKit1.xls";
		public static String TDF_S12 = "Enrollment_Automation_Sprint2_IDDBData.xlsx";
		public static String TDF_S13 = "Claims_Automation_Sprint3_TestData.xlsx";
		public static String TDF_S14 = "SBIDC013_FCT_Member_ID_Card_Discrepancies.xlsx";
		public static String TDF_S15 = "IDcard.xls";
		public static String TDF_S16 = "Claims_Automation_Sprint3_TestData.xls";
		public static String TDF_S17 = "Claims_ITS_Host_TestData.xls";
		public static String TDF_S18 = "ITS HOME.xls";
		public static String TDF_S19 = "PDM.xls";
		public static String TDF_S20 = "PBM.xls";
		public static String TDF_S21 = "PBM_Group_Extract.txt";
		public static String TDF_S22 = "PBM_Member_Extract.txt";
		public static String TDF_S23 = "PBM_Medicare_Member_Extract.txt";
		public static String TDF_S24 ="FormattedOutput_TestData.xls";
		public static  String TDF_S25 = "T.DAILYMADVMAINT.txt";
		public static  String TDF_S26 = "T.DAILYPLMAINT.txt";
		public static  String TDF_S27 = "T.DAILYBCMAINT.txt";
		public static  String TDF_S28 = "T.CONVBCMAINT.txt";
		public static  String TDF_S29 = "T.CONVMADVMAINT.txt";
		public static  String TDF_S30 = "T.CONVPLMAINT.txt";
		public static String TDPOP="";
		public static  String TDF_S31 = "FormattedOutput_TestData.xls";
		public static  String TDF_S32 = "ITS Host.xls";
		public static String TDS_S1_AEGUISCBEnroll = "AEGUISCBEnroll";
		public static String RDPEnvironment = "";
		public static String RDPDataFile = "";
		public static String RDPProcessedDataLocation=""; 
		public static String RDPClonedDataLocation="";
		public static String RDPQueriesLocation="";
		private static String CitrixUsername = "";
		public static String CitrixPassword="";
		public static String TestDataFileName="";
		
		//public static int ListenerTimeOut = 0; 
		
		public static void init(){
			
			//Get the Test Data File Name
			String File_Path = Environment.get("test_data_path");
			File folder = new File(File_Path);
			
			if(folder.isDirectory()) {
				File[] fileList = folder.listFiles();
				
				for(File fileName:fileList) {
	    			System.out.println(fileName.getName());
	    			
	    			if(fileName.getName().toUpperCase().contains("ITSHOST")) {
	    				TestDataFileName = fileName.getName();
	    			}
	    		}
			}
			
			ITSConfig.DRIVER_PATH_IE = Environment.get("DRIVER_PATH_IE");
			ITSConfig.DRIVER_PATH_CHROME=Environment.get("DRIVER_PATH_CHROME");
			ITSConfig.AE_WEB_URL = Environment.get("AE_WEB_URL");
			ITSConfig.BOXI_WEB_URL = Environment.get("BOXI.Web.Url");
			ITSConfig.BASE_DIR = Environment.get("BASE_DIR");
			ITSConfig.BASE_DIR_BOXI = Environment.get("BASE_DIR_BOXI");
			ITSConfig.TDP_BOXI =  Environment.get("BASE_DIR_BOXI");
			ITSConfig.TDP =  Environment.get("BASE_DIR")+"/testdata/";
			ITSConfig.TDPOP =  Environment.get("BASE_DIR")+"/testdata/IDC010/";
			ITSConfig.QTP_Receiver_File = Environment.get("QTP_Receiver_File");
			ITSConfig.Facet_OutputFile = Environment.get("Facet_OutputFile");
			ITSConfig.LSC189_DATAFILE=Environment.get("LSC189_DataFile");
			ITSConfig.LSC210_DATAFILE=Environment.get("LSC210_DataFile");
			ITSConfig.FEP_DATAFILE=Environment.get("FEP_DataFile");
			ITSConfig.NEHP_DATAFILE=Environment.get("NEHP_DataFile");
			ITSConfig.QTP_AE_Member=Environment.get("QTP_AE_Member");
//			AEConfig.QTP_AE_Member=Environment.get("QTP_AE_Member");
			ITSConfig.Facets_WelcomeKit=Environment.get("Facets_WelcomeKit");
			ITSConfig.Claims_FEP=Environment.get("Claims_FEP");
			ITSConfig.Claims_ITSHOST=Environment.get("Claims_ITSHOST");
			ITSConfig.Claims_ITSHOME=Environment.get("Claims_ITSHOME");
			ITSConfig.Facets_IDCard=Environment.get("Facets_IDCard");
			ITSConfig.FEPDirect_WEB_URL=Environment.get("FEPDirect.Web.Url");
			ITSConfig.PLANCONNECTION_WEB_URL=Environment.get("PlanConnection.Web.Url");
			ITSConfig.PDM_Practitioner = Environment.get("PDM_Practitioner");
			ITSConfig.PBM_DATAFILE = Environment.get("PBM_DATAFILE");
			ITSConfig.EDR=Environment.get("EDR");
			ITSConfig.FormattedOutput=Environment.get("FormattedOP_DATAFILE");
			ITSConfig.RDPEnvironment=Environment.get("Environment");
			ITSConfig.RDPDataFile=Environment.get("RDPDataFile");
			ITSConfig.RDPProcessedDataLocation=Environment.get("processed_testdata_path");
			ITSConfig.RDPClonedDataLocation=Environment.get("cloned_testdata_path");
			ITSConfig.RDPQueriesLocation=Environment.get("queries_path");
			ITSConfig.CitrixUsername = Environment.get("CitrixUsername");
			ITSConfig.CitrixPassword = Environment.get("CitrixPassword");
			
			UpdateXML.updateuploadxml(ITSConfig.RDPEnvironment,ITSConfig.CitrixUsername,ITSConfig.CitrixPassword,ITSConfig.RDPProcessedDataLocation,TestDataFileName);
			//AEConfig.ListenerTimeOut =Integer.parseInt(Environment.get("ListenerTimeOut")); 
			
}
}
