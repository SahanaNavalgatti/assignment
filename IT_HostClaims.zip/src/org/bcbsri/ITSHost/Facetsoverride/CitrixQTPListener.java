package org.bcbsri.ITSHost.Facetsoverride;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.ArrayList;

import org.bcbsri.ITSHost.dbutility.TextFileUtilities;

import com.dell.acoe.framework.selenium.util.LineUtilities;
//import com.dell.acoe.framework.selenium.util.TextFileUtilities;
import com.dell.acoe.framework.selenium.verify.Assert;

public class CitrixQTPListener {
	
	public static String executeQTPScript(String statusFile, String scriptName, int maxWaitingTimeInSec, int poolingTimeInSec) throws IOException {
		
		try {
	        Runtime runtme = Runtime.getRuntime();
            Process procss = runtme.exec(new String[] {
        	        "wscript.exe", "C:\\Users\\OHQZTSO\\Desktop\\ITSHost_citrixconnect_Phase2.vbs"});            
					//"wscript.exe", "C:\\svc-user-auto\\ITSHost_citrixconnect.vbs"});            
	        int exitVal = procss.waitFor();
            System.out.println("Process exitValue: " + exitVal);
	    } catch (Exception ex) {
	        ex.printStackTrace();
	    }

		ReplaceInteruptStatus(statusFile,"#InProgress#");
		ReplaceInteruptStatus(statusFile,"#Start#");
		updateScriptStatus(statusFile, scriptName, "Start");
//		updateScriptStatus(statusFile, scriptName, "Start");
		
		int attempts = maxWaitingTimeInSec/poolingTimeInSec;
		String status = "";
		
		for(int i=0; i<attempts; i++){
			status = getQTPScriptStatus(statusFile, scriptName).trim();
			if(status.equalsIgnoreCase("Completed")||status.equalsIgnoreCase("Stopped")){
				Assert.done("QTP - Waiting for "+poolingTimeInSec+" more sec (total:"+maxWaitingTimeInSec+" waited: "+(poolingTimeInSec*i)+") for script execution to complete. current status:"+status);
				break;
			}else{
				try {
					Assert.done("QTP - Waiting for "+poolingTimeInSec+" more sec (total:"+maxWaitingTimeInSec+" waited: "+(poolingTimeInSec*i)+") for script execution to complete. current status:"+status);
					Thread.sleep(poolingTimeInSec*1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		return status;
	}

	public static void stopQTPScript(String statusFile, String scriptName) throws IOException {
		updateScriptStatus(statusFile, scriptName, "Stop");
	}
	
	public static String getQTPScriptStatus(String statusFile, String scriptName){
		String status = "Unknown";
		try {
			ArrayList<String> lines = TextFileUtilities.getDetailLines(statusFile);
			for (int i = 0; i < lines.size(); i++) {
				if (lines.get(i).trim().startsWith(scriptName + "#")) {
					status = LineUtilities.getTokens(lines.get(i), "#")[1];
					break;
				}
			} 
		} catch (Exception e) {
			System.out.println("Error occured while reading file");
		}
		return status;
	}	
	
	private static void updateScriptStatus(String statusFile, String scriptName, String status){
		ArrayList<String> lines = new ArrayList<String>();
		try {
			lines = TextFileUtilities.getAllLines(statusFile);
		} catch (Exception e) {
			System.out.println("Error while reading receiver file");
//			e.printStackTrace();
		}
		for(int i=0; i<lines.size(); i++){
			String[] tokens = lines.get(i).split("#", -1);
			if(lines.get(i).trim().startsWith(scriptName+"#")){
				lines.set(i, scriptName+"#"+status+"#"+tokens[2]);
				break;
			}
		}
		
		try {
			FileWriter writer = new FileWriter(statusFile);
			for (int i = 0; i < lines.size(); i++) {
				writer.write(lines.get(i) + System.getProperty("line.separator"));
			}
			writer.close();
		} catch (Exception e) {
			System.out.println("Error while writing receiver file");
//			e.printStackTrace();
		}
	}
	private static void ReplaceInteruptStatus(String statusFile,String Status){
		Assert.done("Start -> Receiver Clean up");
		ArrayList<String> lines = new ArrayList<String>();
		String PreStatus="#Completed#";
		String originalFileContent = "";
        
        BufferedReader reader = null;
        BufferedWriter writer = null;

		try {
			 reader = new BufferedReader(new FileReader(statusFile));
	            
	            String currentReadingLine = reader.readLine();
//	            System.out.println("currentReadingLine : "+currentReadingLine);
	            while (currentReadingLine != null) {
	                originalFileContent += currentReadingLine + System.lineSeparator();
	                currentReadingLine = reader.readLine();
//	                System.out.println("currentReadingLine : "+currentReadingLine);
	            }
	            
	            String modifiedFileContent = originalFileContent.replaceAll(Status, PreStatus);
//	            System.out.println("modifiedFileContent : "+modifiedFileContent);
	            writer = new BufferedWriter(new FileWriter(statusFile));
	            
//	          
	            writer.write(modifiedFileContent);
	            writer.flush();
	            writer.close();
	            Assert.done("End -> Receiver Clean up");
		}catch (Exception e)
		{
			e.printStackTrace();
		}

	}

	public static void main(String[] args) throws Exception {
		//getQTPScriptStatus("I:/status/BCBSRITransformationQA/Git/GitJenkins/buildfiles/Receiver.txt", "FacetsData");
		CitrixQTPListener.executeQTPScript("I:/status/BCBSRITransformationQA/Git/GitJenkins/buildfiles/Receiver.txt", "FacetsData", 
				100, 5);
		System.exit(0);
		ArrayList<String> lines = TextFileUtilities.getDetailLines("I:/status/BCBSRITransformationQA/Git/GitJenkins/buildfiles/Receiver.txt");
		
		for(int i=0; i<lines.size(); i++){
			System.out.println(lines.get(i));
			if(lines.get(i).trim().startsWith("FACETSlgout#")){
				lines.set(i, "FACETSlgout#Start#");
			}
		}
		
		System.out.println("---");
		FileWriter writer = new FileWriter("I:/status/BCBSRITransformationQA/Git/GitJenkins/buildfiles/Receiver.txt");
		writer.write("Test_Script#Status    #"+System.getProperty("line.separator"));
		for(int i=0; i<lines.size(); i++){
			System.out.println(lines.get(i));
			writer.write(lines.get(i)+System.getProperty("line.separator"));
		}
		writer.close();
	}
}
