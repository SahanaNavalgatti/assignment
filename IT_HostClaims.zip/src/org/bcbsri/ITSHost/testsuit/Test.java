package org.bcbsri.ITSHost.testsuit;

import com.dell.acoe.framework.run.TestRunner;

public class Test {

	public static void main(String[] args) throws Exception {

		
		System.out.println("Starting Test Runner!!");
		String path = System.getProperty("user.dir");
		String Fullpath = path + "\\resources\\config\\ConfigValidation_local.xls";
		//C:\Users\A152TSO\OneDrive - Blue Cross and Blue Shield of Rhode Island\Jars\Documents\IT_HostClaims_Phase2_Latest\resources\config
		System.out.println("Config path : " + Fullpath);
		TestRunner.runTests(Fullpath);
		//C:\Users\A152TSO\OneDrive - Blue Cross and Blue Shield of Rhode Island\Jars\Documents\IT_HostClaims_Phase2_Latest\resources\config\ConfigValidation_local.xls
	}

}


