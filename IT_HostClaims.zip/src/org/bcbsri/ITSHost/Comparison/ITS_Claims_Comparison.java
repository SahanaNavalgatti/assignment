package org.bcbsri.ITSHost.Comparison;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.bcbsri.ITSHost.Blue2.ITSHost_blue_Nochnage;
import org.bcbsri.ITSHost.dbutility.TextFileUtilities;
import org.bcbsri.configvalidation.ConfigValidation;
import org.bcbsri.configvalidation.Readexcel;

import com.dell.acoe.framework.config.Environment;

public class ITS_Claims_Comparison {
	
	static Readexcel re = new Readexcel();

	public static void its_validateclaims_generatenotes() throws Exception {
		
		//Variable Declaration
		String File_Name = "";
		String FileExist = "";
		String ClaimID_Corrected = "";
		String List_ClaimID_Original = "";
		String List_ClaimID_Corrected = "";
		String Str_ClaimType = "";
		String Blank_ProfClaims = "False";
		String Prof_SubFiltered_Claims = "False";
		String Prof_BillProvFiltered_Claims = "False";
		String Blank_InstiClaims = "False";
		String Insti_SubFiltered_Claims = "False";
		
		
		int rowIndex=0;
		int row_Index = 0;
		int row_Index1 = 0;
		int row_Index2 = 0;
		int Org_row_Index1 = 0;
		int Org_row_Index2 = 0;
		int ClaimID_Column = 0;
		int ClaimType_Column = 0;
		int MicroFilmID_Column = 0;
		int TestData_Rowcount;
		
		int Notes_column_Value = 0;
		int SCCF_column_Value = 0;
		
		
		String File_Path = Environment.get("test_data_path");
		File folder = new File(File_Path);
		File[] fileList = folder.listFiles();
		
		String PreMove = Environment.get("Environment");
		
		ArrayList<String> FilteredClaims_SubMemProv = new ArrayList<String>();
		ArrayList<String> FilteredClaims_BillProv = new ArrayList<String>();
		
		//Create Excel - Prof claims details comparison
        Workbook wb = new XSSFWorkbook();
        String Prof_ComparisionSheet = "Prof_MemberDetailsComparision.xlsx";
        String ExcelFilePath = File_Path+"\\"+Prof_ComparisionSheet;
        OutputStream fileOut = new FileOutputStream(ExcelFilePath); 
        wb.createSheet("Adj_Sub_Mem_Prov");
        wb.write(fileOut);
        wb.close();
        
        FormulaEvaluator evaluator = wb.getCreationHelper().createFormulaEvaluator();
		
        //Get the Test Data File Name through Partial Text
		for(File fileName:fileList) {
			//System.out.println(fileName.getName());
			if(fileName.getName().toUpperCase().contains("ITSHOST")) {
				
				File_Name = fileName.getName();
				FileExist = "True";
				break;
				
			}
			
		}
		
		//Check if Test Data File Exists
		if(FileExist=="True") {
			
			String Testdata_File = File_Path+"\\"+File_Name;
			
			FileInputStream fis = new FileInputStream(Testdata_File);
			XSSFWorkbook wbook_1 = new XSSFWorkbook(fis);
			String SheetName = wbook_1.getSheetName(0);
			Sheet sheet = wbook_1.getSheet(SheetName);
			TestData_Rowcount = sheet.getPhysicalNumberOfRows();
			//TestData_Rowcount = 10;
			
			//Array Declaration for Professional and Institutional claims
			ArrayList<String> ClaimIds_Prof = new ArrayList<String>();
			ArrayList<String> ClaimIds_Insti = new ArrayList<String>();
			
			Row Head_row = null;
			
			//Remove Duplicates, add claims into respective array
			for(int i = 1; i <= TestData_Rowcount-1; i++) {
				
				Row row=sheet.getRow(i); 
				Head_row = sheet.getRow(0);
				
				int ColCount = row.getPhysicalNumberOfCells();
				
				//Claim ID
				if(i==1) {
					
					for(int j=1;j<=ColCount;j++) {
						
						Cell cell = Head_row.getCell(j);
						
						if(cell.getStringCellValue().trim().equals("Claim ID") || cell.getStringCellValue().trim().equals("Claim_ID")) {
							ClaimID_Corrected = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, i, j);
							ClaimID_Column = j;
							break;
						}
						
					}
					
					//MicroFilm ID
					for(int j=1;j<=ColCount;j++) {
						
						Cell cell = Head_row.getCell(j);
						
						if(cell.getStringCellValue().trim().equals("Microfilm ID") || cell.getStringCellValue().trim().equals("Microfilm_ID")) {
							MicroFilmID_Column = j;
							break;
						}
						
					}
					
					// Claim Type
					for(int j=1;j<=ColCount;j++) {
						
						Cell cell = Head_row.getCell(j);
						
						if(cell.getStringCellValue().trim().equals("Claim Type") || cell.getStringCellValue().trim().equals("Claim_Type")) {
							Str_ClaimType = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, i, j);
							ClaimType_Column = j;
							break;
						}
						
					}
					
					//Create SCCF Column through Automation as unable to fetch SCCFs from Test data Sheet
					for(int j=0; j<=ColCount-1; j++) {

						Cell cell = Head_row.getCell(j);
						
						if(cell.getStringCellValue().trim().equals("SCCF_Txt")) {
							SCCF_column_Value = j;
							break;
						}
						
					}
					
					//Create SCCF Column if not exist
					if(SCCF_column_Value==0) {
						Head_row.createCell(Head_row.getPhysicalNumberOfCells()).setCellValue("SCCF_Txt");
						SCCF_column_Value = Head_row.getPhysicalNumberOfCells()-1;
					}
					
					ColCount = Head_row.getPhysicalNumberOfCells();
					
					//Get the Notes Column Value if Exists
					for(int j=0; j<=ColCount-1; j++) {

						Cell cell = Head_row.getCell(j);
						
						if(cell.getStringCellValue().trim().equals("Comparison_Notes")) {
							Notes_column_Value = j;
							break;
						}
						
					}
					
					//Create Notes Column if doesnt Exist
					if(Notes_column_Value==0) {
						Head_row.createCell(Head_row.getPhysicalNumberOfCells()).setCellValue("Comparison_Notes");
						Notes_column_Value = Head_row.getPhysicalNumberOfCells()-1;
					}
					
					
					//Add the Claims to Array based on Type
					if(Str_ClaimType.trim().equals("M")) {
						ClaimIds_Prof.add(ClaimID_Corrected);
					}else if(Str_ClaimType.trim().equals("H")) {
						ClaimIds_Insti.add(ClaimID_Corrected);
					}else {
						TextFileUtilities.Log("Claim Type Value '"+Str_ClaimType+"' is not valid for Claim '"+ClaimID_Corrected+"'", "FAIL");
					}
					
				}else {
						
					//Claim ID
					Cell cell_ClaimID = Head_row.getCell(ClaimID_Column);
					
					switch (evaluator.evaluateInCell(cell_ClaimID).getCellType()) {
					  
					  case Cell.CELL_TYPE_STRING: 
						  
						  ClaimID_Corrected = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, i, ClaimID_Column);
						  //System.out.println(ClaimID_Corrected);
						  break;
						  
					}
					
					//Claim Type
					Cell cell_ClaimType = Head_row.getCell(ClaimType_Column);
					
					switch (evaluator.evaluateInCell(cell_ClaimType).getCellType()) {
					  
					  case Cell.CELL_TYPE_STRING: 
						  
						  Str_ClaimType = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, i, ClaimType_Column);
						  //System.out.println(Claim_ID);
						  break;
						  
					}
					
					//Get list of unique Prof Claims and add it into Array
					if(Str_ClaimType.trim().equals("M")) {
						
						if(!ClaimIds_Prof.contains(ClaimID_Corrected)) {
							ClaimIds_Prof.add(ClaimID_Corrected);
						}
					
					//Get list of unique Insti Claims and add it into Array
					}else if(Str_ClaimType.trim().equals("H")) {
						
						if(!ClaimIds_Insti.contains(ClaimID_Corrected)) {
							ClaimIds_Insti.add(ClaimID_Corrected);
						}
						
					}else {
						TextFileUtilities.Log("Claim Type Value '"+Str_ClaimType+"' is not valid for Claim '"+ClaimID_Corrected+"'", "FAIL");
					}
					
				}
				
			}
			
			FileOutputStream fout_Columns = new FileOutputStream(Testdata_File);
			wbook_1.write(fout_Columns);
			
			Row Head_Row = sheet.getRow(0);
			
			//Professional Claims
			if(!ClaimIds_Prof.isEmpty()) {
				
				TextFileUtilities.Log("Removed duplicates and Listed Professional Claims into an Array", "DONE");
				
				for(int ClaimID=0; ClaimID <= ClaimIds_Prof.size()-1; ClaimID++) {
					
					List_ClaimID_Corrected = ClaimIds_Prof.get(ClaimID);
					
					//Get the Original claim id
					if (!(List_ClaimID_Corrected.endsWith("00"))) {
						List_ClaimID_Original = List_ClaimID_Corrected.substring(0, List_ClaimID_Corrected.length() - 2)+"00"; 
					}
					
					// Subscriber, Member, Provider info query
					String Partial_Text1 = "PROF_Sub_Mem_Prov_Info";
					String QueryFile_MemInfo;
					try {
						QueryFile_MemInfo = ITS_Claims_Code.listFilesForFolder(Partial_Text1);
						
						//Provide Claim ID as input to Query
						String Adj_SubInfo_Query = re.TextFilename(Environment.get("config_path")+"/"+QueryFile_MemInfo+".txt").replace("REPLACE_VALUE", List_ClaimID_Corrected);
						String Org_SubInfo_Query = re.TextFilename(Environment.get("config_path")+"/"+QueryFile_MemInfo+".txt").replace("REPLACE_VALUE", List_ClaimID_Original);
						
						// Subscriber, Member, Provider info Result set
						ResultSet rs1 = ConfigValidation.Database(PreMove, Adj_SubInfo_Query); //Corrected claims data
						ResultSet rs2 = ConfigValidation.Database(PreMove, Org_SubInfo_Query); //Original Claims data
						
						ResultSetMetaData rsmd1 = ConfigValidation.getResultSetMetaData(PreMove,rs1);
						ResultSetMetaData rsmd2 = ConfigValidation.getResultSetMetaData(PreMove,rs2);
						
						//Write DB output to excel - Sub-Mem-Prov info
						int NextRow = Integer.parseInt(ITS_Claims_Code.WriteToExcel(ExcelFilePath,"Adj_Sub_Mem_Prov",rs1,rowIndex,rsmd1)); 
						ITS_Claims_Code.WriteToExcel(ExcelFilePath,"Org_Sub_Mem_Prov",rs2,rowIndex,rsmd2);
						ITS_Claims_Code.WriteToExcel(ExcelFilePath,"Comp_Result_Sub_Mem_Prov",rs1,rowIndex,rsmd1);
						
						//Write DB output based on line count of Previous claim details 
						rowIndex = NextRow-1;
						
					} catch (Exception e) {
						e.printStackTrace();
					}
					
				}
				
				//System.out.println("Claims before filter "+ClaimIds_Prof);
				re.setComparevalues(ExcelFilePath, "Adj_Sub_Mem_Prov","Org_Sub_Mem_Prov", "Comp_Result_Sub_Mem_Prov");
				FilteredClaims_SubMemProv = Readexcel.ReadResultSheet(ExcelFilePath, "Adj_Sub_Mem_Prov", "Comp_Result_Sub_Mem_Prov",ClaimIds_Prof);
				TextFileUtilities.Log("Subscriber_Mem_Provider comparision is completed for Professional Claims", "DONE");
				//System.out.println("SubMemProv - Prof Filtered Claims "+FilteredClaims_SubMemProv);
				
				//Export Comparison Notes to Test Data Sheet - Sub_Mem_Provider
				String Claim_ID = null;
				String Notes_txt = null;
				
				HashMap<String, String> Sub_Mem_Provider_Notes = new HashMap<String, String>();
				
				FileInputStream fis_Notes=new FileInputStream(ExcelFilePath);
				Workbook wbook_Notes = new XSSFWorkbook(fis_Notes);
				Sheet sheet_CompResult = wbook_Notes.getSheet("Comp_Result_Sub_Mem_Prov");
				
				//Get the Notes from Comparison Result Sheet and Store it in Hashmap with Key as Claim ID
				for(int Value = 1; Value <= sheet_CompResult.getPhysicalNumberOfRows()-1; Value++) {
					
					Row row = sheet_CompResult.getRow(Value);
					Cell ClaimID = row.getCell(0);
					Cell Notes_Prof = row.getCell(row.getPhysicalNumberOfCells()-1);
					
					//Get Claim ID
					switch (evaluator.evaluateInCell(ClaimID).getCellType()) {
					  
					  case Cell.CELL_TYPE_STRING: 
						  
						  Claim_ID = ClaimID.getStringCellValue();
						  //System.out.println(Claim_ID);
						  break;
						  
					}
					
					//Get Notes
					switch (evaluator.evaluateInCell(Notes_Prof).getCellType()) {
					  
					  case Cell.CELL_TYPE_STRING: 
						  
						  Notes_txt = Notes_Prof.getStringCellValue();
						  //System.out.println(Claim_ID);
						  break;
						  
					}
					
					
					//Map ClaimID with Notes using HashMap
					if(!(Claim_ID.equals(null))&&!(Notes_txt.equals(null))) {
						Sub_Mem_Provider_Notes.put(Claim_ID,Notes_txt);
					}
					
				}
				
				
				//Write the Notes to Test Data Sheet after Fetching From Comparison Result Sheet
				String Notes = null;
				
				for(int Value = 1; Value<=TestData_Rowcount-1; Value++) {
					
					Row row = sheet.getRow(Value);
					Cell ClaimID = row.getCell(ClaimID_Column);
					
					//Get Claim ID
					switch (evaluator.evaluateInCell(ClaimID).getCellType()) {
					  
					  case Cell.CELL_TYPE_STRING: 
						  
						  Claim_ID = ClaimID.getStringCellValue();
						  //System.out.println(Claim_ID);
						  break;
						  
					}
					
					//Enter Notes to Test Data Sheet
					Notes = Sub_Mem_Provider_Notes.get(Claim_ID);
					//Cell Notes_Txt = row.createCell(Col_Count);
					Cell Notes_Txt = row.createCell(Notes_column_Value);
					Notes_Txt.setCellValue(Notes);
					
				}
				
				TextFileUtilities.Log("Updated the Test Data Sheet with Comparison Notes generated from Subscriber_Mem_Provider details comparision", "DONE");
				
				//FileOutputStream fout_Notes_1 = new FileOutputStream(Testdata_File);
				//wbook_1.write(fout_Notes_1);
				//fout_Notes_1.flush(); 
				//fout_Notes_1.close(); 
				//wbook_1.close();
				//wbook_Notes.close();
				
				//Validate Filtered Claims exists from Sub Mem Provider Query
				if(!FilteredClaims_SubMemProv.isEmpty()) {
					
					//Billing Provider Query - Iterate through list of Filtered Claims from above Comparison
					for(int ClaimID = 0; ClaimID <= FilteredClaims_SubMemProv.size()-1; ClaimID++) {
						
						String Partial_Text2 = "Billing_Provider";
						String QueryFile_BillingProvider;
						
						List_ClaimID_Corrected = FilteredClaims_SubMemProv.get(ClaimID);
						
						//Get the Original claim id
						if (!(List_ClaimID_Corrected.endsWith("00"))) {
							List_ClaimID_Original = List_ClaimID_Corrected.substring(0, List_ClaimID_Corrected.length() - 2)+"00"; 
						}
						
						try {
							QueryFile_BillingProvider = ITS_Claims_Code.listFilesForFolder(Partial_Text2);
							
							String BillingProvider_Query1 = re.TextFilename(Environment.get("config_path")+"/"+QueryFile_BillingProvider+".txt").replace("REPLACE_VALUE", List_ClaimID_Corrected);
							String BillingProvider_Query2 = re.TextFilename(Environment.get("config_path")+"/"+QueryFile_BillingProvider+".txt").replace("REPLACE_VALUE", List_ClaimID_Original);
							
							//Billing Provider Result set
							ResultSet rs3= ConfigValidation.Database(PreMove, BillingProvider_Query1);
							ResultSet rs4= ConfigValidation.Database(PreMove, BillingProvider_Query2);
							
							//Resultset Meta data
							ResultSetMetaData rsmd3 = ConfigValidation.getResultSetMetaData(PreMove,rs3);
							ResultSetMetaData rsmd4 = ConfigValidation.getResultSetMetaData(PreMove,rs4);
							
							//write DB output to excel - Billing Provider info
							int NextRow1 = Integer.parseInt(ITS_Claims_Code.WriteToExcel(ExcelFilePath,"Adj_BillProvider",rs3,row_Index,rsmd3)); 
							ITS_Claims_Code.WriteToExcel(ExcelFilePath,"Org_BillProvider",rs4,row_Index,rsmd4);
							ITS_Claims_Code.WriteToExcel(ExcelFilePath,"CompResult_BillProvider",rs3,row_Index,rsmd3);
							
							//Below Line is to Write DB output in Excel based on Rows of Previous Claim
							row_Index = NextRow1-1;
							
						} catch (Exception e) {
							e.printStackTrace();
						}
						
					}
					
					re.setComparevalues(ExcelFilePath, "Adj_BillProvider","Org_BillProvider", "CompResult_BillProvider");
					FilteredClaims_BillProv = Readexcel.ReadResultSheet(ExcelFilePath, "Adj_BillProvider", "CompResult_BillProvider",FilteredClaims_SubMemProv);
					//System.out.println("Filtered Claims Billing Prov"+FilteredClaims_BillProv);
					TextFileUtilities.Log("Billing Provider Details comparision is completed for Professional Claims", "DONE");
					
					// Write Notes into Test Data Sheet - Billing Provider
					HashMap<String, String> Final_Notes_BillingProv = new HashMap<String, String>();
					FileInputStream fis2=new FileInputStream(ExcelFilePath);
					XSSFWorkbook wbook2 = new XSSFWorkbook(fis2);
					Sheet sheet_BillComp = wbook2.getSheet("CompResult_BillProvider");
					int Billing_Rows = sheet_BillComp.getPhysicalNumberOfRows();
					
					Claim_ID = null;
					Notes_txt = "";
					
					for(int Value = 1; Value <= Billing_Rows-1; Value++) {
						
						Row row_Billing = sheet_BillComp.getRow(Value);
						Cell ClaimID = row_Billing.getCell(0);
						Cell Billing_Notes = row_Billing.getCell(row_Billing.getPhysicalNumberOfCells()-1);
						
						//Get Claim ID
						switch (evaluator.evaluateInCell(ClaimID).getCellType()) {
						  
						  case Cell.CELL_TYPE_STRING: 
							  
							  Claim_ID = ClaimID.getStringCellValue();
							  //System.out.println(Claim_ID);
							  break;
							  
						}
						
						//Get Notes
						switch (evaluator.evaluateInCell(Billing_Notes).getCellType()) {
						  
						  case Cell.CELL_TYPE_STRING: 
							  
							  Notes_txt = Billing_Notes.getStringCellValue();
							  //System.out.println(Claim_ID);
							  break;
							  
						}
						
						
						//Combine ClaimID and Notes
						if(!(Claim_ID.equals("null"))&&!(Notes_txt.equals("null"))) {
							Final_Notes_BillingProv.put(Claim_ID,Notes_txt);
						}
						
					}
					
					//Write the Notes to Test Data Sheet which is Fetched from Comparison Result
					for(int Value = 1; Value<=TestData_Rowcount-1; Value++) {
						
						Notes = "";
						
						Row row = sheet.getRow(Value);
						Cell ClaimID = row.getCell(ClaimID_Column);
						
						//Get Claim ID
						switch (evaluator.evaluateInCell(ClaimID).getCellType()) {
						  
						  case Cell.CELL_TYPE_STRING: 
							  
							  Claim_ID = ClaimID.getStringCellValue();
							  //System.out.println(Claim_ID);
							  break;
							  
						}
						
						//Write Notes into Test Data Sheet
						if(Final_Notes_BillingProv.containsKey(Claim_ID)) {
							
							Notes = Final_Notes_BillingProv.get(Claim_ID);
							Cell Notes_Txt = row.createCell(Notes_column_Value);
							Notes_Txt.setCellValue(Notes);
							
						}
						
					}
					
					TextFileUtilities.Log("Updated the Test Data Sheet with Notes generated from Billing Provider Details comparision for Professional claims", "DONE");
					
					//Indicative Query [Professional] - Iterate through list of Filtered Claims from above Comparison
					if(!FilteredClaims_BillProv.isEmpty()) {
						
						HashMap<String, String> IndNotes_Txt = new HashMap<String, String>();
						
						for(int ClaimID = 0; ClaimID <= FilteredClaims_BillProv.size()-1; ClaimID++) {
							
							String Partial_Text3 = "Indicative";
							String QueryFile_Indicative;
							String All = "";
							
							ArrayList<String> Adj_DifferentValues = new ArrayList<String>();
							ArrayList<String> Org_DifferentValues = new ArrayList<String>();
							
							List_ClaimID_Corrected = FilteredClaims_BillProv.get(ClaimID);
							//System.out.println(List_ClaimID_Corrected);
							
							//Get the Original claim id
							if (!(List_ClaimID_Corrected.endsWith("00"))) {
								List_ClaimID_Original = List_ClaimID_Corrected.substring(0, List_ClaimID_Corrected.length() - 2)+"00";
							}
							
							try {
								
								QueryFile_Indicative = ITS_Claims_Code.listFilesForFolder(Partial_Text3);
								
								String Indicative_Query1 = re.TextFilename(Environment.get("config_path")+"/"+QueryFile_Indicative+".txt").replace("REPLACE_VALUE", List_ClaimID_Corrected);
								String Indicative_Query2 = re.TextFilename(Environment.get("config_path")+"/"+QueryFile_Indicative+".txt").replace("REPLACE_VALUE", List_ClaimID_Original);
								
								//Indicative screen Result set
								ResultSet rs5= ConfigValidation.Database(PreMove, Indicative_Query1);
								ResultSet rs6= ConfigValidation.Database(PreMove, Indicative_Query2);
								
								//Resultset Meta data
								ResultSetMetaData rsmd5 = ConfigValidation.getResultSetMetaData(PreMove,rs5);
								ResultSetMetaData rsmd6 = ConfigValidation.getResultSetMetaData(PreMove,rs6);
								
								//Adjusted Claims - Get Before and After Count
								String Adj_Bef_Aft_Cnt = ITS_Claims_Code.WriteToExcel(ExcelFilePath,"Adj_Indicative",rs5,row_Index1,rsmd5);
								String[] Split_Cnt_Adj = Adj_Bef_Aft_Cnt.split(":");
								
								//Define the row index for next iteration
								row_Index1 = Integer.parseInt(Split_Cnt_Adj[1])-1;
								
								//Original claims - Get Before and After Count
								String Org_Bef_Aft_Cnt = ITS_Claims_Code.WriteToExcel(ExcelFilePath,"Org_Indicative",rs6,Org_row_Index1,rsmd6);
								String[] Split_Cnt_Org = Org_Bef_Aft_Cnt.split(":");
								
								//Define the row index for next iteration
								Org_row_Index1 = Integer.parseInt(Split_Cnt_Org[1]) - 1;
								
								Adj_DifferentValues = ITS_Claims_Code.ListAllClaimDetails(ExcelFilePath, "Adj_Indicative", Adj_Bef_Aft_Cnt);
								Org_DifferentValues = ITS_Claims_Code.ListAllClaimDetails(ExcelFilePath, "Org_Indicative", Org_Bef_Aft_Cnt);
								
								ArrayList<String> Temp_Array = new ArrayList<String>();
								ArrayList<String> TotalDifferences = new ArrayList<String>();
								
								//Add data of Adjusted Claim into Array
								TotalDifferences.addAll(Adj_DifferentValues);
								
								//Keep only Differences in the Array - Remove all Similars with Original Claim Data
								TotalDifferences.removeAll(Org_DifferentValues);
								
								//Combine all the Differences into Single Notes
								if(!TotalDifferences.isEmpty()) {
									
									ArrayList<String> ToBeRemoved = new ArrayList<String>();
									ArrayList<String> ToBeAdded = new ArrayList<String>();
									
									for(String EachElement : TotalDifferences) {
										
										//split to seperate Header and Value
										String[] PartialValue_EachDifference = EachElement.split("-");
											
										//Get all Values from Original Claim Data Which matches Expected Header
										ArrayList<String> Org_FetchAllSimilars = new ArrayList<String>();
										for(String Org_EachElement : Org_DifferentValues) {
											
											if(Org_EachElement.contains(PartialValue_EachDifference[0])) {
												Org_FetchAllSimilars.add(Org_EachElement);
											}
											
										}
										
										//Get all Values from Adjusted Claim Data Which matches Expected Header
										ArrayList<String> Adj_FetchAllSimilars = new ArrayList<String>();
										for(String Adj_EachElement : Adj_DifferentValues) {
											
											if(Adj_EachElement.contains(PartialValue_EachDifference[0])) {
												Adj_FetchAllSimilars.add(Adj_EachElement);
												
											}
											
										}
										
										//Check if similars exist in Original Claim then Create notes accordingly
										if(!Org_FetchAllSimilars.isEmpty()) {
											
											if(PartialValue_EachDifference[1].equals("Null")) {
												
												//ToBeAdded.add("REMOVING "+EachElement);
												ToBeRemoved.add(EachElement);
												ToBeAdded.add("REMOVING "+PartialValue_EachDifference[0].trim());
											
											}else if(Adj_FetchAllSimilars.size() == Org_FetchAllSimilars.size()){
												
												String Null_Exist = "False";
												for(String Org_NullValue:Org_FetchAllSimilars) {
													
													if(Org_NullValue.contains("Null")) {
														Null_Exist = "True";
													}
													
												}
												
												if(Null_Exist.equals("True")) {
													
													//ToBeAdded.add("ADDING "+EachElement);
													ToBeRemoved.add(EachElement);
													ToBeAdded.add("ADDING "+PartialValue_EachDifference[0].trim());
												}else {
													
													//ToBeAdded.add("CORRECTING "+EachElement);
													ToBeRemoved.add(EachElement);
													ToBeAdded.add("CORRECTING "+PartialValue_EachDifference[0].trim());
												}
											
											}else {
												
												//ToBeAdded.add("ADDING "+EachElement);
												ToBeRemoved.add(EachElement);
												ToBeAdded.add("ADDING "+PartialValue_EachDifference[0].trim());
												
											}
											
										}
										
									}
									
									//Add different values into array
									Temp_Array.addAll(ToBeAdded);
									
									//Remove above values from main array
									TotalDifferences.removeAll(ToBeRemoved);
									
								}
								
								//Remove Duplicates and Add Notes
								if(!Temp_Array.isEmpty()) {
									
									for(String NoDuplicates : Temp_Array) {
										
										if(TotalDifferences.isEmpty()) {
											TotalDifferences.add(NoDuplicates);
										}else {
											if(!TotalDifferences.contains(NoDuplicates)) {
												TotalDifferences.add(NoDuplicates);
											}
										}
										
									}
									
								}
								
								//Reporter statement
								if(ClaimID == FilteredClaims_BillProv.size()-1) {
									TextFileUtilities.Log("Indicative screen details comparision is completed for Professional Claims", "DONE");
								}
								
								//row_Index1 = NextRow2-1;
								//Org_row_Index1 = Org_NextRow2 - 1;
								
								File src = new File(ExcelFilePath);
								FileInputStream FIS = new FileInputStream(src);
								Workbook workbook = new XSSFWorkbook(FIS);
								
								//Write Indicative Notes into Indicative Result Sheet
								if(ClaimID==0) {
									workbook.createSheet("CompResult_Indicative");
									Row row_head = workbook.getSheet("CompResult_Indicative").createRow(0);
									
									Cell col_head = row_head.createCell(0);
									col_head.setCellValue("Claim ID");
									
									Cell col_head1 = row_head.createCell(1);
									col_head1.setCellValue("Notes");
									
								}
								
								
								Row row = workbook.getSheet("CompResult_Indicative").createRow(ClaimID+1);
								Cell cell_ClaimID = row.createCell(0);
								Cell cell_Notes = row.createCell(1);
								
								cell_ClaimID.setCellValue(List_ClaimID_Corrected);
								
								//Enter Notes
								if(!TotalDifferences.isEmpty()) {
									
									for (String eachRow : TotalDifferences) {
						            	
						            	if (All=="") {
						            		All = eachRow;
						            	}else {
						            		All = All+", "+eachRow;
						            	}
						            	
						            	//System.out.println(All);
						            }
									
									//Enter Notes into Indicative Comparision Result Sheet
									if (All!="") {
										cell_Notes.setCellValue(All+",");
										IndNotes_Txt.put(List_ClaimID_Corrected, All);
									}
									
								}
								
								FileOutputStream fout = new FileOutputStream(src);
			                    workbook.write(fout);
			                    fout.flush();
			               		fout.close();
								
							} catch (Exception e) {
								
								e.printStackTrace();
							}
							
						}
						
						TextFileUtilities.Log("Updated the Professional sheet with Notes generated from Indicative screen Details comparision", "DONE");
						
						//Line_Items Query
						for(int ClaimID=0; ClaimID <= FilteredClaims_BillProv.size()-1; ClaimID++) {
							
							String Partial_Text4 = "Line_Items";
							String QueryFile_LineItems;
							String All = "";
							
							Map<String,ArrayList<String>> Adj_DifferentValues = new HashMap<String, ArrayList<String>>();
							Map<String,ArrayList<String>> Org_DifferentValues = new HashMap<String, ArrayList<String>>();
							
							List_ClaimID_Corrected = FilteredClaims_BillProv.get(ClaimID);
							
							//Get the Original claim id
							if (!(List_ClaimID_Corrected.endsWith("00"))) {
								List_ClaimID_Original = List_ClaimID_Corrected.substring(0, List_ClaimID_Corrected.length() - 2)+"00"; 
							}
							
							//Get Query Output for Line Items Screen
							try {
								
								QueryFile_LineItems = ITS_Claims_Code.listFilesForFolder(Partial_Text4);
								
								String LineItems_Query1 = re.TextFilename(Environment.get("config_path")+"/"+QueryFile_LineItems+".txt").replace("REPLACE_VALUE", List_ClaimID_Corrected);
								String LineItems_Query2 = re.TextFilename(Environment.get("config_path")+"/"+QueryFile_LineItems+".txt").replace("REPLACE_VALUE", List_ClaimID_Original);
								
								//Line Items Result set
								ResultSet rs7= ConfigValidation.Database(PreMove, LineItems_Query1);
								ResultSet rs8= ConfigValidation.Database(PreMove, LineItems_Query2);
								
								//Resultset Meta data
								ResultSetMetaData rsmd7 = ConfigValidation.getResultSetMetaData(PreMove,rs7);
								ResultSetMetaData rsmd8 = ConfigValidation.getResultSetMetaData(PreMove,rs8);
								
								//Adjusted Claims
								String Adj_Bef_Aft_Cnt = ITS_Claims_Code.WriteToExcel(ExcelFilePath,"Adj_LineItems",rs7,row_Index2,rsmd7);
								String[] Split_Cnt1 = Adj_Bef_Aft_Cnt.split(":");
								int NextRow3 = Integer.parseInt(Split_Cnt1[1]);  
								row_Index2 = NextRow3 - 1;
								
								//Original - check
								String Org_Bef_Aft_Cnt = ITS_Claims_Code.WriteToExcel(ExcelFilePath,"Org_LineItems",rs8,Org_row_Index2,rsmd8);
								String[] Split_Cnt2 = Org_Bef_Aft_Cnt.split(":");
								int Org_NextRow3 = Integer.parseInt(Split_Cnt2[1]);
								Org_row_Index2 = Org_NextRow3 - 1;
								
								Adj_DifferentValues = ITS_Claims_Code.LineItemDifferences(ExcelFilePath, "Adj_LineItems", Adj_Bef_Aft_Cnt);
								Org_DifferentValues = ITS_Claims_Code.LineItemDifferences(ExcelFilePath, "Org_LineItems", Org_Bef_Aft_Cnt);
								
								//Hashmap Iteration - Create Notes for [Add, Remove, Correct] Scenarios
								ArrayList<String> Adj_LineItemValues = new ArrayList<String>();
								ArrayList<String> Org_LineItemValues = new ArrayList<String>();
								ArrayList<String> Temp_Array = new ArrayList<String>();
								ArrayList<String> TotalDifferences = new ArrayList<String>();
								
								float Adj_TotalCharge = 0;
								float Org_TotalCharge = 0;
								
								for(String Key : Adj_DifferentValues.keySet()) {
									
									Adj_LineItemValues = Adj_DifferentValues.get(Key);
									
									ArrayList<String> ToBeRemoved = new ArrayList<String>();
									ArrayList<String> ToBeAdded = new ArrayList<String>();
									
									//Removing CPT code scenario
									if(Org_DifferentValues.keySet().size() > Adj_DifferentValues.keySet().size()) {
										
										ToBeAdded.add("REMOVING ProcedureCode");
										ToBeAdded.add("CORRECTING Charges");
										
										Temp_Array.addAll(ToBeAdded);
										
									}
									
									if(Org_DifferentValues.containsKey(Key)) {
										
										Org_LineItemValues = Org_DifferentValues.get(Key);
										
										//Add Listed Differences into Another Array
										for(String RemoveUnwantedCol : Adj_LineItemValues) {
											
											String[] HeaderValue = RemoveUnwantedCol.split("-");
											
											//Skip TOS and SCCFNum
											if(!(HeaderValue[0].equals("TOS") || HeaderValue[0].equals("SCCFNum"))) {
												TotalDifferences.add(RemoveUnwantedCol);
											}
											
										}
										
										//TotalDifferences.addAll(Adj_LineItemValues);
										TotalDifferences.removeAll(Org_LineItemValues);
										
										if(!TotalDifferences.isEmpty()) {
											
											//Compare Total Charges for Adjusted and Original Claim
											
											//Get the Charges - Adjusted
											String[] Individual_Charge;
											for (ArrayList<String> Adj_Collection_Values : Adj_DifferentValues.values()) {
								            	
												for(String Adj_Value: Adj_Collection_Values) {
													
													if(Adj_Value.contains("Charges")) {
														Individual_Charge = Adj_Value.split("-");
														Adj_TotalCharge = Adj_TotalCharge+(float) Double.parseDouble(Individual_Charge[1]);;
													}
													
												}
								            	
								            }
											//System.out.println(Adj_TotalCharge);
											
											//Get the Charges - Original
											String[] Individual_Charge_Org;
											//Org_TotalCharge = 0;
											for (ArrayList<String> Org_Collection_Values : Org_DifferentValues.values()) {
								            	
												for(String Org_Value : Org_Collection_Values) {
													
													if(Org_Value.contains("Charges")) {
														Individual_Charge_Org = Org_Value.split("-");
														Org_TotalCharge = Org_TotalCharge+(float) Double.parseDouble(Individual_Charge_Org[1]);;
													}
													
												}
								            	
								            }
											
											//System.out.println(Org_TotalCharge);
											
											//ArrayList<String> ToBeRemoved = new ArrayList<String>();
											//ArrayList<String> ToBeAdded = new ArrayList<String>();
											
											for(String EachElement : TotalDifferences) {
												
												String[] PartialValue_EachDifference = EachElement.split("-");
												
												//Add Org Values into an array which matches Expected Header
												ArrayList<String> Org_FetchAllSimilars = new ArrayList<String>();
												for(String Org_EachElement : Org_LineItemValues) {
													
													if(Org_EachElement.contains(PartialValue_EachDifference[0])) {
														Org_FetchAllSimilars.add(Org_EachElement);
													}
													
												}
												
												//Add Adj Values into an array which matches Expected Header
												ArrayList<String> Adj_FetchAllSimilars = new ArrayList<String>();
												for(String Adj_EachElement : Adj_LineItemValues) {
													
													if(Adj_EachElement.contains(PartialValue_EachDifference[0])) {
														Adj_FetchAllSimilars.add(Adj_EachElement);
													}
													
												}
												
												//Check if similars exist in Original Claim
												if(!Org_FetchAllSimilars.isEmpty()) {
													
													if(PartialValue_EachDifference[1].equals("Null")) {
														
														if(!EachElement.contains("SequenceNo")) {
															ToBeRemoved.add(EachElement);
															//ToBeAdded.add("REMOVING "+EachElement);
															
															String CheckCol = PartialValue_EachDifference[0].trim();
															if(CheckCol.equals("ProcModifier2") || CheckCol.equals("ProcModifier3") || CheckCol.equals("ProcModifier4") ) {
																ToBeAdded.add("REMOVING Modifier");
															}else if(CheckCol.equals("DiagPointer2") || CheckCol.equals("DiagPointer3") || CheckCol.equals("DiagPointer4") || CheckCol.equals("DiagPointer5") || CheckCol.equals("DiagPointer6") || CheckCol.equals("DiagPointer7") || CheckCol.equals("DiagPointer8")) {
																ToBeAdded.add("REMOVING DiagPointer");
															}else {
																ToBeAdded.add("REMOVING "+PartialValue_EachDifference[0].trim());
															}
															
														}
													
													}else if(Adj_FetchAllSimilars.size() == Org_FetchAllSimilars.size() && PartialValue_EachDifference[0].contains("ProcedureCode")){
														
														//Removing/Adding Modifier Notes
															
														//Create Notes for Removing Modifier in Procedure Code Column
														for(String Org_Mod : Org_FetchAllSimilars) {
															
															String[] SplitProcCode = Org_Mod.split("-");
															if(SplitProcCode[1].length() == PartialValue_EachDifference[1].length()+2) {
																//Remove_Mod = Remove_Mod + 1;
																
																if(SplitProcCode[1].startsWith(PartialValue_EachDifference[1])) {
																	ToBeRemoved.add(EachElement);
																	ToBeAdded.add("REMOVING Modifier");
																	//ToBeAdded.add("REMOVING Modifier-"+SplitProcCode[1].substring(PartialValue_EachDifference[1].length()));
																}
																
															}else if(PartialValue_EachDifference[1].length() == SplitProcCode[1].length()+2) {
																
																//Add_Mod = Add_Mod + 1;
																
																if(PartialValue_EachDifference[1].startsWith(SplitProcCode[1])) {
																	ToBeRemoved.add(EachElement);
																	ToBeAdded.add("ADDING Modifier");
																	//ToBeAdded.add("ADDING Modifier-"+PartialValue_EachDifference[1].substring(SplitProcCode[1].length()));
																}
																
															}else {
																
																if(PartialValue_EachDifference[1].length() == SplitProcCode[1].length()) {
																	
																	String str1 = PartialValue_EachDifference[1].substring(0, PartialValue_EachDifference[1].length()-2);
																	String str2 = SplitProcCode[1].substring(0, SplitProcCode[1].length()-2);
																	
																	if(str1.equals(str2)) {
																		ToBeRemoved.add(EachElement);
																		ToBeAdded.add("CORRECTING Modifier");
																	}else {
																		ToBeRemoved.add(EachElement);
																		ToBeAdded.add("CORRECTING ProcedureCode");
																		//ToBeAdded.add("CORRECTING ProcedureCode-"+PartialValue_EachDifference[1]);
																	}
																	
																}
																
															}
															
														}
															
													
													}else if(Adj_FetchAllSimilars.size() == Org_FetchAllSimilars.size()) {
														
														String Null_Exist = "False";
														for(String Org_NullValue:Org_FetchAllSimilars) {
															
															if(Org_NullValue.contains("Null")) {
																Null_Exist = "True";
															}
															
														}
														
														if(Null_Exist.equals("True")) {
															
															if(!EachElement.contains("SequenceNo")) {
																ToBeRemoved.add(EachElement);
																//ToBeAdded.add("ADDING "+EachElement);
																
																String CheckCol = PartialValue_EachDifference[0];
																
																if(CheckCol.equals("ProcModifier2") || CheckCol.equals("ProcModifier3") || CheckCol.equals("ProcModifier4") ) {
																	//ToBeAdded.add("ADDING "+PartialValue_EachDifference[0]);
																	ToBeAdded.add("ADDING Modifier");
																}else if(CheckCol.equals("DiagPointer2") || CheckCol.equals("DiagPointer3") || CheckCol.equals("DiagPointer4") || CheckCol.equals("DiagPointer5") || CheckCol.equals("DiagPointer6") || CheckCol.equals("DiagPointer7") || CheckCol.equals("DiagPointer8")) {
																	ToBeAdded.add("ADDING DiagPointer");
																}else {
																	ToBeAdded.add("ADDING "+PartialValue_EachDifference[0]);
																}
																
															}
															
														}else {
															
															if(!EachElement.contains("SequenceNo")) {
																ToBeRemoved.add(EachElement);
																//ToBeAdded.add("CORRECTING "+EachElement);
																
																String CheckCol = PartialValue_EachDifference[0].trim();
																if(CheckCol.equals("ProcModifier2") || CheckCol.equals("ProcModifier3") || CheckCol.equals("ProcModifier4") ) {
																	ToBeAdded.add("CORRECTING Modifier");
																}else if(CheckCol.equals("DiagPointer2") || CheckCol.equals("DiagPointer3") || CheckCol.equals("DiagPointer4") || CheckCol.equals("DiagPointer5") || CheckCol.equals("DiagPointer6") || CheckCol.equals("DiagPointer7") || CheckCol.equals("DiagPointer8")) {
																	ToBeAdded.add("CORRECTING DiagPointer");
																}else {
																	ToBeAdded.add("CORRECTING "+PartialValue_EachDifference[0]);
																}
																
															}
															
														}
														
													}else {
														
														if(!EachElement.contains("SequenceNo")) {
															ToBeRemoved.add(EachElement);
															//ToBeAdded.add("ADDING "+EachElement);
															
															String CheckCol = PartialValue_EachDifference[0];
															
															if(CheckCol.equals("ProcModifier2") || CheckCol.equals("ProcModifier3") || CheckCol.equals("ProcModifier4")) {
																//ToBeAdded.add("ADDING "+PartialValue_EachDifference[0]);
																ToBeAdded.add("ADDING Modifier");
															}else if(CheckCol.equals("DiagPointer2") || CheckCol.equals("DiagPointer3") || CheckCol.equals("DiagPointer4") || CheckCol.equals("DiagPointer5") || CheckCol.equals("DiagPointer6") || CheckCol.equals("DiagPointer7") || CheckCol.equals("DiagPointer8")) {
																ToBeAdded.add("ADDING DiagPointer");
															}else {
																ToBeAdded.add("ADDING "+PartialValue_EachDifference[0]);
															}
															
														}
														
													}
													
												}
												
											}
											
											Temp_Array.addAll(ToBeAdded);
											TotalDifferences.removeAll(ToBeRemoved);
											
										}
										
									}else {
										
										//Extra Lines in Adj Claim - Create Notes as Adding
										for(String Adj_ExtraLines : Adj_LineItemValues) {
											
											String[] ColumnValue = Adj_ExtraLines.split("-");
											String ColumnName = ColumnValue[0].trim();
											
											if(Adj_ExtraLines.contains("ProcedureCode")||Adj_ExtraLines.contains("Charges")) {
												
												if(ColumnName.equals("Charges")) {
													ColumnName = "ChargeAmount";
												}
												
												Temp_Array.add("ADDING "+ColumnName);
												
											}
											
										}
										
									}
									
								}
								
								//Remove Duplicates and Add notes into array
								for(String NoDuplicates : Temp_Array) {
									
									if(TotalDifferences.isEmpty()) {
										TotalDifferences.add(NoDuplicates);
									}else {
										if(!TotalDifferences.contains(NoDuplicates)) {
											TotalDifferences.add(NoDuplicates);
										}
									}
									
								}
								
								//Reporter statement
								if(ClaimID == FilteredClaims_BillProv.size()-1) {
									TextFileUtilities.Log("LineItem screen vaidation is completed for Professional claims", "DONE");
								}
								
								//row_Index2 = NextRow3 - 1;
								//Org_row_Index2 = Org_NextRow3 - 1;
								
								File src = new File(ExcelFilePath);
								FileInputStream FIS = new FileInputStream(src);
								@SuppressWarnings("resource")
								Workbook workbook = new XSSFWorkbook(FIS);
								
								if(ClaimID==0) {
									workbook.createSheet("CompResult_LineItems");
									Row row_head = workbook.getSheet("CompResult_LineItems").createRow(0);
									
									Cell col_head = row_head.createCell(0);
									col_head.setCellValue("Claim ID");
									
									Cell col_head1 = row_head.createCell(1);
									col_head1.setCellValue("Notes");
									
									Cell combined_Notes = row_head.createCell(2);
									combined_Notes.setCellValue("Combined_Notes");
									
									
								}
								
								Row row = workbook.getSheet("CompResult_LineItems").createRow(ClaimID+1);
								Cell cell_ClaimID = row.createCell(0);
								Cell cell_Notes = row.createCell(1);
								Cell cell_combNotes = row.createCell(2);
								
								cell_ClaimID.setCellValue(List_ClaimID_Corrected);
								
								//Enter LineItem Notes
								if(!TotalDifferences.isEmpty()) {
									
									for (String eachRow : TotalDifferences) {
						            	
										if(Adj_TotalCharge>0 || Org_TotalCharge>0) {
											
											if(!(eachRow.contains("Charges"))) {
												
												if (All=="") {
								            		All = eachRow;
								            	}else {
								            		All = All+", "+eachRow;
								            	}
												
											}
											
										}else {
											
											if (All=="") {
							            		All = eachRow;
							            	}else {
							            		All = All+", "+eachRow;
							            	}
											
										}
										
						            	
						            	//System.out.println(All);
						            }
									
									//Compare Total Charges
									if(Adj_TotalCharge>0 || Org_TotalCharge>0) {
										
										if(!(Adj_TotalCharge==Org_TotalCharge)) {
											
											if (All!="") {
												//All = "CORRECTING Total Charges-" + Adj_TotalCharge + ", " + All;
												All = "CORRECTING Total Charges" + ", " + All;
												cell_Notes.setCellValue(All);
												
											}else {
												All = "CORRECTING Total Charges";
												cell_Notes.setCellValue(All);
											}
											
										}else {
											
											if (All!="") {
												cell_Notes.setCellValue(All);
											}
											
										}
										
									}else {
										
										if (All!="") {
											cell_Notes.setCellValue(All);
										}
										
									}
									
								}
								
								//Combine Indicative Notes with Line Item Notes
								String Ind_Line_Notes =  IndNotes_Txt.get(List_ClaimID_Corrected);
								
								String ReturnValue_Combine = "";
								
								if(All!="" && Ind_Line_Notes!=null) {
									
									String temp = Ind_Line_Notes+", "+All;
									String[] Full_Notes = temp.split(",");
									
									if(Full_Notes.length > 1) {
										ReturnValue_Combine = Readexcel.CategorizeNotes(ExcelFilePath,temp,ClaimID,Ind_Line_Notes,All);
										cell_combNotes.setCellValue(ReturnValue_Combine);
									}else {
										cell_combNotes.setCellValue(Ind_Line_Notes+", "+All);
									}
									
									
								}else if(All!=""&&Ind_Line_Notes==null) {
									
									String temp = All;
									String[] Full_Notes = temp.split(",");
									
									if(Full_Notes.length > 1) {
										ReturnValue_Combine = Readexcel.CategorizeNotes(ExcelFilePath,temp,ClaimID,Ind_Line_Notes,All);
										cell_combNotes.setCellValue(ReturnValue_Combine);
									}else {
										cell_combNotes.setCellValue(All);
									}
									
									
								}else {
									
									if(!(Ind_Line_Notes==null)) {
										
										String temp = Ind_Line_Notes;
										String[] Full_Notes = temp.split(",");
										
										if(Full_Notes.length > 1) {
											ReturnValue_Combine = Readexcel.CategorizeNotes(ExcelFilePath,temp,ClaimID,Ind_Line_Notes,All);
											cell_combNotes.setCellValue(ReturnValue_Combine);
										}else {
											cell_combNotes.setCellValue(Ind_Line_Notes);
										}
										
									}
									
								}
								
								FileOutputStream fout = new FileOutputStream(src);
			                    workbook.write(fout);
			                    fout.flush();
			               		fout.close();
								
							} catch (Exception e) {
								e.printStackTrace();
							}
							
						}
						
						TextFileUtilities.Log("Updated the Professional sheet with Notes generated from LineItem screen Details comparision", "DONE");
						
					}else {
						TextFileUtilities.Log("Filtered Claims From Billing Provider Query is Empty - Skipping Indicative, Line Item Screen Validation for Professional Claims", "DONE");
						Prof_BillProvFiltered_Claims = "True";
					}
					
				}else {
					TextFileUtilities.Log("Filtered Claims from comparison results of Subscriber/Mem/Provider Query is empty - Skipping Billing Provider, Line Items, Indicative Screen Validation for Professional Claims", "DONE");
					Prof_SubFiltered_Claims = "True";
				}
				
			}else {
				TextFileUtilities.Log("Professional Claims are not available in the Test Data Sheet", "DONE");
				Blank_ProfClaims = "True";
			}

////////////////////////////////////////Institutional Claims/////////////////////////////////////////////////		
			
			String Insti_ComparisionSheet = "Insti_MemberDetailsComparision.xlsx";
			String ExcelFilePath_Insti = File_Path +"\\"+Insti_ComparisionSheet;
			//Validate if Institutional claims exist in Test Data Sheet
			if(!ClaimIds_Insti.isEmpty()) {
				
				TextFileUtilities.Log("Removed Duplicates and Listed Institutional claims into Array", "DONE");
				
				ArrayList<String> Insti_FilteredClaims_SubMemProv = new ArrayList<String>();
				rowIndex = 0;
				
				XSSFWorkbook wb_Insti = new XSSFWorkbook();   
		        OutputStream fileOut_Insti = new FileOutputStream(ExcelFilePath_Insti); 
		        wb_Insti.createSheet("Adj_Sub_Mem_Prov");
		        wb_Insti.write(fileOut_Insti);
		        wb_Insti.close();
		        
		        //Institutional Claims
				for(int ClaimID=0; ClaimID <= ClaimIds_Insti.size()-1; ClaimID++) {
					
					List_ClaimID_Corrected = ClaimIds_Insti.get(ClaimID);
					
					//Get the Original claim id
					if (!(List_ClaimID_Corrected.endsWith("00"))) {
						List_ClaimID_Original = List_ClaimID_Corrected.substring(0, List_ClaimID_Corrected.length() - 2)+"00"; 
					}
					
					//Input Claim ID in the Query
						
					// Subscriber, Member, Provider info query
					String Partial_Text1 = "INSTI_Sub_Mem_Prov_Info";
					String QueryFile_MemInfo;
					try {
						QueryFile_MemInfo = ITS_Claims_Code.listFilesForFolder(Partial_Text1);
						
						String Adj_SubInfo_Query = re.TextFilename(Environment.get("config_path")+"/"+QueryFile_MemInfo+".txt").replace("REPLACE_VALUE", List_ClaimID_Corrected);
						String Org_SubInfo_Query = re.TextFilename(Environment.get("config_path")+"/"+QueryFile_MemInfo+".txt").replace("REPLACE_VALUE", List_ClaimID_Original);
						
						// Subscriber, Member, Provider info Result set
						ResultSet rs1 = ConfigValidation.Database(PreMove, Adj_SubInfo_Query); //Corrected claims data
						ResultSet rs2 = ConfigValidation.Database(PreMove, Org_SubInfo_Query); //Original Claims data
						
						//Resultset Meta data
						ResultSetMetaData rsmd1 = ConfigValidation.getResultSetMetaData(PreMove,rs1);
						ResultSetMetaData rsmd2 = ConfigValidation.getResultSetMetaData(PreMove,rs2);
						
						//Write DB output to Newly Created excel - Sub-Mem-Prov info
						int NextRow = Integer.parseInt(ITS_Claims_Code.WriteToExcel(ExcelFilePath_Insti,"Adj_Sub_Mem_Prov",rs1,rowIndex,rsmd1)); 
						ITS_Claims_Code.WriteToExcel(ExcelFilePath_Insti,"Org_Sub_Mem_Prov",rs2,rowIndex,rsmd2);
						ITS_Claims_Code.WriteToExcel(ExcelFilePath_Insti,"Comp_Result_Sub_Mem_Prov",rs1,rowIndex,rsmd1);
						
						//Below Line is to Write DB output in Excel based on Rows of Previous Claim
						rowIndex = NextRow-1;
						
						//TextFileUtilities.Log(PreMove, SheetName);
						
					} catch (Exception e) {
						e.printStackTrace();
					}
					
				}
				
				re.setComparevalues(ExcelFilePath_Insti, "Adj_Sub_Mem_Prov","Org_Sub_Mem_Prov","Comp_Result_Sub_Mem_Prov");
				Insti_FilteredClaims_SubMemProv = Readexcel.ReadResultSheet(ExcelFilePath_Insti, "Adj_Sub_Mem_Prov", "Comp_Result_Sub_Mem_Prov",ClaimIds_Insti);
				//System.out.println("Insti Filtered Claims "+Insti_FilteredClaims_SubMemProv);
				TextFileUtilities.Log("Subscriber_Member details comparision is completed for Institutional Claims", "PASS");
				
				// Write Notes for Institutional Claims into Test Data Sheet - Sub_Mem_Provider
				String Claim_ID = null;
				String Notes_txt = null;
				
				HashMap<String, String> Insti_Sub_Mem_Provider_Notes = new HashMap<String, String>();
				
				FileInputStream Insti_File = new FileInputStream(ExcelFilePath_Insti);
				XSSFWorkbook Insti_wbook = new XSSFWorkbook(Insti_File);
				Sheet Insti_sheet = Insti_wbook.getSheet("Comp_Result_Sub_Mem_Prov");
				
				//Get the Notes from Comparison Result Sheet and Store it in Hashmap with Key as Claim ID
				for(int Value = 1; Value <= Insti_sheet.getPhysicalNumberOfRows()-1; Value++) {
					
					Row row = Insti_sheet.getRow(Value);
					Cell ClaimID = row.getCell(0);
					Cell Insti_Notes_SubMem = row.getCell(row.getPhysicalNumberOfCells()-1);
					
					//Get Claim ID
					switch (evaluator.evaluateInCell(ClaimID).getCellType()) {
					  
					  case Cell.CELL_TYPE_STRING: 
						  
						  Claim_ID = ClaimID.getStringCellValue();
						  //System.out.println(Claim_ID);
						  break;
						  
					}
					
					//Get Notes
					switch (evaluator.evaluateInCell(Insti_Notes_SubMem).getCellType()) {
					  
					  case Cell.CELL_TYPE_STRING: 
						  
						  Notes_txt = Insti_Notes_SubMem.getStringCellValue();
						  //System.out.println(Claim_ID);
						  break;
						  
					}
					
					
					//Combine ClaimID and Notes
					if(!(Claim_ID.equals(null))&&!(Notes_txt.equals(null))) {
						Insti_Sub_Mem_Provider_Notes.put(Claim_ID,Notes_txt);
					}
					
				}
				
				Insti_wbook.close();
				
				//Write the Notes to Test Data Sheet after Fetching From Comparison Result Sheet
				//FileInputStream fis4 = new FileInputStream(Testdata_File); 
				//wbook_1 = new XSSFWorkbook(fis4);
				// Sheet sheet4 = wbook_1.getSheetAt(0); 
				//Row Header_Row = sheet4.getRow(0);
				
				
				//Variable Declaration
				String Header = "";
				String Notes = null;
				int Col_Count = 0;
				
				for(int Value = 1; Value<=TestData_Rowcount-1; Value++) {
					
					Claim_ID = "";
					
					if(Value==0) {
						
						//Get the Last Column Name and Check if Notes Column Exist
						Cell Prev_Notes = Head_Row.getCell(Head_Row.getPhysicalNumberOfCells()-1);
						
						//Get Claim ID
						switch (evaluator.evaluateInCell(Prev_Notes).getCellType()) {
						  
						  case Cell.CELL_TYPE_STRING: 
							  
							  Header = Prev_Notes.getStringCellValue();
							  //System.out.println(Claim_ID);
							  break;
							  
						}
						
						//If Notes Column Already Exists, Rewrite else Create New Column
						if(Header.equals("Notes")) {
							
							Col_Count = Head_Row.getPhysicalNumberOfCells()-1;
							
						}else {
							Col_Count = Head_Row.getPhysicalNumberOfCells();
							//Cell Notes_Header = Head_Row.createCell(Col_Count);
							//Notes_Header.setCellValue("Notes");
						}
						
					}
					
					Row row = sheet.getRow(Value);
					Cell ClaimID = row.getCell(ClaimID_Column);
					
					//Get Claim ID
					switch (evaluator.evaluateInCell(ClaimID).getCellType()) {
					  
					  case Cell.CELL_TYPE_STRING: 
						  
						  Claim_ID = ClaimID.getStringCellValue();
						  //System.out.println(Claim_ID);
						  break;
						  
					}
					
					//Enter Notes to Test Data Sheet
					if(Insti_Sub_Mem_Provider_Notes.containsKey(Claim_ID)) {
						
						Notes = Insti_Sub_Mem_Provider_Notes.get(Claim_ID);
						Cell Notes_Txt = row.createCell(Notes_column_Value);
						Notes_Txt.setCellValue(Notes);
						
					}
					
				}
				
				TextFileUtilities.Log("Updated the Testdata sheet with Notes generated from Subscriber_Member details comparision", "DONE");
				
				//FileOutputStream fout_Notes = new FileOutputStream(Testdata_File);
				//wbook4.write(fout_Notes); 
				//wbook_1.write(fout_Notes); 
				//fout_Notes.flush(); 
				//fout_Notes.close(); 
				//Insti_wbook.close();
				//wbook_1.close();
				//wb_Insti.close();
				
				//Validate Indicative Screen if Filtered Claims are not Empty
				if(!Insti_FilteredClaims_SubMemProv.isEmpty()) {
					
					//Indicative Query [Institutional] - Iterate through list of Filtered Claims
					HashMap<String, String> Insti_IndNotes_Txt = new HashMap<String, String>();
					row_Index1 = 0;
					Org_row_Index1 = 0;
					
					//ArrayList<String> Insti_Row_Data = new ArrayList<String>();
					
					for(int ClaimID = 0; ClaimID <= Insti_FilteredClaims_SubMemProv.size()-1; ClaimID++) {
						
						String Partial_Text3 = "INSTI_Indicative";
						String QueryFile_Indicative;
						String All = "";
						
						ArrayList<String> Adj_DifferentValues = new ArrayList<String>();
						ArrayList<String> Org_DifferentValues = new ArrayList<String>();
						
						List_ClaimID_Corrected = Insti_FilteredClaims_SubMemProv.get(ClaimID);
						
						//Get the Original claim id
						if (!(List_ClaimID_Corrected.endsWith("00"))) {
							List_ClaimID_Original = List_ClaimID_Corrected.substring(0, List_ClaimID_Corrected.length() - 2)+"00";
						}
						
						try {
							
							QueryFile_Indicative = ITS_Claims_Code.listFilesForFolder(Partial_Text3);
							
							String Indicative_Query1 = re.TextFilename(Environment.get("config_path")+"/"+QueryFile_Indicative+".txt").replace("REPLACE_VALUE", List_ClaimID_Corrected);
							String Indicative_Query2 = re.TextFilename(Environment.get("config_path")+"/"+QueryFile_Indicative+".txt").replace("REPLACE_VALUE", List_ClaimID_Original);
							
							//Indicative screen Result set
							ResultSet rs5= ConfigValidation.Database(PreMove, Indicative_Query1);
							ResultSet rs6= ConfigValidation.Database(PreMove, Indicative_Query2);
							
							//Resultset Meta data
							ResultSetMetaData rsmd5 = ConfigValidation.getResultSetMetaData(PreMove,rs5);
							ResultSetMetaData rsmd6 = ConfigValidation.getResultSetMetaData(PreMove,rs6);
							
							//Adjusted Claims - Get Before and After Count
							String Adj_Bef_Aft_Cnt = ITS_Claims_Code.WriteToExcel(ExcelFilePath_Insti,"Adj_Indicative",rs5,row_Index1,rsmd5);
							String[] Split_Cnt_Adj = Adj_Bef_Aft_Cnt.split(":");
							int NextRow2 = Integer.parseInt(Split_Cnt_Adj[1]);  
							row_Index1 = NextRow2-1;
							
							//Original claims - Get Before and After Count
							String Org_Bef_Aft_Cnt = ITS_Claims_Code.WriteToExcel(ExcelFilePath_Insti,"Org_Indicative",rs6,Org_row_Index1,rsmd6);
							String[] Split_Cnt_Org = Org_Bef_Aft_Cnt.split(":");
							int Org_NextRow2 = Integer.parseInt(Split_Cnt_Org[1]);  
							Org_row_Index1 = Org_NextRow2 - 1;
							
							//Combine Count of Rows for Adj and Org Claims 
							//String Iteration_Count = Adj_Bef_Aft_Cnt+"-"+Org_Bef_Aft_Cnt;
							
							//Insti_Row_Data.add(Iteration_Count);
							
							Adj_DifferentValues = ITS_Claims_Code.ListAllClaimDetails(ExcelFilePath_Insti, "Adj_Indicative", Adj_Bef_Aft_Cnt);
							Org_DifferentValues = ITS_Claims_Code.ListAllClaimDetails(ExcelFilePath_Insti, "Org_Indicative", Org_Bef_Aft_Cnt);
							
							ArrayList<String> Temp_Array = new ArrayList<String>();
							ArrayList<String> TotalDifferences = new ArrayList<String>();
							
							//Add data of Adjusted Claim into Array
							
							  for(String RequiredCol : Adj_DifferentValues) {
							  
								  String[] ColName = RequiredCol.split("-");
								  
								  //Skip PatAccountNo from Notes 
								  if(!ColName[0].equals("Frequency")) {
									  TotalDifferences.add(RequiredCol); 
								  }
							  }
							
							//TotalDifferences.addAll(Adj_DifferentValues);
							
							//Remove all Similar which matches with Original Claim Data
							TotalDifferences.removeAll(Org_DifferentValues);
							
							//Combine all the Differences into Single Notes
							if(!TotalDifferences.isEmpty()) {
								
								ArrayList<String> ToBeRemoved = new ArrayList<String>();
								ArrayList<String> ToBeAdded = new ArrayList<String>();
								
								for(String EachElement : TotalDifferences) {
									
										
									//Split the Value to get Header and Value
									String[] PartialValue_EachDifference = EachElement.split("-");
									ArrayList<String> Org_FetchAllSimilars = new ArrayList<String>();
									
										
									//Get all Values from Original Claim Data Which matches Expected Header
									for(String Org_EachElement : Org_DifferentValues) {
										
										if(Org_EachElement.contains(PartialValue_EachDifference[0])) {
											Org_FetchAllSimilars.add(Org_EachElement);
										}
										
									}
									
									//Get all Values from Adjusted Claim Data Which matches Expected Header
									ArrayList<String> Adj_FetchAllSimilars = new ArrayList<String>();
									for(String Adj_EachElement : Adj_DifferentValues) {
										
										if(Adj_EachElement.contains(PartialValue_EachDifference[0])) {
											Adj_FetchAllSimilars.add(Adj_EachElement);
											
										}
										
									}
									
									//Check if similars exist in Original Claim then Create notes accordingly
									if(!Org_FetchAllSimilars.isEmpty()) {
										
										if(PartialValue_EachDifference[1].equals("Null")) {
											
											ToBeRemoved.add(EachElement);
											//ToBeAdded.add("REMOVING "+EachElement);
											ToBeAdded.add("REMOVING "+PartialValue_EachDifference[0].trim());
										
										}else if(Adj_FetchAllSimilars.size() == Org_FetchAllSimilars.size()){
											
											String Null_Exist = "False";
											for(String Org_NullValue:Org_FetchAllSimilars) {
												
												if(Org_NullValue.contains("Null")) {
													Null_Exist = "True";
												}
												
											}
											
											if(Null_Exist.equals("True")) {
												
												//ToBeAdded.add("ADDING "+EachElement);
												ToBeRemoved.add(EachElement);
												ToBeAdded.add("ADDING "+PartialValue_EachDifference[0].trim());
											}else {
												//ToBeAdded.add("CORRECTING "+EachElement);
												ToBeRemoved.add(EachElement);
												ToBeAdded.add("CORRECTING "+PartialValue_EachDifference[0].trim());
											}
										
										}else {
											//ToBeAdded.add("ADDING "+EachElement);
											ToBeRemoved.add(EachElement);
											ToBeAdded.add("ADDING "+PartialValue_EachDifference[0].trim());
										}
										
									}
									
								}
								
								Temp_Array.addAll(ToBeAdded);
								TotalDifferences.removeAll(ToBeRemoved);
								
							}
							
							//Remove Duplicates and Add Notes
							if(!Temp_Array.isEmpty()) {
								
								for(String NoDuplicates : Temp_Array) {
									
									if(TotalDifferences.isEmpty()) {
										TotalDifferences.add(NoDuplicates);
									}else {
										if(!TotalDifferences.contains(NoDuplicates)) {
											TotalDifferences.add(NoDuplicates);
										}
									}
									
								}
								
							}
							
							//Reporter Statement
							if(ClaimID == Insti_FilteredClaims_SubMemProv.size()-1) {
								TextFileUtilities.Log("Indicative screen details comparison is completed for Institutional claims", "DONE");
							}
							
							//row_Index1 = NextRow2-1;
							//Org_row_Index1 = Org_NextRow2 - 1;
							
							File src = new File(ExcelFilePath_Insti);
							FileInputStream FIS = new FileInputStream(src);
							Workbook workbook = new XSSFWorkbook(FIS);
							
							//Write Indicative Notes into Indicative Result Sheet
							if(ClaimID==0) {
								workbook.createSheet("CompResult_Indicative");
								Row row_head = workbook.getSheet("CompResult_Indicative").createRow(0);
								
								Cell col_head = row_head.createCell(0);
								col_head.setCellValue("Claim ID");
								
								Cell col_head1 = row_head.createCell(1);
								col_head1.setCellValue("Notes");
								
							}
							
							
							Row row = workbook.getSheet("CompResult_Indicative").createRow(ClaimID+1);
							Cell cell_ClaimID = row.createCell(0);
							Cell cell_Notes = row.createCell(1);
							
							cell_ClaimID.setCellValue(List_ClaimID_Corrected);
							
							//Enter Notes
							if(!TotalDifferences.isEmpty()) {
								
								for (String eachRow : TotalDifferences) {
					            	
					            	if (All=="") {
					            		All = eachRow;
					            	}else {
					            		All = All+", "+eachRow;
					            	}
					            	
					            	//System.out.println(All);
					            }
								
								if (All!="") {
									cell_Notes.setCellValue(All+",");
									Insti_IndNotes_Txt.put(List_ClaimID_Corrected, All);
								}
								
							}
							
							FileOutputStream fout = new FileOutputStream(src);
		                    workbook.write(fout);
		                    fout.flush();
		               		fout.close();
							
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
					}
					
					TextFileUtilities.Log("Updated the Institutional sheet with Notes generated from Indicative screen Details comparision", "DONE");
					
					//Line_Items Query - Institutional Claims
					//ArrayList<String> Row_Data_LineItems = new ArrayList<String>();
					row_Index2 = 0;
					Org_row_Index2 = 0;
					
					for(int ClaimID=0; ClaimID <= Insti_FilteredClaims_SubMemProv.size()-1; ClaimID++) {
						
						String Partial_Text4 = "INSTI_Line_Items";
						String QueryFile_LineItems;
						String All = "";
						
						Map<String,ArrayList<String>> Adj_DifferentValues = new HashMap<String, ArrayList<String>>();
						Map<String,ArrayList<String>> Org_DifferentValues = new HashMap<String, ArrayList<String>>();
						
						List_ClaimID_Corrected = Insti_FilteredClaims_SubMemProv.get(ClaimID);
						
						//System.out.println(List_ClaimID_Corrected);
						
						//Get the Original claim id
						if (!(List_ClaimID_Corrected.endsWith("00"))) {
							List_ClaimID_Original = List_ClaimID_Corrected.substring(0, List_ClaimID_Corrected.length() - 2)+"00"; 
						}
						
						//Get Query Output for Line Items Screen
						try {
							
							QueryFile_LineItems = ITS_Claims_Code.listFilesForFolder(Partial_Text4);
							
							String LineItems_Query1 = re.TextFilename(Environment.get("config_path")+"/"+QueryFile_LineItems+".txt").replace("REPLACE_VALUE", List_ClaimID_Corrected);
							String LineItems_Query2 = re.TextFilename(Environment.get("config_path")+"/"+QueryFile_LineItems+".txt").replace("REPLACE_VALUE", List_ClaimID_Original);
							
							//Line Items Result set
							ResultSet rs7= ConfigValidation.Database(PreMove, LineItems_Query1);
							ResultSet rs8= ConfigValidation.Database(PreMove, LineItems_Query2);
							
							//Resultset Meta data
							ResultSetMetaData rsmd7 = ConfigValidation.getResultSetMetaData(PreMove,rs7);
							ResultSetMetaData rsmd8 = ConfigValidation.getResultSetMetaData(PreMove,rs8);
							
							//Adjusted Claims
							String Adj_Bef_Aft_Cnt = ITS_Claims_Code.WriteToExcel(ExcelFilePath_Insti,"Adj_LineItems",rs7,row_Index2,rsmd7);
							String[] Split_Cnt1 = Adj_Bef_Aft_Cnt.split(":");
							int NextRow3 = Integer.parseInt(Split_Cnt1[1]);  
							row_Index2 = NextRow3 - 1;
							
							//Original - check
							String Org_Bef_Aft_Cnt = ITS_Claims_Code.WriteToExcel(ExcelFilePath_Insti,"Org_LineItems",rs8,Org_row_Index2,rsmd8);
							String[] Split_Cnt2 = Org_Bef_Aft_Cnt.split(":");
							int Org_NextRow3 = Integer.parseInt(Split_Cnt2[1]);
							Org_row_Index2 = Org_NextRow3 - 1;
							
							//String Iteration_Count = Adj_Bef_Aft_Cnt+"-"+Org_Bef_Aft_Cnt;
							
							//Row_Data_LineItems.add(Iteration_Count);
							
							Adj_DifferentValues = ITS_Claims_Code.LineItemDifferences(ExcelFilePath_Insti, "Adj_LineItems", Adj_Bef_Aft_Cnt);
							Org_DifferentValues = ITS_Claims_Code.LineItemDifferences(ExcelFilePath_Insti, "Org_LineItems", Org_Bef_Aft_Cnt);
							
							//ArrayList<String> ColumnNames = ITS_Claims_Code.GetColumnNames(ExcelFilePath, "Adj_LineItems");
							
							//Hashmap Iteration - Create Notes for [Add, Remove, Correct] Scenarios
							ArrayList<String> Adj_LineItemValues = new ArrayList<String>();
							ArrayList<String> Org_LineItemValues = new ArrayList<String>();
							ArrayList<String> Temp_Array = new ArrayList<String>();
							ArrayList<String> TotalDifferences = new ArrayList<String>();
							
							
							float Adj_TotalCharge = 0;
							float Org_TotalCharge = 0;
							
							for(String Key : Adj_DifferentValues.keySet()) {
								
								ArrayList<String> ToBeRemoved = new ArrayList<String>();
								ArrayList<String> ToBeAdded = new ArrayList<String>();
								
								Adj_LineItemValues = Adj_DifferentValues.get(Key);
								
								//Removing CPT Scenario
								if(Org_DifferentValues.keySet().size() > Adj_DifferentValues.keySet().size()) {
									
									ToBeAdded.add("REMOVING ProcedureCode");
									ToBeAdded.add("CORRECTING Charges");
									
									Temp_Array.addAll(ToBeAdded);
									
								}
								
								if(Org_DifferentValues.containsKey(Key)) {
									
									Org_LineItemValues = Org_DifferentValues.get(Key);
									
									//Add Listed Differences into Another Array
									//TotalDifferences.addAll(Adj_LineItemValues);
									for(String RemoveUnwantedCol : Adj_LineItemValues) {
										
										String[] HeaderValue = RemoveUnwantedCol.split("-");
										
										//Skip Unwanted Fields for Validation
										if(!(HeaderValue[0].trim().equals("TOS") || HeaderValue[0].trim().equals("Charges") || HeaderValue[0].trim().equals("MicroImageID") || HeaderValue[0].trim().equals("SCCFNum"))) {
											TotalDifferences.add(RemoveUnwantedCol);
										}
										
									}
									
									TotalDifferences.removeAll(Org_LineItemValues);
									
									if(!TotalDifferences.isEmpty()) {
										
										//Compare Total Charges for Adjusted and Original Claim
										
										//Get the Charges - Adjusted
										String[] Individual_Charge;
										//Adj_TotalCharge = 0;
										for (ArrayList<String> Adj_Collection_Values : Adj_DifferentValues.values()) {
							            	
											for(String Adj_Value: Adj_Collection_Values) {
												
												if(Adj_Value.contains("Charges")) {
													Individual_Charge = Adj_Value.split("-");
													Adj_TotalCharge = Adj_TotalCharge+(float) Double.parseDouble(Individual_Charge[1]);;
												}
												
											}
							            	
							            }
										//System.out.println(Adj_TotalCharge);
										
										//Get the Charges - Original
										String[] Individual_Charge_Org;
										//Org_TotalCharge = 0;
										for (ArrayList<String> Org_Collection_Values : Org_DifferentValues.values()) {
							            	
											for(String Org_Value : Org_Collection_Values) {
												
												if(Org_Value.contains("Charges")) {
													Individual_Charge_Org = Org_Value.split("-");
													Org_TotalCharge = Org_TotalCharge+(float) Double.parseDouble(Individual_Charge_Org[1]);;
												}
												
											}
							            	
							            }
										
										//System.out.println(Org_TotalCharge);
										
										//ArrayList<String> ToBeRemoved = new ArrayList<String>();
										//ArrayList<String> ToBeAdded = new ArrayList<String>();
										
										for(String EachElement : TotalDifferences) {
											
											String[] PartialValue_EachDifference = EachElement.split("-");
											
											//Add Org Values into an array which matches Expected Header
											ArrayList<String> Org_FetchAllSimilars = new ArrayList<String>();
												
											for(String Org_EachElement : Org_LineItemValues) {
												
												if(Org_EachElement.contains(PartialValue_EachDifference[0])) {
													Org_FetchAllSimilars.add(Org_EachElement);
												}
												
											}
											
											//Add Adj Values into an array which matches Expected Header
											ArrayList<String> Adj_FetchAllSimilars = new ArrayList<String>();
												
											for(String Adj_EachElement : Adj_LineItemValues) {
												
												if(Adj_EachElement.contains(PartialValue_EachDifference[0])) {
													Adj_FetchAllSimilars.add(Adj_EachElement);
												}
												
											}
											
											//Get all similar values from adjusted claim details
											ArrayList<String> AllSimilars_AdjustedClaim = new ArrayList<String>();
											for(ArrayList<String> Adj_ClaimLevelSimilars : Adj_DifferentValues.values()) {
												
												for(String EachSimilar_Adj : Adj_ClaimLevelSimilars) {
													
													if(EachSimilar_Adj.contains(PartialValue_EachDifference[0])) {
														
														if(!AllSimilars_AdjustedClaim.contains(EachSimilar_Adj)) {
															AllSimilars_AdjustedClaim.add(EachSimilar_Adj);
														}
														
													}
													
												}
												
											}
											
											//Get all the Similar Values from Original Claim Details
											ArrayList<String> AllSimilars_OriginalClaim = new ArrayList<String>();
											for(ArrayList<String> Org_ClaimLevelSimilars : Org_DifferentValues.values()) {
												
												for(String EachSimilar_Org : Org_ClaimLevelSimilars) {
													
													if(EachSimilar_Org.contains(PartialValue_EachDifference[0])) {
														
														if(!AllSimilars_OriginalClaim.contains(EachSimilar_Org)) {
															AllSimilars_OriginalClaim.add(EachSimilar_Org);
														}
														
													}
													
												}
												
											}
											
											//Check if similars exist in Original Claim
											if(!Org_FetchAllSimilars.isEmpty()) {
												
												if(PartialValue_EachDifference[1].equals("Null")) {
													
													if(!EachElement.contains("SequenceNo")) {
														ToBeRemoved.add(EachElement);
														//ToBeAdded.add("REMOVING "+EachElement);
														String ColName = PartialValue_EachDifference[0].trim();
														
														if(ColName.equals("ProcModifier2")||ColName.equals("ProcModifier3")||ColName.equals("ProcModifier4")) {
															ToBeAdded.add("REMOVING Modifier");
														}else if(ColName.equals("DiagPointer2")||ColName.equals("DiagPointer3")||ColName.equals("DiagPointer4")||ColName.equals("DiagPointer5")||ColName.equals("DiagPointer6")||ColName.equals("DiagPointer7")||ColName.equals("DiagPointer8")) {
															ToBeAdded.add("REMOVING DiagPointer");
														}else {
															ToBeAdded.add("REMOVING "+PartialValue_EachDifference[0].trim());
														}
														
													}
												
												}else if(Adj_FetchAllSimilars.size()==Org_FetchAllSimilars.size() && PartialValue_EachDifference[0].contains("ProcedureCode")){
													
													//Removing/Adding Modifier Notes
														
													//Create Notes for Removing Modifier in Procedure Code Column
													for(String Org_Mod : Org_FetchAllSimilars) {
														
														String[] SplitProcCode = Org_Mod.split("-");
														if(SplitProcCode[1].length() == PartialValue_EachDifference[1].length()+2) {
															//Remove_Mod = Remove_Mod + 1;
															
															if(SplitProcCode[1].startsWith(PartialValue_EachDifference[1])) {
																//ToBeAdded.add("REMOVING Modifier-"+SplitProcCode[1].substring(PartialValue_EachDifference[1].length()));
																ToBeRemoved.add(EachElement);
																ToBeAdded.add("REMOVING Modifier");
															}
															
														}else if(PartialValue_EachDifference[1].length() == SplitProcCode[1].length()+2) {
															
															//Add_Mod = Add_Mod + 1;
															
															if(PartialValue_EachDifference[1].startsWith(SplitProcCode[1])) {
																//ToBeAdded.add("ADDING Modifier-"+PartialValue_EachDifference[1].substring(SplitProcCode[1].length()));
																ToBeRemoved.add(EachElement);
																ToBeAdded.add("ADDING Modifier");
															}
															
														}else {
															
															if(PartialValue_EachDifference[1].length() == SplitProcCode[1].length()) {
																
																String str1 = PartialValue_EachDifference[1].substring(0, PartialValue_EachDifference[1].length()-2);
																String str2 = SplitProcCode[1].substring(0, SplitProcCode[1].length()-2);
																
																if(str1.equals(str2)) {
																	ToBeRemoved.add(EachElement);
																	ToBeAdded.add("CORRECTING Modifier");
																}else {
																	ToBeRemoved.add(EachElement);
																	ToBeAdded.add("CORRECTING ProcedureCode");
																	//ToBeAdded.add("CORRECTING ProcedureCode-"+PartialValue_EachDifference[1]);
																}
																
															}
															
														}
														
													}
														
												
												}else if(Adj_FetchAllSimilars.size() == Org_FetchAllSimilars.size()) {
													
													String Null_Exist = "False";
													for(String Org_NullValue:Org_FetchAllSimilars) {
														
														if(Org_NullValue.contains("Null")) {
															Null_Exist = "True";
														}
														
													}
													
													if(Null_Exist.equals("True")) {
														
														if(!EachElement.contains("SequenceNo")) {
															ToBeRemoved.add(EachElement);
															//ToBeAdded.add("ADDING "+EachElement);
															
															String ColName = PartialValue_EachDifference[0].trim();
															
															if(ColName.equals("ProcModifier2")||ColName.equals("ProcModifier3")||ColName.equals("ProcModifier4")) {
																ToBeAdded.add("ADDING Modifier");
															}else if(ColName.equals("DiagPointer2")||ColName.equals("DiagPointer3")||ColName.equals("DiagPointer4")||ColName.equals("DiagPointer5")||ColName.equals("DiagPointer6")||ColName.equals("DiagPointer7")||ColName.equals("DiagPointer8")) {
																ToBeAdded.add("ADDING DiagPointer");
															}else {
																ToBeAdded.add("ADDING "+PartialValue_EachDifference[0].trim());
															}
														}
														
													}else {
														
														if(!EachElement.contains("SequenceNo")) {
															ToBeRemoved.add(EachElement);
															//ToBeAdded.add("CORRECTING "+EachElement);
															String ColName = PartialValue_EachDifference[0].trim();
															
															if(ColName.equals("ProcModifier2")||ColName.equals("ProcModifier3")||ColName.equals("ProcModifier4")) {
																ToBeAdded.add("CORRECTING Modifier");
															}else if(ColName.equals("DiagPointer2")||ColName.equals("DiagPointer3")||ColName.equals("DiagPointer4")||ColName.equals("DiagPointer5")||ColName.equals("DiagPointer6")||ColName.equals("DiagPointer7")||ColName.equals("DiagPointer8")) {
																ToBeAdded.add("CORRECTING DiagPointer");
															}else {
																if(!ColName.equals("SCCFNum")) {
																	ToBeAdded.add("CORRECTING "+PartialValue_EachDifference[0].trim());
																}
															}
															
														}
														
													}
													
												}else {
													
													if(!EachElement.contains("SequenceNo")) {
														ToBeRemoved.add(EachElement);
														//ToBeAdded.add("ADDING "+EachElement);
														String Temp_ColName = PartialValue_EachDifference[0].trim();
														if(Temp_ColName.equals("ProcModifier2")||Temp_ColName.equals("ProcModifier3")||Temp_ColName.equals("ProcModifier4")) {
															ToBeAdded.add("ADDING Modifier");
														}else if(Temp_ColName.equals("DiagPointer2")||Temp_ColName.equals("DiagPointer3")||Temp_ColName.equals("DiagPointer4")||Temp_ColName.equals("DiagPointer5")||Temp_ColName.equals("DiagPointer6")||Temp_ColName.equals("DiagPointer7")||Temp_ColName.equals("DiagPointer8")) {
															ToBeAdded.add("ADDING DiagPointer");
														}
														else {
															ToBeAdded.add("ADDING "+PartialValue_EachDifference[0].trim());
														}
														
													}
													
												}
												
											}
											
										}
										
										Temp_Array.addAll(ToBeAdded);
										TotalDifferences.removeAll(ToBeRemoved);
										
									}
									
								}else {
									
									//Extra Lines in Adj Claim - Create Notes as Adding
									for(String Adj_ExtraLines : Adj_LineItemValues) {
										
										String [] ColumnData = Adj_ExtraLines.split("-");
										String ColumnName = ColumnData[0].trim();
										
										//if(!Org_LineItemValues.contains(Adj_ExtraLines)&&Adj_ExtraLines.contains("ProcedureCode")) {
											//Temp_Array.add("ADDING "+ColumnName[0].trim());
										//}
										
										if(Adj_ExtraLines.contains("RevenueCode")||Adj_ExtraLines.contains("ProcedureCode")||Adj_ExtraLines.contains("Charges")) {
											
											if(ColumnName.equals("Charges")) {
												ColumnName = "ChargeAmount";
											}
											Temp_Array.add("ADDING "+ColumnName);
											
										}
										
									}
									
								}
								
							}
							
							//Remove Duplicates and Add notes into array
							for(String NoDuplicates : Temp_Array) {
								
								if(TotalDifferences.isEmpty()) {
									TotalDifferences.add(NoDuplicates);
								}else {
									if(!TotalDifferences.contains(NoDuplicates)) {
										TotalDifferences.add(NoDuplicates);
									}
								}
								
							}
							
							//Reporter Statement
							if(ClaimID == Insti_FilteredClaims_SubMemProv.size()-1) {
								TextFileUtilities.Log("LineItem details comparison is completed for Institutional claims", "DONE");
							}
							
							//row_Index2 = NextRow3 - 1;
							//Org_row_Index2 = Org_NextRow3 - 1;
							
							File src = new File(ExcelFilePath_Insti);
							FileInputStream FIS = new FileInputStream(src);
							@SuppressWarnings("resource")
							Workbook workbook = new XSSFWorkbook(FIS);
							
							if(ClaimID==0) {
								workbook.createSheet("CompResult_LineItems");
								Row row_head = workbook.getSheet("CompResult_LineItems").createRow(0);
								
								Cell col_head = row_head.createCell(0);
								col_head.setCellValue("Claim ID");
								
								Cell col_head1 = row_head.createCell(1);
								col_head1.setCellValue("Notes");
								
								Cell combined_Notes = row_head.createCell(2);
								combined_Notes.setCellValue("Combined_Notes");
								
								
							}
							
							Row row = workbook.getSheet("CompResult_LineItems").createRow(ClaimID+1);
							Cell cell_ClaimID = row.createCell(0);
							Cell cell_Notes = row.createCell(1);
							Cell cell_combNotes = row.createCell(2);
							
							cell_ClaimID.setCellValue(List_ClaimID_Corrected);
							
							//Enter LineItem Notes
							if(!TotalDifferences.isEmpty()) {
								
								for (String eachRow : TotalDifferences) {
									
									if(Adj_TotalCharge > 0 || Org_TotalCharge > 0) {
										
										if(!(eachRow.contains("Charges"))) {
											
											if (All=="") {
							            		All = eachRow;
							            	}else {
							            		All = All+", "+eachRow;
							            	}
											
										}
										
									}else {
										
										if (All=="") {
						            		All = eachRow;
						            	}else {
						            		All = All+", "+eachRow;
						            	}
										
									}
					            	
					            	//System.out.println(All);
					            }
								
								//Compare Total Charges
								if(Adj_TotalCharge > 0 || Org_TotalCharge > 0) {
									
									if(!(Adj_TotalCharge==Org_TotalCharge)) {
										
										if (All!="") {
											//All = "CORRECTING Total Charges-" + Adj_TotalCharge + ", " + All;
											All = "CORRECTING Total Charges" + ", " + All;
											cell_Notes.setCellValue(All);
										}else {
											
											All = "CORRECTING Total Charges";
											cell_Notes.setCellValue(All);
										}
										
									}else {
										
										if (All!="") {
											cell_Notes.setCellValue(All);
										}
										
									}
									
								}else {
									
									if (All!="") {
										cell_Notes.setCellValue(All);
									}
									
								}
								
							}
							
							//Combine Indicative Notes with Line Item Notes
							String Insti_Ind_Line_Notes =  Insti_IndNotes_Txt.get(List_ClaimID_Corrected);
							
							String ReturnValue_Combine = "";
							
							if(All!="" && Insti_Ind_Line_Notes!=null) {
								
								String temp = Insti_Ind_Line_Notes+", "+All;
								String[] Full_Notes = temp.split(",");
								
								if(Full_Notes.length > 1) {
									ReturnValue_Combine = Readexcel.CategorizeNotes(ExcelFilePath_Insti,temp,ClaimID,Insti_Ind_Line_Notes,All);
									cell_combNotes.setCellValue(ReturnValue_Combine);
								}else {
									cell_combNotes.setCellValue(Insti_Ind_Line_Notes+", "+All);
								}
								
								
							}else if(All!=""&&Insti_Ind_Line_Notes==null) {
								
								String temp = All;
								String[] Full_Notes = temp.split(",");
								
								if(Full_Notes.length > 1) {
									ReturnValue_Combine = Readexcel.CategorizeNotes(ExcelFilePath_Insti,temp,ClaimID,Insti_Ind_Line_Notes,All);
									cell_combNotes.setCellValue(ReturnValue_Combine);
								}else {
									cell_combNotes.setCellValue(All);
								}
								
								
							}else {
								
								if(!(Insti_Ind_Line_Notes==null)) {
									
									String temp = Insti_Ind_Line_Notes;
									String[] Full_Notes = temp.split(",");
									
									if(Full_Notes.length > 1) {
										ReturnValue_Combine = Readexcel.CategorizeNotes(ExcelFilePath_Insti,temp,ClaimID,Insti_Ind_Line_Notes,All);
										cell_combNotes.setCellValue(ReturnValue_Combine);
									}else {
										cell_combNotes.setCellValue(Insti_Ind_Line_Notes);
									}
									
								}
								
							}
							
							FileOutputStream fout = new FileOutputStream(src);
		                    workbook.write(fout);
		                    fout.flush();
		               		fout.close();
							
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
					}
					
					TextFileUtilities.Log("Updated the Institutioanl sheet with Notes generated from LineItem screen Details comparision", "DONE");
					
				}else {
					TextFileUtilities.Log("Claims Result set of Subscriber_Mem details comparision is empty- skipping the Indicative, Line Item Screen Validation for Institutional Claims", "DONE");
					Insti_SubFiltered_Claims = "True"; 
				}
				
			}else {
				TextFileUtilities.Log("Institutional Claims does not exist in the Test Data Sheet", "DONE");
				Blank_InstiClaims = "True";
			}
			
/////////////////////////////////////////////Export Correction Notes of Insti and Prof Claims to Test data Sheet//////////////////////////////////////////			
			
			
			//Export Notes to TestData Sheet - Line Items & Indicative [Professional]
			HashMap<String, String> Final_Notes1 = new HashMap<String, String>();
			FileInputStream fis_new=new FileInputStream(ExcelFilePath);
			XSSFWorkbook wbook_new = new XSSFWorkbook(fis_new);
			
			HashMap<String, String> Prof_SCCF_Details = new HashMap<String, String>();
			HashMap<String, String> SCCF_Details = new HashMap<String, String>();
			
			//Write Notes if Professional Claims Exist in Test Data Sheet
			if(!(Blank_ProfClaims.equals("True") || Prof_SubFiltered_Claims.equals("True") || Prof_BillProvFiltered_Claims.equals("True"))) {
				
				//Get the SCCF Details for Prof Claims
				Prof_SCCF_Details = ITS_Claims_Code.GetSCCFNum(File_Path,Prof_ComparisionSheet);
				
				Sheet sheet_N = wbook_new.getSheet("CompResult_LineItems");
				Row Head_R = sheet_N.getRow(0);
				
				//Get Combined Notes From Comparison Sheet - Professional
				for(int Value = 1; Value <= sheet_N.getPhysicalNumberOfRows()-1; Value++) {
					
					String Claim_ID = "";
					String Notes_txt = "";
					//Full_Notes = "";
					
					Row row = sheet_N.getRow(Value);
					Cell ClaimID = row.getCell(0);
					int Colcnt = Head_R.getPhysicalNumberOfCells();
					Cell Notes_new = row.getCell(Colcnt-1);
					
					//Get Claim ID
					switch (evaluator.evaluateInCell(ClaimID).getCellType()) {
					  
					  case Cell.CELL_TYPE_STRING: 
						  
						  Claim_ID = ClaimID.getStringCellValue();
						  break;
						  
					}
					
					//Get Notes
					switch (evaluator.evaluateInCell(Notes_new).getCellType()) {
					  
					  case Cell.CELL_TYPE_STRING: 
						  
						  Notes_txt = Notes_new.getStringCellValue();
						  break;
					}
					
					//Combine ClaimID and Notes
					//if(!(Claim_ID=="")&&!(Notes_txt=="")) {
						//Final_Notes1.put(Claim_ID,Notes_txt);
					//}
					if(!(Claim_ID=="")) {
						Final_Notes1.put(Claim_ID,Notes_txt);
					}
					
					
				}
				
			}
			
			//Write Notes if Institutional Claims Exist in Test Data Sheet
			if(!(Blank_InstiClaims.equals("True") || Insti_SubFiltered_Claims.equals("True"))) {
				
				//Get the SCCF Details for Insti Claims
				SCCF_Details = ITS_Claims_Code.GetSCCFNum(File_Path,Insti_ComparisionSheet);
				
				//Export Notes to TestData Sheet - Line Items & Indicative [Institutional]
				FileInputStream Insti_fis = new FileInputStream(ExcelFilePath_Insti);
				XSSFWorkbook wbook_inst = new XSSFWorkbook(Insti_fis);
				
				Sheet sheet_Inst = wbook_inst.getSheet("CompResult_LineItems");
				Row Header_Inst = sheet_Inst.getRow(0);
				
				int CombineNotes_Col = 0;
				
				//Get Combined Notes From Comparison Sheet - Professional
				for(int Value = 1; Value <= sheet_Inst.getPhysicalNumberOfRows()-1; Value++) {
					
					String Claim_ID = "";
					String Notes_txt = "";
					//Full_Notes = "";
					
					Row row = sheet_Inst.getRow(Value);
					Cell ClaimID = row.getCell(0);
					int Colcnt = Header_Inst.getPhysicalNumberOfCells();
					
					Cell Notes_new = null;
					
					//Get the Combined Notes Column ID
					if(Value==1) {
						
						for(int j=0;j<=Colcnt-1;j++) {
							Cell cell = Header_Inst.getCell(j);
							
							if(cell.getStringCellValue().trim().equals("Combined_Notes")) {
								Notes_new = row.getCell(j);
								CombineNotes_Col = j;
								break;
							}
							
							
						}
						
					}else {
						Notes_new = row.getCell(CombineNotes_Col);
					}
					
					//Get Claim ID
					switch (evaluator.evaluateInCell(ClaimID).getCellType()) {
					  
					  case Cell.CELL_TYPE_STRING: 
						  
						  Claim_ID = ClaimID.getStringCellValue();
						  break;
						  
					}
					
					//Get Notes
					switch (evaluator.evaluateInCell(Notes_new).getCellType()) {
					  
					  case Cell.CELL_TYPE_STRING: 
						  
						  Notes_txt = Notes_new.getStringCellValue();
						  break;
					}
					
					//Combine ClaimID and Notes
					if(!(Claim_ID=="")) {
						Final_Notes1.put(Claim_ID,Notes_txt);
					}
					
				}
				
			}
			
			//Add Prof and Insti SCCF's into single Hashmap
			if(!Prof_SCCF_Details.isEmpty()) {
				SCCF_Details.putAll(Prof_SCCF_Details);
			}
			
			
			//Export Notes to Test Data Sheet
			if(!Final_Notes1.isEmpty()) {
				
				//FileInputStream file = new FileInputStream(Testdata_File);
				//XSSFWorkbook wbook3 = new XSSFWorkbook(file);
				//Sheet sheet3 = wbook_1.getSheetAt(0);
				
				String Notes = null;
				String SCCF_Num = null;
				String Header = "";
				
				int Col_Count = 0;
				int SCCFNum_Col = 0;
				int Notes_Col = 0;
					
				for(int Value = 1; Value<=TestData_Rowcount-1; Value++) {
					
					if(Value==0) {
						
						//Get the Last Column Name and Check if Notes Column Exist
						Cell Prev_Notes = Head_Row.getCell(Head_Row.getPhysicalNumberOfCells()-1);
						
						//Get Last Column Header
						switch (evaluator.evaluateInCell(Prev_Notes).getCellType()) {
						  
						  case Cell.CELL_TYPE_STRING: 
							  
							  Header = Prev_Notes.getStringCellValue();
							  //System.out.println(Claim_ID);
							  break;
							  
						}
						
						//If Notes Column Already Exists, Rewrite else Create New Column
						if(Header.equals("Comparison_Notes")) {
							
							Col_Count = Head_Row.getPhysicalNumberOfCells()-1;
							SCCFNum_Col = Col_Count+1;
							Notes_Col = Col_Count;
							
						}else {
							
							Col_Count = Head_Row.getPhysicalNumberOfCells()-1;
							//Cell Notes_SCCF = Head_Row.createCell(Col_Count);
							//Notes_SCCF.setCellValue("SCCF_Text");
							//SCCFNum_Col = Col_Count;
							
							//Cell Notes_Header = Head_Row.createCell(Col_Count+1);
							//Notes_Header.setCellValue("Notes");
							//Notes_Col = Col_Count+1;
							
						}
						
					}
					
					String Claim_ID = "";
					Row row=sheet.getRow(Value);
					Cell ClaimID = row.getCell(ClaimID_Column);
					
					//Get Claim ID
					switch (evaluator.evaluateInCell(ClaimID).getCellType()) {
					  
					  case Cell.CELL_TYPE_STRING: 
						  
						  Claim_ID = ClaimID.getStringCellValue();
						  //System.out.println(Claim_ID);
						  break;
						  
					}
					
					//Get MicroFilmID
					Cell MicroFilm_ID = row.getCell(MicroFilmID_Column);
					String MicroFilmID = "";
					
					switch (evaluator.evaluateInCell(MicroFilm_ID).getCellType()) {
					  
					  case Cell.CELL_TYPE_STRING: 
						  
						  MicroFilmID = MicroFilm_ID.getStringCellValue().trim();
						  //System.out.println(Claim_ID);
						  break;
						  
					}
					
					//Get SCCF Num
					if(SCCF_Details.containsKey(Claim_ID)) {
						
						SCCF_Num = SCCF_Details.get(Claim_ID);
						Cell SCCF_Txt = row.createCell(SCCF_column_Value);
						
						//SCCF Value
						if(!(SCCF_Num==null)) {
							SCCF_Txt.setCellValue(SCCF_Num);
						}
						
					}
					
					if(Final_Notes1.containsKey(Claim_ID)) {
						
						//SCCF_Num = SCCF_Details.get(Claim_ID);
						//Cell SCCF_Txt = row.createCell(SCCF_column_Value);
						
						//SCCF Value
						//if(!(SCCF_Num==null)) {
							//SCCF_Txt.setCellValue(SCCF_Num);
						//}
						
						Notes = Final_Notes1.get(Claim_ID);
						Cell Notes_Txt = row.createCell(Notes_column_Value);
						
						//Notes Value
						if(!(Notes.equals(""))) {
							Notes_Txt.setCellValue("Please approve VR "+Notes+" as per corrected Image ("+MicroFilmID+"). Please Review, Adjust or Advice. Thanks ");
						}
						else {
							Notes_Txt.setCellValue("No Changes");
						}
						
					}
					
				}
				
			}
			
			FileOutputStream fout_New = new FileOutputStream(Testdata_File);
			wbook_1.write(fout_New); 
			fout_New.flush(); 
			fout_New.close(); 
			wbook_1.close();
			
			TextFileUtilities.Log("All claims in testdatasheet are Updated with Final comparision Notes", "DONE");
			
			//Get Required Original Claim Details for Facets Override
			FileInputStream finput = new FileInputStream(Testdata_File);
			XSSFWorkbook Notes_book = new XSSFWorkbook(finput);
			String SName = Notes_book.getSheetName(0);
			Sheet Req_Sheet = Notes_book.getSheet(SName);
			int RowCount = Req_Sheet.getPhysicalNumberOfRows();
			Row HeaderRow = Req_Sheet.getRow(0);
			
			int StartRow = 0;
			
			for(int row=1; row<=RowCount-1; row++) {
				
				String Notes_Value = "";
				String ClaimID_Original = "";
				
				int Col_Cnt = HeaderRow.getPhysicalNumberOfCells()-1;
				
				
				Cell Notes_Col = HeaderRow.getCell(Notes_column_Value);
				
				if(Notes_Col.getStringCellValue().trim().equals("Comparison_Notes")) {
					Notes_Value = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, row, Notes_column_Value);
				}
				
				//Fetch Original Claim Values
				//if(Notes_Value!=""&&Notes_Value.contains("Please approve")) {
				if(!Notes_Value.contains("Skipping")) {
					
					Cell cell_ClaimID = Head_row.getCell(ClaimID_Column);
					
					switch (evaluator.evaluateInCell(cell_ClaimID).getCellType()) {
					  
					  case Cell.CELL_TYPE_STRING: 
						  
						  ClaimID_Corrected = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, row, ClaimID_Column);
						  //Get the Original claim id
						  if (!(ClaimID_Corrected.endsWith("00"))) {
							ClaimID_Original = ClaimID_Corrected.substring(0, ClaimID_Corrected.length() - 2)+"00"; 
						  }
						  break;
						  
					}
					
					Cell cell_ClaimType = Head_row.getCell(ClaimType_Column);
					
					switch (evaluator.evaluateInCell(cell_ClaimType).getCellType()) {
					  
					  case Cell.CELL_TYPE_STRING: 
						  Str_ClaimType = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, row, ClaimType_Column);
						  break;
					}
					
					//Fetch Original Claim data for Facets Overide
					String Facets_PartText = "Original_Claim_Details";
					String QueryFile_OrgData;
					QueryFile_OrgData = ITS_Claims_Code.listFilesForFolder(Facets_PartText);
					
					String temp = re.TextFilename(Environment.get("config_path")+"/"+QueryFile_OrgData+".txt").replace("REPLACE_CLAIMTYPE", Str_ClaimType);
					String Org_FacetsOverride_Query = temp.replace("REPLACE_CLAIMID", ClaimID_Original);
					
					//Export Query data to Excel
					ResultSet rs = ConfigValidation.Database(PreMove, Org_FacetsOverride_Query); //Corrected claims data
					
					//Resultset Meta data
					ResultSetMetaData rsmd = ConfigValidation.getResultSetMetaData(PreMove,rs);
					
					//Export Original Claim Required Data - Sheet2
					int PrevRow = Integer.parseInt(ITS_Claims_Code.WriteToExcel(Testdata_File,"Sheet2",rs,StartRow,rsmd)); 
					
					//Write DB output based on RowCount
					StartRow = PrevRow-1;
					
				}
				
			}
			
			TextFileUtilities.Log("Original Claim details are captured based on Comparison Notes", "DONE");
		
			
		}else {
			TextFileUtilities.Log("Test Data Input file does not exist in Test data folder", "FAIL");
		}
	  ITSHost_blue_Nochnage.blue2bot();
		return;
	}

}
