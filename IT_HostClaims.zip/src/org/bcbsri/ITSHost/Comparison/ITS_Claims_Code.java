package org.bcbsri.ITSHost.Comparison;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.bcbsri.ITSHost.dbutility.TextFileUtilities;
import org.bcbsri.configvalidation.ConfigValidation;
import org.bcbsri.configvalidation.Readexcel;
import com.dell.acoe.framework.config.Environment;


public class ITS_Claims_Code {
	
	static Readexcel re = new Readexcel();
	
	public static String WriteToExcel(String ReportFilePath,String sheetName, ResultSet rs, int rowIndex,ResultSetMetaData rsmd) throws IOException, SQLException, InvalidFormatException
   	{
   		
   		FileInputStream fis = new FileInputStream(ReportFilePath);
 	    XSSFWorkbook wb = new XSSFWorkbook(fis);
   		//ResultSetMetaData rsmd = rs.getMetaData();
   		List<String> columns = new ArrayList<String>();
		
		String count = "";
		
   		for(int i=1;i<=rsmd.getColumnCount();i++)
   		{
   			columns.add(rsmd.getColumnLabel(i));
   		}
   		
   		XSSFSheet sheet = wb.getSheet(sheetName);
   		
   		//Create New Sheet
        if(sheet==null) {
        	sheet = wb.createSheet(sheetName);
        }else {
        	
        	if(sheetName.equals("Sheet2")&&rowIndex==0) {
        		wb.removeSheetAt(1);
            	FileOutputStream fout = new FileOutputStream(ReportFilePath);
           		wb.write(fout);
           		sheet = wb.createSheet(sheetName);
        	}
        	
        }
        	
   		Row header = sheet.createRow(0);
   		for(int i=0;i<columns.size();i++)
   		{
   			header.createCell(i).setCellValue(columns.get(i));
   		}
   		
   		int Before_Cnt = 0;
   		//Before count - Indicative and Line items
   		if (sheetName.contains("Indicative")||sheetName.contains("LineItems")) {
   			 Before_Cnt = sheet.getPhysicalNumberOfRows();
   	   		//System.out.println("Before Count: "+Before_Cnt);
   		}
   		
   		while(rs.next()) 
   		{
   			Row row = sheet.createRow(++rowIndex);
   			for(int i=0;i<columns.size();i++)
   			{
   				Cell cell = row.createCell(i);
   				
   				String val = Objects.toString(rs.getObject(columns.get(i)),"");
   				
				//Rates
				cell.setCellValue(val);
   				
   			}
   		}
   		
   		FileOutputStream fout = new FileOutputStream(ReportFilePath);
   		wb.write(fout);
   		wb.close();
   		
   		//Applicable for Indicative and LineItems
   		if(!(sheetName.equals("CompResult_Indicative"))&&!(sheetName.equals("CompResult_LineItems"))) {
   			
   			if(sheetName.contains("Indicative")||sheetName.contains("LineItems")) {
   				
   				int After_Cnt = sheet.getPhysicalNumberOfRows();
   	   	   		//System.out.println("After Count: "+After_Cnt);
   				count = Before_Cnt+":"+After_Cnt;
   	   			//System.out.println(Bef_Aft_Cnt);
   				
   			}else {
   				count = sheet.getPhysicalNumberOfRows()+"";
   			}
   			
   		}
   		
   		return count;
   		
   	}
	
	
	public static String WriteToExcel1(String ReportFilePath,String sheetName, ResultSet rs, int rowIndex) throws IOException, SQLException, InvalidFormatException
   	{
   		
   		FileInputStream fis = new FileInputStream(ReportFilePath);
 	    XSSFWorkbook wb = new XSSFWorkbook(fis);
   		ResultSetMetaData rsmd = rs.getMetaData();
   		List<String> columns = new ArrayList<String>();
		
		String count = "";
		
   		for(int i=1;i<=rsmd.getColumnCount();i++)
   		{
   			columns.add(rsmd.getColumnLabel(i));
   		}
   		
   		XSSFSheet sheet = wb.getSheet(sheetName);
   		
   		//Create New Sheet
        if(sheet==null) {
        	sheet = wb.createSheet(sheetName);
        }else {
        	
        	if(sheetName.equals("Sheet2")&&rowIndex==0) {
        		wb.removeSheetAt(1);
            	FileOutputStream fout = new FileOutputStream(ReportFilePath);
           		wb.write(fout);
           		sheet = wb.createSheet(sheetName);
        	}
        	
        }
        	
   		Row header = sheet.createRow(0);
   		for(int i=0;i<columns.size();i++)
   		{
   			header.createCell(i).setCellValue(columns.get(i));
   		}
   		
   		int Before_Cnt = 0;
   		//Before count - Indicative and Line items
   		if (sheetName.contains("Indicative")||sheetName.contains("LineItems")) {
   			 Before_Cnt = sheet.getPhysicalNumberOfRows();
   	   		//System.out.println("Before Count: "+Before_Cnt);
   		}
   		
   		while(rs.next()) 
   		{
   			Row row = sheet.createRow(++rowIndex);
   			for(int i=0;i<columns.size();i++)
   			{
   				Cell cell = row.createCell(i);
   				
   				String val = Objects.toString(rs.getObject(columns.get(i)),"");
   				
				//Rates
				cell.setCellValue(val);
   				
   			}
   		}
   		
   		FileOutputStream fout = new FileOutputStream(ReportFilePath);
   		wb.write(fout);
   		wb.close();
   		
   		//Applicable for Indicative and LineItems
   		if(!(sheetName.equals("CompResult_Indicative"))&&!(sheetName.equals("CompResult_LineItems"))) {
   			
   			if(sheetName.contains("Indicative")||sheetName.contains("LineItems")) {
   				
   				int After_Cnt = sheet.getPhysicalNumberOfRows();
   	   	   		//System.out.println("After Count: "+After_Cnt);
   				count = Before_Cnt+":"+After_Cnt;
   	   			//System.out.println(Bef_Aft_Cnt);
   				
   			}else {
   				count = sheet.getPhysicalNumberOfRows()+"";
   			}
   			
   		}
   		
   		return count;
   		
   	}
	
	
	
	public static ArrayList<String> ListAllClaimDetails(String ReportFilePath, String sheetName, String LinesCount) throws Exception {
		
		FileInputStream fis = new FileInputStream(ReportFilePath);
 	    @SuppressWarnings("resource")
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheet(sheetName);
		FormulaEvaluator evaluator = wb.getCreationHelper().createFormulaEvaluator();
		
		ArrayList<String> Differences = new ArrayList<String>();
		
		String[] temp1 = LinesCount.split(":");
		int Before_Cnt = Integer.parseInt(temp1[0]);
		int After_Cnt = Integer.parseInt(temp1[1]);
		
		//After count - Indicative and Line items
		Row row = sheet.getRow(0);
		int ColCount = row.getPhysicalNumberOfCells();
		
		for(int column=1; column<=ColCount-1; column++) {
			
			Cell ColumnName = row.getCell(column);
			for (int line=Before_Cnt; line<=After_Cnt-1; line++) {
				
				Row row_New = sheet.getRow(line);
				
				Cell value = row_New.getCell(column);
				
				switch (evaluator.evaluateInCell(value).getCellType()) {
				  
				  case Cell.CELL_TYPE_STRING: 
					  
					  String CellValue = value.getStringCellValue();
					  //System.out.println(CellValue);
					  
					  //Value for cell with blank data
					  if(CellValue.trim().equals("")) {
						  CellValue = "Null";
					  }
					  
					  //Add Values with headers into Array
					  if(!ColumnName.getStringCellValue().equals("PatAccountNo")) {
						  
						  if(Differences.isEmpty()){
							  Differences.add(ColumnName+"-"+CellValue);
						  }else {

							  if(!(Differences.contains(ColumnName+"-"+CellValue))) {
								  Differences.add(ColumnName+"-"+CellValue);
							  }

						  }
						  
					  }
					  
					  
					  break;
					  
				  default:
					  TextFileUtilities.Log("cell type is not string for the column "+ColumnName, "FAIL");
					  
				}
   				
   			}
			
		}
		
		return Differences;
		
	}
	
	public static ArrayList<String> GetColumnNames(String ReportFilePath, String sheetName) throws IOException{
		
		FileInputStream fis = new FileInputStream(ReportFilePath);
 	    @SuppressWarnings("resource")
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheet(sheetName);
		FormulaEvaluator evaluator = wb.getCreationHelper().createFormulaEvaluator();
		String CellValue = null;
		
		ArrayList<String> ColumnNames = new ArrayList<String>();
		
		Row row = sheet.getRow(0);
		int ColCount = row.getPhysicalNumberOfCells();
		
		for(int column=1; column<=ColCount-1; column++) {
			
			Cell ColumnName = row.getCell(column);
			
			switch (evaluator.evaluateInCell(ColumnName).getCellType()) {
			  
			  case Cell.CELL_TYPE_STRING: 
				  
				  CellValue = ColumnName.getStringCellValue();
				  //System.out.println(CellValue);
				  
				  break;
				  
			  default:
				  System.out.println("Entered into default block for OtherPayeeInfo block");
				  
			}
			
			ColumnNames.add(CellValue);
			
		}
		
		return ColumnNames;
		
	}
	
	
	public static Map<String, ArrayList<String>> LineItemDifferences(String ReportFilePath, String SheetName, String LinesCount) throws Exception {
		
		FileInputStream fis = new FileInputStream(ReportFilePath);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet Adjsheet = wb.getSheet(SheetName);
		
		int SequenceNo_ColumnID = 0;
		String Actual_LineItemValue = null;
		
		ArrayList<String> LineItem_Values = new ArrayList<String>();
		Map<String,ArrayList<String>> MultiValueMap = new HashMap<String, ArrayList<String>>();
		
		FormulaEvaluator evaluator = wb.getCreationHelper().createFormulaEvaluator();
	
		String[] temp1 = LinesCount.split(":");
		int Before_Cnt = Integer.parseInt(temp1[0]);
		int After_Cnt = Integer.parseInt(temp1[1]);
		
		//Column ID - Sequence No.
		Row Head_row = Adjsheet.getRow(0);
		for(int j=1;j<=Head_row.getPhysicalNumberOfCells();j++) {
			
			Cell cell = Head_row.getCell(j);
			
			if(cell.getStringCellValue().equals("SequenceNo")) {
				SequenceNo_ColumnID = j;
				break;
			}
			
		}

		//Get the Values from Line Items
		Row row = Adjsheet.getRow(0);

		int ColCount = row.getPhysicalNumberOfCells();
		String Prev_Seq = null;

		for (int line=Before_Cnt; line<=After_Cnt-1; line++) {
			
			//Get the Sequence ID from second iteration
			if(line > Before_Cnt) {

				Row Prev_row = Adjsheet.getRow(line-1);
				Cell Prev_Column_Seq = Prev_row.getCell(SequenceNo_ColumnID);
				
				switch (evaluator.evaluateInCell(Prev_Column_Seq).getCellType()) {

				case Cell.CELL_TYPE_STRING: 

					Prev_Seq = Prev_Column_Seq.getStringCellValue().trim();
					//System.out.println(CellValue);
					break;

				default:
					TextFileUtilities.Log("Cell type is not string for column "+Prev_Column_Seq, "FAIL");
				}

			}
			
			//Add Cell values into Array and Hashmap
			for(int column = 1; column <= ColCount-1; column++) {

				Cell ColumnName = row.getCell(column);
				String Col_Name = ColumnName.getStringCellValue();

				Row row_New = Adjsheet.getRow(line);
				Cell Actual_Value = row_New.getCell(SequenceNo_ColumnID);

				switch (evaluator.evaluateInCell(Actual_Value).getCellType()) {

				case Cell.CELL_TYPE_STRING: 

					Actual_LineItemValue = Actual_Value.getStringCellValue();
					//System.out.println(CellValue);
					break;

				default:
					TextFileUtilities.Log("Cell type is not string for column "+Actual_Value, "FAIL");

				}

				Cell value = row_New.getCell(column);
				String CellValue = null;
				switch (evaluator.evaluateInCell(value).getCellType()) {

				case Cell.CELL_TYPE_STRING: 

					CellValue = value.getStringCellValue().trim();
					//System.out.println(CellValue);
					break;

				}
				
				if(CellValue.equals("")) {
					CellValue = "Null";
				}
				
				//Add Values into Array
				if(LineItem_Values.isEmpty()) {
					
					//Add only Required Values
					if(!(Col_Name.equals("TOS") || Col_Name.equals("SCCFNum"))) {
						LineItem_Values.add(Col_Name+"-"+CellValue);
					}
					
				}else {

					//Clear the Array to add next sequence values
					if(!Actual_LineItemValue.equals(Prev_Seq)) {
						if(column==1) {
							LineItem_Values = new ArrayList<String>();
						}
					}

					//Add only Required Values
					if(!(Col_Name.equals("TOS") || Col_Name.equals("SCCFNum"))) {

						if(LineItem_Values.isEmpty()) {
							LineItem_Values.add(Col_Name+"-"+CellValue);
						}else {
							
							if(!(LineItem_Values.contains(Col_Name+"-"+CellValue))) {
								LineItem_Values.add(Col_Name+"-"+CellValue);
							}
							

						}
						
					}
					
				}
				
				//if(MultiValueMap.isEmpty()) {
					MultiValueMap.put(Actual_LineItemValue, LineItem_Values);
				//}

			}

		}
			
		return MultiValueMap;
		
	}
	
	
	public static void PreMove(String Query_Corrected,String Query_Original,String ExcelFilePath,String PreMove,String Sheet1, String Sheet2)
    {
    	  try {
    		  
			ResultSet rs1= ConfigValidation.Database(PreMove, Query_Corrected); //Corrected claims data
			ResultSet rs2= ConfigValidation.Database(PreMove, Query_Original); //Original Claims data
			
			//write DB output to excel 
			//ConfigValidation.WriteToExcel(ExcelFilePath,Sheet1,rs1); 
			//ConfigValidation.WriteToExcel(ExcelFilePath,Sheet2,rs2);
			//ConfigValidation.WriteToExcel(ExcelFilePath,"Result",rs1);
			
			//re.setComparevalues(ExcelFilePath, Sheet1,Sheet2, "Result");
			//TextFileUtilities.Log(PreMove, SheetName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Please check the query "+e.getMessage());
		}
  		
    }
	
	public static String listFilesForFolder(String Partial_Text) throws Exception
	{
		
		//String Path_Config = "C:\\Users\\MAJITSO\\OneDrive - Blue Cross and Blue Shield of Rhode Island\\Documents\\ITS_HostClaims_Practice\\resources\\config";
		//File folder = new File(Path_Config);
		
		File folder = new File(Environment.get("config_path"));
		
		File[] listOfFiles = folder.listFiles();
		ArrayList<String> fileNames = new ArrayList<String>();
		String fileName=null;
		String Query_fileName = null;
		 
        int lastPeriodPos;
        int i;
		for (i=0; i < listOfFiles.length; i++) 
		{
		    if (listOfFiles[i].isFile()) 
		    {
		    	fileName = listOfFiles[i].getName();
		    	fileNames.add(fileName);
		    }
		    else 
		    {
		    	System.out.println("No files are present in the config folder");
		    }
		}   
		    try
		    {
				for (int j=0; j <fileNames.size(); j++) 
				{
					if(fileNames.get(j).contains(Partial_Text)&&fileNames.get(j).contains(".txt"))
			    	{
				    	
		        		lastPeriodPos = fileNames.get(j).lastIndexOf('.');
		                
						if (lastPeriodPos > 0)
							Query_fileName = fileNames.get(j).substring(0, lastPeriodPos);
				     	
				     }
					
				  }
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
			   System.out.println("File Names dont follow the required naming convention or File Not Found");
			}
			return Query_fileName;
		}
	
	public static String ReadCellData(String ReportFilePath,String SheetName,int vRow, int vColumn)  
	{  
		String value=null;           
		Workbook wb=null;           
		try  
		{  
			FileInputStream fis=new FileInputStream(ReportFilePath);  
			wb=new XSSFWorkbook(fis);  
		}  
		catch(FileNotFoundException e)  
		{  
			e.printStackTrace();  
		}  
		catch(IOException e1)  
		{  
			e1.printStackTrace();  
		}  

		//getting the XSSFSheet object at given index  
		Sheet sheet=wb.getSheet(SheetName);
		Row row=sheet.getRow(vRow); 
		Cell cell=row.getCell(vColumn); 
		
		if(!(cell==null)) {
			value=cell.getStringCellValue();    
		}
		
		//System.out.println("cell value is :"+value);
		return value;               
	}
	
	public static HashMap<String, String> GetSCCFNum(String File_Path,String ExcelFileName) throws IOException {
		
		String Testdata_File = File_Path+"\\"+ExcelFileName;
		String SCCFNum;
		String ClaimID;
		int SCCF_ColNum = 0;
		int Claim_ColNum = 0;
		
		FileInputStream fis = new FileInputStream(Testdata_File);
		XSSFWorkbook wbook_new = new XSSFWorkbook(fis);
		String SheetName = "Adj_LineItems";
		Sheet sheet = wbook_new.getSheet("Adj_LineItems");
		int TestData_Rowcount = sheet.getPhysicalNumberOfRows();
		
		FormulaEvaluator evaluator = wbook_new.getCreationHelper().createFormulaEvaluator();
		
		HashMap<String, String> SCCF_Details = new HashMap<String, String>();
		
		for(int SCCFRow=1;SCCFRow<=TestData_Rowcount-1;SCCFRow++) {
			
			Row row = sheet.getRow(SCCFRow); 
			Row Header_Value = sheet.getRow(0);
			int ColCount = Header_Value.getPhysicalNumberOfCells();
			
			if(SCCFRow==1) {
				
				for(int j=0;j<=ColCount-1;j++) {
					Cell cell = Header_Value.getCell(j);
					
					if(cell.getStringCellValue().trim().equals("ClaimID")) {
						Claim_ColNum = j;
						break;
					}
					
				}
				
				for(int j=0;j<=ColCount;j++) {
					
					Cell cell = Header_Value.getCell(j);
					
					if(cell.getStringCellValue().trim().equals("SCCFNum")) {
						SCCFNum = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, SCCFRow, j);
						ClaimID = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, SCCFRow, Claim_ColNum);
						SCCF_ColNum = j;
						SCCF_Details.put(ClaimID, SCCFNum);
						break;
					}
					
				}
				
			}else {
				
				Cell cell_ClaimID = row.getCell(SCCF_ColNum);
				
				switch (evaluator.evaluateInCell(cell_ClaimID).getCellType()) {
				  
				  case Cell.CELL_TYPE_STRING: 
					  
					  ClaimID = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, SCCFRow, Claim_ColNum);
					  
					  if(!SCCF_Details.containsKey(ClaimID)) {
						  SCCFNum = ITS_Claims_Code.ReadCellData(Testdata_File, SheetName, SCCFRow, SCCF_ColNum);
						  SCCF_Details.put(ClaimID, SCCFNum);
					  }
					  
					  break;
					  
				}
				
			}
			
		}
		
		wbook_new.close();
		return SCCF_Details;
		
	}

}
