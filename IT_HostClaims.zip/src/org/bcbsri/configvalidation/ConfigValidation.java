package org.bcbsri.configvalidation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.ComparisonOperator;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFConditionalFormattingRule;
import org.apache.poi.xssf.usermodel.XSSFPatternFormatting;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFSheetConditionalFormatting;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.bcbsri.ITSHost.Comparison.ITS_Claims_Comparison;
import org.bcbsri.ITSHost.Facetsoverride.ITS_HostClaim_Overrides;

import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.selenium.util.DBUtil;
import com.dell.acoe.framework.selenium.verify.Assert;
import com.ntt.cryptic.aesTest;

public class ConfigValidation 
{
	static Readexcel re = new Readexcel();

	public static void listFilesForFolder(String FileName_Sort) throws Exception
	{
		File folder = new File(Environment.get("config_path"));
		File[] listOfFiles = folder.listFiles();
		ArrayList<String> fileNames = new ArrayList<String>();
		String fileName;
		String Query=null;

		int lastPeriodPos;
		int i;
		for (i=0; i < listOfFiles.length; i++) 
		{
			if (listOfFiles[i].isFile()) 
			{
				fileName = listOfFiles[i].getName();
				fileNames.add(fileName);
			}
			else 
			{
				System.out.println("No files are present");
			}
		}   
		try
		{
			for (int j=0; j <fileNames.size(); j++) 
			{
				if(fileNames.get(j).contains("ExRate")&&FileName_Sort.contains("ExRate")&&fileNames.get(j).contains(".txt"))
				{

					lastPeriodPos = fileNames.get(j).lastIndexOf('.');
					String fileNamee = null;
					if (lastPeriodPos > 0)
						fileNamee = fileNames.get(j).substring(0, lastPeriodPos);
					Query = re.TextFilename(Environment.get("config_path")+"/"+fileNamee+".txt").replace("REPLACE_VALUE", FileName_Sort);
					System.out.println("Query : " +Query);
					String ExcelFilePath = Environment.get("test_data_path")+"/"+FileName_Sort;
					System.out.println("ExcelFilePath : "+ExcelFilePath);
					String PreMove = Environment.get("PreMove");
					String SheetName = "EX_rate_grid";
					PreMove(Query,ExcelFilePath,PreMove,SheetName);

				}

				if(fileNames.get(j).contains("PRSP_RATES")&&FileName_Sort.contains("PRSP_RATES")&&fileNames.get(j).contains(".txt"))
				{

					lastPeriodPos = fileNames.get(j).lastIndexOf('.');
					String fileNamee = null;
					if (lastPeriodPos > 0)
						fileNamee = fileNames.get(j).substring(0, lastPeriodPos);
					Query = re.TextFilename(Environment.get("config_path")+"/"+fileNamee+".txt").replace("REPLACE_VALUE", FileName_Sort);
					System.out.println("Query : " +Query);
					String ExcelFilePath = Environment.get("test_data_path")+"/"+FileName_Sort;
					System.out.println("ExcelFilePath : "+ExcelFilePath);
					String PreMove = Environment.get("PreMove");
					String SheetName = "PRSP_rates";
					PreMove(Query,ExcelFilePath,PreMove,SheetName);

				}

				if(fileNames.get(j).contains("PRSP_STATUS_LKP")&&FileName_Sort.contains("PRSP_STATUS_LKP")&&fileNames.get(j).contains(".txt"))
				{

					lastPeriodPos = fileNames.get(j).lastIndexOf('.');
					String fileNamee = null;
					if (lastPeriodPos > 0)
						fileNamee = fileNames.get(j).substring(0, lastPeriodPos);
					Query = re.TextFilename(Environment.get("config_path")+"/"+fileNamee+".txt").replace("REPLACE_VALUE", FileName_Sort);
					System.out.println("Query : " +Query);
					String ExcelFilePath = Environment.get("test_data_path")+"/"+FileName_Sort;
					System.out.println("ExcelFilePath : "+ExcelFilePath);
					String PreMove = Environment.get("PreMove");
					String SheetName = "PRSP_STATUS_LKP";
					PreMove(Query,ExcelFilePath,PreMove,SheetName);

				}

				if(fileNames.get(j).contains("OPEN_COMM")&&FileName_Sort.contains("OPEN_COMM")&&fileNames.get(j).contains(".txt"))
				{

					lastPeriodPos = fileNames.get(j).lastIndexOf('.');
					String fileNamee = null;
					if (lastPeriodPos > 0)
						fileNamee = fileNames.get(j).substring(0, lastPeriodPos);
					Query = re.TextFilename(Environment.get("config_path")+"/"+fileNamee+".txt").replace("REPLACE_VALUE", FileName_Sort);
					System.out.println("Query : " +Query);
					String ExcelFilePath = Environment.get("test_data_path")+"/"+FileName_Sort;
					System.out.println("ExcelFilePath : "+ExcelFilePath);
					String PreMove = Environment.get("PreMove");
					String SheetName = "OpenVueComm";
					PreMove(Query,ExcelFilePath,PreMove,SheetName);

				}

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("File Names dont follow the required naming convention or File Not Found");
		}

	}


	// Move .xlsx file from Source path to destination path	
	public static void FileMove(String FileName) throws IOException, Exception

	{

		if (!(FileName == "")) {
			String Src_path = Environment.get("test_data_path");
			String Dest_path = Environment.get("processed_path");
			FileInputStream fis = new FileInputStream(Src_path + "\\" + FileName);

			Workbook wb;
			wb = WorkbookFactory.create(fis);

			FileOutputStream fos = new FileOutputStream(new File(Dest_path + "\\" + FileName));
			wb.write(fos);
			fos.close();

		}

	}


	// Sort Filenames from Required folder 
	public static void descendingmethod() throws IOException, Exception
	{

		String File_Path = Environment.get("Server_path");
		File folder = new File(File_Path);

		LocalDate dateObj = LocalDate.now();       
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");       
		//String date = dateObj.format(formatter);   
		String date = "20220325";

		if(folder.isDirectory()) {

			File[] fileList = folder.listFiles();

			ArrayList<String> arraylist_ExRate = new ArrayList<String>();
			ArrayList<String> arraylist_PRSPRates = new ArrayList<String>();
			ArrayList<String> arraylist_PRSPStatus = new ArrayList<String>();
			ArrayList<String> arraylist_openComm = new ArrayList<String>();

			System.out.println("The list of Files present in the Directory:\n");
			for(File fileName:fileList) {
				System.out.println(fileName.getName());
			}

			//Ex Rate Files
			String Latest_File = null;
			String contains = null;
			label: for(File file:fileList) {

				// Ex Rate
				try {

					if(file.getName().contains("ExRate")){
						contains = "True";
						arraylist_ExRate.add(file.getName());

					}

				}catch(Exception e) {
					break label;
				}

			}

			//ExRate Latest File - Execute only if File exists
			if (contains == "True") {

				Collections.sort(arraylist_ExRate, Collections.reverseOrder());
				String sortedFile_ExRate = arraylist_ExRate.get(0);

				//Checking Exrate files with current date
				if (sortedFile_ExRate.contains(date))
				{ 
					Latest_File = "True";
					FileMove(sortedFile_ExRate);

				}

				//Error Statement - Ex Rate
				if (!(Latest_File == "True"))
					System.out.println("The Latest Ex Rate file from the directory doesn't contain the current Date");

			}


			//PRSP Rates File
			String Contains1 = null;
			String LatestFile_1 = null;
			label : for(File file:fileList) {

				try {

					// PRSP Rate
					if(file.getName().contains("PRSP_RATES")){
						Contains1 = "True";
						arraylist_PRSPRates.add(file.getName());

					}


				}catch (Exception e) {
					break label;
				}

			}

			//PRSP Rates Latest File - Execute only if File Exists
			if (Contains1 == "True") {

				//PRSPRate Latest File
				Collections.sort(arraylist_PRSPRates, Collections.reverseOrder());
				String sortedFile_PRSPRate = arraylist_PRSPRates.get(0);

				//Checking PRSPRate files with current date
				if (sortedFile_PRSPRate.contains(date))
				{ 
					LatestFile_1 = "True";
					FileMove(sortedFile_PRSPRate);

				}

				//Error Statement - PRSP Rates
				if (!(LatestFile_1 == "True"))
					System.out.println("The Latest PRSP Rate file from the directory doesn't contain the current Date");

			}

			//PRSP Status Files
			String LatestFile_2 = null;
			String Contains2 = null;
			label: for(File file:fileList) {

				try {

					// PRSP Status
					if(file.getName().contains("PRSP_STATUS_LKP")){
						Contains2 = "True";
						arraylist_PRSPStatus.add(file.getName());

					}

				}catch (Exception e) {
					break label;
				}

			}
			//PRSPRate Status File - Execute if File exists
			if (Contains2 == "True") {

				Collections.sort(arraylist_PRSPStatus, Collections.reverseOrder());
				String sortedFile_PRSPStatus = arraylist_PRSPStatus.get(0);

				//Checking PRSPstatus files with current date
				if (sortedFile_PRSPStatus.contains(date)) 
				{ 
					LatestFile_2 = "True";
					FileMove(sortedFile_PRSPStatus);

				}

				//Error Statement - PRSP Status
				if (!(LatestFile_2 == "True"))
					System.out.println("The Latest PRSP Status file from the directory doesn't contain the current Date");

			}


			// Open Commission Files
			String LatestFile_3 = null;
			String Contains3 = null;
			label : for(File file:fileList)
			{

				try {

					// OPEN COMM
					if(file.getName().contains("OPEN_COMM")){
						Contains3 = "True";
						arraylist_openComm.add(file.getName());

					}


				}catch(Exception e) {
					break label;
				}

			}

			//OPEN COMM Latest File - Execute if File exists
			if (Contains3 == "True") {

				Collections.sort(arraylist_openComm, Collections.reverseOrder());
				String sortedFile_OpenComm = arraylist_openComm.get(0);

				//Checking Open commission files with current date
				if (sortedFile_OpenComm.contains(date))
				{ 
					LatestFile_3 = "True";
					FileMove(sortedFile_OpenComm);

				}

				//Error Statement - Open Commission
				if (!(LatestFile_3 == "True"))
					System.out.println("The Latest Open commission file from the directory doesn't contain the current Date");

			}


		}
		else {
			System.out.println("Provided Path"+File_Path+"is not a directory");
		}


	}
public static void ExecuteAllfilesinfolder() throws Exception 
    
    {
          //listFilesForFolder();
	      String Testdatapath = Environment.get("test_data_path");
	      String Processedpath =Environment.get("processed_path");
	      Date now = new Date();
	      SimpleDateFormat dateFormat = new SimpleDateFormat("MMddyyyyHHmmSS");
	      String time = dateFormat.format(now);
          //System.out.println(Processedpath+"\\"+time);
	      File dir = new File(Processedpath+"\\Report_"+time);
	      dir.mkdir();
	      File from = new File(Testdatapath);
          File to = new File(Processedpath+"\\Report_"+time+"\\");
          File[] listOfFiles = from.listFiles();
          if (listOfFiles != null)
          {
              for (File child : listOfFiles )
              {
            	  
                  String filefullpath = child.getAbsolutePath();
                  
                  if((filefullpath.toLowerCase()).contains(".xlsx")){
                	  conditionalFormatting(filefullpath);
                  }
                  // Move files to destination folder
                  child.renameTo(new File(to + "\\" + child.getName()));

                  
              } 
          }
    }

	public static void PreMove(String Query,String ExcelFilePath,String PreMove,String SheetName)
	{
		try {

			ResultSet rs= Database(PreMove, Query); //Corrected claims data
			WriteToExcel(ExcelFilePath,SheetName,rs); 
			WriteToExcel(ExcelFilePath,"DB_OutputActual",rs); 
			WriteToExcel(ExcelFilePath,"Result",rs);

			re.setComparevalues(ExcelFilePath, SheetName,"DB_OutputActual", "Result");
			//TextFileUtilities.Log(PreMove, SheetName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Please check the query"+e.getMessage());
		}

	}

	public static String ReadResultSheet(String ReportFilePath, String SheetName) throws IOException {

		String Value = "";
		int cnt = 0;
		FileInputStream fis = new FileInputStream(ReportFilePath);
		@SuppressWarnings("resource")
		Workbook workbook = new XSSFWorkbook(fis);
		FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

		Sheet sheet = workbook.getSheet(SheetName);

		int RowCount = sheet.getPhysicalNumberOfRows();
		for (int i = 1; i < RowCount; i++) {
			Row row = sheet.getRow(i);
			int ColCount = row.getPhysicalNumberOfCells();

			for (int j = 0; j < ColCount; j++) {

				Cell cell = row.getCell(j);

				System.out.println(cell.getCellType());

				switch (evaluator.evaluateInCell(cell).getCellType()) {

				case Cell.CELL_TYPE_STRING:
					Value = cell.getStringCellValue();

				case Cell.CELL_TYPE_ERROR:

				}

				if(Value=="Not Equal") {
					cnt = cnt +1;
				}

				if(cnt>0) {
					//report fail with count
				}

			}

		}
		return Value;

	}

	public static void WriteToExcel(String ReportFilePath,String sheetName, ResultSet rs) throws IOException, SQLException, InvalidFormatException
	{

		FileInputStream fis = new FileInputStream(ReportFilePath);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		ResultSetMetaData rsmd = rs.getMetaData();
		List<String> columns = new ArrayList<String>();
		for(int i=1;i<=rsmd.getColumnCount();i++)
		{
			columns.add(rsmd.getColumnLabel(i));
		}

		XSSFSheet sheet = wb.getSheet(sheetName);
		if(sheet==null)
			sheet = wb.createSheet(sheetName);
		Row header = sheet.createRow(0);
		for(int i=0;i<columns.size();i++)
		{
			header.createCell(i).setCellValue(columns.get(i));
		}
		int rowIndex = 0;
		while(rs.next()) 
		{
			Row row = sheet.createRow(++rowIndex);
			for(int i=0;i<columns.size();i++)
			{
				Cell cell = row.createCell(i);

				String val = Objects.toString(rs.getObject(columns.get(i)),"");

				//Rates
				cell.setCellValue(val);

			}
		}
		FileOutputStream fout = new FileOutputStream(ReportFilePath);
		wb.write(fout);
		wb.close();


	} 


	public static ResultSet Database(String DB,String Query)
	{
		ResultSet rs = null;
		String username = null;
		String pass = null;
		String dbURL = null;
		String jdbcDriver = null;

		jdbcDriver = Environment.get("SqlDBx.JdbcDriver");

		//Get DB Values w.r.t environment
		if(DB.equalsIgnoreCase("Test")||DB.equalsIgnoreCase("Minor"))
		{

			username = Environment.get("DB.Minor.pbm.Username");
			pass = Environment.get("DB.Minor.pbm.Password");
			dbURL = Environment.get("DB.MinorURL");
			try {
				pass = aesTest.decrypt(pass);
			} catch (Exception e) {
				Assert.fail("Failed to decrypt the password" + e.getMessage());
			}

		}
		else if(DB.equalsIgnoreCase("Major")||DB.equalsIgnoreCase("PPMO"))
		{
			username = Environment.get("DB.Sybase.Major.Username");
			pass = Environment.get("DB.Sybase.Major.Password");
			dbURL = Environment.get("DB.MajorURL");
			try {
				pass = aesTest.decrypt(pass);
			} catch (Exception e) {
				Assert.fail("Failed to decrypt the password" + e.getMessage());
			}

		}
		else if (DB.equalsIgnoreCase("DEV2"))
		{

			username = Environment.get("DB.SqlDBx.Username");
			pass = Environment.get("DB.SqlDBx.Password");
			dbURL = Environment.get("DB.DevURL");

			try {
				pass = aesTest.decrypt(pass);
			} catch (Exception e) {
				Assert.fail("Failed to decrypt the password" + e.getMessage());
			} 

		}
		else if (DB.equalsIgnoreCase("Prod"))
		{
			username = Environment.get("DB.Prod.Username");
			pass = Environment.get("DB.Prod.Password");
			dbURL = Environment.get("DB.ProdURL");

			try {
				pass = aesTest.decrypt(pass);
			} catch (Exception e) {
				Assert.fail("Failed to decrypt the password" + e.getMessage());
			} 

		}
		else if (DB.equalsIgnoreCase("ITS"))
		{
			dbURL = Environment.get("SqlDBx.ITS");
		}

		try {
			DBUtil.getConnection(jdbcDriver, dbURL, username, pass);
			//rs = DBUtil.getResultSet(jdbcDriver, dbURL, username, pass, Query);
			rs = getResultSet(jdbcDriver, dbURL, username, pass, Query);
			return rs;
			
		} catch (Exception e) {
			//e.printStackTrace();
			return rs;
		}

	}
	
	public static ResultSet getResultSet(String jdbcDriver, String dbURL, String username, String password, String sqlQuery) {
		Connection conn = null;
		ResultSet resultSet = null;

		try {
			Class.forName(jdbcDriver);
			conn = DriverManager.getConnection(dbURL, username, password);
			Statement stmt = conn.createStatement();
			resultSet = stmt.executeQuery(sqlQuery);
			//conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultSet;
	}
	
	public static ResultSetMetaData getResultSetMetaData(String DB, ResultSet rs) {
		Connection conn = null;
		ResultSetMetaData rsmd = null;
		
		String username;
		String pass;
		String dbURL;
		
		String jdbcDriver = null;
		jdbcDriver = Environment.get("SqlDBx.JdbcDriver");
		
		//Get DB Values w.r.t environment
		if(DB.equalsIgnoreCase("Test")||DB.equalsIgnoreCase("Minor"))
		{

			username = Environment.get("DB.Minor.pbm.Username");
			pass = Environment.get("DB.Minor.pbm.Password");
			dbURL = Environment.get("DB.MinorURL");
			try {
				pass = aesTest.decrypt(pass);
			} catch (Exception e) {
				Assert.fail("Failed to decrypt the password" + e.getMessage());
			}

		}
		else if(DB.equalsIgnoreCase("Major")||DB.equalsIgnoreCase("PPMO"))
		{
			username = Environment.get("DB.Sybase.Major.Username");
			pass = Environment.get("DB.Sybase.Major.Password");
			dbURL = Environment.get("DB.MajorURL");
			try {
				pass = aesTest.decrypt(pass);
			} catch (Exception e) {
				Assert.fail("Failed to decrypt the password" + e.getMessage());
			}

		}
		else if (DB.equalsIgnoreCase("DEV2"))
		{

			username = Environment.get("DB.SqlDBx.Username");
			pass = Environment.get("DB.SqlDBx.Password");
			dbURL = Environment.get("DB.DevURL");

			try {
				pass = aesTest.decrypt(pass);
			} catch (Exception e) {
				Assert.fail("Failed to decrypt the password" + e.getMessage());
			} 

		}
		else if (DB.equalsIgnoreCase("Prod"))
		{
			username = Environment.get("DB.Prod.Username");
			pass = Environment.get("DB.Prod.Password");
			dbURL = Environment.get("DB.ProdURL");

			try {
				pass = aesTest.decrypt(pass);
			} catch (Exception e) {
				Assert.fail("Failed to decrypt the password" + e.getMessage());
			} 

		}
		else if (DB.equalsIgnoreCase("ITS"))
		{
			dbURL = Environment.get("SqlDBx.ITS");
		}
		
		username = Environment.get("DB.Prod.Username");
		pass = Environment.get("DB.Prod.Password");
		dbURL = Environment.get("DB.ProdURL");

		try {
			pass = aesTest.decrypt(pass);
		} catch (Exception e) {
			Assert.fail("Failed to decrypt the password" + e.getMessage());
		} 

		try {
			Class.forName(jdbcDriver);
			conn = DriverManager.getConnection(dbURL, username, pass);
			rsmd = rs.getMetaData();
			conn.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return rsmd;
		
	}

	public static void conditionalFormatting(String ExcelFilePath) throws IOException {
		/* Create Workbook and Worksheet - Add Input Rows */
		//System.out.println("ExcelFilePath : " + ExcelFilePath);
		FileInputStream fis = new FileInputStream(ExcelFilePath);

		XSSFWorkbook my_workbook = new XSSFWorkbook(fis);


		int sheetcount = my_workbook.getNumberOfSheets();
		System.out.println("sheetcount: " + sheetcount);
		for (int i = 0; i < sheetcount; i++) {

			if (my_workbook.getSheetName(i).contains("Result")) {
				System.out.print(my_workbook.getSheetName(i) + "  ");
				XSSFSheet my_sheet = my_workbook.getSheet(my_workbook.getSheetName(i));

				/* Access conditional formatting facet layer */
				XSSFSheetConditionalFormatting my_cond_format_layer = my_sheet.getSheetConditionalFormatting();

				/* Create a Rule - greater than rule , to pick all cells equal to "Not Equal"*/
				XSSFConditionalFormattingRule my_rule = my_cond_format_layer
						.createConditionalFormattingRule(ComparisonOperator.EQUAL, "\"Not Equal\"");

				/* Define font formatting if rule is met */
				/* RED color for all matching cells */
				XSSFPatternFormatting fill_pattern = my_rule.createPatternFormatting();
				fill_pattern.setFillBackgroundColor(IndexedColors.RED.index);

				/* Create a Cell Range Address */
				CellRangeAddress[] my_data_range = { CellRangeAddress.valueOf("A1:XFD1048576") };

				/* Attach rule to cell range */
				my_cond_format_layer.addConditionalFormatting(my_data_range, my_rule);
			}
		}
		fis.close();
		/* Write changes to the workbook */
		FileOutputStream out = new FileOutputStream(new File(ExcelFilePath));
		my_workbook.write(out);
		out.close();
		my_workbook.close();
	}
}