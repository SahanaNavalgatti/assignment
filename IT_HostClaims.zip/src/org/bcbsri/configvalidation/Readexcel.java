package org.bcbsri.configvalidation;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.dell.acoe.framework.config.Environment;


public class Readexcel
{
	static String xlFilePath = Environment.get("test_data_path"); //Excel File Path 
	public static FileOutputStream fos = null;
	public static XSSFSheet sheet = null;
	public static XSSFRow row = null;
	public static XSSFCell cell = null;   

	//Write data into Excel sheet
	public static boolean setCellData(String FilePath, int colNumber, int rowNum, String value) throws IOException
	{
		FileInputStream fis = new FileInputStream(FilePath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);

		//Enter Message into Test data Sheet
		try
		{
			Sheet sheet = workbook.getSheetAt(2);
			Row row = sheet.getRow(rowNum);

			Cell cell = row.getCell(colNumber);

			if(cell==null) {
				cell = row.createCell(colNumber);
			}
			
			else {
				
			 row.removeCell(cell);
			}
			cell =row.createCell(colNumber);
			cell.setCellValue(value);

			FileOutputStream fos = new FileOutputStream(FilePath);
			workbook.write(fos);
			fos.close();
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
			return  false;
		}
		return true;
	}

	//Write data into Excel sheet
		public static boolean setCellData1(String FilePath, int colNumber, int rowNum, String list_ClaimID_Corrected) throws IOException
		{
			//Enter Message into Test data Sheet
		
			try
			{
             
				FileInputStream fis = new FileInputStream(FilePath);
				XSSFWorkbook workbook = new XSSFWorkbook(fis);
		
				
				Sheet sheet = workbook.getSheetAt(2);
				if(row==null) 
				    sheet.createRow(rowNum);
				
				Row row = sheet.getRow(rowNum);

				Cell cell = row.getCell(colNumber);

				if(cell==null) 
					cell = row.createCell(colNumber);
				
				//sheet.getRow(rowNum).getCell(colNumber).setCellValue(list_ClaimID_Corrected);
				
				//cell =row.createCell(colNumber);
				cell.setCellValue(list_ClaimID_Corrected);
				
				FileOutputStream fos = new FileOutputStream(FilePath);
				workbook.write(fos);
				fos.close();
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
				return  false;
			}
			return true;
		}

		
		
		
		//Write data into Excel sheet
		public static boolean setCellData2(String FilePath, int colNumber1,int colNumber2, int rowNum1, String list_ClaimID_Corrected,String values) throws IOException
		{
			
			
			FileInputStream fis = new FileInputStream(FilePath);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);

			//Enter Message into Test data Sheet
			try
			{
				Sheet sheet = workbook.getSheetAt(3);
				if(row==null) 
				    sheet.createRow(rowNum1);
				
				Row row = sheet.getRow(rowNum1);

				Cell cell = row.getCell(colNumber1);
				Cell cell1 = row.getCell(colNumber2);

				if(cell==null) 
					cell = row.createCell(colNumber1);
				if(cell1==null)
					cell1 = row.createCell(colNumber2);
					
				
				if (cell != null)
				//cell =row.createCell(colNumber);
				cell.setCellValue(list_ClaimID_Corrected);
				if (cell1 != null)
				cell1.setCellValue(values);
				

				FileOutputStream fos = new FileOutputStream(FilePath);
				workbook.write(fos);
				fos.close();
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
				return  false;
			}
			return true;
		}
		
		
		public static boolean setCellData3(String FilePath, int colNumber1,int colNumber2,int colNumber3,int colNumber4, int rowNum1, String value1,String value2,String value3,String value4) throws IOException
		{
			
			
			FileInputStream fis = new FileInputStream(FilePath);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);

			//Enter Message into Test data Sheet
			try
			{
				Sheet sheet = workbook.getSheetAt(2);
				if(row==null) 
				    sheet.createRow(rowNum1);
				
				Row row = sheet.getRow(rowNum1);

				Cell cell = row.getCell(colNumber1);
				Cell cell1 = row.getCell(colNumber2);
				Cell cell2 = row.getCell(colNumber3);
				Cell cell3= row.getCell(colNumber4);

				if(cell==null) 
					cell = row.createCell(colNumber1);
				if(cell1==null)
					cell1 = row.createCell(colNumber2);
				if(cell2==null) 
					cell2 = row.createCell(colNumber3);
				if(cell3==null)
					cell3 = row.createCell(colNumber4);
					
				
				if (cell != null)
				//cell =row.createCell(colNumber);
				cell.setCellValue(value1);
				if (cell1 != null)
				cell1.setCellValue(value2);
				if (cell2 != null)
					cell2.setCellValue(value3);
				if (cell3 != null)
					cell3.setCellValue(value4);

				FileOutputStream fos = new FileOutputStream(FilePath);
				workbook.write(fos);
				fos.close();
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
				return  false;
			}
			return true;
		}
	//write into main test data sheet
		
		public static boolean setCellData4(String FilePath, int colNumber, int rowNum, String value) throws IOException
		{
			FileInputStream fis = new FileInputStream(FilePath);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);

			//Enter Message into Test data Sheet
			try
			{
				Sheet sheet = workbook.getSheetAt(0);
				Row row = sheet.getRow(rowNum);

				Cell cell = row.getCell(colNumber);

				if(cell==null) {
					cell = row.createCell(colNumber);
				}
				
				else {
					
				 row.removeCell(cell);
				}
				cell =row.createCell(colNumber);
				cell.setCellValue(value);

				FileOutputStream fos = new FileOutputStream(FilePath);
				workbook.write(fos);
				fos.close();
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
				return  false;
			}
			return true;
		}


	public void setComparevalues(String ReportFilePath, String Adjusted, String Original, String Result)
			throws IOException, InvalidFormatException {

		File src = new File(ReportFilePath);
		FileInputStream fis = new FileInputStream(src);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet Sheet1 = wb.getSheet(Adjusted);
		XSSFSheet Sheet2 = wb.getSheet(Original);
		XSSFSheet Sheet3 = wb.getSheet(Result);

		int rowLenth = Sheet1.getLastRowNum() - Sheet1.getFirstRowNum();
		//System.out.println("RowLength > "+rowLenth);
		int noOfColumns = Sheet1.getRow(0).getLastCellNum();
		//System.out.println("NoOfColumns > "+noOfColumns);
		// int Col=1;

		int r = 1;

		for (int i = 1; i <=rowLenth; i++) {

			Row row = Sheet3.createRow(r++);
			int c = 0;
			//System.out.println("Row last cell " + row.getLastCellNum());

			for (int j = 1; j<=noOfColumns; j++) {

				StringBuilder columnName = new StringBuilder();

				int columnNumber=j; 
				while (columnNumber > 0) 
				{ 
					int rem = columnNumber % 26;
					if (rem == 0) {
						columnName.append("Z"); 
						columnNumber = (columnNumber / 26) - 1;
					} 
					else { 
						columnName.append((char)((rem - 1) + 'A')); 
						columnNumber = columnNumber / 26; 
					}
				}

				Cell cell = row.createCell(c++);
				CellReference cellReference = new CellReference(cell);
				String thisR = cellReference.getCellRefParts()[1]; 

				//Sub_Mem_Provider
				if (Result=="Comp_Result_Sub_Mem_Prov") {

					if(j==1||j==2||j==noOfColumns) {
						cell.setCellFormula("TRIM("+Adjusted+"!"+columnName.reverse()+""+thisR+" :"+columnName+""+thisR+")");
					}else {
						cell.setCellFormula("IF("+Adjusted+"!"+columnName.reverse()+""+thisR+" :"+columnName+""+thisR+" ="+Original+"!"+columnName+""+thisR+" :"+columnName+""+thisR+",\"Equal\",\"Not Equal\")");
					}

				//Billing Provider
				}else {

					if(j==1) {
						cell.setCellFormula("TRIM("+Adjusted+"!"+columnName.reverse()+""+thisR+" :"+columnName+""+thisR+")");
					}else {
						cell.setCellFormula("IF("+Adjusted+"!"+columnName.reverse()+""+thisR+" :"+columnName+""+thisR+" ="+Original+"!"+columnName+""+thisR+" :"+columnName+""+thisR+",\"Equal\",\"Not Equal\")");
					}

				}

			}
		}

		FileOutputStream fout = new FileOutputStream(src);
		wb.write(fout);
		fout.flush();
		fout.close();

	}

	public static String CategorizeNotes(String ExcelFilePath, String temp, int ClaimID, String Ind_Line_Notes, String All) throws IOException {

		Map<String,String> Combine_Notes = new HashMap<String, String>();
		ArrayList<String> Adding = new ArrayList<String>();
		ArrayList<String> Removing = new ArrayList<String>();
		ArrayList<String> Correcting = new ArrayList<String>();

		String Blank = "";
		String[] Full_Notes = temp.split(",");

		for(String Each_Note : Full_Notes) {

			if(Ind_Line_Notes!=null && !Ind_Line_Notes.contains("ADDING DiagnosisCode")) {
				if(Each_Note.trim().contains("ADDING")){
					String Split_Add[] = Each_Note.trim().split("ADDING");
					Adding.add(Split_Add[1].trim());
				}
			}else {
				if(Each_Note.trim().contains("ADDING")){
					//Remove the two columns when there is diagnosis code in Notes for Add scneario
					if(!(Each_Note.trim().contains("PrimaryDiagnosisCode") || Each_Note.trim().contains("AdditionalDiagCodesIncludesPrimaryCode"))) {
						String Split_Add[] = Each_Note.trim().split("ADDING");
						Adding.add(Split_Add[1].trim());
					}
				}

			}

			if(Each_Note.trim().contains("REMOVING")){
				String Split_Remove[] = Each_Note.trim().split("REMOVING");
				Removing.add(Split_Remove[1].trim());
			}

			if(Each_Note.trim().contains("CORRECTING")){
				String Split_Correct[] = Each_Note.trim().split("CORRECTING");
				Correcting.add(Split_Correct[1].trim());
			}

		}

		//Adding
		String Add_Again = "";
		if(!Adding.isEmpty()) {

			for(String Merge_Add : Adding) {

				if(Add_Again=="") {
					Add_Again = Merge_Add;
				}else {
					Add_Again = Add_Again +", " +Merge_Add;
				}

			}

			Add_Again = "ADDING "+Add_Again;

		}

		//Removing
		String Remove_Again = "";
		if(!Removing.isEmpty()) {

			for(String Merge_Remove : Removing) {

				if(Remove_Again=="") {
					Remove_Again = Merge_Remove;
				}else {
					Remove_Again = Remove_Again + ", "+Merge_Remove;
				}

			}

			Remove_Again = "REMOVING "+Remove_Again;

		}

		//Correcting
		String Correct_Again = "";
		if(!Correcting.isEmpty()) {

			for(String Merge_Correct : Correcting) {

				if(Correct_Again=="") {
					Correct_Again = Merge_Correct;
				}else {
					Correct_Again = Correct_Again + ", "+Merge_Correct;
				}

			}

			Correct_Again = "CORRECTING "+Correct_Again;

		}

		//cell_combNotes.setCellValue(Ind_Line_Notes+", "+All);

		if(!(Add_Again=="")){
			Combine_Notes.put("ADDING", Add_Again);
		}

		if(!(Remove_Again=="")){
			Combine_Notes.put("REMOVING", Remove_Again);
		}

		if(!(Correct_Again=="")){
			Combine_Notes.put("CORRECTING", Correct_Again);
		}

		//Combine All Notes
		if(Combine_Notes.containsKey("ADDING")) {
			Blank = Combine_Notes.get("ADDING");
		}

		if(!(Blank=="")) {

			if(Combine_Notes.containsKey("REMOVING")) {
				Blank = Blank + ", "+Combine_Notes.get("REMOVING");
			}

		}else {

			//Adding condition as it is Returning Null if String 'Blank' is empty
			if(Combine_Notes.containsKey("REMOVING")) {
				Blank = Combine_Notes.get("REMOVING");
			}

		}

		if(!(Blank=="")) {

			if(Combine_Notes.containsKey("CORRECTING")) {
				Blank = Blank + ", "+Combine_Notes.get("CORRECTING");
			}

		}else {
			//Adding condition as it is Returning Null if String 'Blank' is empty
			if(Combine_Notes.containsKey("CORRECTING")) {
				Blank = Combine_Notes.get("CORRECTING");
			}

		}

		//System.out.println(Blank);

		return Blank;

	}

	public static ArrayList<String> ReadResultSheet(String ReportFilePath, String AdjustedSheet, String Result, ArrayList<String> claims) throws IOException {

		String Value = "";
		String ClaimID = "";
		String PayeeInfo = "";
		String ProfBillType = "";
		String Prof_VoidType = "";
		String Freq = "";
		int ClaimID_Column = 0;
		int OtherPayeeCol = 0;
		int FrequencyCol = 0;
		int Prof_BillType_Col = 0;

		File src = new File(ReportFilePath);
		FileInputStream fis = new FileInputStream(src);
		Workbook workbook = new XSSFWorkbook(fis);
		FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
		Sheet sheet = workbook.getSheet(Result);

		int RowCount = sheet.getPhysicalNumberOfRows();

		for (int i = 1; i <= RowCount-1; i++) {

			int count = 0;
			String All = "";

			ArrayList<String> Notes_Txt = new ArrayList<String>();
			Row row = sheet.getRow(i);
			int ColCount = row.getPhysicalNumberOfCells();

			Row row_head = sheet.getRow(0);
			Cell col_head = row_head.createCell(ColCount);
			//col_head.setCellValue("Notes");

			//Get Column Number of Required Fields
			if(i==1) {

				for(int Col=1;Col<=ColCount;Col++) {

					Cell cell = row_head.getCell(Col);

					if(cell.getStringCellValue().trim().equals("ClaimID")) {
						ClaimID_Column = Col;
						break;
					}

				}

				//Get Column Number of OtherPayee Info
				for(int Col=1;Col<=ColCount;Col++) {

					Cell cell = row_head.getCell(Col);

					if(cell.getStringCellValue().trim().equals("OtherPayeeInfo")) {
						OtherPayeeCol = Col;
						break;
					}

				}

				//Get Frequency/PROF_FREQ Column - Insti/Prof Claims
				for(int Col=1;Col<=ColCount;Col++) {

					Cell cell = row_head.getCell(Col);

					if(cell.getStringCellValue().trim().equals("Frequency") || cell.getStringCellValue().trim().equals("PROF_FREQ")) {
						FrequencyCol = Col;
						break;
					}

				}

			}

			//Get Claim ID
			Cell Claim_ID = row.getCell(ClaimID_Column);
			switch (evaluator.evaluateInCell(Claim_ID).getCellType()) {

			case Cell.CELL_TYPE_STRING: 
				ClaimID = Claim_ID.getStringCellValue();
				break;

			}
			
			//Check for Insti claims - void type
			if(AdjustedSheet.equals("Adj_Sub_Mem_Prov") && !(FrequencyCol==0)) {

				Sheet sheet_New = workbook.getSheet(AdjustedSheet);
				Row row_new = sheet_New.getRow(i);

				Cell cell_Freq = row_new.getCell(FrequencyCol);

				switch (evaluator.evaluateInCell(cell_Freq).getCellType()) {

				case Cell.CELL_TYPE_STRING:
					Freq = cell_Freq.getStringCellValue();
					//System.out.println(Freq);

				}

			}

			//Sub, Mem, Provider Query - Validate OtherPayee Info
			if (Result.equals("Comp_Result_Sub_Mem_Prov")) {

				Cell cell_payee = row.getCell(OtherPayeeCol);
				switch (evaluator.evaluateInCell(cell_payee).getCellType()) {

				case Cell.CELL_TYPE_STRING: 
					PayeeInfo = cell_payee.getStringCellValue().toUpperCase();
					break;

				}

			}

			//Skip the Validation if OtherPayeeInfo - 'Y'
			if(!(PayeeInfo.equals("Y"))) {

				//Skip validation if frequency - 8
				if(!(Freq.equals("8"))) {

					for (int j = 0; j <= ColCount-1; j++) {

						Cell cell = row.getCell(j);
						Cell header_txt = row_head.getCell(j);

						switch (evaluator.evaluateInCell(cell).getCellType()) {

						case Cell.CELL_TYPE_STRING: 
							Value = cell.getStringCellValue().trim();
							//System.out.println(Value);
							break;

						}

						//Create Notes as Skipping the Claim if any of the comparison is Returned Not Equal
						String Notes = "";
						col_head.setCellValue("Notes");
						Cell cell_Notes = row.createCell(ColCount);

						if(Value.equals("Not Equal")) {

							count = count+1;
							StringBuilder columnName = new StringBuilder();

							int columnNumber = j+1;

							while (columnNumber > 0) 
							{ 
								int rem = columnNumber % 26;
								if (rem == 0) {
									columnName.append("Z"); 
									columnNumber = (columnNumber / 26) - 1;
								} 
								else { 
									columnName.append((char)((rem - 1) + 'A')); 
									columnNumber = columnNumber / 26; 
								}
							}
							
							//Get Original Claim Data for State and Zip fields
							String FieldHeader = header_txt.getStringCellValue().trim();
							String Org_Field_Value = "";
							if(FieldHeader.equals("SubscriberState") || FieldHeader.equals("sub_STATE") || FieldHeader.equals("sub_ZIP")) {
								
								String OriginalSheet = "Org_Sub_Mem_Prov";
								CellReference cellReference = new CellReference(cell_Notes);
								String thisR = cellReference.getCellRefParts()[1]; 

								//Get the Adjusted value through formula
								StringBuilder ColName =  columnName.reverse();
								cell_Notes.setCellFormula(OriginalSheet+"!"+ColName+""+thisR+" :"+ColName+""+thisR);

								FileOutputStream fout = new FileOutputStream(src);
								workbook.write(fout);
								fout.flush();
								fout.close();
								
								switch (evaluator.evaluateInCell(cell_Notes).getCellType()) {

								case Cell.CELL_TYPE_STRING: 

									Org_Field_Value = cell_Notes.getStringCellValue().trim();

									if(Org_Field_Value.isEmpty()) {
										Org_Field_Value = "Null";
									}

									//Clear the Reference Value from Adjusted Sheet
									cell_Notes.setCellValue("");

									FileOutputStream fclear = new FileOutputStream(src);
									workbook.write(fclear);
									fout.flush();
									fout.close();
									break;

								}
								
							}
							
							//Ignore Validation for Sub_State, sub_Zip fields if original claim value is Blank
							if(!(FieldHeader.equals("SubscriberState") || FieldHeader.equals("sub_STATE") || FieldHeader.equals("sub_ZIP"))) {
								
								if(!(Org_Field_Value.equalsIgnoreCase("Null"))) {
									
									//Remove ClaimID from Array to skip the claim
									claims.remove(ClaimID);
									
									CellReference cellReference = new CellReference(cell_Notes);
									String thisR = cellReference.getCellRefParts()[1]; 

									//Get the Adjusted value through formula
									StringBuilder ColName =  columnName.reverse();
									cell_Notes.setCellFormula(AdjustedSheet+"!"+ColName+""+thisR+" :"+ColName+""+thisR);

									FileOutputStream fout = new FileOutputStream(src);
									workbook.write(fout);
									fout.flush();
									fout.close();

									Notes = "";
									switch (evaluator.evaluateInCell(cell_Notes).getCellType()) {

									case Cell.CELL_TYPE_STRING: 

										String ChangeInValue = cell_Notes.getStringCellValue().trim();

										if(ChangeInValue=="") {
											ChangeInValue = "Null";
											Notes = header_txt.getStringCellValue()+": "+ChangeInValue;
										}else {
											Notes = header_txt.getStringCellValue()+": "+ChangeInValue;
										}

										//Clear the Reference Value from Adjusted Sheet
										cell_Notes.setCellValue("");

										FileOutputStream fclear = new FileOutputStream(src);
										workbook.write(fclear);
										fout.flush();
										fout.close();
										break;

										//System.out.println(Notes);

									}

									//Get the Differences in Each Column of Claim into Array - For which Comparison returned Not Equal
									Notes_Txt.add(Notes);
									
								}
								
							}

						}

						//Enter Notes
						if(j==ColCount-1) {

							for (String EachCell : Notes_Txt) {

								if (All=="") {
									All = EachCell;
								}else {
									All = All+", "+EachCell;
								}

								//System.out.println(All);
							}

							if (All!="") {

								if(Result.contains("BillProvider")) {
									cell_Notes.setCellValue("Skipping the claim due to the change in Billing Provider Information - "+All);
								}else {
									cell_Notes.setCellValue("Skipping the claim due to the change in Subscriber/Member/RenderingProvider Information - "+All);
								}

							}else {
								cell_Notes.setCellValue("");
							}

						}

					}

				}else {

					Cell cell_Notes = row.createCell(ColCount);
					cell_Notes.setCellValue("Skipping as the claim is void with Frequency 8");
					claims.remove(ClaimID);

				}

			}else {

				Cell cell_Notes = row.createCell(ColCount);
				cell_Notes.setCellValue("Skipping the claim as Otherpayeeid value is Y");
				claims.remove(ClaimID);

			}

		}

		FileOutputStream fout = new FileOutputStream(src);
		workbook.write(fout);
		fout.flush();
		fout.close();

		return claims;

	}
		

	public void setCellActualData(String ReportFilePath,int DBrowsize, String columnName, String value, int count) throws IOException 
	{

		File src = new File(ReportFilePath);
		FileInputStream fis = new FileInputStream(src);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet Sheet1 = wb.getSheet("DB_OutputActual");

		int rowLenth = Sheet1.getLastRowNum() - Sheet1.getFirstRowNum();
		int r=1;
		int c=0;
		// String value = object.toString();
		for (int i = 1; i < rowLenth; i++) {
			Row row = Sheet1.createRow(r++);
			for (int j = 1; j < DBrowsize; j++) {
				//if (row.getCell(i).getStringCellValue().equalsIgnoreCase(columnName)) {


				row = Sheet1.createRow(r++);

				Cell cell = row.createCell(c++);
				cell = row.getCell(j);
				if(cell == null)
					cell = row.createCell(j);

				cell.setCellValue(value);
				System.out.println(value);
				//Sheet1.getRow(i).createCell(count++).setCellValue(object.toString());

			}

		}
		//}
		FileOutputStream fout = new FileOutputStream(src);
		wb.write(fout);
		fout.flush();
		fout.close();
	}


	public String TextFilename(String filename)throws Exception
	{
		String Query=null;
		/*File file = new File(filename);

	  BufferedReader br = new BufferedReader(new FileReader(file));

	  String st;
	  while ((st = br.readLine()) != null)
	   // System.out.println(st);
	  Query=st;
	  System.out.println(Query);*/
		String content = new String(Files.readAllBytes(Paths.get(filename)), StandardCharsets.UTF_8);
		return content;
	}

	//Read cell data from the excel sheet
	public static String ReadCellData(String ReportFilePath,String SheetName,int vRow, int vColumn) throws IOException  
	{  

		String value = null;           
		FileInputStream fis=new FileInputStream(ReportFilePath);  
		Workbook wb = new XSSFWorkbook(fis);  

		Sheet sheet=wb.getSheet(SheetName);  
		Row row=sheet.getRow(vRow); 

		Cell cell=row.getCell(vColumn); 
		if(!(cell==null)) {
			value=cell.getStringCellValue().trim();
		}else {
			value = "";
		}

		return value;    

	}
	
	
	public static String ReadCellData_Date(String ReportFilePath,String SheetName,int vRow, int vColumn) throws IOException  

	{  

		FileInputStream fis=new FileInputStream(ReportFilePath);  
		Workbook wb = new XSSFWorkbook(fis);  

		//FormulaEvaluator evaluator = wb.getCreationHelper().createFormulaEvaluator();
		Sheet sheet=wb.getSheet(SheetName);  
		Row row=sheet.getRow(vRow); 

		Cell cell=row.getCell(vColumn);

		//getting the cell representing the given column 
		Date date = HSSFDateUtil.getJavaDate(cell.getNumericCellValue()); 
		//int value=(int) cell.getNumericCellValue();   //getting cell value 

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyy");
		String myDateString = simpleDateFormat.format(date);
		return myDateString;                

	}



}





