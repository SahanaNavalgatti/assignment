package org.bcbsri.selfservice.cmd_prompt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

//import org.bcbsri.selfservice.commonMethods.UtilMethod;

import com.dell.acoe.framework.config.Environment;

public class Testrunner {

	public static void launchRunner(String files_path,String endpoint,String xmlFile,String testSuite, String testCase) {
	
		
		testdatapath = Environment.get("test_data_path")+"/"+env+"/"+testfilename+".xls";
		
		//testdatapath = "C:\\Users\\svc-user-auto\\Documents\\selfserviceautomation\\SelfService\\resources\\testdata\\claimsTestData\\Claims.xls";
		String[] command =
	    {
	        "cmd",
	    };
	    Process p;{
		try {
			p = Runtime.getRuntime().exec(command);
		        new Thread(new SyncPipe(p.getErrorStream(), System.err)).start();
	                new Thread(new SyncPipe(p.getInputStream(), System.out)).start();
	                PrintWriter stdin = new PrintWriter(p.getOutputStream());
	                stdin.println("cd /d C:\\Windows");
	                //stdin.println("cd C:\\Program Files (x86)\\SmartBear\\SoapUI-5.5.0\\bin");
	                //stdin.println("cd C:\\Program Files\\SmartBear\\SoapUI-5.5.0\\SoapUI-5.5.0\\bin");
					stdin.println("cd C:\\Users\\svc-user-auto\\Documents\\SmartBear\\SoapUI-5.5.0\\bin");
	                
	                //stdin.println("cd C:\\Users\\A152TSO\\OneDrive - Blue Cross and Blue Shield of Rhode Island\\Jars\\Documents\\SoapUI-5.5.0\\bin");
	                //stdin.println("testrunner.bat -e"+endpoint+" -s"+testSuite+" -c"+testCase+" -r -a -I -f"+files_path+" "+"-Ptestdatapath="+testdatapath+" "+xmlFile+"");
	                //stdin.println("testrunner.bat -e"+endpoint+" -s"+testSuite+" -c"+testCase+" -r -a -I -f"+files_path+" "+xmlFile+"");
	                stdin.println("testrunner.bat -sDataSetUp -cDataEntry -r -a -I "+xmlFile+"");
	                stdin.close();
	                p.waitFor();
	               
	              
	    	} catch (Exception e) {
	 		
		}
		//return path;
}
}
}

