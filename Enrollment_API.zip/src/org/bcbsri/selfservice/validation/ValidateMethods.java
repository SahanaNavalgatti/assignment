package org.bcbsri.selfservice.validation;

import java.io.File;
import java.io.IOException;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.http.protocol.ExecutionContext;
import org.bcbsri.selfservice.commonMethods.ByteStreamConverter;
import org.bcbsri.selfservice.commonMethods.PDFValidation;
import org.bcbsri.selfservice.commonMethods.UtilMethod;
import org.bcbsri.selfservice.dbutility.ViewClaimsDBS;
import org.json.XML;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.selenium.testdata.DataTable1;
import com.dell.acoe.framework.selenium.verify.Assert;
import com.eviware.soapui.model.iface.Response;

import lombok.ToString;

import org.bcbsri.selfservice.commonMethods.UtilMethod;;

public class ValidateMethods {

	static JSONParser jsonparser = new JSONParser();

	/**
	 * This method is used to validate the JSON data and DB data of ViewClaims
	 * service
	 * 
	 * @param content
	 *            = JSON response data
	 * @param testID
	 *            = TestCase ID
	 * @throws Exception
	 */

	public static void validateViewClaims(String content, String testID, String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";
		DataTable1 Dttestdata = new DataTable1(testdir + "Claims.xls", "GetClaims_Input1", "" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		//String ReportFilePath = Environment.get("GetClaims_ExcelReport_Path");
		
		String ReportFilePath = "";
		if(Environment.get("Jenkins_Run").equalsIgnoreCase("Yes")) {
		String excelName = Environment.get("GetClaims_XML");		
		String excelReportName = excelName.replace(".xml", ".xslx");
		 ReportFilePath = Environment.get("report_path")+"//"+excelReportName;
		}
		else {
		 ReportFilePath = Environment.get("GetClaims_ExcelReport_Path");
		}
		if (content.contains("errorCode")) {
			errorflag = false;
		} else {
			validateflag = true;
		}
		if (validateflag) {
			Object obj = jsonparser.parse(content);
			JSONObject ClaimObj = (JSONObject) obj;

			String inputtestID = Dttestdata.getValue("TestID");
			String testDesc = Dttestdata.getValue("Test_Description");
			String subscriberID = Dttestdata.getValue("SubscriberID");
			String dependentID = Dttestdata.getValue("DependentID");
			String claimType = Dttestdata.getValue("ClaimType");
			String claimNum = Dttestdata.getValue("ClaimNum");
			String claimVersion = Dttestdata.getValue("ClaimVersion");
			String sensitiveClaimFlag = Dttestdata.getValue("SensitiveClaimFlag");
			String strQuery = "";
			String claimLineDetailsQuery = "";
			try {
				Assert.done("Test ID: " + inputtestID);
				Assert.done("Test Description: " + testDesc);

				if (!(claimType.equalsIgnoreCase("P"))) {
					if (!(sensitiveClaimFlag.equalsIgnoreCase(""))) {

						strQuery = "SELECT DISTINCT MP.SUBSCRIBER_ID AS subscriberID , MP.DEPENDENT_ID AS dependentID,MCS.CLAIM_TYPE_CODE AS claimType, CTR.CLAIM_TYPE_DESC AS claimTypeDesc ,MCS.PROCESSED_STATUS_CODE AS statusCode , MCS.SOURCE_CLAIM_ID AS claimNumber, MCS.IS_SENSITIVE_CLAIM AS sensitiveClaimInfoFlag, MCS.VERSION_NUMBER AS claimVersionAdjudicationLevel, MCS.VERSION_NUMBER AS numberofClaimIterations, MCS.CLAIM_ADJUDICATED_DATE AS processDate, MCS.SERVICE_FROM_DATE AS serviceFromDate ,MCS.SERVICE_TO_DATE AS serviceToDate ,MCS.LEGACY_CLAIM_REC_ID AS prescriptionNumber, SUM(MCS.TOTAL_BILLED_AMOUNT) AS claimAmountBilled, SUM(MCD.NETWORK_DISCOUNT) AS claimDiscount , SUM(MCD.ALLOWED_AMOUNT) AS claimAmountAllowed, SUM(MCD.AMOUNT_PAID) AS claimAmountCovered,  SUM(MCD.COPAY_AMOUNT) AS claimCopay , SUM(MCD.COINSURANCE_AMOUNT) AS claimCoinsurance ,  SUM(MCD.DEDUCTIBLE_AMOUNT) AS claimDeductible, SUM(MCD.OTHER_AMOUNT_PAYABLE) AS claimOther  ,  MCS.TOTAL_MEMBER_LIABILITY AS claimMemberLiability,  CASE WHEN MCD.PAID_DENIED_IND = 'P' THEN SUM(MCD.ORIGINAL_BILL_AMOUNT ) ELSE 0 END  AS totalApprovedServicesAmountBilled,  CASE WHEN MCD.PAID_DENIED_IND = 'P' THEN SUM(MCD.ALLOWED_AMOUNT)  ELSE 0 END AS totalApprovedServicesAmountAllowed,  CASE WHEN MCD.PAID_DENIED_IND = 'P'  THEN SUM(MCD.AMOUNT_PAID) ELSE 0 END AS totalApprovedServicesPlanPaid,  CASE WHEN MCD.PAID_DENIED_IND = 'P'  THEN SUM(MCD.TOTAL_MEMBER_LIABILITY )ELSE 0 END AS totalApprovedServicesMemberLiability,  CASE WHEN MCD.PAID_DENIED_IND = 'D' THEN  SUM(MCD.ORIGINAL_BILL_AMOUNT) ELSE 0 END  AS totalDeniedServicesAmountBilled,  CASE WHEN MCD.PAID_DENIED_IND = 'D'  THEN SUM(MCD.PROVIDER_LIABILITY_AMOUNT ) ELSE 0 END AS totalDeniedServicesProviderLiability,  CASE WHEN MCD.PAID_DENIED_IND = 'D' THEN SUM(MCD.TOTAL_MEMBER_LIABILITY) ELSE  0  END AS totalDeniedServicesMemberLiability,  PP.LEGACY_PROV_ID AS providerID, PP.LAST_NAME  AS providerLastName ,PP.FIRST_NAME  AS providerFirstName , PP.PROVIDER_SPECIALITY_CODE  AS providerSpeciality ,PTR.provider_type_desc AS providerTypeDescription , PP.LAST_NAME  AS providerGroupName,PA.PROVIDER_STREET_ADDRESS1 AS providerAddressStreet1,  PA.PROVIDER_STREET_ADDRESS2 AS providerAddressStreet2, PA.PROVIDER_STREET_ADDRESS3  AS providerAddressStreet3,PA.PROVIDER_CITY_NAME AS providerAddressCity,PA.PROVIDER_STATE_CODE  AS providerAddressState ,PA.PROVIDER_ZIP_CODE AS providerAddressZipCode , pharmacyName = (CASE WHEN (PHP.PHARMACY_NAME IS NULL ) THEN '' ELSE  PHP.PHARMACY_NAME END), pharmacyAddress = (CASE WHEN (PHP.PHARMACY_ADDRESS IS NULL ) THEN '' ELSE PHP.PHARMACY_ADDRESS END), pharmacyCity = (CASE WHEN (PHP.PHARMACY_CITY IS NULL ) THEN '' ELSE PHP.PHARMACY_CITY  END), pharmacyStateCode = (CASE WHEN (PHP.PHARMACY_STATE_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_STATE_CODE  END), pharmacyZipCode = (CASE WHEN (PHP.PHARMACY_ZIP_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_ZIP_CODE  END), eOBAvailableIndicator = (CASE WHEN (MCS.EOB_AVAILABLE_FLAG IS NULL ) THEN '' ELSE MCS.EOB_AVAILABLE_FLAG  END), eOBKey = (CASE WHEN (MCS.EOB_LINK IS NULL ) THEN '' ELSE MCS.EOB_LINK  END)  FROM SS_SQL.MEMBER_PROFILE MP  INNER JOIN SS_SQL.MEMBER_CLAIMS_SUMMARY MCS ON MP.MEMBER_PROFILE_ID=MCS.MEMBER_PROFILE_ID  INNER JOIN SS_SQL.MEMBER_CLAIM_DETAIL MCD  ON MCS.CLAIM_SUMMARY_ID=MCD.CLAIMS_SUMMARY_ID   INNER JOIN SS_SQL.PROVIDER_ADDRESSES PA ON MCS.PROVIDER_PROFILE_ID=PA.PROVIDER_PROFILE_ID  INNER JOIN SS_SQL.PROVIDER_PROFILE PP ON PA.PROVIDER_PROFILE_ID=PP.PROVIDER_PROFILE_ID  INNER JOIN SS_SQL.PROVIDER_TYPE_REF PTR ON PP.PROVIDER_TYPE_CODE=PTR.provider_type_code  INNER JOIN SS_SQL.CLAIM_TYPE_REF CTR ON MCS.CLAIM_TYPE_CODE=CTR.CLAIM_TYPE_CODE LEFT JOIN SS_SQL.PHARMACY_PROFILES PHP ON MCS.PHARMACY_PROFILE_ID=PHP.PHARMACY_PROFILE_ID	WHERE  MCS.SOURCE_CLAIM_ID = '"
								+ claimNum + "'  AND MP.SUBSCRIBER_ID = '" + subscriberID + "'  AND MP.DEPENDENT_ID = '"
								+ dependentID + "' AND MCS.CLAIM_TYPE_CODE in ('" + claimType
								+ "') AND MCS.VERSION_NUMBER = '" + claimVersion + "'  AND MCS.IS_SENSITIVE_CLAIM = '"
								+ sensitiveClaimFlag
								+ "' GROUP BY MCD.PAID_DENIED_IND, SUBSCRIBER_ID,DEPENDENT_ID,MCS.CLAIM_TYPE_CODE,SOURCE_CLAIM_ID,MCS.IS_SENSITIVE_CLAIM, MCS.VERSION_NUMBER,MCS.VERSION_NUMBER, MCS.TOTAL_BILLED_AMOUNT,CTR.CLAIM_TYPE_DESC, MCS.PROCESSED_STATUS_CODE,MCS.SERVICE_FROM_DATE,MCS.SERVICE_TO_DATE, MCS.CLAIM_ADJUDICATED_DATE,MCS.LEGACY_CLAIM_REC_ID, MCS.TOTAL_MEMBER_LIABILITY,PP.LEGACY_PROV_ID,PP.LAST_NAME, PP.FIRST_NAME,PP.PROVIDER_SPECIALITY_CODE,PTR.provider_type_desc,PP.LAST_NAME,PA.PROVIDER_STREET_ADDRESS1, PA.PROVIDER_STREET_ADDRESS2,PA.PROVIDER_STREET_ADDRESS3,PA.PROVIDER_CITY_NAME,PA.PROVIDER_STATE_CODE, PA.PROVIDER_ZIP_CODE,MCD.ORIGINAL_BILL_AMOUNT , PHP.PHARMACY_NAME , PHP.PHARMACY_ADDRESS , PHP.PHARMACY_CITY ,PHP.PHARMACY_STATE_CODE  , PHP.PHARMACY_ZIP_CODE , MCS.EOB_AVAILABLE_FLAG , MCS.EOB_LINK";

						claimLineDetailsQuery = "SELECT DISTINCT MCD.LINE_ID AS claimLineNumber,pharmacyQuantity = (CASE WHEN MCD.QUANTITY_PRESCRIBED IS  NULL THEN '' ELSE MCD.QUANTITY_PRESCRIBED END), MCD.CLAIM_LINE_CODE AS claimLineServiceCode , MCD.CLAIM_LINE_DESCRIPTION AS claimLineServiceDescription ,MCS.SERVICE_FROM_DATE AS claimLineServiceFromDate, MCS.SERVICE_TO_DATE AS claimLineServiceToDate, MCD.ORIGINAL_BILL_AMOUNT AS claimLineAmountBilled, MCD.NETWORK_DISCOUNT AS claimLineDiscount , MCD.ALLOWED_AMOUNT AS claimLineAmountAllowed, MCD.AMOUNT_PAID AS claimLineAmountCovered, MCD.COPAY_AMOUNT AS claimLineCopay , MCD.COINSURANCE_AMOUNT AS claimLineCoinsurance , MCD.DEDUCTIBLE_AMOUNT AS claimLineDeductible, MCD.OTHER_AMOUNT_PAYABLE AS claimLineOther, RCR.REASON_CODE AS claimLineReasonCode , RCR.REASON_CODE_DESC AS claimLineReasonCodeDescription, MCD.LIABILITY_INDICATOR AS liabilityCode,MCD.LIABILITY_INDICATOR AS liabilityCode , MCD.PAID_DENIED_IND AS paidDeniedIndicator ,MCD.TOTAL_MEMBER_LIABILITY AS totalMemberLiability ,MCD.PROVIDER_LIABILITY_AMOUNT AS providerLiabilityAmount,MCD.MEMBER_DENIED_AMOUNT AS memberDeniedAmount FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN SS_SQL.MEMBER_CLAIMS_SUMMARY MCS ON MP.MEMBER_PROFILE_ID=MCS.MEMBER_PROFILE_ID INNER JOIN SS_SQL.MEMBER_CLAIM_DETAIL MCD ON MCS.CLAIM_SUMMARY_ID=MCD.CLAIMS_SUMMARY_ID INNER JOIN SS_SQL.MEMBER_CLAIM_REASONS MCR ON MCD.CLAIM_ID=MCR.CLAIM_ID INNER JOIN SS_SQL.REASON_CODE_REFS RCR ON MCR.REASON_ID=RCR.REASON_ID  WHERE  MCS.SOURCE_CLAIM_ID = '"
								+ claimNum + "'  AND MP.SUBSCRIBER_ID = '" + subscriberID + "'  AND MP.DEPENDENT_ID = '"
								+ dependentID + "' AND MCS.CLAIM_TYPE_CODE in ('" + claimType
								+ "') AND MCS.VERSION_NUMBER = '" + claimVersion + "'  AND MCS.IS_SENSITIVE_CLAIM = '"
								+ sensitiveClaimFlag + "' ORDER BY MCD.LINE_ID";
					}

					else {
						strQuery = "SELECT DISTINCT MP.SUBSCRIBER_ID AS subscriberID , MP.DEPENDENT_ID AS dependentID,MCS.CLAIM_TYPE_CODE AS claimType, CTR.CLAIM_TYPE_DESC AS claimTypeDesc ,MCS.PROCESSED_STATUS_CODE AS statusCode , MCS.SOURCE_CLAIM_ID AS claimNumber, MCS.IS_SENSITIVE_CLAIM AS sensitiveClaimInfoFlag, MCS.VERSION_NUMBER AS claimVersionAdjudicationLevel, MCS.VERSION_NUMBER AS numberofClaimIterations, MCS.CLAIM_ADJUDICATED_DATE AS processDate, MCS.SERVICE_FROM_DATE AS serviceFromDate ,MCS.SERVICE_TO_DATE AS serviceToDate ,MCS.LEGACY_CLAIM_REC_ID AS prescriptionNumber, SUM(MCS.TOTAL_BILLED_AMOUNT) AS claimAmountBilled, SUM(MCD.NETWORK_DISCOUNT) AS claimDiscount , SUM(MCD.ALLOWED_AMOUNT) AS claimAmountAllowed, SUM(MCD.AMOUNT_PAID) AS claimAmountCovered, SUM(MCD.COPAY_AMOUNT) AS claimCopay , SUM(MCD.COINSURANCE_AMOUNT) AS claimCoinsurance , SUM(MCD.DEDUCTIBLE_AMOUNT) AS claimDeductible, SUM(MCD.OTHER_AMOUNT_PAYABLE) AS claimOther  , MCS.TOTAL_MEMBER_LIABILITY AS claimMemberLiability, CASE WHEN MCD.PAID_DENIED_IND = 'P' THEN SUM(MCD.ORIGINAL_BILL_AMOUNT ) ELSE 0 END AS totalApprovedServicesAmountBilled, CASE WHEN MCD.PAID_DENIED_IND = 'P' THEN SUM(MCD.ALLOWED_AMOUNT) ELSE 0 END AS totalApprovedServicesAmountAllowed, CASE WHEN MCD.PAID_DENIED_IND = 'P' THEN SUM(MCD.AMOUNT_PAID) ELSE 0 END AS totalApprovedServicesPlanPaid, CASE WHEN MCD.PAID_DENIED_IND = 'P' THEN SUM(MCD.TOTAL_MEMBER_LIABILITY )ELSE 0 END AS totalApprovedServicesMemberLiability, CASE WHEN MCD.PAID_DENIED_IND = 'D' THEN  SUM(MCD.ORIGINAL_BILL_AMOUNT) ELSE 0 END AS totalDeniedServicesAmountBilled, CASE WHEN MCD.PAID_DENIED_IND = 'D' THEN SUM(MCD.PROVIDER_LIABILITY_AMOUNT ) ELSE 0 END AS totalDeniedServicesProviderLiability, CASE WHEN MCD.PAID_DENIED_IND = 'D' THEN SUM(MCD.TOTAL_MEMBER_LIABILITY) ELSE  0 END AS totalDeniedServicesMemberLiability, PP.LEGACY_PROV_ID AS providerID, PP.LAST_NAME AS providerLastName ,PP.FIRST_NAME AS providerFirstName , PP.PROVIDER_SPECIALITY_CODE AS providerSpeciality ,PTR.provider_type_desc AS providerTypeDescription , PP.LAST_NAME AS providerGroupName,PA.PROVIDER_STREET_ADDRESS1 AS providerAddressStreet1, PA.PROVIDER_STREET_ADDRESS2 AS providerAddressStreet2, PA.PROVIDER_STREET_ADDRESS3 AS providerAddressStreet3,PA.PROVIDER_CITY_NAME AS providerAddressCity,PA.PROVIDER_STATE_CODE AS providerAddressState ,PA.PROVIDER_ZIP_CODE AS providerAddressZipCode  ,pharmacyName = (CASE WHEN (PHP.PHARMACY_NAME IS NULL ) THEN '' ELSE  PHP.PHARMACY_NAME END), pharmacyAddress = (CASE WHEN (PHP.PHARMACY_ADDRESS IS NULL ) THEN '' ELSE PHP.PHARMACY_ADDRESS END), pharmacyCity = (CASE WHEN (PHP.PHARMACY_CITY IS NULL ) THEN '' ELSE PHP.PHARMACY_CITY  END), pharmacyStateCode = (CASE WHEN (PHP.PHARMACY_STATE_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_STATE_CODE  END), pharmacyZipCode = (CASE WHEN (PHP.PHARMACY_ZIP_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_ZIP_CODE  END),  eOBAvailableIndicator = (CASE WHEN (MCS.EOB_AVAILABLE_FLAG IS NULL ) THEN '' ELSE MCS.EOB_AVAILABLE_FLAG  END), eOBKey = (CASE WHEN (MCS.EOB_LINK IS NULL ) THEN '' ELSE MCS.EOB_LINK  END)  FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN SS_SQL.MEMBER_CLAIMS_SUMMARY MCS ON MP.MEMBER_PROFILE_ID=MCS.MEMBER_PROFILE_ID INNER JOIN SS_SQL.MEMBER_CLAIM_DETAIL MCD ON MCS.CLAIM_SUMMARY_ID=MCD.CLAIMS_SUMMARY_ID INNER JOIN SS_SQL.MEMBER_CLAIM_REASONS MCR ON MCD.CLAIM_ID=MCR.CLAIM_ID INNER JOIN SS_SQL.REASON_CODE_REFS RCR ON MCR.REASON_ID=RCR.REASON_ID INNER JOIN SS_SQL.PROVIDER_ADDRESSES PA ON MCS.PROVIDER_PROFILE_ID=PA.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_PROFILE PP ON PA.PROVIDER_PROFILE_ID=PP.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_TYPE_REF PTR ON PP.PROVIDER_TYPE_CODE=PTR.provider_type_code INNER JOIN SS_SQL.CLAIM_TYPE_REF CTR ON MCS.CLAIM_TYPE_CODE=CTR.CLAIM_TYPE_CODE LEFT JOIN SS_SQL.PHARMACY_PROFILES PHP ON MCS.PHARMACY_PROFILE_ID=PHP.PHARMACY_PROFILE_ID  WHERE  MCS.SOURCE_CLAIM_ID = '"
								+ claimNum + "'  AND MP.SUBSCRIBER_ID = '" + subscriberID + "'  AND MP.DEPENDENT_ID = '"
								+ dependentID + "' AND MCS.CLAIM_TYPE_CODE in ('" + claimType
								+ "') AND MCS.VERSION_NUMBER = '" + claimVersion
								+ "'  GROUP BY MCD.PAID_DENIED_IND, SUBSCRIBER_ID,DEPENDENT_ID,MCS.CLAIM_TYPE_CODE,SOURCE_CLAIM_ID,MCS.IS_SENSITIVE_CLAIM, MCS.VERSION_NUMBER,MCS.VERSION_NUMBER, MCS.TOTAL_BILLED_AMOUNT,CTR.CLAIM_TYPE_DESC, MCS.PROCESSED_STATUS_CODE,MCS.SERVICE_FROM_DATE,MCS.SERVICE_TO_DATE, MCS.CLAIM_ADJUDICATED_DATE,MCS.LEGACY_CLAIM_REC_ID, MCS.TOTAL_MEMBER_LIABILITY,PP.LEGACY_PROV_ID,PP.LAST_NAME, PP.FIRST_NAME,PP.PROVIDER_SPECIALITY_CODE,PTR.provider_type_desc,PP.LAST_NAME,PA.PROVIDER_STREET_ADDRESS1, PA.PROVIDER_STREET_ADDRESS2,PA.PROVIDER_STREET_ADDRESS3,PA.PROVIDER_CITY_NAME,PA.PROVIDER_STATE_CODE, PA.PROVIDER_ZIP_CODE,MCD.ORIGINAL_BILL_AMOUNT ,PHP.PHARMACY_NAME , PHP.PHARMACY_ADDRESS , PHP.PHARMACY_CITY ,PHP.PHARMACY_STATE_CODE  , PHP.PHARMACY_ZIP_CODE , MCS.EOB_AVAILABLE_FLAG , MCS.EOB_LINK";

						claimLineDetailsQuery = "SELECT  DISTINCT MCD.LINE_ID AS claimLineNumber,pharmacyQuantity = (CASE WHEN MCD.QUANTITY_PRESCRIBED IS  NULL THEN '' ELSE MCD.QUANTITY_PRESCRIBED END), MCD.CLAIM_LINE_CODE AS claimLineServiceCode , MCD.CLAIM_LINE_DESCRIPTION AS claimLineServiceDescription ,MCS.SERVICE_FROM_DATE AS claimLineServiceFromDate, MCS.SERVICE_TO_DATE AS claimLineServiceToDate, MCD.ORIGINAL_BILL_AMOUNT AS claimLineAmountBilled, MCD.NETWORK_DISCOUNT AS claimLineDiscount , MCD.ALLOWED_AMOUNT AS claimLineAmountAllowed, MCD.AMOUNT_PAID AS claimLineAmountCovered, MCD.COPAY_AMOUNT AS claimLineCopay , MCD.COINSURANCE_AMOUNT AS claimLineCoinsurance , MCD.DEDUCTIBLE_AMOUNT AS claimLineDeductible, MCD.OTHER_AMOUNT_PAYABLE AS claimLineOther, RCR.REASON_CODE AS claimLineReasonCode , RCR.REASON_CODE_DESC AS claimLineReasonCodeDescription, MCD.LIABILITY_INDICATOR AS liabilityCode,MCD.LIABILITY_INDICATOR AS liabilityCode , MCD.PAID_DENIED_IND AS paidDeniedIndicator ,MCD.TOTAL_MEMBER_LIABILITY AS totalMemberLiability ,MCD.PROVIDER_LIABILITY_AMOUNT AS providerLiabilityAmount,MCD.MEMBER_DENIED_AMOUNT AS memberDeniedAmount FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN SS_SQL.MEMBER_CLAIMS_SUMMARY MCS ON MP.MEMBER_PROFILE_ID=MCS.MEMBER_PROFILE_ID INNER JOIN SS_SQL.MEMBER_CLAIM_DETAIL MCD ON MCS.CLAIM_SUMMARY_ID=MCD.CLAIMS_SUMMARY_ID INNER JOIN SS_SQL.MEMBER_CLAIM_REASONS MCR ON MCD.CLAIM_ID=MCR.CLAIM_ID INNER JOIN SS_SQL.REASON_CODE_REFS RCR ON MCR.REASON_ID=RCR.REASON_ID  WHERE  MCS.SOURCE_CLAIM_ID = '"
								+ claimNum + "'  AND MP.SUBSCRIBER_ID = '" + subscriberID + "'  AND MP.DEPENDENT_ID = '"
								+ dependentID + "' AND MCS.CLAIM_TYPE_CODE in ('" + claimType
								+ "') AND MCS.VERSION_NUMBER = '" + claimVersion + "' ORDER BY MCD.LINE_ID";

					}
				} else {
					strQuery = "SELECT DISTINCT MP.SUBSCRIBER_ID AS subscriberID , MP.DEPENDENT_ID AS dependentID,MCS.CLAIM_TYPE_CODE AS claimType, CTR.CLAIM_TYPE_DESC AS claimTypeDesc ,MCS.PROCESSED_STATUS_CODE AS statusCode , MCS.SOURCE_CLAIM_ID AS claimNumber, MCS.IS_SENSITIVE_CLAIM AS sensitiveClaimInfoFlag, MCS.VERSION_NUMBER AS claimVersionAdjudicationLevel, MCS.VERSION_NUMBER AS numberofClaimIterations, MCS.CLAIM_ADJUDICATED_DATE AS processDate, MCS.SERVICE_FROM_DATE AS serviceFromDate ,MCS.SERVICE_TO_DATE AS serviceToDate ,MCS.LEGACY_CLAIM_REC_ID AS prescriptionNumber, SUM(MCS.TOTAL_BILLED_AMOUNT) AS claimAmountBilled, SUM(MCD.NETWORK_DISCOUNT) AS claimDiscount , SUM(MCD.ALLOWED_AMOUNT) AS claimAmountAllowed, SUM(MCD.AMOUNT_PAID) AS claimAmountCovered, SUM(MCD.COPAY_AMOUNT) AS claimCopay , SUM(MCD.COINSURANCE_AMOUNT) AS claimCoinsurance , SUM(MCD.DEDUCTIBLE_AMOUNT) AS claimDeductible, SUM(MCD.OTHER_AMOUNT_PAYABLE) AS claimOther  , MCS.TOTAL_MEMBER_LIABILITY AS claimMemberLiability, CASE WHEN MCD.PAID_DENIED_IND = 'P' THEN SUM(MCD.ORIGINAL_BILL_AMOUNT ) ELSE 0 END AS totalApprovedServicesAmountBilled, CASE WHEN MCD.PAID_DENIED_IND = 'P' THEN SUM(MCD.ALLOWED_AMOUNT) ELSE 0 END AS totalApprovedServicesAmountAllowed, CASE WHEN MCD.PAID_DENIED_IND = 'P' THEN SUM(MCD.AMOUNT_PAID) ELSE 0 END AS totalApprovedServicesPlanPaid, CASE WHEN MCD.PAID_DENIED_IND = 'P' THEN SUM(MCD.TOTAL_MEMBER_LIABILITY )ELSE 0 END AS totalApprovedServicesMemberLiability, CASE WHEN MCD.PAID_DENIED_IND = 'D' THEN  SUM(MCD.ORIGINAL_BILL_AMOUNT) ELSE 0 END AS totalDeniedServicesAmountBilled, CASE WHEN MCD.PAID_DENIED_IND = 'D' THEN SUM(MCD.PROVIDER_LIABILITY_AMOUNT ) ELSE 0 END AS totalDeniedServicesProviderLiability, CASE WHEN MCD.PAID_DENIED_IND = 'D' THEN SUM(MCD.TOTAL_MEMBER_LIABILITY) ELSE  0 END AS totalDeniedServicesMemberLiability, PP.LEGACY_PROV_ID AS providerID, PP.LAST_NAME AS providerLastName ,PP.FIRST_NAME AS providerFirstName , PP.PROVIDER_SPECIALITY_CODE AS providerSpeciality ,PTR.provider_type_desc AS providerTypeDescription , PP.LAST_NAME AS providerGroupName,PA.PROVIDER_STREET_ADDRESS1 AS providerAddressStreet1, PA.PROVIDER_STREET_ADDRESS2 AS providerAddressStreet2, PA.PROVIDER_STREET_ADDRESS3 AS providerAddressStreet3,PA.PROVIDER_CITY_NAME AS providerAddressCity,PA.PROVIDER_STATE_CODE AS providerAddressState ,PA.PROVIDER_ZIP_CODE AS providerAddressZipCode , pharmacyName = (CASE WHEN (PHP.PHARMACY_NAME IS NULL ) THEN '' ELSE  PHP.PHARMACY_NAME END), pharmacyAddress = (CASE WHEN (PHP.PHARMACY_ADDRESS IS NULL ) THEN '' ELSE PHP.PHARMACY_ADDRESS  END), pharmacyCity = (CASE WHEN (PHP.PHARMACY_CITY IS NULL ) THEN '' ELSE PHP.PHARMACY_CITY  END), pharmacyStateCode = (CASE WHEN (PHP.PHARMACY_STATE_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_STATE_CODE  END), pharmacyZipCode = (CASE WHEN (PHP.PHARMACY_ZIP_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_ZIP_CODE  END), eOBAvailableIndicator = (CASE WHEN (MCS.EOB_AVAILABLE_FLAG IS NULL ) THEN '' ELSE MCS.EOB_AVAILABLE_FLAG  END), eOBKey = (CASE WHEN (MCS.EOB_LINK IS NULL ) THEN '' ELSE MCS.EOB_LINK  END) FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN SS_SQL.MEMBER_CLAIMS_SUMMARY MCS ON MP.MEMBER_PROFILE_ID=MCS.MEMBER_PROFILE_ID INNER JOIN SS_SQL.MEMBER_CLAIM_DETAIL MCD ON MCS.CLAIM_SUMMARY_ID=MCD.CLAIMS_SUMMARY_ID  INNER JOIN SS_SQL.PROVIDER_ADDRESSES PA ON MCS.PROVIDER_PROFILE_ID=PA.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_PROFILE PP ON PA.PROVIDER_PROFILE_ID=PP.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_TYPE_REF PTR ON PP.PROVIDER_TYPE_CODE=PTR.provider_type_code INNER JOIN SS_SQL.CLAIM_TYPE_REF CTR ON MCS.CLAIM_TYPE_CODE=CTR.CLAIM_TYPE_CODE  LEFT JOIN SS_SQL.PHARMACY_PROFILES PHP ON MCS.PHARMACY_PROFILE_ID=PHP.PHARMACY_PROFILE_ID   WHERE  MCS.SOURCE_CLAIM_ID = '"
							+ claimNum + "'  AND MP.SUBSCRIBER_ID = '" + subscriberID + "'  AND MP.DEPENDENT_ID = '"
							+ dependentID + "' AND MCS.CLAIM_TYPE_CODE in ('" + claimType
							+ "') AND MCS.VERSION_NUMBER = '" + claimVersion + "'  AND MCS.IS_SENSITIVE_CLAIM = '"
							+ sensitiveClaimFlag

							+ "'  GROUP BY MCD.PAID_DENIED_IND, SUBSCRIBER_ID,DEPENDENT_ID,MCS.CLAIM_TYPE_CODE,SOURCE_CLAIM_ID,MCS.IS_SENSITIVE_CLAIM, MCS.VERSION_NUMBER,MCS.VERSION_NUMBER, MCS.TOTAL_BILLED_AMOUNT,CTR.CLAIM_TYPE_DESC, MCS.PROCESSED_STATUS_CODE,MCS.SERVICE_FROM_DATE,MCS.SERVICE_TO_DATE, MCS.CLAIM_ADJUDICATED_DATE,MCS.LEGACY_CLAIM_REC_ID, MCS.TOTAL_MEMBER_LIABILITY,PP.LEGACY_PROV_ID,PP.LAST_NAME, PP.FIRST_NAME,PP.PROVIDER_SPECIALITY_CODE,PTR.provider_type_desc,PP.LAST_NAME,PA.PROVIDER_STREET_ADDRESS1, PA.PROVIDER_STREET_ADDRESS2,PA.PROVIDER_STREET_ADDRESS3,PA.PROVIDER_CITY_NAME,PA.PROVIDER_STATE_CODE, PA.PROVIDER_ZIP_CODE,MCD.ORIGINAL_BILL_AMOUNT ,PHP.PHARMACY_NAME , PHP.PHARMACY_ADDRESS , PHP.PHARMACY_CITY ,PHP.PHARMACY_STATE_CODE  , PHP.PHARMACY_ZIP_CODE , MCS.EOB_AVAILABLE_FLAG , MCS.EOB_LINK";

					claimLineDetailsQuery = "SELECT  DISTINCT MCD.LINE_ID AS claimLineNumber  ,pharmacyQuantity = (CASE WHEN MCD.QUANTITY_PRESCRIBED IS  NULL THEN '' ELSE MCD.QUANTITY_PRESCRIBED END),  claimLineServiceCode = (CASE WHEN MCD.CLAIM_LINE_CODE  IS  NULL THEN '' ELSE MCD.CLAIM_LINE_CODE  END),MCD.MEDICATION, MCS.SERVICE_FROM_DATE , MCS.SERVICE_TO_DATE AS claimLineServiceToDate, MCD.ORIGINAL_BILL_AMOUNT AS claimLineAmountBilled, MCD.NETWORK_DISCOUNT AS claimLineDiscount ,  MCD.ALLOWED_AMOUNT AS claimLineAmountAllowed, MCD.AMOUNT_PAID AS claimLineAmountCovered, MCD.COPAY_AMOUNT  AS claimLineCopay , MCD.COINSURANCE_AMOUNT AS claimLineCoinsurance , MCD.DEDUCTIBLE_AMOUNT  AS claimLineDeductible, MCD.OTHER_AMOUNT_PAYABLE AS claimLineOther,  MCD.LIABILITY_INDICATOR   AS liabilityCode,MCD.LIABILITY_INDICATOR AS liabilityCode , MCD.PAID_DENIED_IND AS paidDeniedIndicator ,   MCD.TOTAL_MEMBER_LIABILITY AS totalMemberLiability,  providerLiabilityAmount =     (CASE WHEN  MCD.PROVIDER_LIABILITY_AMOUNT IS  NULL THEN '0' ELSE  MCD.PROVIDER_LIABILITY_AMOUNT  END)   , ISNULL(CAST(MCD.MEMBER_DENIED_AMOUNT AS NVARCHAR), '0.0') AS MEMBER_DENIED_AMOUNT FROM SS_SQL.MEMBER_PROFILE MP    INNER JOIN SS_SQL.MEMBER_CLAIMS_SUMMARY MCS ON MP.MEMBER_PROFILE_ID=MCS.MEMBER_PROFILE_ID    INNER JOIN SS_SQL.MEMBER_CLAIM_DETAIL MCD ON MCS.CLAIM_SUMMARY_ID=MCD.CLAIMS_SUMMARY_ID   WHERE  MCS.SOURCE_CLAIM_ID = '"
							+ claimNum + "'  AND MP.SUBSCRIBER_ID = '" + subscriberID + "' AND MP.DEPENDENT_ID = '"
							+ dependentID + "' AND MCS.CLAIM_TYPE_CODE in ('" + claimType
							+ "') AND MCS.VERSION_NUMBER = '" + claimVersion + "'  AND MCS.IS_SENSITIVE_CLAIM = '"
							+ sensitiveClaimFlag + "' ORDER BY MCD.LINE_ID";
				}

				Assert.done("Start-> Validation of the Static Data");

				ValidateMethods.validateStaticFieldsWithDb(ClaimObj, strQuery, "Microsoft", ReportFilePath);
				// Validating Dynamic Fields With DB
				Assert.done("Start-> Validation of the Dynamic Data");

				String claimLineDetail = "claimLineDetails";
				String uniqueColumn = null;
				if (!(claimType.equalsIgnoreCase("P"))) {
					// String UniqueColumn = "claimLineReasonCodeDescription";
					uniqueColumn = "claimLineReasonCodeDescription";
				} else {

					uniqueColumn = "pharmacyQuantity";
				}
				ValidateMethods.validateJsonArrayDataWithDb(ClaimObj, claimLineDetail, claimLineDetailsQuery,
						uniqueColumn, "Microsoft", ReportFilePath);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Assert.done("Test ID: " + testID);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg");
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {
					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
				UtilMethod.Log(content, "FAIL", true);
			}
		}
	}

	/**
	 * Validate only the static fields
	 * 
	 * @param ClaimObj
	 *            = JSON Object
	 * @param strQuery
	 *            = DB Query
	 * @throws SQLException
	 * @throws IOException
	 */
	public static void validateStaticFieldsWithDb(JSONObject ClaimObj, String strQuery, String DB,
			String ReportFilePath) throws SQLException, IOException {
		// String QueryDB =
		Map<String, Object> responseData = UtilMethod.readJsonData(ClaimObj);
		org.json.JSONArray dbData = ViewClaimsDBS.getMemberInfofromDBS(strQuery, DB);
		Set<String> keys = responseData.keySet();
		for (String key : keys) {
			UtilMethod.setCellData(key, responseData.get(key), 1, ReportFilePath);
			UtilMethod.validateTag(dbData, key, responseData.get(key), ReportFilePath);
		}

	}

	/**
	 * Validate the JSon Array with DB data
	 * 
	 * @param ClaimObj
	 *            = JSON Object
	 * @param strArrayName
	 *            = JSON Array name
	 * @param strQuery
	 *            = DB Query used
	 * @param strUniqueColName
	 *            = Unique column name
	 * @throws Exception
	 */

	public static void validateJsonArrayDataWithDb(JSONObject ClaimObj, String strArrayName, String strQuery,
			String strUniqueColName, String DB, String ReportFilePath) throws Exception {
		JSONArray responseClaimLineDetails = (JSONArray) ClaimObj.get(strArrayName);
		org.json.JSONArray dbClaimLineDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, DB);
		try {
			if (responseClaimLineDetails.size() == dbClaimLineDetails.length()) {

				Map<String, Object> strCLaimDetailsRes = null;
				JSONObject response = null;
				Map<String, Object> db_data = null;
				org.json.JSONObject db_response = null;

				boolean errorflag = false;
				boolean validateflag = true;

				// Comparing Response data with db row
				for (int j = 0; j < responseClaimLineDetails.size(); j++) {
					int k = j * 2 + 1; // 1,3,5
					int l = j * 2 + 2; // 2,4,6
					response = (JSONObject) responseClaimLineDetails.get(j);
					strCLaimDetailsRes = UtilMethod.readJsonData(response);
					Assert.done("Validating " + j + " row DB values with response");
					for (int i = 0; i < dbClaimLineDetails.length(); i++) {
						db_response = (org.json.JSONObject) dbClaimLineDetails.get(i);
						db_data = UtilMethod.readJsonData(db_response);
						if (strCLaimDetailsRes.get(strUniqueColName).toString().trim()
								.equalsIgnoreCase(db_data.get(strUniqueColName).toString().trim())) {
							break;
						}
					}

					Set<String> jsonKeys = strCLaimDetailsRes.keySet();
					for (String tagname : jsonKeys) {
						Object Value = strCLaimDetailsRes.get(tagname);
						UtilMethod.setCellData(tagname, Value, k, ReportFilePath);

						UtilMethod.validateJSONObject(db_data, tagname, Value, l, ReportFilePath);

					}
				}

			} else {
				UtilMethod.Log(
						"Cannot validate as the Json response claim line details record size is not matching with DB response claim line details records.. please check the query you are passing",
						"FAIL", true);
			}
		} catch (Exception e) {
			Assert.fail(
					"Cannot validate claim line details with db as size is not matching.. please check the query you are passing...");
		}

	}

	/**
	 * This method is used to validate the JSON data and DB data of GetPCP service
	 * 
	 * @param content
	 *            = JSON Response data
	 * @param testID
	 *            = TestCase ID
	 * @throws Exception
	 */

	public static void validateGetPCP(String content, String testID,String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		//String testdir = Environment.get("PCP_BASE_DIR");
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";
		DataTable1 Dttestdata = new DataTable1(testdir + "PCP.xls", "GetPCPDetails_Input", "" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String ReportFilePath = "";
		if(Environment.get("Jenkins_Run").equalsIgnoreCase("Yes")) {
		String excelName = Environment.get("GetPCP_XML");		
		String excelReportName = excelName.replace(".xml", ".xslx");
		 ReportFilePath = Environment.get("report_path")+"//"+excelReportName;
		}
		else {
		 ReportFilePath = Environment.get("PCP_excel_path");
		}
		//String ReportFilePath = Environment.get("PCP_excel_path");
		if (content.contains("errorCode")) {
			errorflag = false;
		} else {
			validateflag = true;
		}
		if (validateflag) {
			Object obj = jsonparser.parse(content);
			JSONObject PCPobj = (JSONObject) obj;

			String inputtestID = Dttestdata.getValue("TestID");
			String testDesc = Dttestdata.getValue("Test_Description");
			String subscriberID = Dttestdata.getValue("SubscriberID");
			String dependentID = Dttestdata.getValue("DependentID");
			String memeCK = Dttestdata.getValue("MemeCK");
			String startDate = Dttestdata.getValue("StartDate");
			String endDate = Dttestdata.getValue("EndDate");
			// String eligind = Dttestdata.getValue("Elig_Ind");
			String futureSDT = Dttestdata.getValue("FutureStartDate");
			String futureEDT = Dttestdata.getValue("FutureEndDate");
			String strQuery = "";
			String validationQuery = "";
			try {
				Assert.done("Test ID: " + inputtestID);
				Assert.done("Test Description: " + testDesc);
				if (subscriberID.equals("") && dependentID.equals("")) {
					subscriberID = null;
					dependentID = null;
				} else if (memeCK.equals("")) {
					memeCK = null;
				}
				// String Query = Environment.get("Static_query");

				if (!(futureSDT.equalsIgnoreCase(""))) {
					if (futureEDT.equalsIgnoreCase("")) {
						endDate = futureSDT;
					}
					strQuery = "SELECT Distinct prpr.PRPR_NPI as providerNPI,prcp.PRCP_FIRST_NAME as pcpfname,prcp.PRCP_LAST_NAME as pcplname,CONVERT(DATE,prim.MEPR_EFF_DT) as pcpstartDate, CONVERT(DATE,prim.MEPR_TERM_DT) as pcpendDate,prim.PRPR_ID as providerId,groupName =(CASE WHEN (prer.PRER_PRPR_ENTITY='G') then (select PRPR_NAME from CMC_PRPR_PROV where PRPR_ID=prer.PRER_PRPR_ID AND prim.PRPR_ID=prpr.PRPR_ID) else '' end),"
							+ " groupId= (CASE WHEN(prer.PRER_PRPR_ENTITY='G' and prim.PRPR_ID=prpr.PRPR_ID) THEN prer.PRER_PRPR_ID else '' END) FROM CMC_SBSB_SUBSC S INNER JOIN CMC_MEME_MEMBER M ON S.SBSB_CK=M.SBSB_CK INNER JOIN CMC_MEPE_PRCS_ELIG mep ON M.MEME_CK=mep.MEME_CK INNER JOIN CMC_MEPR_PRIM_PROV prim ON mep.MEME_CK=prim.MEME_CK INNER JOIN CMC_PRPR_PROV prpr ON prim.PRPR_ID = prpr.PRPR_ID Left JOIN CMC_PRER_RELATION prer ON prpr.PRPR_ID=prer.PRPR_ID INNER JOIN CMC_PRCP_COMM_PRAC prcp ON prcp.PRCP_ID = prpr.PRCP_ID LEFT JOIN CMC_NWPX_RELATION nwpx ON prim.PRPR_ID=nwpx.PRPR_ID WHERE M.MEME_CK="
							+ memeCK + " AND prim.MEPR_CR_EFF_DT < '" + startDate + "' AND prim.MEPR_CR_TERM_DT  > '"
							+ endDate + "' AND mep.MEPE_ELIG_IND = 'Y' and prer.PRER_PRPR_ENTITY='G' ";
				} else if (!(endDate.equals(""))) {

					strQuery = "SELECT  Distinct prpr.PRPR_NPI as providerNPI,prcp.PRCP_FIRST_NAME as pcpfname,prcp.PRCP_LAST_NAME as pcplname,CONVERT(DATE,prim.MEPR_EFF_DT) as pcpstartDate, CONVERT(DATE,prim.MEPR_TERM_DT) as pcpendDate,prim.PRPR_ID as providerId,groupName =(CASE WHEN (prer.PRER_PRPR_ENTITY='G') then (select PRPR_NAME from CMC_PRPR_PROV where PRPR_ID=prer.PRER_PRPR_ID AND prim.PRPR_ID=prpr.PRPR_ID) else '' end),"
							+ " groupId = (CASE WHEN(prer.PRER_PRPR_ENTITY='G' and prim.PRPR_ID=prpr.PRPR_ID) THEN prer.PRER_PRPR_ID else '' END) FROM CMC_SBSB_SUBSC S inner join CMC_MEME_MEMBER M ON S.SBSB_CK=M.SBSB_CK INNER JOIN CMC_MEPE_PRCS_ELIG mep ON M.MEME_CK=mep.MEME_CK INNER JOIN CMC_MEPR_PRIM_PROV prim ON mep.MEME_CK=prim.MEME_CK INNER JOIN CMC_PRPR_PROV prpr ON prim.PRPR_ID = prpr.PRPR_ID INNER JOIN CMC_PRER_RELATION prer ON prpr.PRPR_ID=prer.PRPR_ID INNER JOIN CMC_PRCP_COMM_PRAC prcp ON prcp.PRCP_ID = prpr.PRCP_ID LEFT JOIN CMC_NWPX_RELATION nwpx ON prim.PRPR_ID=nwpx.PRPR_ID WHERE "
							+ " ((S.SBSB_ID= '" + subscriberID + "' and M.MEME_SFX= " + dependentID + ") OR M.MEME_CK= "
							+ memeCK + " )" + " AND prim.MEPR_EFF_DT <'" + startDate + "'AND prim.MEPR_TERM_DT >'"
							+ endDate + "'" + " AND mep.MEPE_ELIG_IND = 'Y' and prer.PRER_PRPR_ENTITY='G'";
				} else {

					/*
					 * validationQuery =
					 * "SELECT  distinct top 20 grgr.GRGR_ID,CSPI.CSCS_ID,sgsg.SGSG_ID,mepe.PDPD_ID,AIAI.AIAI_PCP_REQ_IND, mepe.MEPE_EFF_DT FROM CMC_MEME_MEMBER meme INNER JOIN CMC_SBSB_SUBSC sbsb ON meme.SBSB_CK = sbsb.SBSB_CK "
					 * +
					 * "INNER JOIN CMC_MEPE_PRCS_ELIG mepe ON mepe.MEME_CK = meme.MEME_CK INNER JOIN CMC_GRGR_GROUP grgr ON mepe.GRGR_CK=grgr.GRGR_CK INNER JOIN CMC_CSPI_CS_PLAN   CSPI ON grgr.GRGR_CK   = CSPI.GRGR_CK "
					 * +
					 * "INNER JOIN CMC_SGSG_SUB_GROUP sgsg ON grgr.GRGR_CK=sgsg.GRGR_CK INNER JOIN CMC_PDBC_PROD_COMP PDBC ON CSPI.PDPD_ID = PDBC.PDPD_ID INNER JOIN CMC_AIAI_ADM_INFO AIAI ON PDBC.PDBC_PFX = AIAI.PDBC_PFX "
					 * + "WHERE mepe.MEME_CK = "+memeCK+" OR (sbsb.SBSB_ID='"
					 * +subscriberID+"' AND meme.MEME_SFX="
					 * +dependentID+") AND mepe.MEPE_ELIG_IND='Y' AND PDBC.PDBC_TYPE = 'AIAI'" +
					 * " AND '"+startDate+"' between mepe.MEPE_EFF_DT AND mepe.MEPE_TERM_DT " +
					 * " AND (CSPI.CSPI_EFF_DT <> CSPI.CSPI_TERM_DT)" +
					 * " AND mepe.MEPE_EFF_DT < '"+startDate+"' AND mepe.MEPE_TERM_DT > '"
					 * +startDate+"' " +
					 * " AND mepe.MEPE_ELIG_IND='Y' AND (mepe.MEPE_EFF_DT <> mepe.MEPE_TERM_DT)" +
					 * " AND  CSPI.CSPI_EFF_DT  < '"+startDate+"' AND  CSPI.CSPI_TERM_DT > '"
					 * +startDate+"' "+ " AND PDBC.PDBC_TYPE = 'AIAI'" +
					 * " AND (CSPI.CSPI_EFF_DT <> CSPI.CSPI_TERM_DT)" +
					 * " AND  PDBC.PDBC_EFF_DT  < '"+startDate+"' AND PDBC.PDBC_TERM_DT > '"
					 * +startDate+"'";
					 * 
					 * if((!(startDate.equals("")))&& (endDate.equals(""))) { org.json.JSONArray
					 * validationDetails = ViewClaimsDBS.getMemberInfofromDBS(validationQuery,
					 * "Sybase"); if(validationDetails.length()!=0) {
					 * Assert.done("PCP Validation Done"); } else { Assert.fail("No data found"); }
					 * }
					 */
					if (startDate.equals("")) {
						DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
						Date date = new Date();
						startDate = dateFormat.format(date);
					}
					strQuery = "SELECT DISTINCT PRPR.PRPR_NPI as providerNPI, PRCP.PRCP_FIRST_NAME as pcpfname, PRCP.PRCP_LAST_NAME as pcplname,CONVERT(DATE,MEPR.MEPR_EFF_DT) as pcpstartDate, "
							+ " CONVERT(DATE,MEPR.MEPR_TERM_DT) as pcpendDate,MEPR.PRPR_ID as providerId,groupName =(CASE WHEN (PRER.PRER_PRPR_ENTITY='G') then (select PRPR_NAME from CMC_PRPR_PROV where PRPR_ID=PRER.PRER_PRPR_ID AND MEPR.PRPR_ID=PRPR.PRPR_ID) else '' end),"
							+ " groupId = (CASE WHEN(PRER.PRER_PRPR_ENTITY='G' and MEPR.PRPR_ID=PRPR.PRPR_ID) THEN PRER.PRER_PRPR_ID else '' END) FROM CMC_MEPR_PRIM_PROV MEPR "
							+ " INNER JOIN CMC_PRPR_PROV PRPR ON MEPR.PRPR_ID = PRPR.PRPR_ID left JOIN CMC_PRER_RELATION PRER ON PRER.PRPR_ID=PRPR.PRPR_ID INNER JOIN CMC_MEME_MEMBER MEME ON MEME.MEME_CK = MEPR.MEME_CK INNER JOIN CMC_MEPE_PRCS_ELIG mepe ON MEME.MEME_CK=mepe.MEME_CK "
							+ " INNER JOIN CMC_SBSB_SUBSC SBSB ON SBSB.SBSB_CK = MEME.SBSB_CK INNER JOIN CMC_GRGR_GROUP GRGR ON GRGR.GRGR_CK = SBSB.GRGR_CK INNER JOIN CMC_PRCP_COMM_PRAC PRCP ON PRCP.PRCP_ID=PRPR.PRCP_ID JOIN "
							+ " CMC_CSPI_CS_PLAN CSPI ON CSPI.GRGR_CK=SBSB.GRGR_CK WHERE ((SBSB.SBSB_ID='"
							+ subscriberID + "' and MEME.MEME_SFX=" + dependentID + " ) OR  MEME.MEME_CK=" + memeCK
							+ ") " + " AND mepe.MEPE_ELIG_IND = 'Y' AND '" + startDate
							+ "' Between MEPR.MEPR_EFF_DT AND MEPR.MEPR_TERM_DT and (PRER.PRER_PRPR_ENTITY = 'G' OR PRER.PRER_PRPR_ENTITY IS NULL) --PRER.PRER_PRPR_ENTITY in('G',(NULL))  ";

				}

				String pcpdetails = "PCP";
				// String UniqueColumn = "providerId";
				String[] uniqueColumn = { "providerNPI", "providerId", "pcpstartDate" };

				ValidateMethods.validateJsonArrayDataWithDb1(PCPobj, pcpdetails, strQuery, uniqueColumn, "Sybase",
						ReportFilePath);

			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Assert.done("Test ID: " + testID);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg");
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {

					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
				Assert.fail(content);
			}
		}
	}
	/**
	 * This method is used to validate the JSON data and DB data of FindClaims
	 * service
	 * 
	 * @param content
	 *            = JSON Response data
	 * @param testID
	 *            = TestCase ID
	 * @throws Exception
	 */
	public static void validateFindClaims(String content, String testID ,String env) throws Exception {
		boolean flag = true;
		boolean flag1 = false;
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";  
		DataTable1 Dttestdata = new DataTable1(testdir + "Claims.xls", "FindClaims_Input1", "" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String ReportFilePath = "";
		if(Environment.get("Jenkins_Run").equalsIgnoreCase("Yes")) {
		String excelName = Environment.get("FindClaims_XML");		
		String excelReportName = excelName.replace(".xml", ".xslx");
		 ReportFilePath = Environment.get("report_path")+"//"+excelReportName;
		}
		else {
		 ReportFilePath = Environment.get("FindClaims_ExcelReport_Path");
		}
		//String ReportFilePath = Environment.get("FindClaims_ExcelReport_Path");
		if (content.contains("errorCode")) {
			flag = false;
		} else {
			flag1 = true;
		}
		if (flag1) {
			Object obj = jsonparser.parse(content);
			JSONObject ClaimObj = (JSONObject) obj;
			String inputtestID = Dttestdata.getValue("TestID");
			String testDesc = Dttestdata.getValue("Test_Description");
			String subscriberID = Dttestdata.getValue("SubscriberID");
			String dependentID = Dttestdata.getValue("DependentID");
			String sensitiveClaimInfo = Dttestdata.getValue("SensitiveClaimInfo");
			String startDate = Dttestdata.getValue("StartDate");
			String endDate = Dttestdata.getValue("EndDate");
			String claimType = Dttestdata.getValue("ClaimType");
			String claimStatus = Dttestdata.getValue("claimStatus");
			String SortOrderDB = Dttestdata.getValue("SortOrderDB");
			String LOWERLIMITDB = Dttestdata.getValue("LOWERLIMITDB");
			String UPPERLIMITDB = Dttestdata.getValue("UPPERLIMITDB");
			String SortOnDB = Dttestdata.getValue("SortOnDB");
			String pageLoad = Dttestdata.getValue("pageLoad");
			String pageOffset = Dttestdata.getValue("pageOffset");
			String strQuery = "";
			String claimLineDetailsQuery = "";
			String countQuery = "";
			try {
				Assert.done("Test ID: " + inputtestID);
				Assert.done("Test Description: " + testDesc);
				if (endDate.equalsIgnoreCase("")) {
					startDate = startDateMinusTwoYears(endDate);
					endDate = checkNullStartEndDate(endDate);
				}
				if (claimType.equalsIgnoreCase("")) {
					claimType = "M,P,D,V";
				}
				claimType = claimType.replace(",", "','");
				if (SortOnDB.equalsIgnoreCase("MCS.CLAIM_ADJUDICATED_DATE")) {
					if ((sensitiveClaimInfo.equalsIgnoreCase("M"))) {
						countQuery = "SELECT count(*) AS claimsCount FROM SS_SQL.MEMBER_CLAIMS_SUMMARY MCS INNER JOIN SS_SQL.MEMBER_PROFILE MP ON MCS.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_PROFILE PP ON MCS.PROVIDER_PROFILE_ID = PP.PROVIDER_PROFILE_ID  INNER JOIN SS_SQL.PROVIDER_ADDRESSES PA ON PA.PROVIDER_PROFILE_ID = PP.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.CLAIM_STATUS_REF CSR ON CSR.PROCESSED_STATUS_CODE = MCS.PROCESSED_STATUS_CODE INNER JOIN SS_SQL.CLAIM_TYPE_REF CTR ON MCS.CLAIM_TYPE_CODE = CTR.CLAIM_TYPE_CODE WHERE MCS.CLAIM_ADJUDICATED_DATE BETWEEN '"
								+ startDate + "' AND '" + endDate + "' AND MP.DEPENDENT_ID = '" + dependentID
								+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
								+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
								+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID + "' "
								+ "AND MCS.IS_SENSITIVE_CLAIM='Y'";

						strQuery = "SELECT * FROM (SELECT DISTINCT SUBSCRIBER_ID AS subscriberID , DEPENDENT_ID AS dependentID,MCS. PROCESSED_STATUS_CODE AS claimStatus, ROW_NUMBER() OVER (ORDER BY "
								+ SortOnDB + " " + SortOrderDB
								+ " ) R  FROM SS_SQL.MEMBER_CLAIMS_SUMMARY MCS, SS_SQL.MEMBER_PROFILE MP WHERE MCS.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID AND MCS.CLAIM_ADJUDICATED_DATE BETWEEN '"
								+ startDate + "' AND '" + endDate + "' AND MP.DEPENDENT_ID = '" + dependentID
								+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
								+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
								+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID
								+ "' AND MCS.IS_SENSITIVE_CLAIM='Y') X WHERE X.R = 1";

						claimLineDetailsQuery = "SELECT * FROM (SELECT DISTINCT MCS.SOURCE_CLAIM_ID AS claimNumber ,MCS.LEGACY_CLAIM_REC_ID AS prescriptionNumber ,MCS.CLAIM_TYPE_CODE AS claimTypeCode, CTR.CLAIM_TYPE_DESC AS claimTypeDescription,MCS.PROCESSED_STATUS_CODE AS statusCode,CSR.PROCESSED_STATUS_DESC AS statusDescription, MCS.CLAIM_ADJUDICATED_DATE AS processDate,MCS.SERVICE_FROM_DATE AS startDate, MCS.SERVICE_TO_DATE AS endDate,MCS.CLAIM_SUMMARY_ID AS claimSummaryID ,PP.LEGACY_PROV_ID AS providerID, PP.LAST_NAME AS providerLastName,PP.FIRST_NAME AS providerFirstName, PP.PROVIDER_SPECIALITY_CODE AS providerSpeciality,PTR.provider_type_desc AS providerTypeDescription,PA.PROVIDER_STREET_ADDRESS1 AS providerAddressStreet1, PA.PROVIDER_STREET_ADDRESS2 AS providerAddressStreet2, PA.PROVIDER_STREET_ADDRESS3 AS providerAddressStreet3,PA.PROVIDER_CITY_NAME AS providerAddressCity,PA.PROVIDER_STATE_CODE AS providerAddressState,PA.PROVIDER_ZIP_CODE AS providerAddressZipCode, MCS.TOTAL_BILLED_AMOUNT AS amountBilled, MCS.TOTAL_MEMBER_LIABILITY AS memberLiability,MCS.VERSION_NUMBER AS versionNumber,MCS.IS_SENSITIVE_CLAIM AS isSensitiveClaim,eobavailableIndicator = (CASE WHEN MCS.EOB_AVAILABLE_FLAG IS  NULL THEN '' ELSE MCS.EOB_AVAILABLE_FLAG END),eobkey = (CASE WHEN MCS.EOB_LINK IS  NULL THEN '' ELSE MCS.EOB_LINK END), pharmacyName = (CASE WHEN (PHP.PHARMACY_NAME IS NULL ) THEN '' ELSE  PHP.PHARMACY_NAME END), pharmacyCity = (CASE WHEN (PHP.PHARMACY_CITY IS NULL ) THEN '' ELSE PHP.PHARMACY_CITY  END), pharmacyStateCode = (CASE WHEN (PHP.PHARMACY_STATE_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_STATE_CODE  END), pharmacyZipCode = (CASE WHEN (PHP.PHARMACY_ZIP_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_ZIP_CODE  END)  ,ROW_NUMBER() OVER (ORDER BY "
								+ SortOnDB + " " + SortOrderDB
								+ ") R 	FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN SS_SQL.MEMBER_CLAIMS_SUMMARY MCS ON MP.MEMBER_PROFILE_ID=MCS.MEMBER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_ADDRESSES PA ON MCS.PROVIDER_PROFILE_ID=PA.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_PROFILE PP ON PA.PROVIDER_PROFILE_ID=PP.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_TYPE_REF PTR ON PP.PROVIDER_TYPE_CODE=PTR.provider_type_code INNER JOIN SS_SQL.CLAIM_STATUS_REF CSR ON CSR.PROCESSED_STATUS_CODE = MCS.PROCESSED_STATUS_CODE INNER JOIN SS_SQL.CLAIM_TYPE_REF CTR ON MCS.CLAIM_TYPE_CODE = CTR.CLAIM_TYPE_CODE LEFT JOIN SS_SQL.PHARMACY_PROFILES PHP ON MCS.PHARMACY_PROFILE_ID=PHP.PHARMACY_PROFILE_ID  WHERE  MCS.CLAIM_ADJUDICATED_DATE BETWEEN '"
								+ startDate + "' AND '" + endDate + "' AND MP.DEPENDENT_ID = '" + dependentID
								+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
								+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
								+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID
								+ "' AND MCS.IS_SENSITIVE_CLAIM='Y') a WHERE a.R BETWEEN " + LOWERLIMITDB + " AND "
								+ UPPERLIMITDB + "";

					} else if (!(sensitiveClaimInfo.equalsIgnoreCase(""))) {

						if ((sensitiveClaimInfo.equalsIgnoreCase("Y"))) {
							sensitiveClaimInfo = sensitiveClaimInfo.replace("Y", "Y,N");
							sensitiveClaimInfo = sensitiveClaimInfo.replace(",", "','");
							countQuery = "SELECT count(*) AS claimsCount FROM SS_SQL.MEMBER_CLAIMS_SUMMARY MCS INNER JOIN SS_SQL.MEMBER_PROFILE MP ON MCS.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_PROFILE PP ON MCS.PROVIDER_PROFILE_ID = PP.PROVIDER_PROFILE_ID  INNER JOIN SS_SQL.PROVIDER_ADDRESSES PA ON PA.PROVIDER_PROFILE_ID = PP.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.CLAIM_STATUS_REF CSR ON CSR.PROCESSED_STATUS_CODE = MCS.PROCESSED_STATUS_CODE INNER JOIN SS_SQL.CLAIM_TYPE_REF CTR ON MCS.CLAIM_TYPE_CODE = CTR.CLAIM_TYPE_CODE WHERE MCS.CLAIM_ADJUDICATED_DATE BETWEEN '"
									+ startDate + "' AND '" + endDate + "' AND MP.DEPENDENT_ID = '" + dependentID
									+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
									+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
									+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID
									+ "' AND current_version_flag= 'Y' AND  MCS.IS_SENSITIVE_CLAIM IN ('"
									+ sensitiveClaimInfo + "')";
							strQuery = "SELECT * FROM (SELECT DISTINCT SUBSCRIBER_ID AS subscriberID , DEPENDENT_ID AS dependentID,MCS. PROCESSED_STATUS_CODE AS claimStatus,MCS.IS_SENSITIVE_CLAIM AS sensitiveClaimInfo ,ROW_NUMBER() OVER (ORDER BY "
									+ SortOnDB + " " + SortOrderDB
									+ " ) R  FROM SS_SQL.MEMBER_CLAIMS_SUMMARY MCS, SS_SQL.MEMBER_PROFILE MP WHERE MCS.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID AND MCS.CLAIM_ADJUDICATED_DATE BETWEEN '"
									+ startDate + "' AND '" + endDate + "' AND MP.DEPENDENT_ID = '" + dependentID
									+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
									+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
									+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID
									+ "'  AND current_version_flag= 'Y'  AND MCS.IS_SENSITIVE_CLAIM  ='Y') X WHERE X.R = 1";

							claimLineDetailsQuery = "SELECT * FROM (SELECT DISTINCT MCS.SOURCE_CLAIM_ID AS claimNumber ,MCS.LEGACY_CLAIM_REC_ID AS prescriptionNumber ,MCS.CLAIM_TYPE_CODE AS claimTypeCode, CTR.CLAIM_TYPE_DESC AS claimTypeDescription,MCS.PROCESSED_STATUS_CODE AS statusCode,CSR.PROCESSED_STATUS_DESC AS statusDescription, MCS.CLAIM_ADJUDICATED_DATE AS processDate,MCS.SERVICE_FROM_DATE AS startDate, MCS.SERVICE_TO_DATE AS endDate,MCS.CLAIM_SUMMARY_ID AS claimSummaryID ,PP.LEGACY_PROV_ID AS providerID, PP.LAST_NAME AS providerLastName,PP.FIRST_NAME AS providerFirstName, PP.PROVIDER_SPECIALITY_CODE AS providerSpeciality,PTR.provider_type_desc AS providerTypeDescription,PA.PROVIDER_STREET_ADDRESS1 AS providerAddressStreet1, PA.PROVIDER_STREET_ADDRESS2 AS providerAddressStreet2, PA.PROVIDER_STREET_ADDRESS3 AS providerAddressStreet3,PA.PROVIDER_CITY_NAME AS providerAddressCity,PA.PROVIDER_STATE_CODE AS providerAddressState,PA.PROVIDER_ZIP_CODE AS providerAddressZipCode, MCS.TOTAL_BILLED_AMOUNT AS amountBilled, MCS.TOTAL_MEMBER_LIABILITY AS memberLiability,MCS.VERSION_NUMBER AS versionNumber,MCS.IS_SENSITIVE_CLAIM AS isSensitiveClaim,eobavailableIndicator = (CASE WHEN MCS.EOB_AVAILABLE_FLAG IS  NULL THEN '' ELSE MCS.EOB_AVAILABLE_FLAG END),eobkey = (CASE WHEN MCS.EOB_LINK IS  NULL THEN '' ELSE MCS.EOB_LINK END), pharmacyName = (CASE WHEN (PHP.PHARMACY_NAME IS NULL ) THEN '' ELSE  PHP.PHARMACY_NAME END), pharmacyCity = (CASE WHEN (PHP.PHARMACY_CITY IS NULL ) THEN '' ELSE PHP.PHARMACY_CITY  END), pharmacyStateCode = (CASE WHEN (PHP.PHARMACY_STATE_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_STATE_CODE  END), pharmacyZipCode = (CASE WHEN (PHP.PHARMACY_ZIP_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_ZIP_CODE  END)   , ROW_NUMBER() OVER (ORDER BY "
									+ SortOnDB + " " + SortOrderDB
									+ ") R 	FROM  SS_SQL.MEMBER_PROFILE MP INNER JOIN SS_SQL.MEMBER_CLAIMS_SUMMARY MCS ON MP.MEMBER_PROFILE_ID=MCS.MEMBER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_ADDRESSES PA ON MCS.PROVIDER_PROFILE_ID=PA.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_PROFILE PP ON PA.PROVIDER_PROFILE_ID=PP.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_TYPE_REF PTR ON PP.PROVIDER_TYPE_CODE=PTR.provider_type_code INNER JOIN SS_SQL.CLAIM_STATUS_REF CSR ON CSR.PROCESSED_STATUS_CODE = MCS.PROCESSED_STATUS_CODE INNER JOIN SS_SQL.CLAIM_TYPE_REF CTR ON MCS.CLAIM_TYPE_CODE = CTR.CLAIM_TYPE_CODE LEFT JOIN SS_SQL.PHARMACY_PROFILES PHP ON MCS.PHARMACY_PROFILE_ID=PHP.PHARMACY_PROFILE_ID WHERE MCS.CLAIM_ADJUDICATED_DATE BETWEEN '"
									+ startDate + "' AND '" + endDate + "' AND MP.DEPENDENT_ID = '" + dependentID
									+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
									+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
									+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID
									+ "'  AND current_version_flag= 'Y' AND MCS.IS_SENSITIVE_CLAIM IN ('"
									+ sensitiveClaimInfo + "')) a WHERE a.R BETWEEN " + LOWERLIMITDB + " AND "
									+ UPPERLIMITDB + "";
						} else {
							countQuery = "SELECT count(*) AS claimsCount FROM SS_SQL.MEMBER_CLAIMS_SUMMARY MCS INNER JOIN SS_SQL.MEMBER_PROFILE MP ON MCS.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_PROFILE PP ON MCS.PROVIDER_PROFILE_ID = PP.PROVIDER_PROFILE_ID  INNER JOIN SS_SQL.PROVIDER_ADDRESSES PA ON PA.PROVIDER_PROFILE_ID = PP.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.CLAIM_STATUS_REF CSR ON CSR.PROCESSED_STATUS_CODE = MCS.PROCESSED_STATUS_CODE INNER JOIN SS_SQL.CLAIM_TYPE_REF CTR ON MCS.CLAIM_TYPE_CODE = CTR.CLAIM_TYPE_CODE WHERE MCS.CLAIM_ADJUDICATED_DATE BETWEEN '"
									+ startDate + "' AND '" + endDate + "' AND MP.DEPENDENT_ID = '" + dependentID
									+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
									+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
									+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID
									+ "' AND MCS.IS_SENSITIVE_CLAIM='" + sensitiveClaimInfo + "'";
							strQuery = "SELECT * FROM (SELECT DISTINCT SUBSCRIBER_ID AS subscriberID , DEPENDENT_ID AS dependentID,MCS. PROCESSED_STATUS_CODE AS claimStatus,MCS.IS_SENSITIVE_CLAIM AS sensitiveClaimInfo ,ROW_NUMBER() OVER (ORDER BY "
									+ SortOnDB + " " + SortOrderDB
									+ " ) R  FROM SS_SQL.MEMBER_CLAIMS_SUMMARY MCS, SS_SQL.MEMBER_PROFILE MP WHERE MCS.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID AND MCS.CLAIM_ADJUDICATED_DATE BETWEEN '"
									+ startDate + "' AND '" + endDate + "' AND MP.DEPENDENT_ID = '" + dependentID
									+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
									+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
									+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID
									+ "' AND MCS.IS_SENSITIVE_CLAIM='" + sensitiveClaimInfo + "') X WHERE X.R = 1";

							claimLineDetailsQuery = "SELECT * FROM (SELECT DISTINCT MCS.SOURCE_CLAIM_ID AS claimNumber ,MCS.LEGACY_CLAIM_REC_ID AS prescriptionNumber ,MCS.CLAIM_TYPE_CODE AS claimTypeCode, CTR.CLAIM_TYPE_DESC AS claimTypeDescription,MCS.PROCESSED_STATUS_CODE AS statusCode,CSR.PROCESSED_STATUS_DESC AS statusDescription, MCS.CLAIM_ADJUDICATED_DATE AS processDate,MCS.SERVICE_FROM_DATE AS startDate, MCS.SERVICE_TO_DATE AS endDate,MCS.CLAIM_SUMMARY_ID AS claimSummaryID ,PP.LEGACY_PROV_ID AS providerID, PP.LAST_NAME AS providerLastName,PP.FIRST_NAME AS providerFirstName, PP.PROVIDER_SPECIALITY_CODE AS providerSpeciality,PTR.provider_type_desc AS providerTypeDescription,PA.PROVIDER_STREET_ADDRESS1 AS providerAddressStreet1, PA.PROVIDER_STREET_ADDRESS2 AS providerAddressStreet2, PA.PROVIDER_STREET_ADDRESS3 AS providerAddressStreet3,PA.PROVIDER_CITY_NAME AS providerAddressCity,PA.PROVIDER_STATE_CODE AS providerAddressState,PA.PROVIDER_ZIP_CODE AS providerAddressZipCode, MCS.TOTAL_BILLED_AMOUNT AS amountBilled, MCS.TOTAL_MEMBER_LIABILITY AS memberLiability,MCS.VERSION_NUMBER AS versionNumber,MCS.IS_SENSITIVE_CLAIM AS isSensitiveClaim,eobavailableIndicator = (CASE WHEN MCS.EOB_AVAILABLE_FLAG IS  NULL THEN '' ELSE MCS.EOB_AVAILABLE_FLAG END),eobkey = (CASE WHEN MCS.EOB_LINK IS  NULL THEN '' ELSE MCS.EOB_LINK END), pharmacyName = (CASE WHEN (PHP.PHARMACY_NAME IS NULL ) THEN '' ELSE  PHP.PHARMACY_NAME END), pharmacyCity = (CASE WHEN (PHP.PHARMACY_CITY IS NULL ) THEN '' ELSE PHP.PHARMACY_CITY  END), pharmacyStateCode = (CASE WHEN (PHP.PHARMACY_STATE_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_STATE_CODE  END), pharmacyZipCode = (CASE WHEN (PHP.PHARMACY_ZIP_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_ZIP_CODE  END)  , ROW_NUMBER() OVER (ORDER BY "
									+ SortOnDB + " " + SortOrderDB
									+ ") R 	FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN SS_SQL.MEMBER_CLAIMS_SUMMARY MCS ON MP.MEMBER_PROFILE_ID=MCS.MEMBER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_ADDRESSES PA ON MCS.PROVIDER_PROFILE_ID=PA.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_PROFILE PP ON PA.PROVIDER_PROFILE_ID=PP.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_TYPE_REF PTR ON PP.PROVIDER_TYPE_CODE=PTR.provider_type_code INNER JOIN SS_SQL.CLAIM_STATUS_REF CSR ON CSR.PROCESSED_STATUS_CODE = MCS.PROCESSED_STATUS_CODE INNER JOIN SS_SQL.CLAIM_TYPE_REF CTR ON MCS.CLAIM_TYPE_CODE = CTR.CLAIM_TYPE_CODE LEFT JOIN SS_SQL.PHARMACY_PROFILES PHP ON MCS.PHARMACY_PROFILE_ID=PHP.PHARMACY_PROFILE_ID WHERE MCS.CLAIM_ADJUDICATED_DATE BETWEEN '"
									+ startDate + "' AND '" + endDate + "' AND MP.DEPENDENT_ID = '" + dependentID
									+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
									+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
									+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID
									+ "' AND MCS.IS_SENSITIVE_CLAIM='" + sensitiveClaimInfo + "') a WHERE a.R BETWEEN "
									+ LOWERLIMITDB + " AND " + UPPERLIMITDB + "";
						}
					}

					else {
						countQuery = "SELECT count(*) AS claimsCount FROM SS_SQL.MEMBER_CLAIMS_SUMMARY MCS INNER JOIN SS_SQL.MEMBER_PROFILE MP ON MCS.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_PROFILE PP ON MCS.PROVIDER_PROFILE_ID = PP.PROVIDER_PROFILE_ID  INNER JOIN SS_SQL.PROVIDER_ADDRESSES PA ON PA.PROVIDER_PROFILE_ID = PP.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.CLAIM_STATUS_REF CSR ON CSR.PROCESSED_STATUS_CODE = MCS.PROCESSED_STATUS_CODE INNER JOIN SS_SQL.CLAIM_TYPE_REF CTR ON MCS.CLAIM_TYPE_CODE = CTR.CLAIM_TYPE_CODE WHERE MCS.CLAIM_ADJUDICATED_DATE BETWEEN '"
								+ startDate + "' AND '" + endDate + "' AND MP.DEPENDENT_ID = '" + dependentID
								+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
								+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
								+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID + "'";
						strQuery = "SELECT * FROM (SELECT DISTINCT SUBSCRIBER_ID AS subscriberID , DEPENDENT_ID AS dependentID,MCS. PROCESSED_STATUS_CODE AS claimStatus,MCS.IS_SENSITIVE_CLAIM AS sensitiveClaimInfo, ROW_NUMBER() OVER (ORDER BY "
								+ SortOnDB + " " + SortOrderDB
								+ " ) R  FROM SS_SQL.MEMBER_CLAIMS_SUMMARY MCS, SS_SQL.MEMBER_PROFILE MP WHERE MCS.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID AND MCS.CLAIM_ADJUDICATED_DATE BETWEEN '"
								+ startDate + "' AND '" + endDate + "' AND MP.DEPENDENT_ID = '" + dependentID
								+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
								+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
								+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID + "') X WHERE X.R = 1";

						claimLineDetailsQuery = "SELECT * FROM (SELECT DISTINCT MCS.SOURCE_CLAIM_ID AS claimNumber ,MCS.LEGACY_CLAIM_REC_ID AS prescriptionNumber ,MCS.CLAIM_TYPE_CODE AS claimTypeCode, CTR.CLAIM_TYPE_DESC AS claimTypeDescription,MCS.PROCESSED_STATUS_CODE AS statusCode,CSR.PROCESSED_STATUS_DESC AS statusDescription, MCS.CLAIM_ADJUDICATED_DATE AS processDate,MCS.SERVICE_FROM_DATE AS startDate, MCS.SERVICE_TO_DATE AS endDate,MCS.CLAIM_SUMMARY_ID AS claimSummaryID ,PP.LEGACY_PROV_ID AS providerID, PP.LAST_NAME AS providerLastName,PP.FIRST_NAME AS providerFirstName, PP.PROVIDER_SPECIALITY_CODE AS providerSpeciality,PTR.provider_type_desc AS providerTypeDescription,PA.PROVIDER_STREET_ADDRESS1 AS providerAddressStreet1, PA.PROVIDER_STREET_ADDRESS2 AS providerAddressStreet2, PA.PROVIDER_STREET_ADDRESS3 AS providerAddressStreet3,PA.PROVIDER_CITY_NAME AS providerAddressCity,PA.PROVIDER_STATE_CODE AS providerAddressState,PA.PROVIDER_ZIP_CODE AS providerAddressZipCode, MCS.TOTAL_BILLED_AMOUNT AS amountBilled, MCS.TOTAL_MEMBER_LIABILITY AS memberLiability,MCS.VERSION_NUMBER AS versionNumber,MCS.IS_SENSITIVE_CLAIM AS isSensitiveClaim, eobavailableIndicator = (CASE WHEN MCS.EOB_AVAILABLE_FLAG IS  NULL THEN '' ELSE MCS.EOB_AVAILABLE_FLAG END),eobkey = (CASE WHEN MCS.EOB_LINK IS  NULL THEN '' ELSE MCS.EOB_LINK END), pharmacyName = (CASE WHEN (PHP.PHARMACY_NAME IS NULL ) THEN '' ELSE  PHP.PHARMACY_NAME END), pharmacyCity = (CASE WHEN (PHP.PHARMACY_CITY IS NULL ) THEN '' ELSE PHP.PHARMACY_CITY  END), pharmacyStateCode = (CASE WHEN (PHP.PHARMACY_STATE_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_STATE_CODE  END), pharmacyZipCode = (CASE WHEN (PHP.PHARMACY_ZIP_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_ZIP_CODE  END)   , ROW_NUMBER() OVER (ORDER BY "
								+ SortOnDB + " " + SortOrderDB
								+ ") R 	FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN SS_SQL.MEMBER_CLAIMS_SUMMARY MCS ON MP.MEMBER_PROFILE_ID=MCS.MEMBER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_ADDRESSES PA ON MCS.PROVIDER_PROFILE_ID=PA.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_PROFILE PP ON PA.PROVIDER_PROFILE_ID=PP.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_TYPE_REF PTR ON PP.PROVIDER_TYPE_CODE=PTR.provider_type_code INNER JOIN SS_SQL.CLAIM_STATUS_REF CSR ON CSR.PROCESSED_STATUS_CODE = MCS.PROCESSED_STATUS_CODE INNER JOIN SS_SQL.CLAIM_TYPE_REF CTR ON MCS.CLAIM_TYPE_CODE = CTR.CLAIM_TYPE_CODE LEFT JOIN SS_SQL.PHARMACY_PROFILES PHP ON MCS.PHARMACY_PROFILE_ID=PHP.PHARMACY_PROFILE_ID  WHERE  MCS.CLAIM_ADJUDICATED_DATE BETWEEN '"
								+ startDate + "' AND '" + endDate + "' AND MP.DEPENDENT_ID = '" + dependentID
								+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
								+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
								+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID + "') a WHERE a.R BETWEEN "
								+ LOWERLIMITDB + " AND " + UPPERLIMITDB + "";
					}
				} else {

					if (!(sensitiveClaimInfo.equalsIgnoreCase(""))) {

						if ((sensitiveClaimInfo.equalsIgnoreCase("Y"))) {
							sensitiveClaimInfo = sensitiveClaimInfo.replace("Y", "Y,N");
							sensitiveClaimInfo = sensitiveClaimInfo.replace(",", "','");
							countQuery = "SELECT count(*) AS claimsCount FROM SS_SQL.MEMBER_CLAIMS_SUMMARY MCS INNER JOIN SS_SQL.MEMBER_PROFILE MP ON MCS.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_PROFILE PP ON MCS.PROVIDER_PROFILE_ID = PP.PROVIDER_PROFILE_ID  INNER JOIN SS_SQL.PROVIDER_ADDRESSES PA ON PA.PROVIDER_PROFILE_ID = PP.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.CLAIM_STATUS_REF CSR ON CSR.PROCESSED_STATUS_CODE = MCS.PROCESSED_STATUS_CODE INNER JOIN SS_SQL.CLAIM_TYPE_REF CTR ON MCS.CLAIM_TYPE_CODE = CTR.CLAIM_TYPE_CODE WHERE (MCS.SERVICE_FROM_DATE BETWEEN '"
									+ startDate + "' AND '" + endDate + "' OR MCS.SERVICE_TO_DATE BETWEEN '" + startDate
									+ "' AND '" + endDate + "' ) AND MP.DEPENDENT_ID = '" + dependentID
									+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
									+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
									+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID + "'  "
									+ "AND current_version_flag= 'Y' AND MCS.IS_SENSITIVE_CLAIM IN ('"
									+ sensitiveClaimInfo + "')";
							strQuery = "SELECT * FROM (SELECT DISTINCT SUBSCRIBER_ID AS subscriberID , DEPENDENT_ID AS dependentID,MCS. PROCESSED_STATUS_CODE AS claimStatus,MCS.IS_SENSITIVE_CLAIM AS sensitiveClaimInfo, ROW_NUMBER() OVER (ORDER BY  "
									+ SortOnDB + " " + SortOrderDB
									+ ") R FROM SS_SQL.MEMBER_CLAIMS_SUMMARY MCS, SS_SQL.MEMBER_PROFILE MP , SS_SQL.PROVIDER_PROFILE PP WHERE MCS.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID AND  MCS.PROVIDER_PROFILE_ID = PP.PROVIDER_PROFILE_ID AND (MCS.SERVICE_FROM_DATE BETWEEN '"
									+ startDate + "' AND '" + endDate + "' OR MCS.SERVICE_TO_DATE BETWEEN '" + startDate
									+ "' AND '" + endDate + "' ) AND MP.DEPENDENT_ID = '" + dependentID
									+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
									+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
									+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID
									+ "'  AND current_version_flag= 'Y' AND MCS.IS_SENSITIVE_CLAIM  ='Y') X WHERE X.R = 1";

							claimLineDetailsQuery = "SELECT * FROM (SELECT DISTINCT MCS.SOURCE_CLAIM_ID AS claimNumber,MCS.CLAIM_TYPE_CODE AS claimTypeCode, CTR.CLAIM_TYPE_DESC AS claimTypeDescription,MCS.PROCESSED_STATUS_CODE AS statusCode,CSR.PROCESSED_STATUS_DESC AS statusDescription, MCS.CLAIM_ADJUDICATED_DATE AS processDate,MCS.SERVICE_FROM_DATE AS startDate, MCS.SERVICE_TO_DATE AS endDate,MCS.CLAIM_SUMMARY_ID AS claimSummaryID ,PP.LEGACY_PROV_ID AS providerID, PP.LAST_NAME AS providerLastName,PP.FIRST_NAME AS providerFirstName, PP.PROVIDER_SPECIALITY_CODE AS providerSpeciality,PTR.provider_type_desc AS providerTypeDescription,PA.PROVIDER_STREET_ADDRESS1 AS providerAddressStreet1, PA.PROVIDER_STREET_ADDRESS2 AS providerAddressStreet2, PA.PROVIDER_STREET_ADDRESS3 AS providerAddressStreet3,PA.PROVIDER_CITY_NAME AS providerAddressCity,PA.PROVIDER_STATE_CODE AS providerAddressState,PA.PROVIDER_ZIP_CODE AS providerAddressZipCode, MCS.TOTAL_BILLED_AMOUNT AS amountBilled, MCS.TOTAL_MEMBER_LIABILITY AS memberLiability,MCS.VERSION_NUMBER AS versionNumber,MCS.IS_SENSITIVE_CLAIM AS isSensitiveClaim, eobavailableIndicator = (CASE WHEN MCS.EOB_AVAILABLE_FLAG IS  NULL THEN '' ELSE MCS.EOB_AVAILABLE_FLAG END),eobkey = (CASE WHEN MCS.EOB_LINK IS  NULL THEN '' ELSE MCS.EOB_LINK END), pharmacyName = (CASE WHEN (PHP.PHARMACY_NAME IS NULL ) THEN '' ELSE  PHP.PHARMACY_NAME END), pharmacyCity = (CASE WHEN (PHP.PHARMACY_CITY IS NULL ) THEN '' ELSE PHP.PHARMACY_CITY  END), pharmacyStateCode = (CASE WHEN (PHP.PHARMACY_STATE_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_STATE_CODE  END), pharmacyZipCode = (CASE WHEN (PHP.PHARMACY_ZIP_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_ZIP_CODE  END)  , ROW_NUMBER() OVER (ORDER BY  "
									+ SortOnDB + " " + SortOrderDB
									+ ") R FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN SS_SQL.MEMBER_CLAIMS_SUMMARY MCS ON MP.MEMBER_PROFILE_ID=MCS.MEMBER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_ADDRESSES PA ON MCS.PROVIDER_PROFILE_ID=PA.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_PROFILE PP ON PA.PROVIDER_PROFILE_ID=PP.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_TYPE_REF PTR ON PP.PROVIDER_TYPE_CODE=PTR.provider_type_code INNER JOIN SS_SQL.CLAIM_STATUS_REF CSR ON CSR.PROCESSED_STATUS_CODE = MCS.PROCESSED_STATUS_CODE INNER JOIN SS_SQL.CLAIM_TYPE_REF CTR ON MCS.CLAIM_TYPE_CODE = CTR.CLAIM_TYPE_CODE LEFT JOIN SS_SQL.PHARMACY_PROFILES PHP ON MCS.PHARMACY_PROFILE_ID=PHP.PHARMACY_PROFILE_ID WHERE  (MCS.SERVICE_FROM_DATE BETWEEN '"
									+ startDate + "' AND '" + endDate + "' OR MCS.SERVICE_TO_DATE BETWEEN '" + startDate
									+ "' AND '" + endDate + "' ) AND MP.DEPENDENT_ID = '" + dependentID
									+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
									+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
									+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID
									+ "'  AND current_version_flag= 'Y' AND MCS.IS_SENSITIVE_CLAIM IN ('"
									+ sensitiveClaimInfo + "')) a WHERE a.R BETWEEN " + LOWERLIMITDB + " AND "
									+ UPPERLIMITDB + "";
						} else {
							countQuery = "SELECT count(*) AS claimsCount FROM SS_SQL.MEMBER_CLAIMS_SUMMARY MCS INNER JOIN SS_SQL.MEMBER_PROFILE MP ON MCS.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_PROFILE PP ON MCS.PROVIDER_PROFILE_ID = PP.PROVIDER_PROFILE_ID  INNER JOIN SS_SQL.PROVIDER_ADDRESSES PA ON PA.PROVIDER_PROFILE_ID = PP.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.CLAIM_STATUS_REF CSR ON CSR.PROCESSED_STATUS_CODE = MCS.PROCESSED_STATUS_CODE INNER JOIN SS_SQL.CLAIM_TYPE_REF CTR ON MCS.CLAIM_TYPE_CODE = CTR.CLAIM_TYPE_CODE WHERE (MCS.SERVICE_FROM_DATE BETWEEN '"
									+ startDate + "' AND '" + endDate + "' OR MCS.SERVICE_TO_DATE BETWEEN '" + startDate
									+ "' AND '" + endDate + "' ) AND MP.DEPENDENT_ID = '" + dependentID
									+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
									+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
									+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID
									+ "' AND MCS.IS_SENSITIVE_CLAIM='" + sensitiveClaimInfo + "'";
							strQuery = "SELECT * FROM (SELECT DISTINCT SUBSCRIBER_ID AS subscriberID , DEPENDENT_ID AS dependentID,MCS. PROCESSED_STATUS_CODE AS claimStatus,MCS.IS_SENSITIVE_CLAIM AS sensitiveClaimInfo, ROW_NUMBER() OVER (ORDER BY  "
									+ SortOnDB + " " + SortOrderDB
									+ ") R FROM SS_SQL.MEMBER_CLAIMS_SUMMARY MCS, SS_SQL.MEMBER_PROFILE MP , SS_SQL.PROVIDER_PROFILE PP WHERE MCS.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID AND  MCS.PROVIDER_PROFILE_ID = PP.PROVIDER_PROFILE_ID AND (MCS.SERVICE_FROM_DATE BETWEEN '"
									+ startDate + "' AND '" + endDate + "' OR MCS.SERVICE_TO_DATE BETWEEN '" + startDate
									+ "' AND '" + endDate + "' ) AND MP.DEPENDENT_ID = '" + dependentID
									+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
									+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
									+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID
									+ "' AND MCS.IS_SENSITIVE_CLAIM='" + sensitiveClaimInfo + "') X WHERE X.R = 1";

							claimLineDetailsQuery = "SELECT * FROM (SELECT DISTINCT MCS.SOURCE_CLAIM_ID AS claimNumber,MCS.CLAIM_TYPE_CODE AS claimTypeCode, CTR.CLAIM_TYPE_DESC AS claimTypeDescription,MCS.PROCESSED_STATUS_CODE AS statusCode,CSR.PROCESSED_STATUS_DESC AS statusDescription, MCS.CLAIM_ADJUDICATED_DATE AS processDate,MCS.SERVICE_FROM_DATE AS startDate, MCS.SERVICE_TO_DATE AS endDate,MCS.CLAIM_SUMMARY_ID AS claimSummaryID ,PP.LEGACY_PROV_ID AS providerID, PP.LAST_NAME AS providerLastName,PP.FIRST_NAME AS providerFirstName, PP.PROVIDER_SPECIALITY_CODE AS providerSpeciality,PTR.provider_type_desc AS providerTypeDescription,PA.PROVIDER_STREET_ADDRESS1 AS providerAddressStreet1, PA.PROVIDER_STREET_ADDRESS2 AS providerAddressStreet2, PA.PROVIDER_STREET_ADDRESS3 AS providerAddressStreet3,PA.PROVIDER_CITY_NAME AS providerAddressCity,PA.PROVIDER_STATE_CODE AS providerAddressState,PA.PROVIDER_ZIP_CODE AS providerAddressZipCode, MCS.TOTAL_BILLED_AMOUNT AS amountBilled, MCS.TOTAL_MEMBER_LIABILITY AS memberLiability,MCS.VERSION_NUMBER AS versionNumber,MCS.IS_SENSITIVE_CLAIM AS isSensitiveClaim, eobavailableIndicator = (CASE WHEN MCS.EOB_AVAILABLE_FLAG IS  NULL THEN '' ELSE MCS.EOB_AVAILABLE_FLAG END),eobkey = (CASE WHEN MCS.EOB_LINK IS  NULL THEN '' ELSE MCS.EOB_LINK END), pharmacyName = (CASE WHEN (PHP.PHARMACY_NAME IS NULL ) THEN '' ELSE  PHP.PHARMACY_NAME END), pharmacyCity = (CASE WHEN (PHP.PHARMACY_CITY IS NULL ) THEN '' ELSE PHP.PHARMACY_CITY  END), pharmacyStateCode = (CASE WHEN (PHP.PHARMACY_STATE_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_STATE_CODE  END), pharmacyZipCode = (CASE WHEN (PHP.PHARMACY_ZIP_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_ZIP_CODE  END)  , ROW_NUMBER() OVER (ORDER BY  "
									+ SortOnDB + " " + SortOrderDB
									+ ") R FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN SS_SQL.MEMBER_CLAIMS_SUMMARY MCS ON MP.MEMBER_PROFILE_ID=MCS.MEMBER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_ADDRESSES PA ON MCS.PROVIDER_PROFILE_ID=PA.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_PROFILE PP ON PA.PROVIDER_PROFILE_ID=PP.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_TYPE_REF PTR ON PP.PROVIDER_TYPE_CODE=PTR.provider_type_code INNER JOIN SS_SQL.CLAIM_STATUS_REF CSR ON CSR.PROCESSED_STATUS_CODE = MCS.PROCESSED_STATUS_CODE INNER JOIN SS_SQL.CLAIM_TYPE_REF CTR ON MCS.CLAIM_TYPE_CODE = CTR.CLAIM_TYPE_CODE LEFT JOIN SS_SQL.PHARMACY_PROFILES PHP ON MCS.PHARMACY_PROFILE_ID=PHP.PHARMACY_PROFILE_ID WHERE  (MCS.SERVICE_FROM_DATE BETWEEN '"
									+ startDate + "' AND '" + endDate + "' OR MCS.SERVICE_TO_DATE BETWEEN '" + startDate
									+ "' AND '" + endDate + "' ) AND MP.DEPENDENT_ID = '" + dependentID
									+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
									+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
									+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID
									+ "' AND MCS.IS_SENSITIVE_CLAIM='" + sensitiveClaimInfo + "') a WHERE a.R BETWEEN "
									+ LOWERLIMITDB + " AND " + UPPERLIMITDB + "";
						}
					} else {
						countQuery = "SELECT count(*) AS claimsCount FROM SS_SQL.MEMBER_CLAIMS_SUMMARY MCS INNER JOIN SS_SQL.MEMBER_PROFILE MP ON MCS.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_PROFILE PP ON MCS.PROVIDER_PROFILE_ID = PP.PROVIDER_PROFILE_ID  INNER JOIN SS_SQL.PROVIDER_ADDRESSES PA ON PA.PROVIDER_PROFILE_ID = PP.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.CLAIM_STATUS_REF CSR ON CSR.PROCESSED_STATUS_CODE = MCS.PROCESSED_STATUS_CODE INNER JOIN SS_SQL.CLAIM_TYPE_REF CTR ON MCS.CLAIM_TYPE_CODE = CTR.CLAIM_TYPE_CODE WHERE (MCS.SERVICE_FROM_DATE BETWEEN '"
								+ startDate + "' AND '" + endDate + "' OR MCS.SERVICE_TO_DATE BETWEEN '" + startDate
								+ "' AND '" + endDate + "' ) AND MP.DEPENDENT_ID = '" + dependentID
								+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
								+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
								+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID + "'";
						strQuery = "SELECT * FROM (SELECT DISTINCT SUBSCRIBER_ID AS subscriberID , DEPENDENT_ID AS dependentID,MCS. PROCESSED_STATUS_CODE AS claimStatus,MCS.IS_SENSITIVE_CLAIM AS sensitiveClaimInfo, ROW_NUMBER() OVER (ORDER BY  "
								+ SortOnDB + " " + SortOrderDB
								+ ") R FROM SS_SQL.MEMBER_CLAIMS_SUMMARY MCS, SS_SQL.MEMBER_PROFILE MP , SS_SQL.PROVIDER_PROFILE PP WHERE MCS.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID AND  MCS.PROVIDER_PROFILE_ID = PP.PROVIDER_PROFILE_ID AND (MCS.SERVICE_FROM_DATE BETWEEN '"
								+ startDate + "' AND '" + endDate + "' OR MCS.SERVICE_TO_DATE BETWEEN '" + startDate
								+ "' AND '" + endDate + "' ) AND MP.DEPENDENT_ID = '" + dependentID
								+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
								+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
								+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID + "') X WHERE X.R = 1";

						claimLineDetailsQuery = "SELECT * FROM (SELECT DISTINCT MCS.SOURCE_CLAIM_ID AS claimNumber,MCS.CLAIM_TYPE_CODE AS claimTypeCode, CTR.CLAIM_TYPE_DESC AS claimTypeDescription,MCS.PROCESSED_STATUS_CODE AS statusCode,CSR.PROCESSED_STATUS_DESC AS statusDescription, MCS.CLAIM_ADJUDICATED_DATE AS processDate,MCS.SERVICE_FROM_DATE AS startDate, MCS.SERVICE_TO_DATE AS endDate,MCS.CLAIM_SUMMARY_ID AS claimSummaryID ,PP.LEGACY_PROV_ID AS providerID, PP.LAST_NAME AS providerLastName,PP.FIRST_NAME AS providerFirstName, PP.PROVIDER_SPECIALITY_CODE AS providerSpeciality,PTR.provider_type_desc AS providerTypeDescription,PA.PROVIDER_STREET_ADDRESS1 AS providerAddressStreet1, PA.PROVIDER_STREET_ADDRESS2 AS providerAddressStreet2, PA.PROVIDER_STREET_ADDRESS3 AS providerAddressStreet3,PA.PROVIDER_CITY_NAME AS providerAddressCity,PA.PROVIDER_STATE_CODE AS providerAddressState,PA.PROVIDER_ZIP_CODE AS providerAddressZipCode, MCS.TOTAL_BILLED_AMOUNT AS amountBilled, MCS.TOTAL_MEMBER_LIABILITY AS memberLiability,MCS.VERSION_NUMBER AS versionNumber,MCS.IS_SENSITIVE_CLAIM AS isSensitiveClaim, eobavailableIndicator = (CASE WHEN MCS.EOB_AVAILABLE_FLAG IS  NULL THEN '' ELSE MCS.EOB_AVAILABLE_FLAG END),eobkey = (CASE WHEN MCS.EOB_LINK IS  NULL THEN '' ELSE MCS.EOB_LINK END), pharmacyName = (CASE WHEN (PHP.PHARMACY_NAME IS NULL ) THEN '' ELSE  PHP.PHARMACY_NAME END), pharmacyCity = (CASE WHEN (PHP.PHARMACY_CITY IS NULL ) THEN '' ELSE PHP.PHARMACY_CITY  END), pharmacyStateCode = (CASE WHEN (PHP.PHARMACY_STATE_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_STATE_CODE  END), pharmacyZipCode = (CASE WHEN (PHP.PHARMACY_ZIP_CODE IS NULL ) THEN '' ELSE PHP.PHARMACY_ZIP_CODE  END)  , ROW_NUMBER() OVER (ORDER BY  "
								+ SortOnDB + " " + SortOrderDB
								+ ") R FROM  SS_SQL.MEMBER_PROFILE MP INNER JOIN SS_SQL.MEMBER_CLAIMS_SUMMARY MCS ON MP.MEMBER_PROFILE_ID=MCS.MEMBER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_ADDRESSES PA ON MCS.PROVIDER_PROFILE_ID=PA.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_PROFILE PP ON PA.PROVIDER_PROFILE_ID=PP.PROVIDER_PROFILE_ID INNER JOIN SS_SQL.PROVIDER_TYPE_REF PTR ON PP.PROVIDER_TYPE_CODE=PTR.provider_type_code INNER JOIN SS_SQL.CLAIM_STATUS_REF CSR ON CSR.PROCESSED_STATUS_CODE = MCS.PROCESSED_STATUS_CODE INNER JOIN SS_SQL.CLAIM_TYPE_REF CTR ON MCS.CLAIM_TYPE_CODE = CTR.CLAIM_TYPE_CODE LEFT JOIN SS_SQL.PHARMACY_PROFILES PHP ON MCS.PHARMACY_PROFILE_ID=PHP.PHARMACY_PROFILE_ID WHERE (MCS.SERVICE_FROM_DATE BETWEEN '"
								+ startDate + "' AND '" + endDate + "' OR MCS.SERVICE_TO_DATE BETWEEN '" + startDate
								+ "' AND '" + endDate + "' ) AND MP.DEPENDENT_ID = '" + dependentID
								+ "' AND MCS.CLAIM_TYPE_CODE IN ('" + claimType
								+ "') AND MCS. PROCESSED_STATUS_CODE IN ('" + claimStatus
								+ "') AND MP.SUBSCRIBER_ID like  '" + subscriberID + "') a WHERE a.R BETWEEN "
								+ LOWERLIMITDB + " AND " + UPPERLIMITDB + "";
					}
				}
				Assert.done("Start-> Validation of the Static Data");

				Map<String, String> map = new HashMap<>();
				startDate = startDate.substring(0, 4) + "-" + startDate.substring(4, 6) + "-" + startDate.substring(6);
				map.put("startDate", startDate);
				endDate = endDate.substring(0, 4) + "-" + endDate.substring(4, 6) + "-" + endDate.substring(6);
				map.put("claimType", claimType);
				map.put("endDate", endDate);
				if (!(pageLoad.equalsIgnoreCase(""))) {
					map.put("pageLoad", pageLoad);
					map.put("pageOffset", pageOffset);
				} else {
					map.put("pageLoad", UPPERLIMITDB);
					map.put("pageOffset", LOWERLIMITDB);
				}

				ValidateMethods.validateStaticFieldsWithDb1(ClaimObj, strQuery, "Microsoft", ReportFilePath, map,
						countQuery);

				// Validating Dynamic Fields With DB
				Assert.done("Start-> Validation of the Dynamic Data");

				String claimLineDetail = "claimMultipleLine";
				String[] uniqueColumn2 = null;
				if (!(sensitiveClaimInfo.equalsIgnoreCase("M"))) {
					uniqueColumn2 = new String[] { "processDate", "claimSummaryID", "claimTypeDescription", "N" };
				} else {
					uniqueColumn2 = new String[] { "claimNumber", "startDate", "endDate", "M" };
				}
				ValidateMethods.validateJsonArrayDataWithDbForThreecoloumn(ClaimObj, claimLineDetail,
						claimLineDetailsQuery, uniqueColumn2, "Microsoft", ReportFilePath);

			} catch (Exception e) {
				Assert.done("Completed");
			}
		} else {

			Assert.done("Test ID: " + testID);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg");
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {
					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
			}
		}
	}

	/**
	 * This method is used to validate the JSON data and DB data of FindPCP service
	 * 
	 * @param content
	 *            = JSON Response data
	 * @param testID
	 *            = TestCase ID
	 * @throws Exception
	 */
	public static void validateFindPCP(String content, String testID, String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		//String testdir = Environment.get("PCP_BASE_DIR");
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";
		DataTable1 Dttestdata = new DataTable1(testdir + "PCP.xls", "FindPCP_Input", "" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String ReportFilePath = "";
		if(Environment.get("Jenkins_Run").equalsIgnoreCase("Yes")) {
		String excelName = Environment.get("FindPCP_XML");		
		String excelReportName = excelName.replace(".xml", ".xslx");
		 ReportFilePath = Environment.get("report_path")+"//"+excelReportName;
		}
		else {
		 ReportFilePath = Environment.get("FindPCP_Excel_path");
		}
		//String ReportFilePath = Environment.get("FindPCP_Excel_path");
		String testDesc = Dttestdata.getValue("Test_Description");
		if (content.contains("errorCode")) {
			errorflag = false;
		} else {
			validateflag = true;
		}
		if (validateflag) {
			Object obj = jsonparser.parse(content);
			JSONObject PCPobj = (JSONObject) obj;

			String inputtestID = Dttestdata.getValue("TestID");

			String productID = Dttestdata.getValue("productId");
			String memeCK = Dttestdata.getValue("MemeCK");
			String subscriberID = Dttestdata.getValue("SubscriberID");
			String dependentID = Dttestdata.getValue("DependentID");
			String pcpfname = Dttestdata.getValue("pcpFirstName");
			String pcplname = Dttestdata.getValue("pcpLastName");
			String state = Dttestdata.getValue("state");
			String city = Dttestdata.getValue("city");
			String zip = Dttestdata.getValue("zip");
			String npi = Dttestdata.getValue("npi");
			String date = Dttestdata.getValue("date");
			String speciality = Dttestdata.getValue("speciality");
			String strQuery = "";
			String PCP_count = "";
			String staticQuery = "";
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			int PCP_InfoSize = 0;

			try {
				Assert.done("Test ID: " + inputtestID);
				Assert.done("Test Description: " + testDesc);
				if (!(subscriberID.equals("") && dependentID.equals(""))) {
					String subQuery = "SELECT S.SBSB_ID, M.MEME_CK FROM CMC_SBSB_SUBSC S "
							+ " INNER JOIN CMC_MEME_MEMBER M ON S.SBSB_CK = M.SBSB_CK " + " WHERE S.SBSB_ID='"
							+ subscriberID + "' AND M.MEME_SFX= " + dependentID + " ";
					org.json.JSONArray dbDetails = ViewClaimsDBS.getMemberInfofromDBS(subQuery, "Sybase");
					memeCK = dbDetails.getJSONObject(0).getString("MEME_CK");
				}
				/*JSONParser parser = new JSONParser();
				JSONArray PCPArray = (JSONArray) parser.parse(PCPobj.get("PCP_INFO").toString());
				PCP_InfoSize = PCPArray.size();
				if (PCP_InfoSize < 200) {
					PCP_count = "F";
				} else {
					PCP_count = "T";
				}*/

				if (!pcpfname.equalsIgnoreCase("")) {
					city = "";
					state = "";
				}
				zip = zip.replace(",", "','");

				if (date.equalsIgnoreCase("")) {
					Date currentDate = new Date();
					date = dateFormat.format(currentDate);
				}
				if(npi.equalsIgnoreCase("")) {
					npi = "NULL";
				}

				/*staticQuery = "SELECT UserID = 'CHNLESBMEP',SBSB.SBSB_ID AS SUBSCRIBER_ID, MEME.MEME_SFX AS DEPENDENT_ID, PCP_COUNT_FLAG = '"
						+ PCP_count + "' "
						+ " FROM CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME ON SBSB.SBSB_CK = MEME.MEME_CK "
						+ "WHERE  MEME.MEME_CK = " + memeCK + " ";

				ValidateMethods.validateStaticFieldsWithDb(PCPobj, staticQuery, "Sybase", ReportFilePath);*/
				if (pcpfname.equalsIgnoreCase("") && (!pcplname.equalsIgnoreCase(""))) {
					strQuery = "SELECT DISTINCT TOP 201 PRCP.PRCP_FIRST_NAME AS pcp_FIRST_NAME,PRCP.PRCP_LAST_NAME AS pcp_LAST_NAME, "
							+ "PRPR.PRCF_MCTR_SPEC AS pcp_PRIMARY_SPEC,MCTR.MCTR_DESC AS spec_DESC,PRAD.PRAD_ADDR1 AS address1,"
							+ "PRAD.PRAD_ADDR2 AS address2,PRAD.PRAD_ADDR3 AS address3,PRCP.PRCP_TITLE AS pcp_TITLE,"
							+ "group_NAME = (CASE WHEN(prprg.PRPR_NAME IS NULL) THEN '' ELSE prprg.PRPR_NAME END) ,"
							+ "PRPR.PRPR_ID AS provider_ID,PRAD.PRAD_CITY AS city,PRAD.PRAD_STATE AS state,PRAD.PRAD_ZIP AS zip,"
							+ "group_ID = (CASE WHEN(prer.PRER_PRPR_ID IS NULL) THEN '' else prer.PRER_PRPR_ID END) "
							+ "FROM CMC_MEPE_PRCS_ELIG MEPE INNER JOIN CMC_CSPI_CS_PLAN CSPI ON MEPE.MEME_CK = "
							+ memeCK + " and CSPI.PDPD_ID='" + productID + "' "
							+ "AND MEPE.CSPD_CAT='M' AND MEPE.MEPE_ELIG_IND='Y' "
							+ "AND CSPI.GRGR_CK=MEPE.GRGR_CK AND CSPI.CSPD_CAT=MEPE.CSPD_CAT AND CSPI.CSCS_ID=MEPE.CSCS_ID "
							+ "AND CSPI.PDPD_ID=MEPE.PDPD_ID AND CSPI.CSPI_ID=MEPE.CSPI_ID INNER JOIN CMC_NWST_NET_SET NWST ON CSPI.NWST_PFX=NWST.NWST_PFX "
							+ "AND '" + date
							+ "' BETWEEN NWST.NWST_EFF_DT AND NWST.NWST_TERM_DT INNER JOIN CMC_NWPR_RELATION NWPR ON NWST.NWNW_ID=NWPR.NWNW_ID "
							+ "AND  NWPR.NWPR_PFX=NWST.NWPR_PFX AND NWPR.NWPR_PCP_IND = 'Y' AND '" + date
							+ "' BETWEEN NWPR.NWPR_EFF_DT AND NWPR.NWPR_TERM_DT "
							+ "INNER JOIN CMC_PRPR_PROV PRPR ON NWPR.PRPR_ID = PRPR.PRPR_ID "
							+ "INNER JOIN CMC_PRAD_ADDRESS PRAD ON PRPR.PRAD_ID = PRAD.PRAD_ID "
							+ "AND PRAD.PRAD_TYPE like 'P%' AND '" + date
							+ "' BETWEEN  PRAD.PRAD_EFF_DT AND PRAD.PRAD_TERM_DT "
							+ "INNER JOIN CMC_PRCP_COMM_PRAC PRCP ON PRPR.PRCP_ID = PRCP.PRCP_ID  AND PRPR.PRPR_ENTITY='P' "
							+ "AND ( LOWER(PRCP.PRCP_LAST_NAME) LIKE '%' +LOWER('" + pcplname + "') +'%' ) "
							+ "INNER JOIN CMC_MCTR_CD_TRANS MCTR ON MCTR.MCTR_VALUE=PRPR.PRCF_MCTR_SPEC AND MCTR.MCTR_ENTITY = 'PRAC' "
							+ "AND MCTR.MCTR_TYPE ='SPEC' LEFT JOIN CMC_PRER_RELATION prer ON PRPR.PRPR_ID=prer.PRPR_ID  AND prer.PRER_PRPR_ENTITY='G' "
							+ "AND '" + date
							+ "' BETWEEN  prer.PRER_EFF_DT AND prer.PRER_TERM_DT LEFT JOIN CMC_PRPR_PROV prprg ON prer.PRER_PRPR_ID=prprg.PRPR_ID --order by PRAD.PRAD_TYPE ";

				} else if ((!pcpfname.equalsIgnoreCase("") && (!pcplname.equalsIgnoreCase("")))
						|| (!zip.equalsIgnoreCase("") && (speciality.equalsIgnoreCase("")))) {
					strQuery = "SELECT DISTINCT TOP 201 PRCP.PRCP_FIRST_NAME AS pcp_FIRST_NAME,PRCP.PRCP_LAST_NAME AS pcp_LAST_NAME, "
							+ "PRPR.PRCF_MCTR_SPEC AS pcp_PRIMARY_SPEC,MCTR.MCTR_DESC AS spec_DESC,PRAD.PRAD_ADDR1 AS address1,"
							+ "PRAD.PRAD_ADDR2 AS address2,PRAD.PRAD_ADDR3 AS address3,PRCP.PRCP_TITLE AS pcp_TITLE,"
							+ "group_NAME = (CASE WHEN(prprg.PRPR_NAME IS NULL) THEN '' ELSE prprg.PRPR_NAME END),"
							+ "PRPR.PRPR_ID AS provider_ID,PRAD.PRAD_CITY AS city,PRAD.PRAD_STATE AS state,PRAD.PRAD_ZIP AS zip,"
							+ "group_ID = (CASE WHEN(prer.PRER_PRPR_ID IS NULL) THEN '' else prer.PRER_PRPR_ID END) "
							+ "FROM CMC_MEPE_PRCS_ELIG MEPE INNER JOIN CMC_CSPI_CS_PLAN CSPI ON MEPE.MEME_CK = "
							+ memeCK + " and CSPI.PDPD_ID='" + productID + "' "
							+ "AND MEPE.CSPD_CAT='M' AND MEPE.MEPE_ELIG_IND='Y' "
							+ "AND CSPI.GRGR_CK=MEPE.GRGR_CK AND CSPI.CSPD_CAT=MEPE.CSPD_CAT AND CSPI.CSCS_ID=MEPE.CSCS_ID "
							+ "AND CSPI.PDPD_ID=MEPE.PDPD_ID AND CSPI.CSPI_ID=MEPE.CSPI_ID INNER JOIN CMC_NWST_NET_SET NWST ON CSPI.NWST_PFX=NWST.NWST_PFX "
							+ "AND '" + date
							+ "' BETWEEN NWST.NWST_EFF_DT AND NWST.NWST_TERM_DT INNER JOIN CMC_NWPR_RELATION NWPR ON NWST.NWNW_ID=NWPR.NWNW_ID "
							+ "AND  NWPR.NWPR_PFX=NWST.NWPR_PFX AND NWPR.NWPR_PCP_IND = 'Y' AND '" + date
							+ "' BETWEEN NWPR.NWPR_EFF_DT AND NWPR.NWPR_TERM_DT "
							+ "INNER JOIN CMC_PRPR_PROV PRPR ON NWPR.PRPR_ID = PRPR.PRPR_ID "
							+ "INNER JOIN CMC_PRAD_ADDRESS PRAD ON PRPR.PRAD_ID = PRAD.PRAD_ID "
							+ "AND PRAD.PRAD_TYPE like 'P%' AND '" + date
							+ "' BETWEEN  PRAD.PRAD_EFF_DT AND PRAD.PRAD_TERM_DT "
							+ "INNER JOIN CMC_PRCP_COMM_PRAC PRCP ON PRPR.PRCP_ID = PRCP.PRCP_ID  AND PRPR.PRPR_ENTITY='P' "
							+ "AND ((LOWER(PRAD.PRAD_STATE) = LOWER('" + state
							+ "') AND LOWER(PRAD.PRAD_CITY) LIKE '%'+ LOWER('" + city + "')+'%')  "
							+ "or (LOWER(PRCP.PRCP_FIRST_NAME) = LOWER('" + pcpfname
							+ "') AND LOWER(PRCP.PRCP_LAST_NAME) LIKE '%' +LOWER('" + pcplname
							+ "') +'%' ) OR PRAD.PRAD_ZIP IN ('" + zip + "') ) "
							+ "INNER JOIN CMC_MCTR_CD_TRANS MCTR ON MCTR.MCTR_VALUE=PRPR.PRCF_MCTR_SPEC AND MCTR.MCTR_ENTITY = 'PRAC' "
							+ "AND MCTR.MCTR_TYPE ='SPEC' LEFT JOIN CMC_PRER_RELATION prer ON PRPR.PRPR_ID=prer.PRPR_ID  AND prer.PRER_PRPR_ENTITY='G' "
							+ "AND '" + date
							+ "' BETWEEN  prer.PRER_EFF_DT AND prer.PRER_TERM_DT LEFT JOIN CMC_PRPR_PROV prprg ON prer.PRER_PRPR_ID=prprg.PRPR_ID --order by PRAD.PRAD_TYPE ";

				} else {
					strQuery = "SELECT DISTINCT TOP 201 PRCP.PRCP_FIRST_NAME AS pcp_FIRST_NAME,PRCP.PRCP_LAST_NAME AS pcp_LAST_NAME, "
							+ "PRPR.PRCF_MCTR_SPEC AS pcp_PRIMARY_SPEC,MCTR.MCTR_DESC AS spec_DESC,PRAD.PRAD_ADDR1 AS address1,"
							+ "PRAD.PRAD_ADDR2 AS address2,PRAD.PRAD_ADDR3 AS address3,PRCP.PRCP_TITLE AS pcp_TITLE,"
							+ "group_NAME = (CASE WHEN(prprg.PRPR_NAME IS NULL) THEN '' ELSE prprg.PRPR_NAME END),"
							+ "PRPR.PRPR_ID AS provider_ID,PRAD.PRAD_CITY AS city,PRAD.PRAD_STATE AS state,PRAD.PRAD_ZIP AS zip,"
							+ "group_ID = (CASE WHEN(prer.PRER_PRPR_ID IS NULL) THEN '' else prer.PRER_PRPR_ID END)"
							+ "FROM CMC_MEPE_PRCS_ELIG MEPE INNER JOIN CMC_CSPI_CS_PLAN CSPI ON MEPE.MEME_CK = "
							+ memeCK + " and CSPI.PDPD_ID='" + productID + "' "
							+ "AND MEPE.CSPD_CAT='M' AND MEPE.MEPE_ELIG_IND='Y' "
							+ "AND CSPI.GRGR_CK=MEPE.GRGR_CK AND CSPI.CSPD_CAT=MEPE.CSPD_CAT AND CSPI.CSCS_ID=MEPE.CSCS_ID "
							+ "AND CSPI.PDPD_ID=MEPE.PDPD_ID AND CSPI.CSPI_ID=MEPE.CSPI_ID INNER JOIN CMC_NWST_NET_SET NWST ON CSPI.NWST_PFX=NWST.NWST_PFX "
							+ "AND '" + date
							+ "' BETWEEN NWST.NWST_EFF_DT AND NWST.NWST_TERM_DT INNER JOIN CMC_NWPR_RELATION NWPR ON NWST.NWNW_ID=NWPR.NWNW_ID "
							+ "AND  NWPR.NWPR_PFX=NWST.NWPR_PFX AND NWPR.NWPR_PCP_IND = 'Y' AND '" + date
							+ "' BETWEEN NWPR.NWPR_EFF_DT AND NWPR.NWPR_TERM_DT "
							+ "INNER JOIN CMC_PRPR_PROV PRPR ON NWPR.PRPR_ID = PRPR.PRPR_ID "
							+ "INNER JOIN CMC_PRAD_ADDRESS PRAD ON PRPR.PRAD_ID = PRAD.PRAD_ID "
							+ "AND PRAD.PRAD_TYPE like 'P%' AND '" + date
							+ "' BETWEEN  PRAD.PRAD_EFF_DT AND PRAD.PRAD_TERM_DT "
							+ "INNER JOIN CMC_PRCP_COMM_PRAC PRCP ON PRPR.PRCP_ID = PRCP.PRCP_ID  AND PRPR.PRPR_ENTITY='P' "
							+ "AND (( PRPR.PRPR_NPI = '" + npi + "' OR PRPR.PRCF_MCTR_SPEC ='" + speciality
							+ "' ) AND ((LOWER(PRAD.PRAD_STATE) = LOWER('" + state
							+ "') AND LOWER(PRAD.PRAD_CITY) LIKE '%'+ LOWER('" + city + "')+'%') "
							+ "OR PRAD.PRAD_ZIP IN ('" + zip + "')))  "
							+ "INNER JOIN CMC_MCTR_CD_TRANS MCTR ON MCTR.MCTR_VALUE=PRPR.PRCF_MCTR_SPEC AND MCTR.MCTR_ENTITY = 'PRAC' "
							+ "AND MCTR.MCTR_TYPE ='SPEC' LEFT JOIN CMC_PRER_RELATION prer ON PRPR.PRPR_ID=prer.PRPR_ID  AND prer.PRER_PRPR_ENTITY='G' "
							+ "AND '" + date
							+ "' BETWEEN  prer.PRER_EFF_DT AND prer.PRER_TERM_DT LEFT JOIN CMC_PRPR_PROV prprg ON prer.PRER_PRPR_ID=prprg.PRPR_ID WHERE  PRCP.PRCP_TITLE <>'' --order by PRAD.PRAD_TYPE " ;

				}
				String pcpdetails = "PCP";
				String[] UniqueColumn = {"provider_ID","pcp_FIRST_NAME","address1"};

				ValidateMethods.validateJsonArrayDataWithDB3(PCPobj, pcpdetails, strQuery, UniqueColumn, "Sybase",
						ReportFilePath);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Assert.done("Test ID: " + testID);
			Assert.done("Test Description: " + testDesc);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg");
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {

					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
				Assert.fail(content);
			}
		}
	}

	// ************************************HELPER FUNCTION ***********************\\

	private static String checkNullStartEndDate(String dateParameter) throws Exception {
		if (dateParameter.equalsIgnoreCase("")) {
			DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			Date date = new Date();
			dateParameter = dateFormat.format(date);
		}
		return dateParameter;
	}

	/**
	 * This method is used to validate the JSON data and DB data of GetMember
	 * Demographics service
	 * 
	 * @param content
	 *            = JSON Response data
	 * @param testID
	 *            = TestCase ID
	 * @throws Exception
	 */

	/**
	 * This method is used to validate the JSON data and DB data of GetMember
	 * Demographics service
	 * 
	 * @param content
	 *            = JSON Response data
	 * @param testID
	 *            = TestCase ID
	 * @throws Exception
	 */

	public static void validateGetMember(String content, String testID, String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		//String testdir = Environment.get("Member_Base_Dir");
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";
		DataTable1 Dttestdata = new DataTable1(testdir + "Member.xls", "GetMemberDemographics_Input", "" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String ReportFilePath = "";
		if(Environment.get("Jenkins_Run").equalsIgnoreCase("Yes")) {
		String excelName = Environment.get("GetMember_XML");		
		String excelReportName = excelName.replace(".xml", ".xslx");
		 ReportFilePath = Environment.get("report_path")+"//"+excelReportName;
		}
		else {
		 ReportFilePath = Environment.get("GetMemberDemo_excel_path");
		}
		//String ReportFilePath = Environment.get("Report_excel_path");
		if (content.contains("errorCode")) {
			errorflag = false;
		} else {
			validateflag = true;
		}
		if (validateflag) {
			Object obj = jsonparser.parse(content);
			JSONObject Memberobj = (JSONObject) obj;

			String inputtestID = Dttestdata.getValue("TestID");
			String testDesc = Dttestdata.getValue("Test_Description");
			String UserID = Dttestdata.getValue("UserID");
			String SubscriberID = Dttestdata.getValue("SubscriberID");
			String DependentID = Dttestdata.getValue("DependentID");
			String MemberContrivedKey = Dttestdata.getValue("MemberContrivedKey");
			String SubscriberContrivedKey = Dttestdata.getValue("SubscriberContrivedKey");
			// String productType = Dttestdata.getValue("ProductType");
			String dependentDetails = "";
			String strQuery = "";
			String staticQuery = "";
			String memberQuery = "";
			String dependentQuery = "";
			String sbsbCK = "";
			String MemeSfx = "";
			if (!(SubscriberContrivedKey.equals(""))) {
				MemeSfx = "0";
				sbsbCK = SubscriberContrivedKey;
			} else {
				sbsbCK = null;
			}

			if (!(DependentID.equals(""))) {
				strQuery = "SELECT SBSB.SBSB_ID, MEME_SFX FROM CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME ON SBSB.SBSB_CK = MEME.SBSB_CK WHERE SBSB.SBSB_ID = '"
						+ SubscriberID + "' AND MEME_SFX=" + DependentID + " ";
				//org.json.JSONArray dbSubscriberDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, "Sybase");
				org.json.JSONArray dbSubscriberDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, "Sybase");
				MemeSfx = dbSubscriberDetails.getJSONObject(0).getString("MEME_SFX");
			} else if (!(MemberContrivedKey.equals(""))) {
				strQuery = "SELECT SBSB.SBSB_ID, MEME_SFX FROM CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME ON SBSB.SBSB_CK = MEME.SBSB_CK WHERE "
						+ " MEME.MEME_CK = " + MemberContrivedKey + "";
				//org.json.JSONArray dbSubscriberDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, "Sybase");
				org.json.JSONArray dbSubscriberDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, "Sybase");
				MemeSfx = dbSubscriberDetails.getJSONObject(0).getString("MEME_SFX");

			} else {

				strQuery = "SELECT distinct SBSB_ID FROM CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME ON SBSB.SBSB_CK = MEME.SBSB_CK WHERE SBSB.SBSB_ID = '"
						+ SubscriberID + "' Or SBSB.SBSB_CK=" + sbsbCK + " ";
				//org.json.JSONArray dbSubscriberDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, "Sybase");
				org.json.JSONArray dbSubscriberDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, "Sybase");
				String SbsbID = dbSubscriberDetails.getJSONObject(0).getString("SBSB_ID");
				MemeSfx = "0";
			}
			Assert.done("Test ID: " + inputtestID);
			Assert.done("Test Description: " + testDesc);
			if (!(DependentID.equals(""))) {
				dependentDetails = "SELECT SBSB_ID, MEME_SFX FROM CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME ON MEME.SBSB_CK = SBSB.SBSB_CK WHERE SBSB.SBSB_ID = '"
						+ SubscriberID + "' AND MEME.MEME_SFX =" + DependentID + "";
				//org.json.JSONArray dependentdetails = ViewClaimsDBS.getMemberInfofromDBS(dependentDetails, "Sybase");
				org.json.JSONArray dependentdetails = ViewClaimsDBS.getMemberInfofromDBS(dependentDetails, "Sybase");
				if (dependentdetails.length() != 0) {
					Assert.done("Dependent ID is present in the DB");
				}
			}
			if (MemberContrivedKey.equals("")) {
				MemberContrivedKey = null;
			}

			Assert.done("--Validating Static fields--");
			if (!(MemeSfx.equals("0") || (MemeSfx.equals("1")))) {
				staticQuery = "SELECT MEME.SBSB_CK as subscriberContrivedKey,addressStreet1 ='',addressStreet2='' ,"
						+ "addressStreet3 = '',zipCode= '',billingaddressTypeIndicator ='B'  "
						+ " ,city='' ,SBSB.SBSB_ID as subscriberID,state = '' "
						+ "FROM CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME ON MEME.SBSB_CK = SBSB.SBSB_CK INNER JOIN CMC_SBAD_ADDR SBAD ON SBAD.SBSB_CK = SBSB.SBSB_CK  "
						+ "WHERE (SBSB.SBSB_ID ='" + SubscriberID + "'  OR MEME.MEME_CK =" + MemberContrivedKey
						+ "  )  AND "
						+ "(SBAD.SBAD_TYPE = MEME.SBAD_TYPE_HOME OR SBAD.SBAD_TYPE = MEME.SBAD_TYPE_MAIL)";

			} else {
				staticQuery = "SELECT MEME.SBSB_CK as subscriberContrivedKey,BEIN.BEIN_BLEI_ADDR1 as addressStreet1,BEIN.BEIN_BLEI_ADDR2 as addressStreet2,BEIN.BEIN_BLEI_ADDR3 as addressStreet3, BEIN.BEIN_BLEI_ZIP as zipCode,billingaddressTypeIndicator = (CASE WHEN (MEME.MEME_SFX= 0 )THEN 'B' ELSE ' ' END),BEIN.BEIN_BLEI_CITY as city ,SBSB.SBSB_ID as subscriberID,BEIN.BEIN_BLEI_STATE as state"
						+ " FROM CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME ON MEME.SBSB_CK = SBSB.SBSB_CK INNER JOIN CMC_SBAD_ADDR SBAD ON SBAD.SBSB_CK = SBSB.SBSB_CK INNER JOIN CDS_BEIN_BL_INDIC BEIN ON SBAD.SBSB_CK = BEIN.SBSB_CK"
						+ " WHERE (SBSB.SBSB_ID ='" + SubscriberID + "'  OR MEME.MEME_CK =" + MemberContrivedKey + " "
						+ " OR SBSB.SBSB_CK = " + sbsbCK + ") AND MEME.MEME_SFX=0 AND"
						+ " (SBAD.SBAD_TYPE = MEME.SBAD_TYPE_HOME OR SBAD.SBAD_TYPE = MEME.SBAD_TYPE_MAIL)";

			}
			//ValidateMethods.validateStaticFieldsWithDb(Memberobj, staticQuery, "Sybase", ReportFilePath);
			ValidateMethods.validateStaticFieldsWithDb(Memberobj, staticQuery, "Sybase", ReportFilePath);

			String memberDemographicDetails = "memberDemographicDetails";
			String UniqueColumn = "addressType";

			Assert.done("--Validating Member Demographic Details--");
			if ((DependentID.equals("")) && (!(SubscriberID.equals("")))) {
				memberQuery = "SELECT distinct SBAD.SBAD_TYPE as addressType,SBAD.SBAD_CITY as city ,SBAD.SBAD_ZIP as zipCode,SBAD.SBAD_ADDR1 as addressStreet1,SBAD.SBAD_ADDR2 as addressStreet2,SBAD.SBAD_ADDR3 as addressStreet3,SBAD.SBAD_PHONE as phoneNumber,SBAD.SBAD_PHONE_EXT as phoneExtension,(CASE WHEN (MEME.MEME_SFX= 0 )THEN SBAD.SBAD_EMAIL ELSE '' END) as emailID,SBAD.SBAD_STATE as state"
						+ " FROM CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME ON MEME.SBSB_CK = SBSB.SBSB_CK INNER JOIN CMC_SBAD_ADDR SBAD ON SBAD.SBSB_CK = SBSB.SBSB_CK"
						+ " WHERE SBSB.SBSB_ID ='" + SubscriberID + "'" + "  AND "
						+ "( SBAD.SBAD_TYPE = MEME.SBAD_TYPE_HOME OR SBAD.SBAD_TYPE = MEME.SBAD_TYPE_MAIL ) ";

				dependentQuery = "SELECT distinct MEME.MEME_CK as memberContrivedKey,MEME.SBAD_TYPE_HOME as addressTypeHome,MEME.SBAD_TYPE_MAIL as addressTypeMail,MEME.MEME_FIRST_NAME as memberFirstName,MEME.MEME_LAST_NAME as memberLastName, MEME.MEME_MID_INIT as memberMiddleName,MEME.MEME_WRK_PHONE as workPhone,MEME.MEME_WRK_PHONE_EXT as workPhoneExtn,MEME.MEME_CELL_PHONE as mobilePhone,MEME.MEME_SFX as dependentID"
						+ " FROM CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME ON MEME.SBSB_CK = SBSB.SBSB_CK INNER JOIN CMC_SBAD_ADDR SBAD ON SBAD.SBSB_CK = SBSB.SBSB_CK"
						+ " WHERE SBSB.SBSB_ID ='" + SubscriberID + "' AND "
						+ "( SBAD.SBAD_TYPE = MEME.SBAD_TYPE_HOME OR SBAD.SBAD_TYPE = MEME.SBAD_TYPE_MAIL )";

			} else {

				if (!(SubscriberContrivedKey.equals(""))) {

					memberQuery = "SELECT distinct SBAD.SBAD_TYPE as addressType,SBAD.SBAD_CITY as city ,SBAD.SBAD_ZIP as zipCode,SBAD.SBAD_ADDR1 as addressStreet1,SBAD.SBAD_ADDR2 as addressStreet2,SBAD.SBAD_ADDR3 as addressStreet3,SBAD.SBAD_PHONE as phoneNumber,SBAD.SBAD_PHONE_EXT as phoneExtension,(CASE WHEN (MEME.MEME_SFX <>0 AND ATXR.ATSY_ID = 'EMAL' )THEN ATXR.ATXR_DESC ELSE SBAD.SBAD_EMAIL END) as emailID,SBAD.SBAD_STATE as state"
							+ " FROM CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME ON MEME.SBSB_CK = SBSB.SBSB_CK  Inner JOIN CER_ATXR_ATTACH_U ATXR ON MEME.ATXR_SOURCE_ID = ATXR.ATXR_SOURCE_ID INNER JOIN  "
							+ "CMC_SBAD_ADDR SBAD ON SBAD.SBSB_CK = SBSB.SBSB_CK" + " WHERE  SBSB.SBSB_CK ="
							+ SubscriberContrivedKey + " "
							+ " AND ( SBAD.SBAD_TYPE = MEME.SBAD_TYPE_HOME OR SBAD.SBAD_TYPE = MEME.SBAD_TYPE_MAIL ) AND ATXR_CREATE_USUS='' ";

				}

				else if ((!(DependentID.equals(""))) || (!(MemberContrivedKey.equals("")))) {
					memberQuery = "SELECT distinct SBAD.SBAD_TYPE as addressType,SBAD.SBAD_CITY as city ,SBAD.SBAD_ZIP as zipCode,SBAD.SBAD_ADDR1 as addressStreet1,SBAD.SBAD_ADDR2 as addressStreet2,SBAD.SBAD_ADDR3 as addressStreet3,SBAD.SBAD_PHONE as phoneNumber,SBAD.SBAD_PHONE_EXT as phoneExtension,(CASE WHEN (MEME.MEME_SFX >2 )THEN SBAD.SBAD_EMAIL ELSE '' END) as emailID,SBAD.SBAD_STATE as state"
							+ " FROM CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME ON MEME.SBSB_CK = SBSB.SBSB_CK  Inner JOIN CER_ATXR_ATTACH_U ATXR ON MEME.ATXR_SOURCE_ID = ATXR.ATXR_SOURCE_ID INNER JOIN  "
							+ "CMC_SBAD_ADDR SBAD ON SBAD.SBSB_CK = SBSB.SBSB_CK" + " WHERE (SBSB.SBSB_ID ='"
							+ SubscriberID + "' AND MEME.MEME_SFX=" + MemeSfx + ") OR MEME.MEME_CK ="
							+ MemberContrivedKey + " "
							+ " AND ( SBAD.SBAD_TYPE = MEME.SBAD_TYPE_HOME OR SBAD.SBAD_TYPE = MEME.SBAD_TYPE_MAIL ) ";

				} else {

					memberQuery = "SELECT distinct SBAD.SBAD_TYPE as addressType,SBAD.SBAD_CITY as city ,SBAD.SBAD_ZIP as zipCode,SBAD.SBAD_ADDR1 as addressStreet1,SBAD.SBAD_ADDR2 as addressStreet2,SBAD.SBAD_ADDR3 as addressStreet3,SBAD.SBAD_PHONE as phoneNumber,SBAD.SBAD_PHONE_EXT as phoneExtension,(CASE WHEN (MEME.MEME_SFX <>0 AND ATXR.ATSY_ID = 'EMAL' )THEN ATXR.ATXR_DESC ELSE SBAD.SBAD_EMAIL END) as emailID,SBAD.SBAD_STATE as state"
							+ " FROM CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME ON MEME.SBSB_CK = SBSB.SBSB_CK  Inner JOIN CER_ATXR_ATTACH_U ATXR ON MEME.ATXR_SOURCE_ID = ATXR.ATXR_SOURCE_ID INNER JOIN  "
							+ "CMC_SBAD_ADDR SBAD ON SBAD.SBSB_CK = SBSB.SBSB_CK" + " WHERE (SBSB.SBSB_ID ='"
							+ SubscriberID + "' AND MEME.MEME_SFX=" + MemeSfx + ") OR MEME.MEME_CK ="
							+ MemberContrivedKey + " "
							+ " AND ( SBAD.SBAD_TYPE = MEME.SBAD_TYPE_HOME OR SBAD.SBAD_TYPE = MEME.SBAD_TYPE_MAIL )";

				}
				if (SubscriberContrivedKey.equals("")) {
					SubscriberContrivedKey = null;
				}
				dependentQuery = "SELECT distinct MEME.MEME_CK as memberContrivedKey,MEME.SBAD_TYPE_HOME as addressTypeHome,MEME.SBAD_TYPE_MAIL as addressTypeMail,MEME.MEME_FIRST_NAME as memberFirstName,MEME.MEME_LAST_NAME as memberLastName, MEME.MEME_MID_INIT as memberMiddleName,MEME.MEME_WRK_PHONE as workPhone,MEME.MEME_WRK_PHONE_EXT as workPhoneExtn,MEME.MEME_CELL_PHONE as mobilePhone,MEME.MEME_SFX as dependentID"
						+ " FROM CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME ON MEME.SBSB_CK = SBSB.SBSB_CK INNER JOIN CMC_SBAD_ADDR SBAD ON SBAD.SBSB_CK = SBSB.SBSB_CK"
						+ " WHERE (SBSB.SBSB_ID ='" + SubscriberID + "' AND MEME.MEME_SFX =" + MemeSfx
						+ ") OR SBSB.SBSB_CK =" + SubscriberContrivedKey + " OR MEME.MEME_CK =" + MemberContrivedKey
						+ " AND " + "( SBAD.SBAD_TYPE = MEME.SBAD_TYPE_HOME OR SBAD.SBAD_TYPE = MEME.SBAD_TYPE_MAIL )";

			}
			//ValidateMethods.validateJsonArrayDataWithDb(Memberobj, memberDemographicDetails, memberQuery, UniqueColumn,
					//"Sybase", ReportFilePath);
			ValidateMethods.validateJsonArrayDataWithDb(Memberobj, memberDemographicDetails, memberQuery, UniqueColumn,
					"Sybase", ReportFilePath);

			String deptDetails = "dependentDetails";
			String UniqueColumnTwo = "dependentID";

			Assert.done("--Validating Dependent details--");
			//ValidateMethods.validateJsonArrayDataWithDb(Memberobj, deptDetails, dependentQuery, UniqueColumnTwo,
					//"Sybase", ReportFilePath);
			ValidateMethods.validateJsonArrayDataWithDb(Memberobj, deptDetails, dependentQuery, UniqueColumnTwo,
					"Sybase", ReportFilePath);
		} else {
			Assert.done("Test ID: " + testID);
			String errorCode = Dttestdata.getValue("ErrorCode");
			if (!(errorCode.equalsIgnoreCase(""))) {
				if (content.contains(errorCode)) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {

					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
				Assert.fail(content);
			}
		}
	}

	/**
	 * This method is used to validate the JSON data and DB data of UpdatePCP
	 * service
	 * 
	 * @param content
	 *            = JSON Response data
	 * @param testID
	 *            = TestCase ID
	 * @throws Exception
	 */
	public static void validateUpdatePCP(String content, String testID, String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		//String testdir = Environment.get("PCP_BASE_DIR");
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";
		DataTable1 Dttestdata = new DataTable1(testdir + "PCP.xls", "UpdatePCP_Input", "" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		String test_ID = Dttestdata.getValue("TestID");
		String testDesc = Dttestdata.getValue("Test_Description");
		{
			if (content.contains("\"ErrorCode\" : \"\"")) {
				validateflag = true;
			}
		}
		if (validateflag) {
			String prprId = Dttestdata.getValue("PRPRid");
			String pcpType = Dttestdata.getValue("PCPType");
			String memeCK = Dttestdata.getValue("MemeCk");

			/*
			 * Object obj = jsonparser.parse(content); JSONObject updatePCP = (JSONObject)
			 * obj; value = updatePCP.get("AppReturnCode").toString();
			 */
			if (content.contains("\"AppReturnCode\" : \"0\"")) {
				// if (value.equalsIgnoreCase("0")) {
				Assert.done("Test ID: " + test_ID);
				Assert.done("Test Description: " + testDesc);
				String strQuery = "SELECT MEME_CK,PRPR_ID,MEPR_PCP_TYPE,CONVERT(DATE,MEPR_EFF_DT) AS effectiveDate FROM CMC_MEPR_PRIM_PROV WHERE MEME_CK = "
						+ memeCK + " AND MEPR_MCTR_TRSN =''";
				org.json.JSONArray dbDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, "Sybase");
				String dbprprID = dbDetails.getJSONObject(0).getString("PRPR_ID");
				String dbpcpType = dbDetails.getJSONObject(0).getString("MEPR_PCP_TYPE");
				String dbeffectiveDT = dbDetails.getJSONObject(0).getString("effectiveDate");
				if ((prprId.equalsIgnoreCase(dbprprID)) && (pcpType.equalsIgnoreCase(dbpcpType))
						&& (startDate.equalsIgnoreCase(dbeffectiveDT))) {
					Assert.pass("No application level errors");
				}
			} else if (content.contains("\"AppReturnCode\" : \"12\"")) {
				Assert.done("Unable to access the Facets Database");
			}

		} else {
			Assert.done("Test ID: " + testID);
			Assert.done("Test Description: " + testDesc);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorDescription");
			if (content.contains("\"AppReturnCode\" : \"8\"")) {
				if (!(errorCode.equalsIgnoreCase(""))) {
					if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
						UtilMethod.Log("Valid Error Code", "PASS", true);
						Assert.done("Returns Error: " + content);
					} else {

						UtilMethod.Log("Invalid Error Code", "FAIL", true);
					}
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
				Assert.fail(content);
			}
		}
	}

	/**
	 * This method is used to get startDateMinusTwoYears
	 * 
	 * @param dateParameter
	 *            = Date value
	 * @return
	 * @throws Exception
	 */
	private static String startDateMinusTwoYears(String dateParameter) throws Exception {
		if (dateParameter.equalsIgnoreCase("")) {
			DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			Date date = new Date();
			dateParameter = dateFormat.format(date);
			Calendar cal = Calendar.getInstance();
			Date Today = cal.getTime();
			cal.add(Calendar.YEAR, -3);
			Date nextYear = cal.getTime();
			dateParameter = dateFormat.format(nextYear);
		}
		return dateParameter;
	}

	/**
	 * This method is used to validate the JSON data and DB data of
	 * UpdateMemberDemographics service
	 * 
	 * @param content
	 *            = JSON response data
	 * @param testID
	 *            = TestCase ID
	 * @throws Exception
	 */
	public static void validateUpdateMember(String content, String testID, String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		//String testdir = Environment.get("Member_Base_Dir");
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";
		DataTable1 Dttestdata = new DataTable1(testdir + "Member.xls", "UpdateMember_Input", "" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String testDesc = Dttestdata.getValue("Test_Description");
		if (content.contains("\"ErrorCode\" : \"NA\"")) {
			validateflag = true;
		}
		if (validateflag) {
			String inputtestID = Dttestdata.getValue("TestID");
			String SubscriberID = Dttestdata.getValue("SubscriberID");
			String DependentID = Dttestdata.getValue("DependentID");
			String MemberCK = Dttestdata.getValue("MemberCK");
			String SbsbCK = Dttestdata.getValue("SubscriberCK");
			String MobilePhoneNumber = Dttestdata.getValue("MobilePhoneNumber").trim();
			String WorkPhoneNumber = Dttestdata.getValue("WorkPhoneNumber").trim();
			String WorkExtension = Dttestdata.getValue("WorkExtension").trim();
			String MailSameAsHomeIndicator = Dttestdata.getValue("MailSameAsHomeIndicator");
			String HomeAddressStreet1 = Dttestdata.getValue("HomeAddressStreet1").trim();
			String HomeAddressStreet2 = Dttestdata.getValue("HomeAddressStreet2").trim();
			String HomeAddressStreet3 = Dttestdata.getValue("HomeAddressStreet3").trim();
			String HomeCity = Dttestdata.getValue("HomeCity").trim();
			String HomeState = Dttestdata.getValue("HomeState").trim();
			String HomeZipCode = Dttestdata.getValue("HomeZipCode");
			String MailAddressStreet1 = Dttestdata.getValue("MailAddressStreet1").trim();
			String MailAddressStreet2 = Dttestdata.getValue("MailAddressStreet2").trim();
			String MailAddressStreet3 = Dttestdata.getValue("MailAddressStreet3").trim();
			String MailCity = Dttestdata.getValue("MailCity").trim();
			String MailState = Dttestdata.getValue("MailState").trim();
			String MailZipCode = Dttestdata.getValue("MailZipCode").trim();
			/*
			 * String AddressStreet1 = Dttestdata.getValue("AddressStreet1").trim(); String
			 * AddressStreet2 = Dttestdata.getValue("AddressStreet2").trim(); String
			 * AddressStreet3 = Dttestdata.getValue("AddressStreet3"); String City =
			 * Dttestdata.getValue("City").trim(); String State =
			 * Dttestdata.getValue("State"); String zip = Dttestdata.getValue("ZipCode");
			 */
			String EmailID = Dttestdata.getValue("EmailID").trim();
			String HomePhone = Dttestdata.getValue("HomePhone").trim();
			// String strQuery = "";
			String homeQuery = "";
			String mailQuery = "";
			if (content.contains("\"ErrorCode\" : \"NA\"")) {
				// if (value.equalsIgnoreCase("0")) {
				Assert.done("Test ID: " + inputtestID);
				Assert.done("Test Description: " + testDesc);
				if (SbsbCK.equalsIgnoreCase("")) {
					SbsbCK = null;
				}
				if (MemberCK.equalsIgnoreCase("")) {
					MemberCK = null;
				}
				if (DependentID.equalsIgnoreCase("")) {
					DependentID = null;
				}
				if (EmailID.equalsIgnoreCase("")) {
					homeQuery = "SELECT DISTINCT MEME.MEME_CELL_PHONE as MobilePhoneNumber,MEME.MEME_WRK_PHONE as WorkPhoneNumber,MEME.MEME_WRK_PHONE_EXT as phoneExtension,SBAD.SBAD_ADDR1 as addressStreet1,SBAD.SBAD_ADDR2 as addressStreet2, "
							+ " SBAD.SBAD_ADDR3 as addressStreet3,SBAD.SBAD_CITY as city ,SBAD.SBAD_STATE as state,SBAD.SBAD_ZIP as zipCode, "
							+ " (CASE WHEN ( ATXR.ATSY_ID = 'EMAL' and MEME.MEME_SFX<>0)THEN ATXR.ATXR_DESC ELSE SBAD.SBAD_EMAIL END) as emailID,SBAD.SBAD_PHONE as HomePhoneNumber "
							+ " FROM CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME ON MEME.SBSB_CK = SBSB.SBSB_CK INNER JOIN CMC_SBAD_ADDR SBAD ON SBAD.SBSB_CK = SBSB.SBSB_CK  "
							+ " Inner JOIN CER_ATXR_ATTACH_U ATXR ON MEME.ATXR_SOURCE_ID = ATXR.ATXR_SOURCE_ID "
							+ " WHERE ((SBSB.SBSB_ID='" + SubscriberID + "' AND MEME.MEME_SFX= " + DependentID
							+ ") or MEME.MEME_CK= " + MemberCK + " or MEME.SBSB_CK= " + SbsbCK + " ) "
							+ " AND  SBAD.SBAD_TYPE = MEME.SBAD_TYPE_HOME ";
				} else {
					homeQuery = "SELECT DISTINCT MEME.MEME_CELL_PHONE as MobilePhoneNumber,MEME.MEME_WRK_PHONE as WorkPhoneNumber,MEME.MEME_WRK_PHONE_EXT as phoneExtension,SBAD.SBAD_ADDR1 as addressStreet1,SBAD.SBAD_ADDR2 as addressStreet2, "
							+ " SBAD.SBAD_ADDR3 as addressStreet3,SBAD.SBAD_CITY as city ,SBAD.SBAD_STATE as state,SBAD.SBAD_ZIP as zipCode, "
							+ " (CASE WHEN ( ATXR.ATSY_ID = 'EMAL' and MEME.MEME_SFX<>0)THEN ATXR.ATXR_DESC ELSE SBAD.SBAD_EMAIL END) as emailID,SBAD.SBAD_PHONE as HomePhoneNumber "
							+ " FROM CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME ON MEME.SBSB_CK = SBSB.SBSB_CK INNER JOIN CMC_SBAD_ADDR SBAD ON SBAD.SBSB_CK = SBSB.SBSB_CK  "
							+ " Inner JOIN CER_ATXR_ATTACH_U ATXR ON MEME.ATXR_SOURCE_ID = ATXR.ATXR_SOURCE_ID "
							+ " WHERE ((SBSB.SBSB_ID='" + SubscriberID + "' AND MEME.MEME_SFX= " + DependentID
							+ ") or MEME.MEME_CK= " + MemberCK + " or MEME.SBSB_CK= " + SbsbCK + " ) "
							+ " AND  SBAD.SBAD_TYPE = MEME.SBAD_TYPE_HOME  AND (ATXR.ATXR_DESC='" + EmailID
							+ "' or SBAD.SBAD_EMAIL='" + EmailID + "' ) ";
				}
				org.json.JSONArray dbDetails = ViewClaimsDBS.getMemberInfofromDBS(homeQuery, "Sybase");
				String email = dbDetails.getJSONObject(0).getString("emailID");
				String homeaddr1 = dbDetails.getJSONObject(0).getString("addressStreet1");
				String homeaddr2 = dbDetails.getJSONObject(0).getString("addressStreet2");
				String homeaddr3 = dbDetails.getJSONObject(0).getString("addressStreet3");
				String homeCity = dbDetails.getJSONObject(0).getString("city");
				String homeState = dbDetails.getJSONObject(0).getString("state");
				String homezipCode = dbDetails.getJSONObject(0).getString("zipCode");
				String WorkPhn = dbDetails.getJSONObject(0).getString("WorkPhoneNumber");
				String workExt = dbDetails.getJSONObject(0).getString("phoneExtension");
				String cellPhn = dbDetails.getJSONObject(0).getString("MobilePhoneNumber");
				String homePhn = dbDetails.getJSONObject(0).getString("HomePhoneNumber");
				if (WorkPhoneNumber.equals("")) {
					if (email.trim().equalsIgnoreCase(EmailID) && homeaddr1.trim().equalsIgnoreCase(HomeAddressStreet1)
							&& homeaddr2.trim().equalsIgnoreCase(HomeAddressStreet2)
							&& homeaddr3.trim().equalsIgnoreCase(HomeAddressStreet3)
							&& homeCity.trim().equalsIgnoreCase(HomeCity)
							&& homeState.trim().equalsIgnoreCase(HomeState)
							&& homezipCode.trim().equalsIgnoreCase(HomeZipCode)) {
						Assert.pass("Updated Home Address successfully");
					} else {
						Assert.fail("Failed to update home address");
					}
				} else if (!(HomePhone.equals(""))) {
					if (email.trim().equalsIgnoreCase(EmailID) && homeaddr1.trim().equalsIgnoreCase(HomeAddressStreet1)
							&& homeaddr2.trim().equalsIgnoreCase(HomeAddressStreet2)
							&& homeaddr3.trim().equalsIgnoreCase(HomeAddressStreet3)
							&& homeCity.trim().equalsIgnoreCase(HomeCity)
							&& homeState.trim().equalsIgnoreCase(HomeState)
							&& homezipCode.trim().equalsIgnoreCase(HomeZipCode)
							&& WorkPhn.trim().equalsIgnoreCase(WorkPhoneNumber)
							&& workExt.trim().equalsIgnoreCase(WorkExtension)
							&& homePhn.trim().equalsIgnoreCase(HomePhone)) {
						Assert.pass("Updated Home Address successfully");
					} else {
						Assert.fail("Failed to update home address");
					}
				}

				else {
					if (email.trim().equalsIgnoreCase(EmailID) && homeaddr1.trim().equalsIgnoreCase(HomeAddressStreet1)
							&& homeaddr2.trim().equalsIgnoreCase(HomeAddressStreet2)
							&& homeaddr3.trim().equalsIgnoreCase(HomeAddressStreet3)
							&& homeCity.trim().equalsIgnoreCase(HomeCity)
							&& homeState.trim().equalsIgnoreCase(HomeState)
							&& homezipCode.trim().equalsIgnoreCase(HomeZipCode)
							&& WorkPhn.trim().equalsIgnoreCase(WorkPhoneNumber)
							&& workExt.trim().equalsIgnoreCase(WorkExtension)
							&& cellPhn.trim().equalsIgnoreCase(MobilePhoneNumber)) {
						Assert.pass("Updated Home Address successfully");
					} else {
						Assert.fail("Failed to update home address");
					}
				}

			}
			if (MailSameAsHomeIndicator.equalsIgnoreCase("N")) {
				mailQuery = "SELECT DISTINCT SBAD.SBAD_ADDR1 as addressStreet1,SBAD.SBAD_ADDR2 as addressStreet2, "
						+ " SBAD.SBAD_ADDR3 as addressStreet3, SBAD.SBAD_STATE as state,SBAD.SBAD_CITY as city ,SBAD.SBAD_ZIP as zipCode "
						+ " FROM CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME ON MEME.SBSB_CK = SBSB.SBSB_CK INNER JOIN CMC_SBAD_ADDR SBAD ON SBAD.SBSB_CK = SBSB.SBSB_CK "
						+ " Inner JOIN CER_ATXR_ATTACH_U ATXR ON MEME.ATXR_SOURCE_ID = ATXR.ATXR_SOURCE_ID "
						+ " WHERE ((SBSB.SBSB_ID='" + SubscriberID + "' AND MEME.MEME_SFX= " + DependentID
						+ ") or MEME.MEME_CK= " + MemberCK + " or MEME.SBSB_CK= " + SbsbCK + " ) "
						+ " AND  SBAD.SBAD_TYPE = MEME.SBAD_TYPE_MAIL ";

				org.json.JSONArray mailDetails = ViewClaimsDBS.getMemberInfofromDBS(mailQuery, "Sybase");
				String mailaddr1 = mailDetails.getJSONObject(0).getString("addressStreet1");
				String mailaddr2 = mailDetails.getJSONObject(0).getString("addressStreet2");
				String mailaddr3 = mailDetails.getJSONObject(0).getString("addressStreet3");
				String mailState = mailDetails.getJSONObject(0).getString("state");
				String mailCity = mailDetails.getJSONObject(0).getString("city");
				String mailzipCode = mailDetails.getJSONObject(0).getString("zipCode");

				if (mailaddr1.trim().equalsIgnoreCase(MailAddressStreet1)
						&& mailaddr2.trim().equalsIgnoreCase(MailAddressStreet2)
						&& mailaddr3.trim().equalsIgnoreCase(MailAddressStreet3)
						&& mailCity.trim().equalsIgnoreCase(MailCity) && mailState.trim().equalsIgnoreCase(MailState)
						&& mailzipCode.trim().equalsIgnoreCase(MailZipCode)) {
					Assert.pass("Updated Mail Address successfully");
				} else {
					Assert.fail("Failed to update Mail Address");
				}
			}

		} else {
			Assert.done("Test ID: " + testID);
			Assert.done("Test Description: " + testDesc);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg");
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {

					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
				Assert.fail(content);
			}
		}
	}

	/**
	 * This method is used to validate the JSON data and DB data of GetCommunication
	 * service
	 * 
	 * @param content
	 *            = JSON response data
	 * @param testID
	 *            = TestCase ID
	 * @throws Exception
	 */
	/**
	 * 
	 * @param content
	 * @param testID
	 * @throws Exception
	 */
	public static void validateGetCommunication(String content, String testID,String env) throws Exception {
		boolean flag = true;
		boolean flag1 = false;
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";  
		DataTable1 Dttestdata = new DataTable1(testdir + "Communication.xls", "GetCommunication_Input",
				"" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		//String ReportFilePath = Environment.get("Report_excel_path");
		String ReportFilePath = "";
		if(Environment.get("Jenkins_Run").equalsIgnoreCase("Yes")) {
		String excelName = Environment.get("GetCommunication_XML");		
		String excelReportName = excelName.replace(".xml", ".xslx");
		 ReportFilePath = Environment.get("report_path")+"//"+excelReportName;
		}
		else {
		 ReportFilePath = Environment.get("GetCommunication_excel_path");
		}
		if (content.contains("errorCode")) {
			flag = false;
		} else {
			flag1 = true;
		}
		if (flag1) {
			Object obj = jsonparser.parse(content);
			JSONObject Commobj = (JSONObject) obj;

			String inputtestID = Dttestdata.getValue("TestID");
			String testDesc = Dttestdata.getValue("Test_Description");
			String SubscriberID = Dttestdata.getValue("SubscriberID");
			String DependentID = Dttestdata.getValue("DependentID");
			String MemeCK = Dttestdata.getValue("MemeCK");
			String CommType = Dttestdata.getValue("CommunicationType");
			String StartDate = Dttestdata.getValue("StartDate");
			String EndDate = Dttestdata.getValue("Date");
			String MEMEREL = Dttestdata.getValue("MEMEREL");
			String strQuery = "";
			String validationQuery = "";
			try {
				Assert.done("Test ID: " + inputtestID);
				Assert.done("Test Description: " + testDesc);
				if (SubscriberID.equals("") && DependentID.equals("")) {
					SubscriberID = null;
					DependentID = null;
				} else if (MemeCK.equals("")) {
					MemeCK = null;
				}

				if (MEMEREL.equals("")) {
					if (!CommType.equals("")) {
						if (StartDate.equals("") && EndDate.equals("")) {
							strQuery = "SELECT DISTINCT S.SBSB_ID AS subscriberID,M.MEME_SFX AS dependentID, M.MEME_CK as memeCk,T.MCTR_VALUE as communicatioType, "
									+ "communicatioTypeDescription =(CASE WHEN T.MCTR_VALUE = 'T001' THEN 'Print Vendor mailings'  when T.MCTR_VALUE = 'T004' then 'Notification Preference' End) , "
									+ "C.MECM_MCTR_CMTH AS communicationPreference, "
									+ "communicationPreferenceDescription =(CASE WHEN C.MECM_MCTR_CMTH='EML' THEN 'Email' when C.MECM_MCTR_CMTH = 'MAIL' then 'US Mail' when C.MECM_MCTR_CMTH = 'PRTL' then 'Portal Only' when C.MECM_MCTR_CMTH ='TEXT' then 'Text' END), "
									+ "Convert(Date,C.MECM_EFF_DT) as effectiveDate,Convert(Date,C.MECM_TERM_DT) as terminationDate,C.MECM_MCTR_TRSN as terminationReason, "
									+ "terminationReasonDescription=(CASE WHEN C.MECM_MCTR_TRSN =' ' THEN 'Clear Selection' when C.MECM_MCTR_TRSN='ERR' then 'Set Up in Error' End), "
									+ "C.MECM_OPT_OUT as optOut,optOutDescription = (Case when C.MECM_OPT_OUT='I' then 'Opt In' when C.MECM_OPT_OUT='O' then 'Opt Out' End), "
									+ "M.MEME_MCTR_LANG as language, languageDescription =(Case when M.MEME_MCTR_LANG= 'ENGL' then 'English' when M.MEME_MCTR_LANG='SPAN' then 'Spanish' End) "
									+ "FROM CMC_SBSB_SUBSC S INNER JOIN CMC_MEME_MEMBER M ON S.SBSB_CK = M.SBSB_CK  "
									+ "INNER JOIN CMC_MECM_COMM C ON M.MEME_CK= C.MEME_CK "
									+ "INNER JOIN CMC_MCTR_CD_TRANS T  ON  T.MCTR_VALUE =C.MECM_MCTR_CTYP "
									+ " where (SBSB_ID ='" + SubscriberID + "' AND M.MEME_SFX= " + DependentID
									+ " Or M.MEME_CK= " + MemeCK + " )  AND  MECM_MCTR_CTYP='" + CommType + "' ";
						} else {
							if (!StartDate.equals("")) {

								strQuery = "SELECT DISTINCT S.SBSB_ID AS subscriberID,M.MEME_SFX AS dependentID, M.MEME_CK as memeCk,T.MCTR_VALUE as communicatioType, "
										+ "communicatioTypeDescription =(CASE WHEN T.MCTR_VALUE = 'T001' THEN 'Print Vendor mailings'  when T.MCTR_VALUE = 'T004' then 'Notification Preference' End) , "
										+ "C.MECM_MCTR_CMTH AS communicationPreference, "
										+ "communicationPreferenceDescription =(CASE WHEN C.MECM_MCTR_CMTH='EML' THEN 'Email' when C.MECM_MCTR_CMTH = 'MAIL' then 'US Mail' when C.MECM_MCTR_CMTH = 'PRTL' then 'Portal Only' when C.MECM_MCTR_CMTH ='TEXT' then 'Text' END), "
										+ "Convert(Date,C.MECM_EFF_DT) as effectiveDate,Convert(Date,C.MECM_TERM_DT) as terminationDate,C.MECM_MCTR_TRSN as terminationReason, "
										+ "terminationReasonDescription=(CASE WHEN C.MECM_MCTR_TRSN =' ' THEN 'Clear Selection' when C.MECM_MCTR_TRSN='ERR' then 'Set Up in Error' End), "
										+ "C.MECM_OPT_OUT as optOut,optOutDescription = (Case when C.MECM_OPT_OUT='I' then 'Opt In' when C.MECM_OPT_OUT='O' then 'Opt Out' End), "
										+ "M.MEME_MCTR_LANG as language, languageDescription =(Case when M.MEME_MCTR_LANG= 'ENGL' then 'English' when M.MEME_MCTR_LANG='SPAN' then 'Spanish' End) "
										+ "FROM CMC_SBSB_SUBSC S INNER JOIN CMC_MEME_MEMBER M ON S.SBSB_CK = M.SBSB_CK  "
										+ "INNER JOIN CMC_MECM_COMM C ON M.MEME_CK= C.MEME_CK "
										+ "INNER JOIN CMC_MCTR_CD_TRANS T  ON  T.MCTR_VALUE =C.MECM_MCTR_CTYP "
										+ " where (SBSB_ID ='" + SubscriberID + "' AND M.MEME_SFX= " + DependentID
										+ " Or M.MEME_CK= " + MemeCK + " ) AND C.MECM_EFF_DT = '" + StartDate
										+ "' AND  MECM_MCTR_CTYP='" + CommType + "' ";
							}

							else {

								strQuery = "SELECT DISTINCT S.SBSB_ID AS subscriberID,M.MEME_SFX AS dependentID, M.MEME_CK as memeCk,T.MCTR_VALUE as communicatioType, "
										+ "communicatioTypeDescription =(CASE WHEN T.MCTR_VALUE = 'T001' THEN 'Print Vendor mailings'  when T.MCTR_VALUE = 'T004' then 'Notification Preference' End) , "
										+ "C.MECM_MCTR_CMTH AS communicationPreference, "
										+ "communicationPreferenceDescription =(CASE WHEN C.MECM_MCTR_CMTH='EML' THEN 'Email' when C.MECM_MCTR_CMTH = 'MAIL' then 'US Mail' when C.MECM_MCTR_CMTH = 'PRTL' then 'Portal Only' when C.MECM_MCTR_CMTH ='TEXT' then 'Text' END), "
										+ "Convert(Date,C.MECM_EFF_DT) as effectiveDate,Convert(Date,C.MECM_TERM_DT) as terminationDate,C.MECM_MCTR_TRSN as terminationReason, "
										+ "terminationReasonDescription=(CASE WHEN C.MECM_MCTR_TRSN =' ' THEN 'Clear Selection' when C.MECM_MCTR_TRSN='ERR' then 'Set Up in Error' End), "
										+ "C.MECM_OPT_OUT as optOut,optOutDescription = (Case when C.MECM_OPT_OUT='I' then 'Opt In' when C.MECM_OPT_OUT='O' then 'Opt Out' End), "
										+ "M.MEME_MCTR_LANG as language, languageDescription =(Case when M.MEME_MCTR_LANG= 'ENGL' then 'English' when M.MEME_MCTR_LANG='SPAN' then 'Spanish' End) "
										+ "FROM CMC_SBSB_SUBSC S INNER JOIN CMC_MEME_MEMBER M ON S.SBSB_CK = M.SBSB_CK  "
										+ "INNER JOIN CMC_MECM_COMM C ON M.MEME_CK= C.MEME_CK "
										+ "INNER JOIN CMC_MCTR_CD_TRANS T  ON  T.MCTR_VALUE =C.MECM_MCTR_CTYP "
										+ " where (SBSB_ID ='" + SubscriberID + "' AND M.MEME_SFX= " + DependentID
										+ " Or M.MEME_CK= " + MemeCK + " ) AND C.MECM_TERM_DT = '" + EndDate
										+ "' AND  MECM_MCTR_CTYP='" + CommType + "' ";
							}
						}
					} else {
						strQuery = "SELECT DISTINCT S.SBSB_ID AS subscriberID,M.MEME_SFX AS dependentID, M.MEME_CK as memeCk,T.MCTR_VALUE as communicatioType, "
								+ "communicatioTypeDescription =(CASE WHEN T.MCTR_VALUE = 'T001' THEN 'Print Vendor mailings'  when T.MCTR_VALUE = 'T004' then 'Notification Preference' End) , "
								+ "C.MECM_MCTR_CMTH AS communicationPreference, "
								+ "communicationPreferenceDescription =(CASE WHEN C.MECM_MCTR_CMTH='EML' THEN 'Email' when C.MECM_MCTR_CMTH = 'MAIL' then 'US Mail' when C.MECM_MCTR_CMTH = 'PRTL' then 'Portal Only' when C.MECM_MCTR_CMTH ='TEXT' then 'Text' END), "
								+ "Convert(Date,C.MECM_EFF_DT) as effectiveDate,Convert(Date,C.MECM_TERM_DT) as terminationDate,C.MECM_MCTR_TRSN as terminationReason, "
								+ "terminationReasonDescription=(CASE WHEN C.MECM_MCTR_TRSN =' ' THEN 'Clear Selection' when C.MECM_MCTR_TRSN='ERR' then 'Set Up in Error' End), "
								+ "C.MECM_OPT_OUT as optOut,optOutDescription = (Case when C.MECM_OPT_OUT='I' then 'Opt In' when C.MECM_OPT_OUT='O' then 'Opt Out' End), "
								+ "M.MEME_MCTR_LANG as language, languageDescription =(Case when M.MEME_MCTR_LANG= 'ENGL' then 'English' when M.MEME_MCTR_LANG='SPAN' then 'Spanish' End) "
								+ "FROM CMC_SBSB_SUBSC S INNER JOIN CMC_MEME_MEMBER M ON S.SBSB_CK = M.SBSB_CK  "
								+ "INNER JOIN CMC_MECM_COMM C ON M.MEME_CK= C.MEME_CK "
								+ "INNER JOIN CMC_MCTR_CD_TRANS T  ON  T.MCTR_VALUE =C.MECM_MCTR_CTYP "
								+ " where (SBSB_ID ='" + SubscriberID + "' AND M.MEME_SFX= " + DependentID
								+ " Or M.MEME_CK= " + MemeCK + ") ";
					}
				} else {
					strQuery = "SELECT DISTINCT S.SBSB_ID AS subscriberID,M.MEME_SFX AS dependentID, "
							+ "M.MEME_CK as memeCk,T.MCTR_VALUE as communicatioType, "
							+ "communicatioTypeDescription =(CASE WHEN T.MCTR_VALUE = 'T001' "
							+ "THEN 'Print Vendor mailings'  when T.MCTR_VALUE = 'T004' then 'Notification Preference' End) ,"
							+ " C.MECM_MCTR_CMTH AS communicationPreference,"
							+ "communicationPreferenceDescription =(CASE WHEN C.MECM_MCTR_CMTH='EML' THEN 'Email' when C.MECM_MCTR_CMTH = 'MAIL' then 'US Mail' when C.MECM_MCTR_CMTH = 'PRTL' then 'Portal Only' when C.MECM_MCTR_CMTH ='TEXT' "
							+ "then 'Text' END), Convert(Date,C.MECM_EFF_DT) as effectiveDate,Convert(Date,C.MECM_TERM_DT) "
							+ "as terminationDate,C.MECM_MCTR_TRSN as terminationReason, "
							+ "terminationReasonDescription=(CASE WHEN C.MECM_MCTR_TRSN =' ' "
							+ "THEN 'Clear Selection' when C.MECM_MCTR_TRSN='ERR' then 'Set Up in Error' End), "
							+ "C.MECM_OPT_OUT as optOut,optOutDescription = (Case when C.MECM_OPT_OUT='I' then 'Opt In' "
							+ "when C.MECM_OPT_OUT='O' then 'Opt Out' End), M.MEME_MCTR_LANG as language, "
							+ "languageDescription =(Case when M.MEME_MCTR_LANG= 'ENGL' then 'English' when M.MEME_MCTR_LANG='SPAN' then 'Spanish' End) "
							+ "FROM CMC_SBSB_SUBSC S INNER JOIN CMC_MEME_MEMBER M ON S.SBSB_CK = M.SBSB_CK "
							+ "INNER JOIN CMC_MECM_COMM C ON M.MEME_CK= C.MEME_CK INNER JOIN CMC_MCTR_CD_TRANS T  "
							+ "ON  T.MCTR_VALUE =C.MECM_MCTR_CTYP where M.MEME_CK in (Select MEME_CK from CMC_MEME_MEMBER "
							+ "where SBSB_CK in (Select SBSB_CK from CMC_MEME_MEMBER where MEME_CK = " + MemeCK + ") "
							+ "and MEME_REL = '" + MEMEREL + "' ) AND  C.MECM_EFF_DT = '" + StartDate + "' "
							+ " AND  MECM_MCTR_CTYP='" + CommType + "' ";

				}
				String getCommunicationdetails = "COMM";
				String[] uniqueColumn2 = { "communicatioType", "communicationPreferenceDescription" };
				ValidateMethods.validateJsonArrayDataWithDb1(Commobj, getCommunicationdetails, strQuery, uniqueColumn2,
						"Sybase", ReportFilePath);

			} catch (Exception e) {
				Assert.done("Completed");
			}
		} else {
			Assert.done("Test ID: " + testID);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg");
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {

					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
			}
		}
	}

	/**
	 * This method is used to validate the JSON Array Data with DB data having more
	 * than one unique column
	 * 
	 * @param ClaimObj
	 *            = JSON object
	 * @param strArrayName
	 *            = JSON array name
	 * @param strQuery
	 *            = DB query used
	 * @param strUniqueColName
	 *            = Unique column name
	 * @param DB
	 *            = Database name
	 * @param ReportFilePath
	 *            = Excel report file path
	 * @throws Exception
	 */
	public static void validateJsonArrayDataWithDb1(JSONObject ClaimObj, String strArrayName, String strQuery,
			String[] strUniqueColName, String DB, String ReportFilePath) throws Exception {
		JSONArray responseClaimLineDetails = (JSONArray) ClaimObj.get(strArrayName);
		org.json.JSONArray dbClaimLineDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, DB);
		try {
			int a = responseClaimLineDetails.size();
			int b = dbClaimLineDetails.length();
			if (responseClaimLineDetails.size() == dbClaimLineDetails.length()) {

				Map<String, Object> strCLaimDetailsRes = null;
				JSONObject response = null;
				Map<String, Object> db_data = null;
				org.json.JSONObject db_response = null;

				boolean errorflag = false;
				boolean validateflag = true;

				// Comparing Response data with db row
				for (int j = 0; j < responseClaimLineDetails.size(); j++) {
					int k = j * 2 + 1; // 1,3,5
					int l = j * 2 + 2; // 2,4,6
					response = (JSONObject) responseClaimLineDetails.get(j);
					strCLaimDetailsRes = UtilMethod.readJsonData(response);
					Assert.done("Validating " + j + " row DB values with response");
					for (int i = 0; i < dbClaimLineDetails.length(); i++) {
						db_response = (org.json.JSONObject) dbClaimLineDetails.get(j);
						db_data = UtilMethod.readJsonData(db_response);
						// for (int x=0; x<strUniqueColName.length ;x++) {

						if (strCLaimDetailsRes.get(strUniqueColName[0]).toString().trim()
								.equalsIgnoreCase(db_data.get(strUniqueColName[0]).toString().trim())
								&& strCLaimDetailsRes.get(strUniqueColName[1]).toString().trim()
										.equalsIgnoreCase(db_data.get(strUniqueColName[1]).toString().trim()))
						// System.out.println("hell0"+strCLaimDetailsRes.get(strUniqueColName[0]).toString().equalsIgnoreCase(db_data.get(strUniqueColName[0]).toString()));
						// System.out.println("hell1"+
						// strCLaimDetailsRes.get(strUniqueColName[1]).toString().equalsIgnoreCase(db_data.get(strUniqueColName[1]).toString()));
						{
							break;
						}
					}
					Set<String> jsonKeys = strCLaimDetailsRes.keySet();
					for (String tagname : jsonKeys) {
						Object Value = strCLaimDetailsRes.get(tagname);
						UtilMethod.setCellData(tagname, Value, k, ReportFilePath);

						UtilMethod.validateJSONObject(db_data, tagname, Value, l, ReportFilePath);					
					
					}
				}

			} else {
				UtilMethod.Log(
						"Cannot validate as the Json response claim line details record size is not matching with DB response claim line details records.. please check the query you are passing",
						"FAIL", true);
			}
		} catch (Exception e) {

			Assert.fail(
					"Cannot validate claim line details with db as size is not matching.. please check the query you are passing...");
		}

	}

	/**
	 * This method is used to validate the static fields with DB
	 * 
	 * @param ClaimObj
	 *            = JSON Object
	 * @param strQuery
	 *            = DB query used
	 * @param DB
	 *            = Database name
	 * @param ReportFilePath
	 *            = Excel report file path
	 * @param map
	 *            = mapping value
	 * @param countQuery
	 *            = counting the records query
	 * @throws SQLException
	 * @throws IOException
	 */
	public static void validateStaticFieldsWithDb1(JSONObject ClaimObj, String strQuery, String DB,
			String ReportFilePath, Map<String, String> map, String countQuery) throws SQLException, IOException {
		// String QueryDB =
		Object value = null;
		Map<String, Object> responseData = UtilMethod.readJsonData(ClaimObj);
		org.json.JSONArray dbData = ViewClaimsDBS.getMemberInfofromDBS(strQuery, DB);
		org.json.JSONArray dbDataCount = ViewClaimsDBS.getMemberInfofromDBS(countQuery, DB);
		Set<String> keys = responseData.keySet();
		for (String key : keys) {
			UtilMethod.setCellData(key, responseData.get(key), 1, ReportFilePath);
			value = responseData.get(key);
			if (value != null) {
				UtilMethod.validateTag1(dbData, key, value, ReportFilePath, map, dbDataCount);
			}

		}
	}

	/**
	 * This method is used to validate the JSON Array Data with DB data having three
	 * columns
	 * 
	 * @param ClaimObj
	 *            = JSON object
	 * @param strArrayName
	 *            = JSON array name
	 * @param strQuery
	 *            = DB query used
	 * @param strUniqueColName
	 *            = Unique column name
	 * @param DB
	 *            = Database name
	 * @param ReportFilePath
	 *            = Excel report file path
	 * @throws Exception
	 */
	public static void validateJsonArrayDataWithDbForThreecoloumn(JSONObject ClaimObj, String strArrayName,
			String strQuery, String[] strUniqueColName, String DB, String ReportFilePath) throws Exception {
		JSONArray responseClaimLineDetails = (JSONArray) ClaimObj.get(strArrayName);
		org.json.JSONArray dbClaimLineDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, DB);

		if (responseClaimLineDetails.size() == dbClaimLineDetails.length()) {

			Map<String, Object> strCLaimDetailsRes = null;
			JSONObject response = null;
			Map<String, Object> db_data = null;
			org.json.JSONObject db_response = null;

			boolean errorflag = false;
			boolean validateflag = true;

			// Comparing Response data with db row
			for (int j = 0; j < responseClaimLineDetails.size(); j++) {
				int k = j * 2 + 1; // 1,3,5
				int l = j * 2 + 2; // 2,4,6
				response = (JSONObject) responseClaimLineDetails.get(j);
				strCLaimDetailsRes = UtilMethod.readJsonData(response);
				Assert.done("Validating " + j + " row DB values with response");
				for (int i = 0; i < dbClaimLineDetails.length(); i++) {
					db_response = (org.json.JSONObject) dbClaimLineDetails.get(i);
					db_data = UtilMethod.readJsonData(db_response);
					// for (int x=0; x<strUniqueColName.length ;x++) {
					if (strCLaimDetailsRes.get(strUniqueColName[0]).toString()
							.equalsIgnoreCase(db_data.get(strUniqueColName[0]).toString())
							&& strCLaimDetailsRes.get(strUniqueColName[1]).toString()
									.equalsIgnoreCase(db_data.get(strUniqueColName[1]).toString())
							&& strCLaimDetailsRes.get(strUniqueColName[2]).toString()
									.equalsIgnoreCase(db_data.get(strUniqueColName[2]).toString())) {
						break;
					}
				}

				Set<String> jsonKeys = strCLaimDetailsRes.keySet();
				for (String tagname : jsonKeys) {
					Object Value = strCLaimDetailsRes.get(tagname);
					UtilMethod.setCellData(tagname, Value, k, ReportFilePath);
					if (strUniqueColName[3].equalsIgnoreCase("M")) {
						if (Value != null) {
						//	UtilMethod.validateJSONObject(db_data, tagname, Value, l, ReportFilePath);
						} else {
							Assert.done("The " + tagname + "value is Masked");
						}
					} else {
						UtilMethod.validateJSONObject(db_data, tagname, Value, l, ReportFilePath);
					}

				}
			}

		} else {
			UtilMethod.Log(
					"Cannot validate as the Json response claim line details record size is not matching with DB response claim line details records.. please check the query you are passing",
					"FAIL", true);
			throw new Exception(
					"Cannot validate claim line details with db as size is not matching.. please check the query you are passing...");
		}

	}

	/**
	 * This method is used to validate the JSON data and DB data of
	 * UpdateCommunication service.
	 * 
	 * @param content
	 *            = JSON Response data
	 * @param testID
	 *            = TestCase ID
	 * @throws Exception
	 */

	public static void validateUpdateCommunication(String content, String testID,String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";  //Add this line
		DataTable1 Dttestdata = new DataTable1(testdir + "Communication.xls", "UpdateCommunication_Input",
				"" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		if (content.contains("\"ErrorCode\" : \"NA\"")) {
			validateflag = true;
		}
		if (validateflag) {
			String inputtestID = Dttestdata.getValue("TestID");
			String testDesc = Dttestdata.getValue("Test_Description");
			String SubscriberID = Dttestdata.getValue("SubscriberID");
			String DependentID = Dttestdata.getValue("DependentID");
			String MemberCK = Dttestdata.getValue("MemeCK");
			String CommType1 = Dttestdata.getValue("CommType1");
			String CommPref1 = Dttestdata.getValue("CommPref1");
			String CommType2 = Dttestdata.getValue("CommType2");
			String CommPref2 = Dttestdata.getValue("CommPref2").trim();
			String StartDT = Dttestdata.getValue("StartDT").trim();
			String EndDT = Dttestdata.getValue("EndDT");
			String TermReason = Dttestdata.getValue("TermReason").trim();
			String OptOut = Dttestdata.getValue("OptOut");
			String Lang = Dttestdata.getValue("Lang");
			if (StartDT.equalsIgnoreCase("")) {
				DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
				Date date = new Date();
				StartDT = dateFormat.format(date);
				EndDT = "99991231";
			}
			if (EndDT.equalsIgnoreCase("")) {
				EndDT = "99991231";
			}

			if (Lang.equalsIgnoreCase("")) {
				Lang = "ENGL";
			}

			int i = 1;
			int j = 0;
			String strQuery = "";
			if (content.contains("\"ErrorCode\" : \"NA\"")) {
				// if (value.equalsIgnoreCase("0")) {
				Assert.done("Test ID: " + inputtestID);
				Assert.done("Test Description: " + testDesc);

				String type = "";
				String pref = "";
				if (!(CommType2.equals(""))) {
					i = 2;
				}
				for (j = 1; j <= i; j++) {

					if (j == 1) {
						type = CommType1;
						pref = CommPref1;
					} else {
						type = CommType2;
						pref = CommPref2;
					}

					if ((MemberCK.equals(""))) {
						strQuery = "SELECT distinct S.SBSB_ID AS subscriberID,M.MEME_SFX AS dependentID, "
								+ "M.MEME_CK as memberContrivedKey,T.MCTR_VALUE as communicatioType, "
								+ "C.MECM_MCTR_CMTH AS communicationPreference,"
								+ "Convert(Date,C.MECM_EFF_DT) as effectiveDate,"
								+ "Convert(Date,C.MECM_TERM_DT) as terminationDate, "
								+ "C.MECM_MCTR_TRSN as terminationReason,C.MECM_MCTR_LANG as language,"
								+ "C.MECM_OPT_OUT as optOut FROM CMC_SBSB_SUBSC S "
								+ "INNER JOIN CMC_MEME_MEMBER M ON S.SBSB_CK = M.SBSB_CK  "
								+ "INNER JOIN CMC_MECM_COMM C ON M.MEME_CK= C.MEME_CK "
								+ "INNER JOIN CMC_MCTR_CD_TRANS T  ON  T.MCTR_VALUE =C.MECM_MCTR_CTYP "
								+ "where (S.SBSB_ID='" + SubscriberID + "' and M.MEME_SFX =" + DependentID + ")  and "
								+ "T.MCTR_VALUE = '" + type + "' and (C.MECM_MCTR_CMTH='" + pref
								+ "' and C.MECM_MCTR_TRSN='')";

					} else if (SubscriberID.equals("")) {
						strQuery = "SELECT distinct S.SBSB_ID AS subscriberID,M.MEME_SFX AS dependentID, "
								+ "M.MEME_CK as memberContrivedKey,T.MCTR_VALUE as communicatioType, "
								+ "C.MECM_MCTR_CMTH AS communicationPreference,"
								+ "Convert(Date,C.MECM_EFF_DT) as effectiveDate,"
								+ "Convert(Date,C.MECM_TERM_DT) as terminationDate, "
								+ "C.MECM_MCTR_TRSN as terminationReason,C.MECM_MCTR_LANG as language,"
								+ "C.MECM_OPT_OUT as optOut FROM CMC_SBSB_SUBSC S "
								+ "INNER JOIN CMC_MEME_MEMBER M ON S.SBSB_CK = M.SBSB_CK  "
								+ "INNER JOIN CMC_MECM_COMM C ON M.MEME_CK= C.MEME_CK "
								+ "INNER JOIN CMC_MCTR_CD_TRANS T  ON  T.MCTR_VALUE =C.MECM_MCTR_CTYP "
								+ "where M.MEME_CK=" + MemberCK + " and T.MCTR_VALUE = '" + type + "' and "
								+ "(C.MECM_MCTR_CMTH='" + pref + "' and C.MECM_MCTR_TRSN='')";

					} else {
						strQuery = "SELECT distinct S.SBSB_ID AS subscriberID,M.MEME_SFX AS dependentID, "
								+ "M.MEME_CK as memberContrivedKey,T.MCTR_VALUE as communicatioType, "
								+ "C.MECM_MCTR_CMTH AS communicationPreference,"
								+ "Convert(Date,C.MECM_EFF_DT) as effectiveDate,"
								+ "Convert(Date,C.MECM_TERM_DT) as terminationDate, "
								+ "C.MECM_MCTR_TRSN as terminationReason,C.MECM_MCTR_LANG as language,"
								+ "C.MECM_OPT_OUT as optOut FROM CMC_SBSB_SUBSC S "
								+ "INNER JOIN CMC_MEME_MEMBER M ON S.SBSB_CK = M.SBSB_CK  "
								+ "INNER JOIN CMC_MECM_COMM C ON M.MEME_CK= C.MEME_CK "
								+ "INNER JOIN CMC_MCTR_CD_TRANS T  ON  T.MCTR_VALUE =C.MECM_MCTR_CTYP "
								+ "where (S.SBSB_ID='" + SubscriberID + "' and M.MEME_SFX =" + DependentID
								+ ") and M.MEME_CK=" + MemberCK + " and T.MCTR_VALUE = '" + type + "' and "
								+ "(C.MECM_MCTR_CMTH='" + pref + "' and C.MECM_MCTR_TRSN='')";

					}
					org.json.JSONArray dbDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, "Sybase");
					String subscriberID = dbDetails.getJSONObject(0).getString("subscriberID");
					String dependentID = dbDetails.getJSONObject(0).getString("dependentID");
					String memeCK = dbDetails.getJSONObject(0).getString("memberContrivedKey");
					String commType1 = dbDetails.getJSONObject(0).getString("communicatioType");
					String communicationPref1 = dbDetails.getJSONObject(0).getString("communicationPreference");
					String effectivDate = dbDetails.getJSONObject(0).getString("effectiveDate");
					String termnDate = dbDetails.getJSONObject(0).getString("terminationDate");
					String termReason = dbDetails.getJSONObject(0).getString("terminationReason");
					String lang = dbDetails.getJSONObject(0).getString("language");
					String optOutAndIn = dbDetails.getJSONObject(0).getString("optOut");
					effectivDate = effectivDate.replace("-", "");
					termnDate = termnDate.replace("-", "");
					if (MemberCK.equals("")) { // if Member CK from Testdata sheet is null
						TermReason = "";
						if (subscriberID.trim().equalsIgnoreCase(SubscriberID)
								&& (dependentID).trim().equalsIgnoreCase(DependentID)
								&& (commType1).trim().equalsIgnoreCase(CommType1)
								&& (communicationPref1).trim().equalsIgnoreCase(CommPref1)
								&& (effectivDate).trim().equalsIgnoreCase(StartDT)
								&& (termnDate).trim().equalsIgnoreCase(EndDT) && (lang).trim().equalsIgnoreCase(Lang)
								&& (termReason).trim().equalsIgnoreCase(TermReason)
								&& (optOutAndIn).trim().equalsIgnoreCase(OptOut)) {
							Assert.pass("Updated Successfully");
						} else {
							Assert.fail("Failed to update");
						}
					} else if (SubscriberID.equals("")) {
						TermReason = "";
						if (memeCK.trim().equalsIgnoreCase(MemberCK) && (commType1).trim().equalsIgnoreCase(CommType1)
								&& (communicationPref1).trim().equalsIgnoreCase(CommPref1)
								&& (effectivDate).trim().equalsIgnoreCase(StartDT)
								&& (termnDate).trim().equalsIgnoreCase(EndDT)
								&& (termReason).trim().equalsIgnoreCase(TermReason)
								&& (lang).trim().equalsIgnoreCase(Lang)
								&& (optOutAndIn).trim().equalsIgnoreCase(OptOut)) {
							Assert.pass("Updated Successfully");
						} else {
							Assert.fail("Failed to update");
						}
					} else {
						TermReason = "";
						if (type.trim().equalsIgnoreCase("T001")) {
							if (memeCK.trim().equalsIgnoreCase(MemberCK)
									&& subscriberID.trim().equalsIgnoreCase(SubscriberID)
									&& (dependentID).trim().equalsIgnoreCase(DependentID)
									&& (commType1).trim().equalsIgnoreCase(CommType1)
									&& (communicationPref1).trim().equalsIgnoreCase(CommPref1)
									&& (effectivDate).trim().equalsIgnoreCase(StartDT)
									&& (termnDate).trim().equalsIgnoreCase(EndDT)
									&& (lang).trim().equalsIgnoreCase(Lang)
									&& (termReason).trim().equalsIgnoreCase(TermReason)
									&& (optOutAndIn).trim().equalsIgnoreCase(OptOut)) {
								Assert.pass("Updated Successfully");
							} else {
								Assert.fail("Failed to update");
							}
						} else {
							if (memeCK.trim().equalsIgnoreCase(MemberCK)
									&& subscriberID.trim().equalsIgnoreCase(SubscriberID)
									&& (dependentID).trim().equalsIgnoreCase(DependentID)
									&& (commType1).trim().equalsIgnoreCase(CommType2)
									&& (communicationPref1).trim().equalsIgnoreCase(CommPref2)
									&& (effectivDate).trim().equalsIgnoreCase(StartDT)
									&& (termnDate).trim().equalsIgnoreCase(EndDT)
									&& (lang).trim().equalsIgnoreCase(Lang)
									&& (termReason).trim().equalsIgnoreCase(TermReason)
									&& (optOutAndIn).trim().equalsIgnoreCase(OptOut)) {
								Assert.pass("Updated Successfully");
							} else {
								Assert.fail("Failed to update");
							}

						}
					}

				}

			}

		} else {
			Assert.done("Test ID: " + testID);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg");
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {

					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
			}
		}
	}

	/**
	 * This method is used to validate the JSON data and DB data of GetUsername
	 * service
	 * 
	 * @param content
	 *            = JSON Response data
	 * @param testID
	 *            = TestCase ID
	 * @throws Exception
	 */

	public static void validateGetUsername(String content, String testID,String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";  
		DataTable1 Dttestdata = new DataTable1(testdir + "Username_Latest.xls", "GetUsername_Input", "" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String ReportFilePath = "";
		if(Environment.get("Jenkins_Run").equalsIgnoreCase("Yes")) {
		String excelName = Environment.get("GetUsername_XML");		
		String excelReportName = excelName.replace(".xml", ".xslx");
		 ReportFilePath = Environment.get("report_path")+"//"+excelReportName;
		}
		else {
		 ReportFilePath = Environment.get("GetUsername_Excel_path");
		}
		if (content.contains("errorCode")) {
			errorflag = false;
		} else {
			validateflag = true;
		}
		if (validateflag) {
			Object obj = jsonparser.parse(content);
			JSONObject ClaimObj = (JSONObject) obj;

			String inputtestID = Dttestdata.getValue("TestID");
			String testDesc = Dttestdata.getValue("Test_Description");
			String ConsistentMemberID = Dttestdata.getValue("ConsistentMemberID");
			String strQuery = "";
			String count = "";
			try {
				Assert.done("Test ID: " + inputtestID);
				Assert.done("Test Description: " + testDesc);

				count = "SELECT count(DISTINCT U.USER_TYPE) as Count FROM SS_SG_SQL.USERS U WHERE CONSISTENT_MEMBER_ID = "
						+ ConsistentMemberID + "";

				org.json.JSONArray dbData = ViewClaimsDBS.getMemberInfofromDBS(count, "Microsoft");
				org.json.JSONObject elements1 = dbData.getJSONObject(0);

				if (elements1.getString("Count").trim().equalsIgnoreCase("2")) {
					strQuery = "SELECT TOP 1 U.USER_NAME AS username, U.CONSISTENT_MEMBER_ID "
							+ "AS consistentMemberId , lastLoginDate = (CASE WHEN (User_Type = 'Member2') "
							+ "THEN (SELECT DISTINCT MAX(Last_Login_Date) FROM SS_SG_SQL.USERS "
							+ "WHERE CONSISTENT_MEMBER_ID = " + ConsistentMemberID + " AND USER_TYPE<>'Member') end),"
							+ " U.USER_TYPE AS userType FROM SS_SG_SQL.USERS U " + "WHERE CONSISTENT_MEMBER_ID = "
							+ ConsistentMemberID + " AND U.USER_TYPE='Member2' ORDER BY U.ID";

				} else {
					strQuery = "SELECT  TOP 1 U.USER_NAME AS username, U.CONSISTENT_MEMBER_ID AS consistentMemberId,"
							+ "U.LAST_LOGIN_DATE AS lastLoginDate, U.USER_TYPE AS userType FROM SS_SG_SQL.USERS U "
							+ "WHERE CONSISTENT_MEMBER_ID = " + ConsistentMemberID + " AND  LAST_LOGIN_DATE "
							+ "IN (SELECT MAX (U.LAST_LOGIN_DATE) FROM SS_SG_SQL.USERS U "
							+ "WHERE U.CONSISTENT_MEMBER_ID = " + ConsistentMemberID + ") ORDER BY U.ID";
				}

				Assert.done("Start-> Validation of the Static Data");

				ValidateMethods.validateStaticFieldsWithDb(ClaimObj, strQuery, "Microsoft", ReportFilePath);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Assert.done("Test ID: " + testID);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg");
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {
					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
				UtilMethod.Log(content, "FAIL", true);
			}
		}
	}

	/**
	 * This method is used to validate the JSON data and DB data of SelectUsername
	 * service
	 * 
	 * @param content
	 *            = JSON Response data
	 * @param testID
	 *            = TestCase ID
	 * @throws Exception
	 */

	public static void validateSelectUsername(String content, String testID,String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		//String testdir = Environment.get("Username_Base_Dir");
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";  
		DataTable1 Dttestdata = new DataTable1(testdir + "Username_Latest.xls", "SelectUsername_Input",
				"" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String testDesc = Dttestdata.getValue("Test_Description");
		if (content.contains("\"ResponseCode\" : \"0\"") || content.contains("\"ResponseCode\" : \"98163\"")
				|| content.contains("\"ResponseCode\" : \"98164\"")) {
			validateflag = true;
		}
		if (validateflag) {
			String inputtestID = Dttestdata.getValue("TestID");
			String SubscriberID = Dttestdata.getValue("SubscriberID");
			String DependentID = Dttestdata.getValue("DependentID");
			String UserType = Dttestdata.getValue("UserType");
			String ConsistentMemberID = Dttestdata.getValue("ConsistentMemberID");
			String InsertFlag = Dttestdata.getValue("InsertFlag");
			String UserID = Dttestdata.getValue("UserID").trim();
			String randomUsername = Integer.toString(UtilMethod.getRandomInteger(10000, 99999));
			String UserName = Dttestdata.getValue("UserName").trim();
			if (UserName.equalsIgnoreCase("")) {
				UserName = "NewUser" + randomUsername.trim();
			}
			String strQuery = "";
			if (InsertFlag.equalsIgnoreCase("y")) {
				Assert.done("Test ID: " + inputtestID);
				Assert.done("Test Description: " + testDesc);
				if (content.contains("\"ResponseCode\" : \"0\"")) {
					// if (value.equalsIgnoreCase("0")) {
					if (ConsistentMemberID.equalsIgnoreCase("") && SubscriberID.equalsIgnoreCase("")
							&& DependentID.equalsIgnoreCase("")) {
						strQuery = "SELECT CHANNEL_USER_ID AS userID,USER_NAME AS userName,USER_TYPE AS userType FROM SS_SG_SQL.USERS where USER_NAME='"
								+ UserName + "' ";
					} else {
						strQuery = "SELECT DISTINCT U.CHANNEL_USER_ID AS userID ,"
								+ "U.USER_NAME AS userName ,U.USER_TYPE  AS userType "
								+ "FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN SS_SG_SQL.USERS U ON "
								+ "MP.CONSISTENT_MEMBER_ID  = U.CONSISTENT_MEMBER_ID "
								+ "WHERE (MP.CONSISTENT_MEMBER_ID ='" + ConsistentMemberID + "' "
								+ "OR (MP.SUBSCRIBER_ID ='" + SubscriberID + "' " + "AND MP.DEPENDENT_ID ='"
								+ DependentID + "')) AND  U.USER_NAME = '" + UserName + "' " + "AND U.USER_TYPE = '"
								+ UserType + "'";
					}
					org.json.JSONArray dbDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, "Microsoft");
					String userID = dbDetails.getJSONObject(0).getString("userID");
					String userName = dbDetails.getJSONObject(0).getString("userName");
					String userType = dbDetails.getJSONObject(0).getString("userType");

					if (userID.trim().equalsIgnoreCase(UserID) && (userName).trim().equalsIgnoreCase(UserName)
							&& (userType).trim().equalsIgnoreCase(UserType)) {
						Assert.pass("Updated Successfully");
					} else {
						Assert.fail("Failed to update");
					}
				} else {
					if (content.contains("\"ResponseCode\" : \"98163\"")) {
						Assert.pass("User Name already exists|ESB||");
					} else {
						if (content.contains("\"ResponseCode\" : \"98164\"")) {
							Assert.pass("User Name does not exists|ESB||");
						}
					}
				}
			} else if (InsertFlag.equalsIgnoreCase("n")) {

				Assert.done("Test ID: " + testID);
				Assert.done("Test Description: " + testDesc);
				String responseCode = Dttestdata.getValue("ErrorCode");
				String responseDescription = Dttestdata.getValue("ErrorMsg");
				if (!(responseCode.equalsIgnoreCase(""))) {
					if ((content.contains(responseCode)) && (content.contains(responseDescription))) {
						UtilMethod.Log("Valid response Code", "PASS", true);
						Assert.done("Returns Response: " + content);
					} else {

						UtilMethod.Log("Invalid Response Code", "FAIL", true);
					}
				}
			}

		} else {
			Assert.done("Test ID: " + testID);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg");
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {

					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
				UtilMethod.Log(content, "FAIL", true);
			}
		}
	}

	/**
	 * This method is used to validate the JSON data and DB data of GetRegistration
	 * Flag
	 * 
	 * @param content
	 *            = JSON Response data
	 * @param testID
	 *            = TestCase ID
	 * @throws Exception
	 */
	public static void validateGetRegistrationFlag(String content, String testID, String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		//String testdir = Environment.get("Registration_Base_Dir");
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";
		DataTable1 Dttestdata = new DataTable1(testdir + "RegistrationFlag.xls", "GetRegistrationFlag_Input",
				"" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String testDesc = Dttestdata.getValue("Test_Description");
		String ReportFilePath = "";
		if(Environment.get("Jenkins_Run").equalsIgnoreCase("Yes")) {
		String excelName = Environment.get("GetRegistration_XML");		
		String excelReportName = excelName.replace(".xml", ".xslx");
		 ReportFilePath = Environment.get("report_path")+"//"+excelReportName;
		}
		else {
		 ReportFilePath = Environment.get("Registration_Excel_Path");
		}
		//String ReportFilePath = Environment.get("Registration_Excel_Path");
		if (content.contains("errorCode")) {
			errorflag = false;
		} else {
			validateflag = true;
		}
		if (validateflag) {
			Object obj = jsonparser.parse(content);
			JSONObject RegObj = (JSONObject) obj;
			String SubscriberID = Dttestdata.getValue("MemberID");
			String DependentID = Dttestdata.getValue("DependentID");
			String ConsistentID = Dttestdata.getValue("ConsistentMemberID");
			String strQuery = "";
			String subQuery = "";
			try {
				Assert.done("TestID: " + testID);
				Assert.done("Test Description: " + testDesc);
				if (!(SubscriberID.equalsIgnoreCase("") && DependentID.equalsIgnoreCase(""))) {
					subQuery = "SELECT CONSISTENT_MEMBER_ID FROM SS_SG_SQL.SG_MIGRATION WHERE MEMBER_ID='"
							+ SubscriberID + "' AND DEPENDENT_ID='" + DependentID + "' ";
					org.json.JSONArray cmiDetails = ViewClaimsDBS.getMemberInfofromDBS(subQuery, "Microsoft");
					ConsistentID = cmiDetails.getJSONObject(0).getString("CONSISTENT_MEMBER_ID");
				}

				if (!(ConsistentID.equalsIgnoreCase(""))) {
					strQuery = "SELECT DISTINCT registrationFlag = (CASE WHEN(REGISTRATION_FLAG ='Y') THEN 'True' ELSE 'False' end), "
							+ " migrationFlag = (CASE WHEN(MIGRATION_FLAG ='Y') THEN 'True' ELSE 'False' end) FROM SS_SG_SQL.SG_MIGRATION "
							+ " WHERE  Consistent_Member_ID= '" + ConsistentID + "' ";
				}
				ValidateMethods.validateStaticFieldsWithDb(RegObj, strQuery, "Microsoft", ReportFilePath);

			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Assert.done("Test ID: " + testID);
			Assert.done("Test Description: " + testDesc);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg");
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {

					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
				UtilMethod.Log(content, "FAIL", true);
			}
		}
	}

	/**
	 * This method is used to validate the JSON data and DB data of
	 * UpdateRegistration Flag
	 * 
	 * @param content
	 *            = JSON Response data
	 * @param testID
	 *            = TestCase ID
	 * @throws Exception
	 */

	public static void validateUpdateRegistrationFlag(String content, String testID, String env) throws Exception {
		boolean validateflag = false;
		//String testdir = Environment.get("Registration_Base_Dir");
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";
		DataTable1 Dttestdata = new DataTable1(testdir + "RegistrationFlag.xls", "UpdateRegistrationFlag_Input",
				"" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String ConsistentID = Dttestdata.getValue("ConsistentMemberID");
		String strQuery = "";
		String regflag = "";
		String updateQuery = "";
		String testDesc = Dttestdata.getValue("Test_Description");
		{
			if (content.contains("\"responseCode\" : \"0\"")) {
				validateflag = true;
			}
		}
		if (validateflag) {
			/*String ConsistentID = Dttestdata.getValue("ConsistentMemberID");
			String strQuery = "";
			String regflag = "";
			String updateQuery = "";*/
			try {
				if (content.contains("Successfully Updated")) {
					Assert.done("TestID: " + testID);
					Assert.done("Test Description: " + testDesc);
					/*
					 * if(!(SubscriberID.equalsIgnoreCase("") && DependentID.equalsIgnoreCase("")))
					 * { strQuery =
					 * "SELECT DISTINCT REGISTRATION_errorflag FROM SS_SG_SQL.SG_MIGRATION WHERE MEMBER_ID='"
					 * +SubscriberID+"' AND DEPENDENT_ID='"+DependentID+"' "; } else {
					 */
					strQuery = "SELECT DISTINCT REGISTRATION_FLAG FROM SS_SG_SQL.SG_MIGRATION WHERE CONSISTENT_MEMBER_ID = '"
							+ ConsistentID + "' ";
					// }
					org.json.JSONArray cmiDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, "Sqldbx");
					regflag = cmiDetails.getJSONObject(0).getString("REGISTRATION_FLAG");
				}
				if (regflag.equalsIgnoreCase("Y")) {
					Assert.pass("Successfully Updated");
				} else {
					Assert.fail("Unable to Update");
				}
			} catch (Exception e) {
				/* Assert.done("Completed"); */
				e.printStackTrace();

			}

			finally {
				updateQuery = "Update SS_SG_SQL.SG_MIGRATION  SET REGISTRATION_FLAG = 'N' WHERE (CONSISTENT_MEMBER_ID='"
						+ ConsistentID + "')  AND REGISTRATION_FLAG = 'Y'";
				ViewClaimsDBS.getMemberInfofromDBS(updateQuery, "Sqldbx");
			}
		} else {

			
				
			
			Assert.done("Test ID: " + testID);
			Assert.done("Test Description: " + testDesc);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg");
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {

					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
			}
		}
	}

	/**
	 * This method is used to validate the JSON response and DB data of GetID Card
	 * service.
	 * 
	 * @param content
	 *            = JSON response data
	 * @param testID
	 *            = TestCase ID
	 * @throws Exception
	 */

	public static void validateGetIDCard(String content, String testID, File folder, String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		//String testdir = Environment.get("IDCard_Base_Dir");
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";
		folder = new File(folder + "/IDCardPDF");
		folder.mkdir();
		DataTable1 Dttestdata = new DataTable1(testdir + "IDCard.xls", "GetIDCard", "" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String testDesc = Dttestdata.getValue("Test_Description");
		if (content.contains("errorCode")) {
			errorflag = false;
		} else {
			validateflag = true;
		}
		if (validateflag) {
			Object obj = jsonparser.parse(content);
			JSONObject idObj = (JSONObject) obj;
			String byteStreamArray = "";
			String SubscriberID = Dttestdata.getValue("SubscriberID");
			String productName = Dttestdata.getValue("ProductName");
			String dependentID = Dttestdata.getValue("DependentID");
			String fname = "";
			String midname = "";
			String lname = "";
			String imgFormat = Dttestdata.getValue("ImageFormat");
			int i = 0;
			String strQuery = "";
			String fullname = "";
			Assert.done("Test ID: " + testID);
			Assert.done("Test Description: " + testDesc);
			if (content.contains("\"success\" : \"SUCCESS\"")) {

				byteStreamArray = idObj.get("byteStream").toString();
				if (imgFormat.equalsIgnoreCase("")) {
					imgFormat = "PDF";
				}

				if (!byteStreamArray.equalsIgnoreCase("")) {
					if (imgFormat.equalsIgnoreCase("PDF")) {

						if (dependentID.equalsIgnoreCase("")) {
							strQuery = " SELECT SUBSCRIBER_ID,DEPENDENT_ID,FIRST_NAME,MIDDLE_INITIAL_NAME,LAST_NAME "
									+ " FROM SS_SQL.MEMBER_PROFILE WHERE SUBSCRIBER_ID='" + SubscriberID + "' ";
						} else {
							strQuery = " SELECT SUBSCRIBER_ID,DEPENDENT_ID,FIRST_NAME,MIDDLE_INITIAL_NAME,LAST_NAME "
									+ " FROM SS_SQL.MEMBER_PROFILE WHERE SUBSCRIBER_ID='" + SubscriberID
									+ "' And  DEPENDENT_ID= '" + dependentID + "' ";
						}

						org.json.JSONArray subDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, "Microsoft");
						int size = subDetails.length();
						ByteStreamConverter.imgformatConverter(testID, byteStreamArray, folder, imgFormat);
						for (i = 0; i < size; i++) {
							Assert.done("Validating Member " + (i + 1) + " details");
							fname = subDetails.getJSONObject(i).getString("FIRST_NAME").trim();
							midname = subDetails.getJSONObject(i).getString("MIDDLE_INITIAL_NAME").trim();
							lname = subDetails.getJSONObject(i).getString("LAST_NAME").trim();
							fullname = fname + " " + midname + " " + lname;
							PDFValidation.runPDFValidation(testID, SubscriberID, productName, folder, fullname, fname);
						}
					} else {
						ByteStreamConverter.imgformatConverter(testID, byteStreamArray, folder, imgFormat);
					}
				} else {
					Assert.fail("ByteStream Array is blank");
				}
			} else if (content.contains("\"success\" : \"FAILURE\"")) {
				Assert.fail("No ID Card found");

			}

		} else {
			Assert.done("Test ID: " + testID);
			Assert.done("Test Description: " + testDesc);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg");
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {

					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
				Assert.fail(content);
			}
		}
	}

	/**
	 * Method to validate the JSON response data and DB data for the ViewID Card
	 * Status service
	 * 
	 * @param content
	 *            = JSON Response data
	 * @param testID
	 *            = Test case ID
	 * @throws Exception
	 */
	public static void validateViewIDCardStatus(String content, String testID, String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		//String testdir = Environment.get("IDCard_Base_Dir");
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";
		DataTable1 Dttestdata = new DataTable1(testdir + "IDCard.xls", "ViewIDCardStatus", "" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String testDesc = Dttestdata.getValue("Test_Description");
		String ReportFilePath = "";
		if(Environment.get("Jenkins_Run").equalsIgnoreCase("Yes")) {
		String excelName = Environment.get("ViewIDCardStatus_XML");		
		String excelReportName = excelName.replace(".xml", ".xslx");
		 ReportFilePath = Environment.get("report_path")+"//"+excelReportName;
		}
		else {
		 ReportFilePath = Environment.get("ViewIDStatus_Report");
		}
		//String ReportFilePath = Environment.get("ViewIDStatus_Report");
		if (content.contains("errorCode")) {
			errorflag = false;
		} else {
			validateflag = true;
		}
		if (validateflag) {
			Object obj = jsonparser.parse(content);
			JSONObject viewIdObj = (JSONObject) obj;

			String SubscriberID = Dttestdata.getValue("SubscriberID");
			String DependentID = Dttestdata.getValue("DependentID");
			String MemeCK = Dttestdata.getValue("MemeCK");
			String fName = "";
			String lName = "";
			String midName = "";
			String staticQuery = "";
			String strQuery = "";
			String subQuery = "";
			String memCK = "";
			String sbsbID = "";
			String depID = "";
			String countQuery = "";
			String RecordCount = "";
			String orderDT = "";
			String shipQuery = "";
			String dbmemCK = "";
			String dbsbsbID = "";
			String dbdepID = "";
			String dborderDT = "";
			String dbshipDT = "";
			String fullname = "";
			int jsonSize = 0;
			Object memCK2 = "";
			int j = 0;
			int json = 1, db = 2;

			Assert.done("Test ID: " + testID);
			Assert.done("Test Description: " + testDesc);
			try {
				JSONArray idDetails = new JSONArray();
				idDetails = (JSONArray) viewIdObj.get("idcardStatusdetails");
				jsonSize = idDetails.size();
				for (j = 0; j < jsonSize; j++) {
					Assert.done("Validating row " + j + " values");
					memCK2 = idDetails.get(j);
					Map<String, Object> responseData = UtilMethod.readJsonData(memCK2);
					memCK = responseData.get("memeCK").toString();
					sbsbID = responseData.get("subscriberId").toString();
					depID = responseData.get("dependentId").toString();
					orderDT = responseData.get("orderDate").toString();
					if (MemeCK.equalsIgnoreCase("")) {
						if (DependentID.equalsIgnoreCase("")) {
							subQuery = "Select S.SBSB_ID,M.MEME_SFX,M.MEME_CK,M.MEME_FIRST_NAME, M.MEME_LAST_NAME, M.MEME_MID_INIT,M.SBSB_CK from CMC_SBSB_SUBSC S inner join "
									+ " CMC_MEME_MEMBER M on S.SBSB_CK=M.SBSB_CK  where S.SBSB_ID='" + sbsbID + "' ";
						} else {
							subQuery = "Select S.SBSB_ID,M.MEME_SFX,M.MEME_CK,M.MEME_FIRST_NAME, M.MEME_LAST_NAME, M.MEME_MID_INIT,M.SBSB_CK from CMC_SBSB_SUBSC S inner join "
									+ " CMC_MEME_MEMBER M on S.SBSB_CK=M.SBSB_CK  where S.SBSB_ID='" + sbsbID
									+ "' AND M.MEME_SFX = " + DependentID + " ";
						}
					} else {
						subQuery = "Select S.SBSB_ID,M.MEME_SFX,M.MEME_CK,M.MEME_FIRST_NAME, M.MEME_LAST_NAME, M.MEME_MID_INIT,M.SBSB_CK from CMC_SBSB_SUBSC S inner join "
								+ " CMC_MEME_MEMBER M on S.SBSB_CK=M.SBSB_CK  where  M.MEME_CK = " + MemeCK + " ";
					}
					org.json.JSONArray subDetails = ViewClaimsDBS.getMemberInfofromDBS(subQuery, "Sybase");
					int dbsize = subDetails.length();
					if (dbsize == jsonSize) {
						dbmemCK = subDetails.getJSONObject(j).getString("MEME_CK");
						dbsbsbID = subDetails.getJSONObject(j).getString("SBSB_ID");
						dbdepID = subDetails.getJSONObject(j).getString("MEME_SFX");
						fName = subDetails.getJSONObject(j).getString("MEME_FIRST_NAME").trim();
						lName = subDetails.getJSONObject(j).getString("MEME_LAST_NAME").trim();
						midName = subDetails.getJSONObject(j).getString("MEME_MID_INIT").trim();
						fullname = fName + " " + midName + " " + lName;
						if (fullname.contains("'")) {
							fullname = fullname.replace("'", "''");
						}

						if (!(memCK.equalsIgnoreCase(""))) {
							strQuery = "SELECT Convert(Date,MEIA_CREATE_DTM) AS orderDate FROM CMC_MEIA_ID_ACT c "
									+ " inner join ( SELECT MAX(MEIA_CREATE_DTM) AS MaxDate FROM CMC_MEIA_ID_ACT where MEME_CK= "
									+ memCK + " ) m "
									+ " on  c.MEIA_CREATE_DTM = m.MaxDate INNER JOIN CMC_MEME_MEMBER M on M.SBSB_CK= c.SBSB_CK  where c.MEME_CK= "
									+ memCK + " ";
							org.json.JSONArray dateDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, "Sybase");
							dborderDT = dateDetails.getJSONObject(j).getString("orderDate");
						} else {
							Assert.fail("MemeCK is not present");
						}
						if (SubscriberID.equals("")) {
							String SubIDQuery = "Select SUBSCRIBER_ID from SS_SQL.MEMBER_PROFILE Where Legacy_SBSB_ID = '"
									+ sbsbID + "'";
							org.json.JSONArray subIDdetails = ViewClaimsDBS.getMemberInfofromDBS(SubIDQuery,
									"Microsoft");
							SubscriberID = subIDdetails.getJSONObject(j).getString("SUBSCRIBER_ID").trim();
						}
						dbdepID = "0" + dbdepID;
						countQuery = "SELECT count(distinct TACTUALSHIPDATE) as RecdCount "
								+ " FROM ROUTER.PV_IDCARD_REGISTER IDCARD " + " WHERE IDCARD. CENROLLEEID = '"
								+ SubscriberID
								+ "' AND IDCARD.CDOCIDEXTENDED = '20' and To_CHAR(IDCARD.TACTUALSHIPDATE,'yyyy-mm-dd') >= '" + orderDT + "' ";
						org.json.JSONArray countDetails = ViewClaimsDBS.getMemberInfofromDBS(countQuery, "Oracle");
						RecordCount = countDetails.getJSONObject(0).getString("RecdCount".toUpperCase());
						if (!RecordCount.equalsIgnoreCase("0")) {
							shipQuery = "SELECT distinct To_CHAR(IDCARD.TACTUALSHIPDATE,'yyyy-mm-dd') as actualShipmentDate "
									+ " FROM ROUTER.PV_IDCARD_REGISTER IDCARD " + " WHERE IDCARD. CENROLLEEID = '"
									+ SubscriberID
									+ "' AND IDCARD.CDOCIDEXTENDED = '20' and IDCARD.CREPORTINGROLLUPVALUE7 = '"
									+ dbdepID + "' and" + " To_CHAR(IDCARD.TACTUALSHIPDATE,'yyyy-mm-dd') >= '" + orderDT
									+ "' ";
							org.json.JSONArray actualDetails = ViewClaimsDBS.getMemberInfofromDBS(shipQuery, "Oracle");
							dbshipDT = actualDetails.getJSONObject(0).getString("actualShipmentDate".toUpperCase());
						} else {
							dbshipDT = "Card shipment has been not processed yet";

						}
						staticQuery = "Select memeCK=" + dbmemCK + ",dependentId = " + dbdepID + ",orderDate = '"
								+ dborderDT + "',actualShipmentDate='" + dbshipDT + "',subscriberId='" + dbsbsbID
								+ "',name='" + fullname + "' from CMC_MEME_MEMBER where MEME_CK=" + dbmemCK + " ";
						ValidateMethods.validateDynamicFieldsWithDb((JSONObject) memCK2, staticQuery, "Sybase", json,
								db, ReportFilePath);
						json = json + 2; // 1,3,5
						db = db + 2;

					} else {
						Assert.fail("Records size from JSON and DB are not matching");
					}
				}

			}

			catch (Exception e) {
				e.printStackTrace();
			}

		} else {
			Assert.done("Test ID: " + testID);
			Assert.done("Test Description: " + testDesc);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg");
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {

					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
				Assert.fail(content);
			}
		}
	}

	/**
	 * Method to validate the JSON response data and DB data for the
	 * ValidateAndOrder IDCard service
	 * 
	 * @param content
	 *            = JSON Response data
	 * @param testID
	 *            = Test case ID
	 * @throws Exception
	 */

	public static void ValidateAndOrderIDCard(String content, String testID,String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";  //Add this line
		DataTable1 Dttestdata = new DataTable1(testdir + "ValidateAndOrderIDCard.xls", "ValidateAndOrderIDCard_Input",
				"" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String ReportFilePath = Environment.get("Report_excel_path");
		String testDesc = Dttestdata.getValue("Test_Description");
		if (content.contains("\"ErrorCode\" : \"\"") || content.contains("\"ErrorCode\" : \"NA\"")) {
			validateflag = true;
		}
		if (validateflag) {
			Object obj = jsonparser.parse(content);
			JSONObject ClaimObj = (JSONObject) obj;
			String inputtestID = Dttestdata.getValue("TestID");
			String SbsbCK = Dttestdata.getValue("SbsbCK");
			String MemeCK = Dttestdata.getValue("MemeCK");
			String IDCardType = Dttestdata.getValue("IDCardType");
			String ProcessFlag = Dttestdata.getValue("ProcessFlag");

			String strQuery = "";
			if (ProcessFlag.equalsIgnoreCase("O")) {
				Assert.done("Test ID: " + inputtestID);
				Assert.done("Test Description: " + testDesc);

				if (MemeCK.equalsIgnoreCase(""))
					strQuery = "select TOP 1  A.MEME_CK as MemeCK, A.SBSB_CK as SbsbCK, "
							+ "A.MEIA_REQ_TYPE AS IDCardType  ,A.MEIA_CREATE_DTM as timestamp From CMC_MEIA_ID_ACT A "
							+ "where A.SBSB_CK= " + SbsbCK + " Order By A.MEIA_CREATE_DTM DESC";

				else if (SbsbCK.equalsIgnoreCase("")) {
					strQuery = "select TOP 1  A.MEME_CK as MemeCK, A.SBSB_CK as SbsbCK, "
							+ "A.MEIA_REQ_TYPE AS IDCardType ,A.MEIA_CREATE_DTM as timestamp From CMC_MEIA_ID_ACT A "
							+ "where A.MEME_CK= " + MemeCK + " Order By A.MEIA_CREATE_DTM DESC";

				} else {

					strQuery = "select TOP 1  A.MEME_CK as MemeCK, A.SBSB_CK as SbsbCK, "
							+ "A.MEIA_REQ_TYPE AS IDCardType ,A.MEIA_CREATE_DTM as timestamp From CMC_MEIA_ID_ACT A "
							+ "where A.MEME_CK= " + MemeCK + " AND A.SBSB_CK= " + SbsbCK
							+ " Order By A.MEIA_CREATE_DTM DESC";
				}

				org.json.JSONArray dbDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, "Sybase");
				String memeCK = dbDetails.getJSONObject(0).getString("MemeCK");
				String sbsbCK = dbDetails.getJSONObject(0).getString("SbsbCK");
				String iDCardType = dbDetails.getJSONObject(0).getString("IDCardType");
				String timestamp = dbDetails.getJSONObject(0).getString("timestamp");
				timestamp = timestamp.substring(0, 10);
				Map<String, String> map = new HashMap<>();
				map.put("Timestamp", timestamp);

				boolean timestampStatus = ValidateMethods.validateStaticFieldsWithDb(ClaimObj, dbDetails, "Sybase",
						ReportFilePath, map);

				if (timestampStatus) {

					if ((memeCK.trim().equalsIgnoreCase(MemeCK) || (sbsbCK).trim().equalsIgnoreCase(SbsbCK))
							&& (iDCardType).trim().equalsIgnoreCase(IDCardType)) {

						Assert.pass("Ordered Successfully");
					} else {
						Assert.fail("Failed to Order the IDCard");
					}
				} else {
					Assert.fail("Failed to Order the IDCard");

				}

			} else if (ProcessFlag.equalsIgnoreCase("V")) {

				Assert.done("Test ID: " + inputtestID);
				Assert.done("Test Description: " + testDesc);
				if (content.contains("\"ApplicationReturnCode\" : \"Y\"")) {
					String applicationReturnCode = Dttestdata.getValue("ValidationReturnedCode");
					String transactionStatus = Dttestdata.getValue("Status");

					if ((content.contains(applicationReturnCode)) && (content.contains(transactionStatus))) {
						UtilMethod.Log("Validation is successfull to Order the IDCard", "PASS", true);
						Assert.done("Returns Response : " + content);
					} else {

						UtilMethod.Log("Invalid Response Code", "FAIL", true);
					}
				} else {
					String transactionStatus = Dttestdata.getValue("Status").trim();
					String errorDescription = Dttestdata.getValue("ErrorMsg").trim();

					if ((content.contains(transactionStatus)) && (content.contains(errorDescription))) {
						UtilMethod.Log("Validation is not successfull to Order the IDCard", "PASS", true);
						Assert.done("Returns Response : " + content);
					} else {

						UtilMethod.Log("Invalid Response Code", "FAIL", true);
					}
				}
			} else {

				Assert.done("Test ID: " + inputtestID);
				Assert.done("Test Description: " + testDesc);
				if (content.contains("\"ErrorCode\" : \"NA\"")) {

					if (MemeCK.equalsIgnoreCase(""))
						strQuery = "select TOP 1  A.MEME_CK as MemeCK, A.SBSB_CK as SbsbCK, "
								+ "A.MEIA_REQ_TYPE AS IDCardType  ,A.MEIA_CREATE_DTM as timestamp From CMC_MEIA_ID_ACT A "
								+ "where A.SBSB_CK= " + SbsbCK + " Order By A.MEIA_CREATE_DTM DESC";

					else if (SbsbCK.equalsIgnoreCase("")) {
						strQuery = "select TOP 1  A.MEME_CK as MemeCK, A.SBSB_CK as SbsbCK, "
								+ "A.MEIA_REQ_TYPE AS IDCardType ,A.MEIA_CREATE_DTM as timestamp From CMC_MEIA_ID_ACT A "
								+ "where A.MEME_CK= " + MemeCK + " Order By A.MEIA_CREATE_DTM DESC";
					} else {

						strQuery = "select TOP 1  A.MEME_CK as MemeCK, A.SBSB_CK as SbsbCK, "
								+ "A.MEIA_REQ_TYPE AS IDCardType ,A.MEIA_CREATE_DTM as timestamp From CMC_MEIA_ID_ACT A "
								+ "where A.MEME_CK= " + MemeCK + " AND A.SBSB_CK= " + SbsbCK
								+ " Order By A.MEIA_CREATE_DTM DESC";
					}
					org.json.JSONArray dbDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, "Sybase");
					String memeCK = dbDetails.getJSONObject(0).getString("MemeCK");
					String sbsbCK = dbDetails.getJSONObject(0).getString("SbsbCK");
					String iDCardType = dbDetails.getJSONObject(0).getString("IDCardType");
					String timestamp = dbDetails.getJSONObject(0).getString("timestamp");
					timestamp = timestamp.substring(0, 10);
					Map<String, String> map = new HashMap<>();
					map.put("timestamp", timestamp);
					boolean timestampStatus = ValidateMethods.validateStaticFieldsWithDb(ClaimObj, dbDetails, "Sybase",
							ReportFilePath, map);

					if (timestampStatus) {

						if ((memeCK.trim().equalsIgnoreCase(MemeCK) || (sbsbCK).trim().equalsIgnoreCase(SbsbCK))
								&& (iDCardType).trim().equalsIgnoreCase(IDCardType)) {

							Assert.pass("Ordered Successfully");
						} else {
							Assert.fail("Failed to Order the IDCard");
						}
					} else {
						Assert.fail("Failed to Order the IDCard");

					}
				} else {

					if (content.contains("\"ApplicationReturnCode\" : \"Y\"")) {
						String applicationReturnCode = Dttestdata.getValue("ValidationReturnedCode");
						String transactionStatus = Dttestdata.getValue("Status");

						if ((content.contains(applicationReturnCode)) && (content.contains(transactionStatus))) {
							UtilMethod.Log("Validation is successfull to Order the IDCard", "PASS", true);
							Assert.done("Returns Response : " + content);
						} else {

							UtilMethod.Log("Invalid Response Code", "FAIL", true);
						}
					} else {
						String transactionStatus = Dttestdata.getValue("Status").trim();
						String errorDescription = Dttestdata.getValue("ErrorMsg").trim();

						if ((content.contains(transactionStatus)) && (content.contains(errorDescription))) {
							UtilMethod.Log("Validation is not successfull to Order the IDCard ", "PASS", true);
							Assert.done("Returns Response: " + content);
						} else {

							UtilMethod.Log("Invalid Response Code", "FAIL", true);
						}
					}
				}
			}
		} else {
			if (content.contains("\"ErrorCode\" : \"99999\"")) {
				Assert.done("Test ID: " + testID);
				Assert.done("Test Description: " + testDesc);
				Assert.fail("Failed to Order the IDCard");

			} else {
				Assert.done("Test ID: " + testID);
				String errorCode = Dttestdata.getValue("ErrorCode");
				String errorMsg = Dttestdata.getValue("ErrorMsg").trim();
				if (!(errorCode.equalsIgnoreCase(""))) {
					if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
						UtilMethod.Log("Valid Error Code", "PASS", true);
						Assert.done("Returns Error: " + content);
					} else {

						UtilMethod.Log("Invalid Error Code", "FAIL", true);
					}
				} else {
					UtilMethod.Log("Unexpected Error Code", "FAIL", true);
					UtilMethod.Log(content, "FAIL", true);
				}
			}
		}
	}

	/**
	 * This method is used convert JSON object into map and pass the JSON value and
	 * DB value and compare them
	 * 
	 * @param ClaimObj
	 * @param dbDetails
	 * @param DB
	 * @param ReportFilePath
	 * @param map
	 * @throws SQLException
	 * @throws IOException
	 */
	public static boolean validateStaticFieldsWithDb(JSONObject ClaimObj, org.json.JSONArray dbDetails, String DB,
			String ReportFilePath, Map<String, String> map) throws SQLException, IOException {
		boolean timestampStatus = false;
		Object value = null;
		Map<String, Object> responseData = UtilMethod.readJsonData(ClaimObj);
		Set<String> keys = responseData.keySet();
		for (String key : keys) {
			value = responseData.get(key);
			if (value != null) {
				timestampStatus = UtilMethod.compareJsonAndDbValueUsingMap(dbDetails, key, value, ReportFilePath, map);
			}

		}
		return timestampStatus;

	}

	/**
	 * 
	 * @param content
	 *            = JSON response data
	 * @param testID
	 *            = TestCase ID
	 * @throws Exception
	 */
	public static void validateGetMemberBenefits(String content, String testID, String env) throws Exception {
		boolean flag = true;
		boolean flag1 = false;
		int i = 0, j = 0, k = 0;
		//String testdir = Environment.get("Benefits_Base_Dir");
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";
		DataTable1 Dttestdata = new DataTable1(testdir + "MemberBenefits.xls", "GetMemberBenefits", "" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String testDesc = Dttestdata.getValue("Test_Description");
		String staticQuery = "";
		String ReportFilePath = "";
		if(Environment.get("Jenkins_Run").equalsIgnoreCase("Yes")) {
		String excelName = Environment.get("GetMemberBenefits_XML");		
		String excelReportName = excelName.replace(".xml", ".xslx");
		 ReportFilePath = Environment.get("report_path")+"//"+excelReportName;
		}
		else {
		 ReportFilePath = Environment.get("GetMemberBenefits_ExcelReport_Path");
		}
		//String ReportFilePath = Environment.get("GetMemberBenefits_ExcelReport_Path");
		if (content.contains("\"ErrorCode\" : \"\"") || content.contains("\"Status\" : \"Partial\"") || content.contains("\"Status\" : \"Success\"")) {
			flag1 = true;
		}
		if (flag1) {
			Object obj = jsonparser.parse(content);
			JSONObject benefitObj = (JSONObject) obj;
			System.out.println(benefitObj.toString());
			String subscriberID = Dttestdata.getValue("SubscriberID");
			String dependentID = Dttestdata.getValue("DependentID");
			String memeCK = Dttestdata.getValue("MemberContrivedKey");
			String productType = Dttestdata.getValue("ProductType");
			String productID = Dttestdata.getValue("ProductID");
			String viewAsDate = Dttestdata.getValue("ViewAsDate");
			String sensitivityIndicator = Dttestdata.getValue("SensitivityIndicator");
			String internalMessages = Dttestdata.getValue("InternalMessages");
			String processType = Dttestdata.getValue("ProcessType");
			String serviceReferenceID = Dttestdata.getValue("ServiceReferenceID");
			String benefitPackageDisplayID = Dttestdata.getValue("BenefitPackageDisplayID");
			String serviceCategoryID = Dttestdata.getValue("ServiceCategoryID");
			String requestedNetwork = Dttestdata.getValue("RequestedNetwork");
			String coverageTier = Dttestdata.getValue("CoverageTier");
			String accumulatorIndicator = Dttestdata.getValue("AccumulatorIndicator");
			String int_Service_Ind = Dttestdata.getValue("Int_Service_Ind");
			String memProfileID = "";
			String serviceName = "";
			String displayType = "";
			String displayLiteral = "";
			String displayQuery = "";
			String oop_accum_method = "";
			String coverageQuery = "";
			String network_tier = "";
			String BenefitQuery = "";
			String msgQuery = "";
			String networkRequested = "";
			int b = 0;
			int methodSize = 0;
			JSONObject benefitSetObj = new JSONObject();
			JSONObject coverageObj1 = new JSONObject();
			String displayTypeQuery = "";
			String accum_method = "";
			String limitQuery = "";
			String accuralQuery = "";
			String metUnmetQuery = "";
			String maxVal = "";
			String bucketVal = "";
			String displayMaxVal = "";
			String metUnmetIndicator = "";
			String message = "";
			String memeKey = "";
			String acc_type = "";
			String accural = "";
			String serviceLevelID = "";
			String displayMaximumQuery = "";
			double remaining = 0;
			double accuralval = 0;
			double maxim = 0;
			String displayAccural = "";
			String displayRemaining = "";
			String oopdisplayRemaining1 = "";
			String oopdisplayRemaining2 = "";
			String deductdisplayRemaining1 = "";
			String deductdisplayRemaining2 = "";
			double ooprem1 = 0;
			double ooprem2 = 0;
			double deductrem1 = 0;
			double deductrem2 = 0;
			JSONObject metUnmetObj = new JSONObject();
			JSONObject covObj = new JSONObject();
			int a = 0;
			String oopactualmethod1 = "";
			String oopactualmethod2 = "";
			String deductactualmethod1 = "";
			String deductactualmethod2 = "";
			String actualmethod = "";
			String methodQuery = "";
			String oop_method = "";
			int metunmet = 0;
			String actualMethod_oop1 = "";
			String actualMethod_oop2 = "";
			String actualMethod_deduct1 = "";
			String actualMethod_deduct2 = "";
			String benefitStartDT2 = "";
			String max = "";
			String accuralQuery2 = "";
			String accumDesc = "";
			String remain = "";
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String serRefID = serviceReferenceID;
			String Br_pkg_ID = benefitPackageDisplayID;
			NumberFormat formatter = NumberFormat.getCurrencyInstance(Locale.CANADA);
			Assert.done("Test Case ID : " + testID);
			Assert.done("Test Description " + testDesc);
			if (viewAsDate.equals("")) {

				Date date = new Date();
				viewAsDate = dateFormat.format(date);
			}

			String memQuery = "Select MP.MEMBER_PROFILE_ID,MPE.BENEFIT_MONTHS, LEGACY_MEME_CK  from SS_SQL.MEMBER_PROFILE MP INNER JOIN SS_SQL.MEMBER_PLAN_ELIGIBILITY MPE ON MP.MEMBER_PROFILE_ID = MPE.MEMBER_PROFILE_ID WHERE ((MP.SUBSCRIBER_ID = '"
					+ subscriberID + "' and MP.DEPENDENT_ID = '" + dependentID + "') or MP.LEGACY_MEME_CK = '" + memeCK
					+ "') ORDER BY MP.MEMBER_PROFILE_ID, MPE.BENEFIT_START_DATE DESC";
			org.json.JSONArray dbSubscriberDetails = ViewClaimsDBS.getMemberInfofromDBS(memQuery, "Microsoft");
			memProfileID = dbSubscriberDetails.getJSONObject(0).getString("MEMBER_PROFILE_ID");
			memeKey = dbSubscriberDetails.getJSONObject(0).getString("LEGACY_MEME_CK");

			if (coverageTier.equalsIgnoreCase("")) {
				coverageTier = "A";
			}
			if (accumulatorIndicator.equalsIgnoreCase("")) {
				accumulatorIndicator = "Y";
			}
			if (requestedNetwork.equalsIgnoreCase("A")) {
				networkRequested = "Y','N";
			} else {
				networkRequested = requestedNetwork;
			}
			if (processType.equalsIgnoreCase("P")) {
				if (productType.equalsIgnoreCase("Medical") | productID.startsWith("M")) {
					serviceName = "Plan Level Benefits','Part A Deductible','Part A Copayments','Part B Coinsurance ";
				}
			}
			if (serviceReferenceID.contains("|")) {

				serviceReferenceID = serviceReferenceID.replace("|", "','");
			}
			if (benefitPackageDisplayID.contains("|")) {
				benefitPackageDisplayID = benefitPackageDisplayID.replace("|", "','");
			}
			if (int_Service_Ind.equalsIgnoreCase("")) {
				int_Service_Ind = "N";
			}
			try {
				Assert.done("Validating Static fields ");
				if (!serviceCategoryID.equalsIgnoreCase("")) {
					staticQuery = "SELECT UserId = 'CHNLESBMEP',SubscriberID = '" + subscriberID + "',DependentID = '"
							+ dependentID + "', MemberContrivedKey = '" + memeCK
							+ "', MPE.BENEFIT_START_DATE AS EligibilityStartDate, "
							+ "MPE.BENEFIT_END_DATE AS EligibilityEndDate, ProcessType = '" + processType
							+ "', Producttype = '" + productType + "' , ProductID = '" + productID + "',  "
							+ "BRPackageDisplayID = '" + Br_pkg_ID + "', ServiceCategory_ID = '" + serviceCategoryID
							+ "' , RequestedNetwork = '" + requestedNetwork + "', "
							+ "MPP.PLAN_ID as PlanID, MPP.PLAN_NAME as PlanName, MPP.BR_PACKAGE_ID AS MemberPackageID, ServiceRef_ID = '"
							+ serRefID + "'," + " MP.LEGACY_SBSB_CK,PR.PDPD_ACC_SFX, SensitivityIndicator = '"
							+ sensitivityIndicator + "', ViewAsDate = '" + viewAsDate + "', GetIntMsgind = '"
							+ internalMessages + "' , "
							+ "ActiveIndicator = (CASE WHEN (GETDATE() BETWEEN MPE.BENEFIT_START_DATE AND MPE.BENEFIT_END_DATE) THEN 'Active' ELSE 'Inactive' END), "
							+ " CoverageTierInd = '" + coverageTier + "', AccCallInd = '" + accumulatorIndicator + "' ,"
							+ "Int_Service_Ind = '" + int_Service_Ind + "' "
							+ "FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN SS_SQL.MEMBER_PLAN_ELIGIBILITY MPE ON MP.MEMBER_PROFILE_ID=MPE.MEMBER_PROFILE_ID "
							+ "INNER JOIN SS_SQL.MEMBER_PLAN_PACKAGES MPP ON MPE.MEMBER_PLAN_ID=MPP.MEMBER_PLAN_ID "
							+ "INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON MPP.BR_PACKAGE_ID=BSD.BR_Package_Id "
							+ "INNER JOIN SS_SQL.BR_CATEGORY_SERVICE_XREF CSX ON CSX.SERVICE_REF_ID = BSD.Service_Ref_Id "
							+ "INNER JOIN SS_SQL.BR_CATEGORY_REF BCR ON BCR.CATEGORY_REF_ID = CSX.CATEGORY_REF_ID "
							+ "INNER JOIN SS_SQL.PRODUCTS_REF PR ON PR.PDPD_ID= MPP.LEGACY_PRODUCT_ID "
							+ "WHERE MP.MEMBER_PROFILE_ID='" + memProfileID + "' AND " + "'" + viewAsDate
							+ "' BETWEEN  MPE.BENEFIT_START_DATE AND MPE.BENEFIT_END_DATE " + "AND (MPP.PRODUCT_TYPE='"
							+ productType + "' OR MPP.LEGACY_PRODUCT_ID= '" + productID
							+ "') AND (BCR.CATEGORY_REF_ID='" + serviceCategoryID + "')";
				} else {
					staticQuery = "SELECT UserId = 'CHNLESBMEP',SubscriberID = '" + subscriberID + "',DependentID = '"
							+ dependentID + "', MemberContrivedKey = '" + memeCK
							+ "', MPE.BENEFIT_START_DATE AS EligibilityStartDate, "
							+ "MPE.BENEFIT_END_DATE AS EligibilityEndDate, ProcessType = '" + processType
							+ "', Producttype = '" + productType + "' , ProductID = '" + productID + "',  "
							+ "BRPackageDisplayID = '" + Br_pkg_ID + "', ServiceCategory_ID = '" + serviceCategoryID
							+ "' , RequestedNetwork = '" + requestedNetwork + "', "
							+ "MPP.PLAN_ID as PlanID, MPP.PLAN_NAME as PlanName, MPP.BR_PACKAGE_ID AS MemberPackageID, ServiceRef_ID = '"
							+ serRefID + "'," + " MP.LEGACY_SBSB_CK,PR.PDPD_ACC_SFX, SensitivityIndicator = '"
							+ sensitivityIndicator + "', ViewAsDate = '" + viewAsDate + "', GetIntMsgind = '"
							+ internalMessages + "' , "
							+ "ActiveIndicator = (CASE WHEN (GETDATE() BETWEEN MPE.BENEFIT_START_DATE AND MPE.BENEFIT_END_DATE) THEN 'Active' ELSE 'Inactive' END), "
							+ " CoverageTierInd = '" + coverageTier + "', AccCallInd = '" + accumulatorIndicator + "' ,"
							+ "Int_Service_Ind = '" + int_Service_Ind + "' "
							+ "FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN SS_SQL.MEMBER_PLAN_ELIGIBILITY MPE ON MP.MEMBER_PROFILE_ID=MPE.MEMBER_PROFILE_ID "
							+ "INNER JOIN SS_SQL.MEMBER_PLAN_PACKAGES MPP ON MPE.MEMBER_PLAN_ID=MPP.MEMBER_PLAN_ID "
							+ "INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON MPP.BR_PACKAGE_ID=BSD.BR_Package_Id "
							+ "INNER JOIN SS_SQL.PRODUCTS_REF PR ON PR.PDPD_ID= MPP.LEGACY_PRODUCT_ID "
							+ "WHERE MP.MEMBER_PROFILE_ID='" + memProfileID + "' AND " + "'" + viewAsDate
							+ "' BETWEEN  MPE.BENEFIT_START_DATE AND MPE.BENEFIT_END_DATE " + "AND (MPP.PRODUCT_TYPE='"
							+ productType + "' OR MPP.LEGACY_PRODUCT_ID= '" + productID
							+ "') AND (BSD.BR_Package_Display_Id in ('" + benefitPackageDisplayID
							+ "') OR BSD.SERVICE_REF_ID IN ('" + serviceReferenceID
							+ "') or bsd.Service_Description In ('" + serviceName + "') )";

				}
				ValidateMethods.validateStaticFieldsWithDb(benefitObj, staticQuery, "Microsoft", ReportFilePath);
				benefitStartDT2 = benefitObj.get("AccumResetDate").toString();
				String serviceDetailQuery = "";
				int json = 1;
				int db = 2;
				int benefitRow = 1;
				int benefitCol = 2;
				Assert.done("Validating service details ");
				if (!serviceCategoryID.equalsIgnoreCase("")) {
					serviceDetailQuery = "SELECT DISTINCT BSS.BR_Package_Display_Id, BSD.BR_Package_Id,BSD.Service_Ref_Id,BSD.Service_Display_Name, "
							+ " Service_Description = (CASE WHEN(BSR.Service_Ref_Desc_Display IS NULL) THEN '' ELSE BSR.Service_Ref_Desc_Display END), BSD.TimePeriod_At_Service as TimePeriod_At_Service, "
							+ " BSD.PLACE_OF_SERVICE as Place_of_Service, BSD.Age_restrictions, BSD.PCP_Flag AS PCPRequiredIND, BSD.Standard_Portfolio_Flag as Standard_portfolio_flag"
							+ "  FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN SS_SQL.MEMBER_PLAN_ELIGIBILITY MPE ON MP.MEMBER_PROFILE_ID=MPE.MEMBER_PROFILE_ID "
							+ "INNER JOIN SS_SQL.MEMBER_PLAN_PACKAGES MPP ON MPE.MEMBER_PLAN_ID=MPP.MEMBER_PLAN_ID "
							+ "INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON MPP.BR_PACKAGE_ID=BSD.BR_Package_Id "
							+ "INNER JOIN SS_SQL.BR_SERVICE_REF BSR ON BSR.SERVICE_REF_ID=BSD.Service_Ref_Id "
							+ "INNER JOIN SS_SQL.BR_CATEGORY_SERVICE_XREF CSX ON CSX.SERVICE_REF_ID = BSR.SERVICE_REF_ID "
							+ "INNER JOIN SS_SQL.BR_CATEGORY_REF BCR ON BCR.CATEGORY_REF_ID = CSX.CATEGORY_REF_ID "
							+ "INNER JOIN ss_sql.Benefits_Service_Display_Details BSS ON BSS.BR_Package_Display_Id= BSD.BR_Package_Display_Id "
							+ "WHERE   MP.MEMBER_PROFILE_ID='" + memProfileID + "' AND " + "'" + viewAsDate
							+ "' BETWEEN  MPE.BENEFIT_START_DATE AND MPE.BENEFIT_END_DATE " + "AND (MPP.PRODUCT_TYPE='"
							+ productType + "' OR  MPP.LEGACY_PRODUCT_ID= '" + productID
							+ "') AND BCR.CATEGORY_REF_ID='" + serviceCategoryID + "'  AND BSS.Network_Type_Code IN ('"
							+ networkRequested + "')";
				} else {
					serviceDetailQuery = "SELECT DISTINCT top 1 BSS.BR_Package_Display_Id, BSD.BR_Package_Id,BSD.Service_Ref_Id,BSD.Service_Display_Name, "
							+ " Service_Description = (CASE WHEN(BSR.Service_Ref_Desc_Display IS NULL) THEN '' ELSE BSR.Service_Ref_Desc_Display END), BSD.TimePeriod_At_Service as TimePeriod_At_Service, "
							+ " BSD.PLACE_OF_SERVICE as Place_of_Service, BSD.Age_restrictions, BSD.PCP_Flag AS PCPRequiredIND, BSD.Standard_Portfolio_Flag as Standard_portfolio_flag"
							+ "  FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN SS_SQL.MEMBER_PLAN_ELIGIBILITY MPE ON MP.MEMBER_PROFILE_ID=MPE.MEMBER_PROFILE_ID "
							+ "INNER JOIN SS_SQL.MEMBER_PLAN_PACKAGES MPP ON MPE.MEMBER_PLAN_ID=MPP.MEMBER_PLAN_ID "
							+ "INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON MPP.BR_PACKAGE_ID=BSD.BR_Package_Id "
							+ "INNER JOIN SS_SQL.BR_SERVICE_REF BSR ON BSR.SERVICE_REF_ID=BSD.Service_Ref_Id "
							+ "INNER JOIN ss_sql.Benefits_Service_Display_Details BSS ON BSS.BR_Package_Display_Id= BSD.BR_Package_Display_Id "
							+ "WHERE   MP.MEMBER_PROFILE_ID='" + memProfileID + "' AND " + "'" + viewAsDate
							+ "' BETWEEN  MPE.BENEFIT_START_DATE AND MPE.BENEFIT_END_DATE " + "AND (MPP.PRODUCT_TYPE='"
							+ productType + "' OR  MPP.LEGACY_PRODUCT_ID= '" + productID
							+ "') AND (BSD.BR_Package_Display_Id in ( '" + benefitPackageDisplayID + "') OR "
							+ "BSD.SERVICE_REF_ID IN ('" + serviceReferenceID + "') or bsd.Service_Description IN ('"
							+ serviceName + "' ) ) AND BSS.Network_Type_Code IN ('" + networkRequested + "') ORDER BY BSS.BR_Package_Display_Id";

				}
				String strArrayName = "ServiceDetails";
				String serviceDisplayName = "";
				String bucketQuery = "";
				String bucketNum = "";
				String limitAccural = "";
				String displayLimitAccural = "";
				String displayLimitMaximum = "";
				String displayLimitRemaining = "";
				String limitMaximum = "";
				double limitRemaining = 0;
				String limitRemain = "";

				String UniqueCol = "BR_Package_Display_Id";
				ValidateMethods.validateJsonArrayDataWithDb((JSONObject) benefitObj, strArrayName, serviceDetailQuery,
						UniqueCol, "Microsoft", ReportFilePath);

				Object serviceDetails = benefitObj.get("ServiceDetails");
				JSONParser parser = new JSONParser();
				JSONArray serviceArray = (JSONArray) parser.parse(serviceDetails.toString());
				for (i = 0; i < serviceArray.size(); i++) {
					JSONObject serviceObj = (JSONObject) serviceArray.get(i);
					String br_pkg_display_id = serviceObj.get("BR_Package_Display_Id").toString();
					serviceDisplayName = serviceObj.get("Service_Display_Name").toString();
					String accuralValQuery = "";
					Assert.done("Validating Limitation details");
					bucketQuery = "SELECT BucketNumber = (CASE WHEN(Ser_Facets_Limit_Bucket IS NULL) THEN '0' ELSE Ser_Facets_Limit_Bucket END),Ser_Limit_Value  "
							+ " FROM SS_SQL.Benefits_Service_Limits_Display " + " WHERE BR_Package_Display_Id = '"
							+ br_pkg_display_id + "' ";
					org.json.JSONArray dbbucketDetails = ViewClaimsDBS.getMemberInfofromDBS(bucketQuery, "Microsoft");
					if (dbbucketDetails.length() > 0) {
						bucketNum = dbbucketDetails.getJSONObject(0).getString("BucketNumber");
						limitMaximum = dbbucketDetails.getJSONObject(0).getString("Ser_Limit_Value");

						accuralValQuery = "Select MATX.MATX_AMT1 as accural from CMC_SBSB_SUBSC SBSB inner join CMC_MEME_MEMBER MEME on "
								+ " SBSB.SBSB_CK= MEME.SBSB_CK inner join CMC_MATX_ACCUM_TXN MATX on MATX.MEME_CK=MEME.MEME_CK where MEME.MEME_CK = "
								+ memeKey + " and MATX.PDPD_ACC_SFX='C001' AND "
								+ " MATX.MATX_ACC_TYPE = 'L' and MATX_BEN_BEG_DT = '" + benefitStartDT2
								+ "' and MATX.ACAC_ACC_NO = " + bucketNum + " ";
						org.json.JSONArray dbaccuralDetails = ViewClaimsDBS.getMemberInfofromDBS(accuralValQuery,
								"Sybase");
						if (dbaccuralDetails.length() > 0) {
							limitAccural = dbaccuralDetails.getJSONObject(0).getString("accural");
							displayLimitMaximum = formatter.format(Double.parseDouble(limitMaximum));
							limitRemaining = Double.parseDouble(limitMaximum) - Double.parseDouble(limitAccural);
							limitRemain = String.valueOf(limitRemaining);
							displayLimitAccural = formatter.format(Double.parseDouble(limitAccural));
							displayLimitRemaining = formatter.format(Double.parseDouble(limitRemain));

						} else {
							limitAccural = "0";
							displayLimitMaximum = "";
							limitRemain = "0";
							displayLimitAccural = "";
							displayLimitRemaining = "";

						}
						limitQuery = "SELECT BR_Service_Limits_Display_Id AS BRSerceLimitDisplayID, Ser_Limit_Value AS Maximum,  "
								+ "Ser_Limits_Description AS LimitDescription, Bucket_Number = '" + bucketNum + "', "
								+ "Accrual = '" + limitAccural + "', Remaining = '" + limitRemain
								+ "', DisplayMaximum = '" + displayLimitMaximum + "', " + "DisplayAccrual = '"
								+ displayLimitAccural + "', DisplayRemaining = '" + displayLimitRemaining
								+ "', Type = 'L' " + " FROM SS_SQL.Benefits_Service_Limits_Display "
								+ " WHERE BR_Package_Display_Id = '" + br_pkg_display_id + "' ";
						String limitArrayName = "LimitationDetails";
						String[] UniqueColumn = { "BRSerceLimitDisplayID" };
						// ValidateMethods.validateJsonArrayDataWithDb((JSONObject)serviceObj,
						// limitArrayName, limitQuery, UniqueColumn, "Microsoft", ReportFilePath);
						ValidateMethods.validateDynamicJsonArrayDataWithDb((JSONObject) serviceObj, limitArrayName,
								limitQuery, UniqueColumn, "Microsoft", json, db, ReportFilePath);
					} else {
						Assert.done("No Limitation Details present");
					}

					Assert.done("Validating Messaging details");
					if (internalMessages.equalsIgnoreCase("N")) {
						msgQuery = "SELECT distinct BSM.BR_SERVICE_MESSAGE_DISPLAY_ID AS BRServiceMsgDisplayID, BSM.Message_Type_Code AS MessageHeader, BSM.Service_Message_Display  AS Message, "
								+ "Tier = BDD.Network_Tier_Level, NetworkTier = BDD.Network_Tier, BSM.Message_Seq AS MessageSeq "
								+ " FROM SS_SQL.MEMBER_PROFILE MP "
								+ " INNER JOIN SS_SQL.MEMBER_PLAN_ELIGIBILITY MPE ON MP.MEMBER_PROFILE_ID=MPE.MEMBER_PROFILE_ID "
								+ " INNER JOIN SS_SQL.MEMBER_PLAN_PACKAGES MPP ON MPE.MEMBER_PLAN_ID=MPP.MEMBER_PLAN_ID "
								+ " INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON MPP.BR_PACKAGE_ID=BSD.BR_Package_Id "
								+ " INNER JOIN SS_SQL.Benefits_Service_Messages_Display BSM ON BSM.BR_Package_Display_Id=BSD.BR_Package_Display_Id "
								+ " INNER JOIN SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD ON BDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id "
								+ " WHERE MP.MEMBER_PROFILE_ID='" + memProfileID + "' AND '" + viewAsDate
								+ "' BETWEEN  MPE.BENEFIT_START_DATE AND MPE.BENEFIT_END_DATE "
								+ " AND (MPP.PRODUCT_TYPE='" + productType + "' OR  MPP.LEGACY_PRODUCT_ID= '"
								+ productID + "') AND BSM.BR_Package_Display_Id ='" + br_pkg_display_id
								+ "' AND BDD.Network_Tier_Level = '' and BSM.Message_Display_Ind <> 'DESCIN'";
					} else {
						msgQuery = "SELECT distinct BSM.BR_SERVICE_MESSAGE_DISPLAY_ID AS BRServiceMsgDisplayID, BSM.Message_Type_Code AS MessageHeader, BSM.Service_Message_Display  AS Message, "
								+ "Tier = BDD.Network_Tier_Level, NetworkTier = BDD.Network_Tier, BSM.Message_Seq AS MessageSeq "
								+ " FROM SS_SQL.MEMBER_PROFILE MP "
								+ " INNER JOIN SS_SQL.MEMBER_PLAN_ELIGIBILITY MPE ON MP.MEMBER_PROFILE_ID=MPE.MEMBER_PROFILE_ID "
								+ " INNER JOIN SS_SQL.MEMBER_PLAN_PACKAGES MPP ON MPE.MEMBER_PLAN_ID=MPP.MEMBER_PLAN_ID "
								+ " INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON MPP.BR_PACKAGE_ID=BSD.BR_Package_Id "
								+ " INNER JOIN SS_SQL.Benefits_Service_Messages_Display BSM ON BSM.BR_Package_Display_Id=BSD.BR_Package_Display_Id "
								+ " INNER JOIN SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD ON BDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id "
								+ " WHERE MP.MEMBER_PROFILE_ID='" + memProfileID + "' AND '" + viewAsDate
								+ "' BETWEEN  MPE.BENEFIT_START_DATE AND MPE.BENEFIT_END_DATE "
								+ " AND (MPP.PRODUCT_TYPE='" + productType + "' OR  MPP.LEGACY_PRODUCT_ID= '"
								+ productID + "') AND BSM.BR_Package_Display_Id ='" + br_pkg_display_id
								+ "' AND BDD.Network_Tier_Level = ''";
					}
					org.json.JSONArray dbmsgDetails = ViewClaimsDBS.getMemberInfofromDBS(msgQuery, "Microsoft");
					if (dbmsgDetails.length() > 0) {
						String msgArrayName = "MessagingDetails";
						String[] UniqueCol1 = { "BRServiceMsgDisplayID", "Message" };
						Assert.done("Messaging details in the " + i + " row of the service details");
						// ValidateMethods.validateJsonArrayDataWithDb1((JSONObject)serviceObj,
						// msgArrayName, msgQuery, UniqueCol1, "Microsoft", ReportFilePath2);
						ValidateMethods.validateDynamicJsonArrayDataWithDb((JSONObject) serviceObj, msgArrayName,
								msgQuery, UniqueCol1, "Microsoft", json, db, ReportFilePath);

					} else {
						Assert.done("No Messaging details present in the " + i + " row of the service details");
					}
					Assert.done("Validating Network Details ");

					int c = 0;
					Object nwDetails = serviceObj.get("Network");
					JSONArray nwArray = (JSONArray) parser.parse(nwDetails.toString());
					for (j = 0; j < nwArray.size(); j++) {
						JSONObject tierObj = (JSONObject) nwArray.get(j);
						String network = tierObj.get("Network").toString();

						Assert.done("Network is " + network);
						String networkQuery = " SELECT distinct Network = '" + network
								+ "' FROM  SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS "
								+ "  WHERE BR_Package_Display_Id ='" + br_pkg_display_id + "'";
						ValidateMethods.validateDynamicFieldsWithDb(tierObj, networkQuery, "Microsoft", json, db,
								ReportFilePath);

						if (network.equalsIgnoreCase("In-Network")) {
							network = "Y";
						} else {
							network = "N";
						}

						Object tierDetails = tierObj.get("Tier");
						JSONArray coverageArray = (JSONArray) parser.parse(tierDetails.toString());
						for (k = 0; k < coverageArray.size(); k++) {
							covObj = (JSONObject) coverageArray.get(k);
							network_tier = covObj.get("Network_Tier").toString();
							UtilMethod.setCellData("Network_Tier", network_tier, json, ReportFilePath);
							UtilMethod.setCellData("Network_Tier", network_tier, db, ReportFilePath);
							oopactualmethod1 = "";
							oopactualmethod2 = "";
							deductactualmethod1 = "";
							deductactualmethod2 = "";
							Object coverageDetails = covObj.get("Coverage");
							JSONArray coverageArray1 = (JSONArray) parser.parse(coverageDetails.toString());

							for (c = 0; c < coverageArray1.size(); c++) {

								coverageObj1 = (JSONObject) coverageArray1.get(c);
								String cover = coverageObj1.get("coverage").toString();
								// JSONObject coverageType = (JSONObject) coverageObj1.get("coverage");
								JSONObject coverageType = (JSONObject) new JSONParser()
										.parse(coverageObj1.toJSONString());

								System.out.println(coverageDetails);

								Object benefitSet = coverageObj1.get("BenefitSet");
								JSONArray benefitArray = (JSONArray) parser.parse(benefitSet.toString());
								methodSize = benefitArray.size();

								for (a = 0; a < benefitArray.size(); a++) {

									benefitSetObj = (JSONObject) benefitArray.get(a);
									serviceLevelID = benefitSetObj.get("BR_Servicelevel_Display_Id").toString();
									accumDesc = benefitSetObj.get("Accumulator_desc").toString();
									/*if (accumDesc.equalsIgnoreCase("Deductible")) {

										methodQuery = "SELECT  DISTINCT method = (CASE WHEN (BDD.Facets_Dedutible_Bucket IS NOT NULL) THEN 'Deductible' "
												+ " WHEN (BDD.Facets_OOP_Bucket IS NOT NULL )THEN 'Out of Pocket' ELSE '' END) FROM "
												+ " SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD "
												+ "  ON  BSD.BR_Package_Display_Id=BDD.BR_Package_Display_Id WHERE BDD.BR_Package_Display_Id='"
												+ br_pkg_display_id + "' " + "  AND BDD.Network_Type_Code = '" + network
												+ "' AND  BDD.Network_Tier = '" + network_tier
												+ "' AND BDD.BR_Servicelevel_Display_Id='" + serviceLevelID + "' ";

									} else {
										methodQuery = "SELECT  method = (CASE WHEN (BDD.Facets_OOP_Bucket IS NOT NULL) THEN 'Out of Pocket'  WHEN (BDD.Facets_Dedutible_Bucket IS NOT NULL )"
												+ "THEN 'Deductible' ELSE '' END) "
												+ "FROM SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD "
												+ "INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON  BSD.BR_Package_Display_Id=BDD.BR_Package_Display_Id WHERE "
												+ "BDD.BR_Package_Display_Id='" + br_pkg_display_id
												+ "' AND BDD.Network_Type_Code = '" + network
												+ "' AND  BDD.Network_Tier = '" + network_tier
												+ "' AND BDD.BR_Servicelevel_Display_Id='" + serviceLevelID + "' ";
									}

									org.json.JSONArray dbmethodDetails = ViewClaimsDBS.getMemberInfofromDBS(methodQuery,
											"Microsoft");*/

									Assert.done("Validating Network Tier : " + network_tier + " details ");
									accum_method = accumDesc;
									coverageQuery = "";

									if (cover.equalsIgnoreCase("Individual")) {
										if (accum_method.equalsIgnoreCase("Deductible")) {
											coverageQuery = "SELECT  coverageType =  BDD.Deductible_Accum_Method, coverage = '"
													+ cover + "' "
													+ " FROM SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON "
													+ "BSD.BR_Package_Display_Id=BDD.BR_Package_Display_Id WHERE BDD.BR_Package_Display_Id='"
													+ br_pkg_display_id + "' AND BDD.Network_Type_Code = '" + network
													+ "' --AND  BDD.Network_Tier = '" + network_tier + "' \n"
													+ "AND (BDD.Deductible_Accum_Method IN ('IND','INDO')) ORDER BY BDD.Deductible_Accum_Method DESC";

										} else if (accum_method.equalsIgnoreCase("Out of Pocket")) {
											coverageQuery = "SELECT  coverageType = BDD.OOP_Accum_Method, coverage = '"
													+ cover + "' "
													+ " FROM SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON "
													+ "BSD.BR_Package_Display_Id=BDD.BR_Package_Display_Id WHERE BDD.BR_Package_Display_Id='"
													+ br_pkg_display_id + "' AND BDD.Network_Type_Code = '" + network
													+ "' --AND  BDD.Network_Tier = '" + network_tier + "' \n"
													+ "AND (BDD.OOP_Accum_Method IN ('IND','INDO')) ORDER BY BDD.OOP_Accum_Method DESC";

										}
										else {
											coverageQuery = "SELECT distinct coverageType = '',coverage = '" + cover + "' "
													+ " FROM SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON "
													+ "BSD.BR_Package_Display_Id=BDD.BR_Package_Display_Id WHERE BDD.BR_Package_Display_Id='"
													+ br_pkg_display_id + "' AND BDD.Network_Type_Code = '" + network
													+ "' --AND  BDD.Network_Tier = '" + network_tier + "' \n"
													+ "AND (BDD.OOP_Accum_Method IN (''))";

										}

									} else if (!cover.equalsIgnoreCase("")) {
										if (accum_method.equalsIgnoreCase("Deductible")) {
											coverageQuery = "SELECT  coverageType = BDD.Deductible_Accum_Method, coverage = '"
													+ cover + "' "
													+ " FROM SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON "
													+ "BSD.BR_Package_Display_Id=BDD.BR_Package_Display_Id WHERE BDD.BR_Package_Display_Id='"
													+ br_pkg_display_id + "' AND BDD.Network_Type_Code = '" + network
													+ "' AND  BDD.Network_Tier = '" + network_tier + "' "
													+ "AND (BDD.Deductible_Accum_Method IN ('AGGO','AGG','2PER','3PER')) ORDER BY BDD.Deductible_Accum_Method DESC";

										} else if (accum_method.equalsIgnoreCase("Out of Pocket")) {
											coverageQuery = "SELECT  coverageType = BDD.OOP_Accum_Method ,coverage = '"
													+ cover + "' "
													+ " FROM SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON "
													+ "BSD.BR_Package_Display_Id=BDD.BR_Package_Display_Id WHERE BDD.BR_Package_Display_Id='"
													+ br_pkg_display_id + "' AND BDD.Network_Type_Code = '" + network
													+ "' --AND  BDD.Network_Tier = '" + network_tier + "' \n"
													+ "AND (BDD.OOP_Accum_Method IN ('AGGO','AGG','2PER','3PER')) ORDER BY BDD.OOP_Accum_Method DESC";

										}
										 else {
												coverageQuery = "SELECT distinct coverageType = '',coverage = '" + cover + "' "
														+ " FROM SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON "
														+ "BSD.BR_Package_Display_Id=BDD.BR_Package_Display_Id WHERE BDD.BR_Package_Display_Id='"
														+ br_pkg_display_id + "' AND BDD.Network_Type_Code = '" + network
														+ "' --AND  BDD.Network_Tier = '" + network_tier + "' \n"
														+ "AND (BDD.OOP_Accum_Method IN (''))";

											}

									} else {
										coverageQuery = "SELECT distinct coverageType = '',coverage = '" + cover + "' "
												+ " FROM SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON "
												+ "BSD.BR_Package_Display_Id=BDD.BR_Package_Display_Id WHERE BDD.BR_Package_Display_Id='"
												+ br_pkg_display_id + "' AND BDD.Network_Type_Code = '" + network
												+ "' --AND  BDD.Network_Tier = '" + network_tier + "' \n"
												+ "AND (BDD.OOP_Accum_Method IN (''))";

									}

									int m = 0;
									ValidateMethods.validateDynamicFieldsWithDb(coverageType, coverageQuery,
											"Microsoft", json, db, ReportFilePath);

									org.json.JSONArray dbBenefitsetDetails = ViewClaimsDBS
											.getMemberInfofromDBS(coverageQuery, "Microsoft");
									// JSONArray benefitsetArray = (JSONArray)
									// parser.parse(coverageDetails.toString());
									for (m = 0; m < dbBenefitsetDetails.length(); m++) {
										oop_accum_method = dbBenefitsetDetails.getJSONObject(m)
												.getString("coverageType");
										System.out.println(oop_accum_method);
										if(oop_accum_method.equalsIgnoreCase("2PER") || oop_accum_method.equalsIgnoreCase("3PER")) {
											
												displayType = "N";
												displayLiteral = "Count Type Accumulation";
											}
											else {
										if (processType.equalsIgnoreCase("P")
												| serviceDisplayName.equalsIgnoreCase("Plan Level Benefits") | serviceDisplayName.equalsIgnoreCase("Part A Deductible") | serviceDisplayName.equalsIgnoreCase("Part A Copayments") | serviceDisplayName.equalsIgnoreCase("Part B Coinsurance")) {
											if(accum_method.equalsIgnoreCase("")) {
											displayTypeQuery = "SELECT DisplayTypeIndicator = (CASE "+
													"WHEN (BSD.Service_Display_Name = 'Plan Level Benefits' AND ((BDD.Facets_OOP_Bucket IS NOT  NULL) AND BDD.OOP_Accum_Method <>'' AND "
													+ "BDD.OOP_Accum_Method NOT IN ('2PER','3PER')) AND ((BDD.Facets_Dedutible_Bucket IS NOT NULL) AND BDD.Deductible_Accum_Method <>'' "
													+ "AND BDD.Deductible_Accum_Method NOT IN ('2PER','3PER')) AND  BDD.Coverage_Available_Flag='Y') THEN 'D' "
													+ "WHEN ((BDD.Facets_OOP_Bucket IS NULL) "
													+ "AND (BDD.Facets_Dedutible_Bucket IS NULL) AND (BDD.OOP_Accum_Method= '') AND "
													+ "(BDD.Deductible_Accum_Method = '') AND  BDD.Coverage_Available_Flag='Y') THEN 'A' "
													+ " WHEN (BDD.OOP_Accum_Method IN ('2PER','3PER') AND BDD.Deductible_Accum_Method IN ('2PER','3PER') AND (BDD.Facets_OOP_Bucket IS NOT  NULL) AND (BDD.Facets_Dedutible_Bucket IS NOT NULL) "
													+ "AND  BDD.Coverage_Available_Flag='Y') THEN 'N' "
													+ " ELSE '' END) "
													+ "FROM SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD "
													+ "INNER JOIN SS_SQL.Benefit_Services_Display BSD ON BDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id "
													+ "WHERE BDD.BR_Package_Display_Id='" + br_pkg_display_id + "' "
													+ "AND BDD.Network_Type_Code = '" + network
													+ "' AND BDD.BR_Servicelevel_Display_Id= '" + serviceLevelID
													+ "'  ";
											}
											else {
												displayTypeQuery = "SELECT DisplayTypeIndicator = (CASE "+
														"WHEN (BSD.Service_Display_Name = 'Plan Level Benefits' AND ((BDD.Facets_OOP_Bucket IS NOT  NULL) AND BDD.OOP_Accum_Method <>'' OR "
														+ "BDD.OOP_Accum_Method NOT IN ('2PER','3PER')) AND ((BDD.Facets_Dedutible_Bucket IS NOT NULL) AND BDD.Deductible_Accum_Method <>'' "
														+ "OR BDD.Deductible_Accum_Method NOT IN ('2PER','3PER')) AND  BDD.Coverage_Available_Flag='Y') THEN 'D' "
														+ "WHEN ((BDD.Facets_OOP_Bucket IS NULL) "
														+ "AND (BDD.Facets_Dedutible_Bucket IS NULL) AND (BDD.OOP_Accum_Method= '') AND "
														+ "(BDD.Deductible_Accum_Method = '') AND  BDD.Coverage_Available_Flag='Y') THEN 'A' "
														+ " WHEN (BDD.OOP_Accum_Method IN ('2PER','3PER') AND BDD.Deductible_Accum_Method IN ('2PER','3PER') AND  BDD.Coverage_Available_Flag='Y') THEN 'N' "
														+ " ELSE '' END) "
														+ "FROM SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD "
														+ "INNER JOIN SS_SQL.Benefit_Services_Display BSD ON BDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id "
														+ "WHERE BDD.BR_Package_Display_Id='" + br_pkg_display_id + "' "
														+ "AND BDD.Network_Type_Code = '" + network
														+ "' AND BDD.BR_Servicelevel_Display_Id= '" + serviceLevelID
														+ "'  ";
											}
										}

										else if (processType.equalsIgnoreCase("S")) {

											displayTypeQuery = "SELECT DisplayTypeIndicator = (CASE "
													+ " WHEN "
													+ "   (BDD.Coverage_Available_Flag='Y') THEN 'S' ELSE '' END)"
													+ "FROM SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD "
													+ "INNER JOIN SS_SQL.Benefit_Services_Display BSD ON BDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id "
													+ "WHERE BDD.BR_Package_Display_Id='" + br_pkg_display_id + "' "
													+ "AND BDD.Network_Type_Code = '" + network
													+ "' AND BDD.BR_Servicelevel_Display_Id= '" + serviceLevelID
													+ "'  ";

										} else if (processType.equalsIgnoreCase("C")) {
											displayTypeQuery = "SELECT DisplayTypeIndicator = (CASE "+
													"WHEN (BSD.Service_Display_Name = 'Plan Level Benefits' AND ((BDD.Facets_OOP_Bucket IS NOT  NULL) AND BDD.OOP_Accum_Method <>'' AND "
													+ "BDD.OOP_Accum_Method NOT IN ('2PER','3PER')) AND ((BDD.Facets_Dedutible_Bucket IS NOT NULL) AND BDD.Deductible_Accum_Method <>'' "
													+ "AND BDD.Deductible_Accum_Method NOT IN ('2PER','3PER')) AND  BDD.Coverage_Available_Flag='Y') THEN 'D' "
													+ "WHEN (BSD.Service_Display_Name = 'Plan Level Benefits' and (BDD.Facets_OOP_Bucket IS NULL) "
													+ "AND (BDD.Facets_Dedutible_Bucket IS NULL) AND (BDD.OOP_Accum_Method= '') AND "
													+ "(BDD.Deductible_Accum_Method = '') AND  BDD.Coverage_Available_Flag='Y') THEN 'A' "
													+ " WHEN (BDD.OOP_Accum_Method IN ('2PER','3PER') AND BDD.Deductible_Accum_Method IN ('2PER','3PER') AND  BDD.Coverage_Available_Flag='Y') THEN 'N' "
													+ " WHEN BDD.Coverage_Available_Flag='Y' THEN 'S' ELSE '' END) "
													+ "FROM SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD "
													+ "INNER JOIN SS_SQL.Benefit_Services_Display BSD ON BDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id "
													+ "WHERE BDD.BR_Package_Display_Id='" + br_pkg_display_id + "' "
													+ "AND BDD.Network_Type_Code = '" + network
													+ "' AND BDD.BR_Servicelevel_Display_Id= '" + serviceLevelID
													+ "'  ";

										}

										org.json.JSONArray dbdisplayDetails = ViewClaimsDBS
												.getMemberInfofromDBS(displayTypeQuery, "Microsoft");
										displayType = dbdisplayDetails.getJSONObject(0)
												.getString("DisplayTypeIndicator");
										if (displayType.equalsIgnoreCase("A")) {
											displayLiteral = "Copay/Coinsurance Information";
										} else if (displayType.equalsIgnoreCase("S")) {
											displayLiteral = "Service Information";
										} else if (displayType.equalsIgnoreCase("D")) {
											displayLiteral = "Default";
										} else if (displayType.equalsIgnoreCase("N")) {
											displayLiteral = "Count Type Accumulation";
										} else if (displayType.equalsIgnoreCase("")) {
											displayLiteral = "";

										}
										}
										 

										Assert.done("Validating BenefitSet details ");
											
										BenefitQuery = "SELECT BDD.BR_Servicelevel_Display_Id, Referral_Flag = (CASE WHEN (BDD.Referral_Flag IS NOT NULL) THEN BDD.Referral_Flag ELSE '' END) ,  "
												+ "Pre_Auth_Required_Flag = (CASE WHEN (BDD.Pre_Auth_Required_Flag IS NOT NULL) THEN BDD.Pre_Auth_Required_Flag ELSE '' END) ,BDD.Coverage_Available_Flag, DisplayTypeIndicator = '"
												+ displayType + "',DisplayTypeLiteral ='" + displayLiteral + "', "
												+ "Accumulator_desc = '" + accum_method
												+ "', Methodology = '"+oop_accum_method+"', "
												+ " Is_Deductible_combined = (CASE WHEN (BDD.Is_Deductible_Combined IS NULL) THEN '' ELSE BDD.Is_Deductible_Combined END ), "
												+ "Is_OOP_Combined = (CASE WHEN (BDD.Is_OOP_Combined IS NULL ) THEN '' ELSE BDD.Is_OOP_Combined END) "
												+ "FROM SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON BSD.BR_Package_Display_Id=BDD.BR_Package_Display_Id "
												+ "WHERE BDD.BR_Package_Display_Id='" + br_pkg_display_id
												+ "' AND BDD.Network_Type_Code = '" + network
												+ "' AND  BDD.BR_Servicelevel_Display_Id= '" + serviceLevelID
												+ "'--AND  BDD.Network_Tier='" + network_tier + "'  ";
										
										ValidateMethods.validateDynamicFieldsWithDb((JSONObject) benefitSetObj,
												BenefitQuery, "Microsoft", json, db, ReportFilePath);

										if (accum_method.equalsIgnoreCase("Out of Pocket")) {
											acc_type = "L";
										} else if (accum_method.equalsIgnoreCase("Deductible")) {
											acc_type = "D";
										}
										if (displayType.equalsIgnoreCase("D")) {

											if (accumDesc.equalsIgnoreCase("Deductible")) {
												displayMaximumQuery = "SELECT MaximumValue = (CASE WHEN (BSDD.Facets_Dedutible_Bucket IS NOT NULL) THEN BSDD.Deductible_Value "
														+ "WHEN  (BSDD.Facets_OOP_Bucket IS NOT NULL) THEN  BSDD.OOP_value ELSE 0 END) , "
														+ "BucketNumberValue = (CASE WHEN BSDD.Facets_Dedutible_Bucket<>'' THEN BSDD.Facets_Dedutible_Bucket "
														+ "WHEN (BSDD.Facets_OOP_Bucket IS NOT NULL) THEN  BSDD.Facets_OOP_Bucket  else 0 END) "
														+ "FROM SS_SQL.Benefits_Service_Display_Details BSDD "
														+ "INNER JOIN SS_SQL.Benefit_Services_Display  BSD ON BSDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id "
														+ "WHERE BSDD.BR_Package_Display_Id = '" + br_pkg_display_id
														+ "' AND BSDD.Network_Type_Code='" + network
														+ "' AND BSDD.BR_Servicelevel_Display_Id = '" + serviceLevelID
														+ "' ";

											} else {
												displayMaximumQuery = "SELECT MaximumValue = (CASE WHEN (BSDD.Facets_OOP_Bucket IS NOT NULL) THEN  BSDD.OOP_value "
														+ "WHEN BSDD.Facets_Dedutible_Bucket<>'' THEN BSDD.Deductible_Value ELSE 0 END) , "
														+ "BucketNumberValue = (CASE WHEN (BSDD.Facets_OOP_Bucket IS NOT NULL) THEN  BSDD.Facets_OOP_Bucket "
														+ "WHEN BSDD.Facets_Dedutible_Bucket<>'' THEN BSDD.Facets_Dedutible_Bucket else 0 END) "
														+ "FROM SS_SQL.Benefits_Service_Display_Details BSDD "
														+ "INNER JOIN SS_SQL.Benefit_Services_Display  BSD ON BSDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id "
														+ "WHERE BSDD.BR_Package_Display_Id = '" + br_pkg_display_id
														+ "' AND BSDD.Network_Type_Code='" + network
														+ "' AND BSDD.BR_Servicelevel_Display_Id = '" + serviceLevelID
														+ "' ";
											}

											org.json.JSONArray dbdisplayMax = ViewClaimsDBS
													.getMemberInfofromDBS(displayMaximumQuery, "Microsoft");
											maxVal = dbdisplayMax.getJSONObject(0).getString("MaximumValue");
											
											bucketVal = dbdisplayMax.getJSONObject(0).getString("BucketNumberValue");
											
											maxim = Double.parseDouble(maxVal);
											displayMaxVal = formatter.format(maxim);
											maxVal = maxVal.replace(".00", ".0");

											if ((!maxVal.equalsIgnoreCase("0.0"))) {

												if (oop_accum_method.equalsIgnoreCase("IND")) {

													accuralQuery = "Select top 1 MATX.MATX_AMT1 as accural from CMC_SBSB_SUBSC SBSB "
															+ "inner join CMC_MEME_MEMBER MEME on SBSB.SBSB_CK= MEME.SBSB_CK "
															+ "inner join CMC_MATX_ACCUM_TXN MATX on MATX.MEME_CK=MEME.MEME_CK "
															+ "where MEME.MEME_CK = " + memeKey + " "
															+ "and MATX.PDPD_ACC_SFX='C001' AND MATX.MATX_ACC_TYPE = '"
															+ acc_type + "' and MATX.ACAC_ACC_NO = " + bucketVal
															+ "  and MATX_BEN_BEG_DT = '" + benefitStartDT2
															+ "' ORDER BY MATX_SEQ_NO DESC";

												} else if (oop_accum_method.equalsIgnoreCase("AGG")
														| oop_accum_method.equalsIgnoreCase("AGGO")
														| oop_accum_method.equalsIgnoreCase("INDO")) {

													accuralQuery = "Select top 1 FATX.FATX_AMT1 as accural from CMC_SBSB_SUBSC SBSB "
															+ "inner join CMC_MEME_MEMBER MEME on SBSB.SBSB_CK= MEME.SBSB_CK "
															+ "inner join CMC_FATX_ACCUM_TXN FATX on FATX.SBSB_CK= SBSB.SBSB_CK "
															+ "where MEME.MEME_CK = " + memeKey + "  "
															+ "and FATX.PDPD_ACC_SFX='C001' AND FATX.FATX_ACC_TYPE = '"
															+ acc_type + "' and FATX.ACAC_ACC_NO = " + bucketVal
															+ " and FATX_BEN_BEG_DT = '" + benefitStartDT2
															+ "'  ORDER BY FATX_SEQ_NO DESC ";

												}

												org.json.JSONArray dbaccuralDetails = ViewClaimsDBS
														.getMemberInfofromDBS(accuralQuery, "Sybase");
												if (dbaccuralDetails.length() > 0) {
													accural = (String) dbaccuralDetails.getJSONObject(0).get("accural");
													accuralval = Double.parseDouble(accural);
													accural = String.valueOf(accuralval);
													displayAccural = formatter.format(accuralval);

												} else {
													accural = "0.0";
													accuralval = 0;
													displayAccural = "$0.00";

												}
												DecimalFormat df = new DecimalFormat("#.##");
												df.setRoundingMode(RoundingMode.HALF_DOWN);

												remaining = Double.parseDouble(maxVal) - (accuralval);
												remain = String.valueOf(remaining);
												if (remain.length() > 6) {
													remain = df.format(remaining);
												}
												remaining = Double.parseDouble(remain);
												remain = String.valueOf(remaining);
												// displayRemaining = "$"+remaining;
												displayRemaining = formatter.format(remaining);
											} else if(!bucketVal.equalsIgnoreCase("0")){
												accural = "0.0";
												remaining = 0;
												remain = "0.0";
												displayAccural = "$0.00";
												displayMaxVal = "";
												displayRemaining = "$0.00";

											}
											else {
												accural = "0";
												remain = "0";
												displayAccural = "";
												displayMaxVal = "";
												displayRemaining = "";
											}
											if (displayRemaining.startsWith("-")) {
												remaining = 0;
												displayRemaining = "$0.00";
											}
											if (methodSize > 0 | coverageTier.equalsIgnoreCase("A")
													&& (!oop_accum_method.equalsIgnoreCase(""))) {
												if (oop_accum_method.equalsIgnoreCase("IND")
														| oop_accum_method.equalsIgnoreCase("INDO")
														&& accum_method.equalsIgnoreCase("Out of Pocket")) {
													ooprem1 = remaining;
													oopdisplayRemaining1 = formatter.format(ooprem1);
													oopactualmethod1 = oop_accum_method;
													actualMethod_oop1 = accum_method;

												} else if (oop_accum_method.equalsIgnoreCase("IND")
														| oop_accum_method.equalsIgnoreCase("INDO")
														&& accum_method.equalsIgnoreCase("Deductible")) {
													deductrem1 = remaining;
													deductdisplayRemaining1 = formatter.format(deductrem1);
													deductactualmethod1 = oop_accum_method;
													actualMethod_deduct1 = accum_method;
												} else if (oop_accum_method.equalsIgnoreCase("AGG")
														| oop_accum_method.equalsIgnoreCase("AGGO")
														&& accum_method.equalsIgnoreCase("Out of Pocket")) {
													ooprem2 = remaining;
													oopdisplayRemaining2 = formatter.format(ooprem2);
													oopactualmethod2 = oop_accum_method;
													actualMethod_oop2 = accum_method;
												} else if (oop_accum_method.equalsIgnoreCase("AGG")
														| oop_accum_method.equalsIgnoreCase("AGGO")
														&& accum_method.equalsIgnoreCase("Deductible")) {
													deductrem2 = remaining;
													deductdisplayRemaining2 = formatter.format(deductrem2);
													deductactualmethod2 = oop_accum_method;
													actualMethod_deduct2 = accum_method;

												}
											}

										} else if (displayType.equalsIgnoreCase("N")) {
											if (cover.equalsIgnoreCase("2 Person")) {
												max = "2.0";
											} else if (cover.equalsIgnoreCase("3 Person")) {
												max = "3.0";
											}
											if(max.equalsIgnoreCase("2.0")|| max.equalsIgnoreCase("3.0")) {
												displayMaximumQuery = "SELECT MaximumValue = '"+max+"', "
														+ " BucketNumberValue = (CASE WHEN (bsdd.Facets_OOP_Bucket IS NOT NULL) THEN bsdd.Facets_OOP_Bucket else 0 END)  "
														+ " FROM SS_SQL.Benefits_Service_Display_Details BSDD INNER JOIN "
														+ "  SS_SQL.Benefit_Services_Display  BSD ON BSDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id WHERE "
														+ "  BSDD.BR_Package_Display_Id = '" + br_pkg_display_id
														+ "' AND BSDD.Network_Type_Code='" + network
														+ "' AND BSDD.BR_Servicelevel_Display_Id = '" + serviceLevelID
														+ "' ";

											}
											else if (accum_method.equals("Deductible")) {
												displayMaximumQuery = "SELECT MaximumValue = BSDD.Deductible_Value, "
														+ " BucketNumberValue = (CASE WHEN (bsdd.Facets_Dedutible_Bucket IS NOT NULL) THEN bsdd.Facets_Dedutible_Bucket else 0 END) "
														+ " FROM SS_SQL.Benefits_Service_Display_Details BSDD INNER JOIN "
														+ "  SS_SQL.Benefit_Services_Display  BSD ON BSDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id WHERE "
														+ "  BSDD.BR_Package_Display_Id = '" + br_pkg_display_id
														+ "' AND BSDD.Network_Type_Code='" + network
														+ "' AND BSDD.BR_Servicelevel_Display_Id = '" + serviceLevelID
														+ "' ";
											}  
											else {
												displayMaximumQuery = "SELECT MaximumValue = BSDD.OOP_value, "
													+ " BucketNumberValue = (CASE WHEN (bsdd.Facets_OOP_Bucket IS NOT NULL) THEN bsdd.Facets_OOP_Bucket else 0 END)  "
													+ " FROM SS_SQL.Benefits_Service_Display_Details BSDD INNER JOIN "
													+ "  SS_SQL.Benefit_Services_Display  BSD ON BSDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id WHERE "
													+ "  BSDD.BR_Package_Display_Id = '" + br_pkg_display_id
													+ "' AND BSDD.Network_Type_Code='" + network
													+ "' AND BSDD.BR_Servicelevel_Display_Id = '" + serviceLevelID
													+ "' ";

										}
											org.json.JSONArray dbdisplayMax = ViewClaimsDBS
													.getMemberInfofromDBS(displayMaximumQuery, "Microsoft");
											maxVal = dbdisplayMax.getJSONObject(0).getString("MaximumValue");
											bucketVal = dbdisplayMax.getJSONObject(0).getString("BucketNumberValue");
											displayMaxVal = maxVal;
											if(!bucketVal.equalsIgnoreCase("0")) {
											if (oop_accum_method.equalsIgnoreCase("2PER")
													| oop_accum_method.equalsIgnoreCase("3PER")) {
												accuralQuery2 = "Select top 1 FATX.FATX_PERSON_CTR as accural from CMC_SBSB_SUBSC SBSB "
														+ "inner join CMC_MEME_MEMBER MEME on SBSB.SBSB_CK= MEME.SBSB_CK "
														+ "inner join CMC_FATX_ACCUM_TXN FATX on FATX.MEME_CK=MEME.MEME_CK "
														+ "where MEME.MEME_CK = " + memeKey + " "
														+ "and FATX.PDPD_ACC_SFX='C001' AND FATX.FATX_ACC_TYPE = '"
														+ acc_type + "' and FATX.ACAC_ACC_NO = " + bucketVal
														+ "  and FATX_BEN_BEG_DT = '" + benefitStartDT2
														+ "' ORDER BY FATX_SEQ_NO DESC";

											}
											org.json.JSONArray dbaccuralDetails2 = ViewClaimsDBS
													.getMemberInfofromDBS(accuralQuery2, "Sybase");
											if (dbaccuralDetails2.length() > 0) {
												accural = (String) dbaccuralDetails2.getJSONObject(0).get("accural");
												accuralval = Double.parseDouble(accural);
												displayAccural = accural;
												accural = String.valueOf(accuralval);
												
											}
											else {
												accural = "0.0";
												displayAccural = "0";

											}
											remaining = Double.parseDouble(maxVal) - Double.parseDouble(accural);
											remain = String.valueOf(remaining);
											displayRemaining = String.valueOf(remaining);
											displayRemaining = displayRemaining.replace(".0", "");
											// remain = displayRemaining;
											displayMaxVal = displayMaxVal.replace(".0", "");
											}
											else if(bucketVal.equalsIgnoreCase("0")) {
												maxVal ="0";
												accural = "0";
												remain = "0";
												displayAccural = "";
												displayMaxVal = "";
												displayRemaining = "";
											}
											else {
												accural = "0";
												displayAccural = "0";

											}
											
											if (methodSize > 0 | coverageTier.equalsIgnoreCase("A")
													&& (!oop_accum_method.equalsIgnoreCase(""))) {

												if (oop_accum_method.equalsIgnoreCase("2PER")
														| oop_accum_method.equalsIgnoreCase("3PER")
														&& accum_method.equalsIgnoreCase("Out of Pocket")) {
													ooprem2 = remaining;
													oopdisplayRemaining2 = formatter.format(ooprem2);
													oopactualmethod2 = oop_accum_method;
													actualMethod_oop2 = accum_method;
												} else if (oop_accum_method.equalsIgnoreCase("2PER")
														| oop_accum_method.equalsIgnoreCase("3PER")
														&& accum_method.equalsIgnoreCase("Deductible")) {
													deductrem2 = remaining;
													deductdisplayRemaining2 = formatter.format(deductrem2);
													deductactualmethod2 = oop_accum_method;
													actualMethod_deduct2 = accum_method;

												}
											}
										}

										
										Assert.done("Validating DisplaytypeOutputSet details");
										if (displayType.equalsIgnoreCase("")) {
											Assert.done("DisplayType outset details are not present");
										} else {
											if (displayType.equalsIgnoreCase("A")) {
												displayQuery = "SELECT DISTINCT BDD.Copay_Value,BDD.Copay_After_OOP_Value,BDD.Copay_Display AS COPAY_DISPLAY, BDD.Copay_After_OOP_Display AS Copay_After_OOP_Display, "
														+ "BDD.Coinsurance_Value AS Coinsurance_value,BDD.Coinsurance_Display AS Coinsurance_Display,BDD.Coinsurance_After_OOP_Value, BDD.Coinsurance_After_OOP_Display AS Coinsurance_After_OOP_Display  "
														+ "FROM SS_SQL.BENEFIT_SERVICES_DISPLAY BSD "
														+ "INNER JOIN SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD ON BDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id "
														+ "WHERE BDD.BR_Package_Display_Id='" + br_pkg_display_id
														+ "' AND BDD.Network_Type_Code = '" + network
														+ "' AND BDD.BR_Servicelevel_Display_Id= '" + serviceLevelID
														+ "' --AND BDD.Network_Tier ='" + network_tier + "'";
											} else if (displayType.equalsIgnoreCase("S")) {
												displayQuery = "SELECT DISTINCT BDD.Copay_Value as Copay_VALUE,BDD.Copay_After_OOP_Value as Copay_After_OOP_VALUE , "
														+ "BDD.Copay_After_OOP_Display AS Copay_After_OOP_Display,BDD.Coinsurance_Value as Coinsurance_value,BDD.Coinsurance_After_OOP_Value as "
														+ "Coinsurance_After_OOP_VALUE, BDD.Coinsurance_After_OOP_Display AS Coinsurance_After_OOP_Display,BDD.Deductible_Display "
														+ "AS DEDUCTIBLE_DISPLAY, BDD.TimePeriod_Ref_Id AS TimePeriod_REF_ID,BDD.Coinsurance_Display AS Coinsurance_Display,BDD.Pay_Before_Deductible AS PAY_BEFORE_DEDUCTIBLE,BDD.PAY_AFTER_DEDUCTIBLE, "
														+ "BDD.Deductible_Value , BDD.Deductible_Value_Display AS Deductible_Value_Display FROM "
														+ "SS_SQL.BENEFIT_SERVICES_DISPLAY BSD INNER JOIN SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD ON BDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id "
														+ "WHERE BDD.BR_Package_Display_Id='" + br_pkg_display_id
														+ "' AND BDD.Network_Type_Code = '" + network
														+ "' AND  BDD.BR_Servicelevel_Display_Id= '" + serviceLevelID
														+ "' --and BDD.Network_Tier ='" + network_tier + "' ";

											} else if (displayType.equalsIgnoreCase("D")) {
												if(accum_method.equalsIgnoreCase("Out of Pocket")) {
													displayMaxVal = "BDD.OOP_Display";
													bucketVal = "BDD.Facets_OOP_Bucket";
												}
												else {
													displayMaxVal = "BDD.Deductible_Value_Display";
													bucketVal = "BDD.Facets_Dedutible_Bucket";
												}
												if (accumulatorIndicator.equalsIgnoreCase("N")) {
													maxVal = maxVal.replace(".00", ".0");
													
													displayQuery = "SELECT DISTINCT Maximum = '" + maxVal + "', "
															+ "DisplayMaximum = "+displayMaxVal+" ,  "
															+ "Accrual = '0.0',Remaining = 0,DisplayAccrual = '',DisplayRemaining = '',Bucket_Number = "+bucketVal+" , "
															+ " LimitDescription = BSD.Ser_Limit_Description FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN "
															+ "SS_SQL.MEMBER_PLAN_ELIGIBILITY MPE ON MP.MEMBER_PROFILE_ID=MPE.MEMBER_PROFILE_ID INNER JOIN SS_SQL.MEMBER_PLAN_PACKAGES MPP "
															+ "ON MPE.MEMBER_PLAN_ID=MPP.MEMBER_PLAN_ID INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON MPP.BR_PACKAGE_ID=BSD.BR_Package_Id "
															+ "INNER JOIN SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD ON BDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id WHERE "
															+ "BDD.BR_Package_Display_Id='" + br_pkg_display_id
															+ "' AND BDD.Network_Type_Code = '" + network
															+ "' AND BDD.BR_Servicelevel_Display_Id= '" + serviceLevelID
															+ "' --and BDD.Network_Tier ='" + network_tier + "' ";
													
												} else {
													if (network.equalsIgnoreCase("Y")) {
														displayQuery = "SELECT DISTINCT Maximum = '" + maxVal + "', "
																+ "DisplayMaximum = "+displayMaxVal+", "
																+ " BucketNumber = " + bucketVal + ",  "
																+ "LimitDescription = BSD.Ser_Limit_Description,Accrual = "
																+ accural + ",Remaining = '" + remain
																+ "', DisplayAccrual = '" + displayAccural
																+ "',DisplayRemaining = '" + displayRemaining + "'  "
																+ "  FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN "
																+ "SS_SQL.MEMBER_PLAN_ELIGIBILITY MPE ON MP.MEMBER_PROFILE_ID=MPE.MEMBER_PROFILE_ID INNER JOIN SS_SQL.MEMBER_PLAN_PACKAGES MPP "
																+ "ON MPE.MEMBER_PLAN_ID=MPP.MEMBER_PLAN_ID INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON MPP.BR_PACKAGE_ID=BSD.BR_Package_Id "
																+ "INNER JOIN SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD ON BDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id WHERE "
																+ "BDD.BR_Package_Display_Id='" + br_pkg_display_id
																+ "' AND BDD.Network_Type_Code = '" + network
																+ "' AND BDD.BR_Servicelevel_Display_Id= '"
																+ serviceLevelID + "' --and BDD.Network_Tier ='"
																+ network_tier + "' ";
													} else {

														displayQuery = "SELECT DISTINCT Maximum = '" + maxVal + "', "
																+ "DisplayMaximum = "+displayMaxVal+", "
																+ " BucketNumber = " + bucketVal + ",  "
																+ "LimitDescription = BSD.Ser_Limit_Description,Accrual = '"+accural+"',Remaining = '"
																+ remain
																+ "', DisplayAccrual = '"+displayAccural+"',DisplayRemaining = '"
																+ displayRemaining + "'  "
																+ "  FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN "
																+ "SS_SQL.MEMBER_PLAN_ELIGIBILITY MPE ON MP.MEMBER_PROFILE_ID=MPE.MEMBER_PROFILE_ID INNER JOIN SS_SQL.MEMBER_PLAN_PACKAGES MPP "
																+ "ON MPE.MEMBER_PLAN_ID=MPP.MEMBER_PLAN_ID INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON MPP.BR_PACKAGE_ID=BSD.BR_Package_Id "
																+ "INNER JOIN SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD ON BDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id WHERE "
																+ "BDD.BR_Package_Display_Id='" + br_pkg_display_id
																+ "' AND BDD.Network_Type_Code = '" + network
																+ "' AND BDD.BR_Servicelevel_Display_Id= '"
																+ serviceLevelID + "' --and BDD.Network_Tier ='"
																+ network_tier + "' ";

													}
												}

											} else if (displayType.equalsIgnoreCase("N")) {
												if(accum_method.equalsIgnoreCase("Out of Pocket")) {
													//displayMaxVal = "BDD.OOP_Display";
													bucketVal = "BDD.Facets_OOP_Bucket";
												}
												else {
													//displayMaxVal = "BDD.Deductible_Value_Display";
													bucketVal = "BDD.Facets_Dedutible_Bucket";
												}
												//accural = accural +".0";
												displayQuery = "SELECT DISTINCT Maximum = '" + maxVal + "', "
														+ "DisplayMaximum = " + displayMaxVal + ",BucketNumber = "
														+ bucketVal + ",  "
														+ "LimitDescription = BSD.Ser_Limit_Description,Accrual = "
														+ accural + ",Remaining = '" + remain
														+ "', DisplayAccrual = '" + displayAccural
														+ "',DisplayRemaining = '" + displayRemaining + "'  "
														+ "  FROM SS_SQL.MEMBER_PROFILE MP INNER JOIN "
														+ "SS_SQL.MEMBER_PLAN_ELIGIBILITY MPE ON MP.MEMBER_PROFILE_ID=MPE.MEMBER_PROFILE_ID INNER JOIN SS_SQL.MEMBER_PLAN_PACKAGES MPP "
														+ "ON MPE.MEMBER_PLAN_ID=MPP.MEMBER_PLAN_ID INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD ON MPP.BR_PACKAGE_ID=BSD.BR_Package_Id "
														+ "INNER JOIN SS_SQL.BENEFITS_SERVICE_DISPLAY_DETAILS BDD ON BDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id WHERE "
														+ "BDD.BR_Package_Display_Id='" + br_pkg_display_id
														+ "' AND BDD.Network_Type_Code = '" + network
														+ "' AND BDD.BR_Servicelevel_Display_Id= '" + serviceLevelID
														+ "' --and BDD.Network_Tier ='" + network_tier + "' ";

											}

											ValidateMethods.validateDynamicFieldsWithDb(
													(JSONObject) benefitSetObj.get("DisplayTypeOutputSet"),
													displayQuery, "Microsoft", json, db, ReportFilePath);
											json = json + 2; // 1,3,5
											db = db + 2;
										}
									}

								}
							}

							Assert.done("Validating MetUnmet Details");
							if (accumulatorIndicator.equalsIgnoreCase("Y")) {

								Object metUnmet = covObj.get("MetUnmetDetails");
								JSONArray metUnmetArray = (JSONArray) parser.parse(metUnmet.toString());
								for (metunmet = 0; metunmet < metUnmetArray.size(); metunmet++) {
									if (!coverageTier.equalsIgnoreCase("I")) {
										if (metUnmetArray.size() > 1) {
											if (metunmet == 0) {
												if (deductactualmethod2.equalsIgnoreCase("AGGO")
														&& actualMethod_deduct2.equalsIgnoreCase("Deductible")) {
													remaining = deductrem2;
													displayRemaining = deductdisplayRemaining2;
													oop_method = deductactualmethod2;
													accum_method = actualMethod_deduct2;
												}

												else {

													if ((!deductactualmethod1.equalsIgnoreCase(""))
															| (!deductactualmethod2.equalsIgnoreCase(""))) {
														if (deductrem1 <= deductrem2) {
															remaining = deductrem1;
															displayRemaining = deductdisplayRemaining1;
															oop_method = deductactualmethod1;
															accum_method = actualMethod_deduct1;
														} else {
															remaining = deductrem2;
															displayRemaining = deductdisplayRemaining2;
															oop_method = deductactualmethod2;
															accum_method = actualMethod_deduct2;
														}
													}
												}
											} else if (metunmet == 1) {
												if (oopactualmethod2.equalsIgnoreCase("AGGO")
														&& (actualMethod_oop2.equalsIgnoreCase("Out of Pocket"))) {
													remaining = ooprem2;
													displayRemaining = oopdisplayRemaining2;
													oop_method = oopactualmethod2;
													accum_method = actualMethod_oop2;
												} else if ((!oopactualmethod1.equalsIgnoreCase(""))
														| (!oopactualmethod2.equalsIgnoreCase(""))) {
													if (ooprem1 <= ooprem2) {
														remaining = ooprem1;
														displayRemaining = oopdisplayRemaining1;
														oop_method = oopactualmethod1;
														accum_method = actualMethod_oop1;
													} else {
														remaining = ooprem2;
														displayRemaining = oopdisplayRemaining2;
														oop_method = oopactualmethod2;
														accum_method = actualMethod_oop2;
													}
												}
											}

											metUnmetObj = (JSONObject) metUnmetArray.get(metunmet);
										} else if ((!deductactualmethod1.equalsIgnoreCase(""))
												&& deductactualmethod2.equalsIgnoreCase("2PER")
														| deductactualmethod2.equalsIgnoreCase("3PER")) {
											remaining = deductrem1;
											displayRemaining = deductdisplayRemaining1;
											oop_method = deductactualmethod2;
											accum_method = actualMethod_deduct1;
										} else if ((!oopactualmethod2.equalsIgnoreCase(""))
												| (!oopactualmethod1.equalsIgnoreCase(""))) {
											if (ooprem2 <= ooprem1 && (!oopactualmethod2.equalsIgnoreCase(""))) {
												remaining = ooprem2;
												displayRemaining = oopdisplayRemaining2;
												oop_method = oopactualmethod2;
												accum_method = actualMethod_oop2;
											} else {
												remaining = ooprem1;
												displayRemaining = oopdisplayRemaining1;
												oop_method = oopactualmethod1;
												accum_method = actualMethod_oop1;
											}
										} else if ((!deductactualmethod2.equalsIgnoreCase(""))
												| (!deductactualmethod1.equalsIgnoreCase(""))) {
											if (deductrem1 <= deductrem2) {
												remaining = deductrem1;
												displayRemaining = deductdisplayRemaining1;
												oop_method = deductactualmethod1;
												accum_method = actualMethod_deduct1;
											} else {
												remaining = deductrem2;
												displayRemaining = deductdisplayRemaining2;
												oop_method = deductactualmethod2;
												accum_method = actualMethod_deduct2;
											}

										}

										metUnmetObj = (JSONObject) metUnmetArray.get(metunmet);

									} else if (coverageTier.equalsIgnoreCase("I")) {
										if (deductactualmethod1.equalsIgnoreCase("IND")
												| deductactualmethod1.equalsIgnoreCase("INDO")
												&& actualMethod_deduct1.equalsIgnoreCase("Deductible")
												&& (metunmet == 0)) {
											remaining = deductrem1;
											displayRemaining = deductdisplayRemaining1;
											oop_method = deductactualmethod1;
											accum_method = actualMethod_deduct1;
										}

										else {
											remaining = ooprem1;
											displayRemaining = oopdisplayRemaining1;
											oop_method = oopactualmethod1;
											accum_method = actualMethod_oop1;
										}
										metUnmetObj = (JSONObject) metUnmetArray.get(metunmet);

									}

									/*
									 * else if(coverageTier.equalsIgnoreCase("F")) {
									 * 
									 * 
									 * if((!deductactualmethod1.equalsIgnoreCase("")) &&
									 * (!deductactualmethod2.equalsIgnoreCase(""))) { if(deductrem1 <= deductrem2) {
									 * remaining = deductrem1; displayRemaining = deductdisplayRemaining1;
									 * oop_method = deductactualmethod1; accum_method = actualMethod_deduct1; } else
									 * { remaining = deductrem2; displayRemaining = deductdisplayRemaining2;
									 * oop_method = deductactualmethod2; accum_method = actualMethod_deduct2; } }
									 * else if((!oopactualmethod1.equalsIgnoreCase("")) &&
									 * (!oopactualmethod2.equalsIgnoreCase(""))){ if(ooprem2 <=ooprem1) { remaining
									 * = ooprem2; displayRemaining = oopdisplayRemaining2; oop_method =
									 * oopactualmethod2; accum_method = actualMethod_oop2; } else {
									 * 
									 * remaining = ooprem1; displayRemaining = oopdisplayRemaining1; oop_method =
									 * oopactualmethod1; accum_method = actualMethod_oop1; } }
									 * 
									 * metUnmetObj = (JSONObject) metUnmetArray.get(metunmet);
									 * 
									 * }
									 */

									else {
										accum_method = actualmethod;
										metUnmetObj = (JSONObject) metUnmetArray.get(metunmet);
									}
									if (metUnmetObj.containsKey("AccumulatorType")) {
										if (remaining != 0) {
											metUnmetIndicator = "No";
											if (oop_method.equalsIgnoreCase("IND")
													| oop_method.equalsIgnoreCase("INDO")) {
												if (accum_method.equalsIgnoreCase("Deductible")) {
													message = "You have " + displayRemaining
															+ " remaining before meeting your " + network_tier
															+ " individual deductible.";
												} else if (accum_method.equalsIgnoreCase("Out of Pocket")) {
													message = "You have " + displayRemaining
															+ " remaining before meeting your " + network_tier
															+ " individual out-of-pocket maximum.";
												}
											} else if (oop_method.equalsIgnoreCase("AGG")
													| oop_method.equalsIgnoreCase("AGGO")) {
												if (accum_method.equalsIgnoreCase("Deductible")) {
													message = "Your family has " + displayRemaining
															+ " remaining before meeting your " + network_tier
															+ " family deductible.";
												} else if (accum_method.equalsIgnoreCase("Out of Pocket")) {
													message = "Your family has " + displayRemaining
															+ " remaining before meeting your " + network_tier
															+ " family out-of-pocket maximum.";
												}
											} else if (oop_method.equalsIgnoreCase("2PER")
													| oop_method.equalsIgnoreCase("3PER")) {
												if (accum_method.equalsIgnoreCase("Deductible")) {
													message = "You have " + displayRemaining + " remaining and "
															+ remain
															+ " family member(s) need to meet their deductible before meeting your  family deductible.";
												}
											}
										} else {
											metUnmetIndicator = "Yes";
											if (oop_method.equalsIgnoreCase("IND")
													| oop_method.equalsIgnoreCase("INDO")) {
												if (accum_method.equalsIgnoreCase("Deductible")) {
													message = "You have met your " + network_tier
															+ " individual deductible.";
												} else if (accum_method.equalsIgnoreCase("Out of Pocket")) {
													message = "You have met your " + network_tier
															+ " individual out-of-pocket maximum.";
												}
											} else {
												if (oop_method.equalsIgnoreCase("AGG")
														| oop_method.equalsIgnoreCase("AGGO")) {
													if (accum_method.equalsIgnoreCase("Deductible")) {
														message = "Your " + network_tier
																+ " family deductible has been met.";
													} else if (accum_method.equalsIgnoreCase("Out of Pocket")) {
														message = "Your " + network_tier
																+ " family out-of-pocket maximum has been met.";
													}

												}
											}
										}

										metUnmetQuery = "SELECT AccumulatorType = '" + accum_method
												+ "',Met_Unmet_Indicator ='" + metUnmetIndicator + "', "
												+ "Met_Unmet_Message = '" + message
												+ "' FROM SS_SQL.Benefits_Service_Display_Details BSDD "
												+ "INNER JOIN SS_SQL.Benefit_Services_Display  BSD ON BSDD.BR_Package_Display_Id=BSD.BR_Package_Display_Id "
												+ "WHERE BSDD.BR_Package_Display_Id ='" + br_pkg_display_id
												+ "' AND BSDD.Network_Type_Code='" + network
												+ "' AND BSDD.BR_Servicelevel_Display_Id='" + serviceLevelID + "' ";

										ValidateMethods.validateDynamicFieldsWithDb((JSONObject) metUnmetObj,
												metUnmetQuery, "Microsoft", benefitRow, benefitCol, ReportFilePath);

										benefitRow = benefitRow + 2; // 1,3,5
										benefitCol = benefitCol + 2;
									} else {
										Assert.done("No UnmetDetails are present");
									}
								}
							} else {
								Assert.done("No UnmetDetails are present");
							}
						}

					}
				}

			} catch (Exception e) {
				e.printStackTrace();
				Assert.fail("Invalid Methodology");
			}
		} else {
			Assert.done("Test Case ID : " + testID);
			Assert.done("Test Description " + testDesc);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg").trim();
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {

					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
				Assert.fail(content);
			}
		}
	}

	/**
	 * Validate only the static fields
	 * 
	 * @param ClaimObj
	 *            = JSON Object
	 * @param strQuery
	 *            = DB Query
	 * @throws SQLException
	 * @throws IOException
	 */
	public static void validatingStaticFieldsWithDb(JSONObject ClaimObj, String strQuery, String DB, int json, int db,
			String ReportFilePath) throws SQLException, IOException {
		// String QueryDB =

		Map<String, Object> responseData = UtilMethod.readJsonData(ClaimObj);
		org.json.JSONArray dbData = ViewClaimsDBS.getMemberInfofromDBS(strQuery, DB);
		Set<String> keys = responseData.keySet();
		for (String key : keys) {
			if (responseData.get(key) != null) {
				UtilMethod.setCellData(key, responseData.get(key), json, ReportFilePath);
			}
			org.json.JSONObject elements = dbData.getJSONObject(0);
			if (elements.has(key)) {
				if (elements.isNull(key)) {
					System.out.println("Null value");
				} else if (elements.getString(key) != null) {
					UtilMethod.setCellData(key, elements.getString(key), db, ReportFilePath);
				}
			}
		}

	}

	/**
	 * 
	 * @param ClaimObj
	 *            = JSON Object
	 * @param strArrayName
	 *            = JSON ArrayName
	 * @param strQuery
	 *            = DB Query
	 * @param strUniqueColName
	 *            = Unique Column name
	 * @param DB
	 *            = DB name
	 * @param ReportFilePath
	 *            = Excel report path
	 * @throws Exception
	 */

	public static void validatingJsonArrayDataWithDb(JSONObject ClaimObj, String strArrayName, String strQuery,
			String[] strUniqueColName, String DB, String ReportFilePath) throws Exception {
		JSONArray responseClaimLineDetails = (JSONArray) ClaimObj.get(strArrayName);
		org.json.JSONArray dbClaimLineDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, DB);

		if (responseClaimLineDetails.size() == dbClaimLineDetails.length()) {

			Map<String, Object> strCLaimDetailsRes = null;
			JSONObject response = null;
			Map<String, Object> db_data = null;
			org.json.JSONObject db_response = null;

			boolean errorflag = false;
			boolean validateflag = true;

			// Comparing Response data with db row
			for (int j = 0; j < responseClaimLineDetails.size(); j++) {
				int k = j * 2 + 1;
				int l = j * 2 + 2;
				response = (JSONObject) responseClaimLineDetails.get(j);
				strCLaimDetailsRes = UtilMethod.readJsonData(response);
				Assert.done("Validating " + j + " row DB values with response");
				for (int i = 0; i < dbClaimLineDetails.length(); i++) {
					db_response = (org.json.JSONObject) dbClaimLineDetails.get(i);
					db_data = UtilMethod.readJsonData(db_response);

					if (strCLaimDetailsRes.get(strUniqueColName[0]).toString()
							.equalsIgnoreCase(db_data.get(strUniqueColName[0]).toString())
							|| strCLaimDetailsRes.get(strUniqueColName[1]).toString()
									.equalsIgnoreCase(db_data.get(strUniqueColName[1]).toString())) {
						break;
					}
				}
				Set<String> jsonKeys = strCLaimDetailsRes.keySet();
				for (String tagname : jsonKeys) {
					Object Value = strCLaimDetailsRes.get(tagname);
					UtilMethod.setCellData(tagname, Value, k, ReportFilePath);

					Map<String, Object> map = db_data;
					if (map.containsKey(tagname)) {
						if (Value != null) {
							String value = Value.toString().trim();
							if (value.length() >= 2 && value.charAt(value.length() - 2) == '.'
									&& value.charAt(value.length() - 1) == '0') {
								value = value.concat("0");
							}
						}
						UtilMethod.setCellData(tagname, Value, l, ReportFilePath);

					}
				}
			}

		} else {
			throw new Exception(
					"Cannot validate claim line details with db as size is not matching.. please check the query you are passing...");
		}

	}

	/**
	 * 
	 * @param ClaimObj
	 *            = JSON Object
	 * @param strArrayName
	 *            = JSON Array name
	 * @param strQuery
	 *            = DB query
	 * @param strUniqueColName
	 *            = Unique Column name
	 * @param DB
	 *            = DB name
	 * @param k
	 *            = row number
	 * @param l
	 *            = column number
	 * @param ReportFilePath
	 *            = Excel report path
	 * @throws Exception
	 */

	public static void validatingMessageDataWithDb(JSONObject ClaimObj, String strArrayName, String strQuery,
			String[] strUniqueColName, String DB, int k, int l, String ReportFilePath) throws Exception {
		JSONArray responseClaimLineDetails = (JSONArray) ClaimObj.get(strArrayName);
		org.json.JSONArray dbClaimLineDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, DB);

		if (responseClaimLineDetails.size() == dbClaimLineDetails.length()) {

			Map<String, Object> strCLaimDetailsRes = null;
			JSONObject response = null;
			Map<String, Object> db_data = null;
			org.json.JSONObject db_response = null;

			boolean errorflag = false;
			boolean validateflag = true;

			// Comparing Response data with db row
			for (int j = 0; j < responseClaimLineDetails.size(); j++) {

				response = (JSONObject) responseClaimLineDetails.get(j);
				strCLaimDetailsRes = UtilMethod.readJsonData(response);
				Assert.done("Validating " + j + " row DB values with response");
				for (int i = 0; i < dbClaimLineDetails.length(); i++) {
					db_response = (org.json.JSONObject) dbClaimLineDetails.get(i);
					db_data = UtilMethod.readJsonData(db_response);

					if (strCLaimDetailsRes.get(strUniqueColName[0]).toString()
							.equalsIgnoreCase(db_data.get(strUniqueColName[0]).toString())
							&& strCLaimDetailsRes.get(strUniqueColName[1]).toString()
									.equalsIgnoreCase(db_data.get(strUniqueColName[1]).toString())) {
						break;
					}
				}
				Set<String> jsonKeys = strCLaimDetailsRes.keySet();
				for (String tagname : jsonKeys) {
					Object Value = strCLaimDetailsRes.get(tagname);
					UtilMethod.setCellData(tagname, Value, k, ReportFilePath);

					Map<String, Object> map = db_data;
					if (map.containsKey(tagname)) {
						if (Value != null) {
							String value = Value.toString().trim();
							if (value.length() >= 2 && value.charAt(value.length() - 2) == '.'
									&& value.charAt(value.length() - 1) == '0') {
								value = value.concat("0");
							}
						}
						UtilMethod.setCellData(tagname, Value, l, ReportFilePath);

					}
				}
				k = k + 2;
				l = l + 2;
			}
		} else {
			throw new Exception(
					"Cannot validate claim line details with db as size is not matching.. please check the query you are passing...");
		}

	}

	/**
	 * 
	 * @param content
	 *            =JSON Response
	 * @param testID
	 *            = TestCase ID
	 * @throws Exception
	 */

	public static void validateGetBenefitsList(String content, String testID, String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		//String testdir = Environment.get("Benefits_Base_Dir"); 
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";  
		DataTable1 Dttestdata = new DataTable1(testdir + "GetBenefitsList.xls", "GetBenefitsList", "" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String ReportFilePath = "";
		if(Environment.get("Jenkins_Run").equalsIgnoreCase("Yes")) {
		String excelName = Environment.get("GetBenefitsList_XML");		
		String excelReportName = excelName.replace(".xml", ".xslx");
		 ReportFilePath = Environment.get("report_path")+"//"+excelReportName;
		}
		else {
		 ReportFilePath = Environment.get("BenefitsList_ExcelReport_Path");
		}
		//String ReportFilePath = Environment.get("BenefitsList_ExcelReport_Path");
		String testDesc = Dttestdata.getValue("Test_Description");
		if (content.contains("errorCode")) {
			errorflag = false;
		} else {
			validateflag = true;
		}
		if (validateflag) {
			Object obj = jsonparser.parse(content);
			JSONObject benefitObj = (JSONObject) obj;

			String inputtestID = Dttestdata.getValue("TestID");
			String memeCK = Dttestdata.getValue("MemberContrivedKey");
			String subscriberID = Dttestdata.getValue("SubscriberID");
			String dependentID = Dttestdata.getValue("DependentID");
			String productID = Dttestdata.getValue("ProductID");
			String viewAsDate = Dttestdata.getValue("ViewAsDate");
			String categoryID = Dttestdata.getValue("CategoryID");
			String listIndicator = Dttestdata.getValue("ListIndicator");
			String staticQuery = "";
			String memCKQuery = "";
			String dynamicQuery = "";

			try {
				Assert.done("Test ID: " + inputtestID);
				Assert.done("Test Description: " + testDesc);
				DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
				if (viewAsDate.equals("")) {

					Date date = new Date();
					viewAsDate = dateFormat.format(date);
				}
				memCKQuery = "SELECT LEGACY_MEME_CK FROM SS_SQL.MEMBER_PROFILE WHERE (SUBSCRIBER_ID = '" + subscriberID
						+ "' AND DEPENDENT_ID='" + dependentID + "') OR LEGACY_MEME_CK = '" + memeCK + "'";
				org.json.JSONArray dbSubscriberDetails = ViewClaimsDBS.getMemberInfofromDBS(memCKQuery, "Microsoft");
				memeCK = dbSubscriberDetails.getJSONObject(0).getString("LEGACY_MEME_CK");

				Assert.done("Validating Static fields");

				staticQuery = "SELECT SUBSCRIBER_ID AS SubscriberID, DEPENDENT_ID AS DependentID, "
						+ "LEGACY_MEME_CK AS MemberContrivedKey, ProductID = '" + productID + "', " + "CONVERT(DATE,'"
						+ viewAsDate + "') AS ViewAsDate " + " FROM SS_SQL.MEMBER_PROFILE MP "
						+ " INNER JOIN SS_SQL.MEMBER_PLAN_ELIGIBILITY MPE "
						+ " ON MPE.MEMBER_PROFILE_ID=MP.MEMBER_PROFILE_ID " + " WHERE LEGACY_MEME_CK = '" + memeCK
						+ "' AND '" + viewAsDate + "' "
						+ " BETWEEN MPE.BENEFIT_START_DATE AND MPE.BENEFIT_END_DATE ORDER BY MPE.BENEFIT_ID";

				ValidateMethods.validateStaticFieldsWithDb(benefitObj, staticQuery, "Microsoft", ReportFilePath);

				Assert.done("Validating the ServiceListResponse details");
				if (!categoryID.equalsIgnoreCase("")) {
					dynamicQuery = "SELECT DISTINCT MPE.PLAN_ID,BCR.CATEGORY_REF_ID AS CategoryID, BSD.SERVICE_REF_ID AS ReferenceID, BSD.SERVICE_DISPLAY_NAME AS ServiceName, BSD.BR_Package_Display_Id AS BR_Package_Display_ID "
							+ "FROM SS_SQL.MEMBER_PLAN_ELIGIBILITY MPE, SS_SQL.MEMBER_PROFILE MP,"
							+ "SS_SQL.MEMBER_PLAN_PACKAGES MPP, SS_SQL.PRODUCTS_REF PR, "
							+ "SS_SQL.BR_CATEGORY_SERVICE_XREF BCSX, SS_SQL.BR_SERVICE_REF BSR,"
							+ "SS_SQL.BENEFIT_SERVICES_DISPLAY BSD, SS_SQL.BR_CATEGORY_REF BCR " + "WHERE "
							+ "MPE.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID "
							+ "AND MPE.MEMBER_PLAN_ID =  MPP.MEMBER_PLAN_ID "
							+ "AND MPP.LEGACY_PRODUCT_ID = PR.PDPD_ID " + "AND MPP.BR_PACKAGE_ID = BSD.BR_PACKAGE_ID "
							+ "AND BCSX.SERVICE_REF_ID = BSR.SERVICE_REF_ID "
							+ "AND BCSX.SERVICE_REF_ID = BSD.SERVICE_REF_ID "
							+ "AND BCSX.CATEGORY_REF_ID = BCR.CATEGORY_REF_ID " + "AND MP.LEGACY_MEME_CK = '" + memeCK
							+ "' " + "AND '" + viewAsDate + "' BETWEEN MPE.BENEFIT_START_DATE AND MPE.BENEFIT_END_DATE "
							+ "AND '" + viewAsDate + "' BETWEEN BSD.EFFECTIVE_DATE AND BSD.TERM_DATE "
							+ "AND BCR.CATEGORY_REF_ID = '" + categoryID + "' AND PR.PDPD_ID = '" + productID + "'"
							+ "AND BSR.INTERNAL_FLAG != 'YES' ORDER BY BSD.SERVICE_DISPLAY_NAME ";

				} else if (listIndicator.equalsIgnoreCase("Y")) {
					dynamicQuery = "SELECT DISTINCT MPE.PLAN_ID,CategoryID = (CASE WHEN (BCR.CATEGORY_REF_ID IS NULL ) THEN '' ELSE BCR.CATEGORY_REF_ID END ), "
							+ "BSD.SERVICE_REF_ID AS ReferenceID, BSD.SERVICE_DISPLAY_NAME AS ServiceName, BSD.BR_Package_Display_Id AS BR_Package_Display_ID "
							+ "FROM " + "SS_SQL.MEMBER_PLAN_ELIGIBILITY MPE " + "INNER JOIN SS_SQL.MEMBER_PROFILE MP "
							+ "ON MPE.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID "
							+ "INNER JOIN SS_SQL.MEMBER_PLAN_PACKAGES MPP "
							+ "ON MPE.MEMBER_PLAN_ID =  MPP.MEMBER_PLAN_ID INNER JOIN SS_SQL.PRODUCTS_REF PR "
							+ "ON MPP.LEGACY_PRODUCT_ID = PR.PDPD_ID "
							+ "INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD "
							+ "ON MPP.BR_PACKAGE_ID = BSD.BR_PACKAGE_ID " + "INNER JOIN SS_SQL.BR_SERVICE_REF BSR "
							+ "ON BSD.SERVICE_REF_ID = BSR.SERVICE_REF_ID "
							+ "LEFT JOIN SS_SQL.BR_CATEGORY_SERVICE_XREF BCSX "
							+ "ON BSR.SERVICE_REF_ID = BCSX.SERVICE_REF_ID " + "LEFT JOIN SS_SQL.BR_CATEGORY_REF BCR "
							+ "ON BCSX.CATEGORY_REF_ID = BCR.CATEGORY_REF_ID " + "WHERE MP.LEGACY_MEME_CK = '" + memeCK
							+ "' " + "AND '" + viewAsDate + "' BETWEEN "
							+ "MPE.BENEFIT_START_DATE AND MPE.BENEFIT_END_DATE " + "AND PR.PDPD_ID = '" + productID
							+ "' " + "AND '" + viewAsDate + "' BETWEEN " + "BSD.EFFECTIVE_DATE AND BSD.TERM_DATE "
							+ "AND BSR.INTERNAL_FLAG != 'YES' " + "ORDER BY BSD.SERVICE_DISPLAY_NAME";

				} else if (listIndicator.equalsIgnoreCase("L")) {
					dynamicQuery = "SELECT DISTINCT MPE.PLAN_ID,CategoryID = (CASE WHEN (BCR.CATEGORY_REF_ID IS NULL ) THEN '' ELSE BCR.CATEGORY_REF_ID END ), \r\n"
							+ "BSD.SERVICE_REF_ID AS ReferenceID, BSD.SERVICE_DISPLAY_NAME AS ServiceName, BSD.BR_Package_Display_Id AS BR_Package_Display_ID \r\n"
							+ "FROM SS_SQL.MEMBER_PLAN_ELIGIBILITY MPE " + "INNER JOIN SS_SQL.MEMBER_PROFILE MP "
							+ "ON MPE.MEMBER_PROFILE_ID = MP.MEMBER_PROFILE_ID "
							+ "INNER JOIN SS_SQL.MEMBER_PLAN_PACKAGES MPP "
							+ "ON MPE.MEMBER_PLAN_ID =  MPP.MEMBER_PLAN_ID  INNER JOIN SS_SQL.PRODUCTS_REF PR "
							+ "ON MPP.LEGACY_PRODUCT_ID = PR.PDPD_ID "
							+ "INNER JOIN SS_SQL.BENEFIT_SERVICES_DISPLAY BSD "
							+ "ON MPP.BR_PACKAGE_ID = BSD.BR_PACKAGE_ID " + "INNER JOIN SS_SQL.BR_SERVICE_REF BSR "
							+ "ON BSD.SERVICE_REF_ID = BSR.SERVICE_REF_ID "
							+ "LEFT JOIN SS_SQL.BR_CATEGORY_SERVICE_XREF BCSX "
							+ "ON BSR.SERVICE_REF_ID = BCSX.SERVICE_REF_ID " + "LEFT JOIN SS_SQL.BR_CATEGORY_REF BCR "
							+ "ON BCSX.CATEGORY_REF_ID = BCR.CATEGORY_REF_ID " + "WHERE MP.LEGACY_MEME_CK = '" + memeCK
							+ "' " + "AND '" + viewAsDate + "' BETWEEN "
							+ "MPE.BENEFIT_START_DATE AND MPE.BENEFIT_END_DATE " + "AND PR.PDPD_ID = '" + productID
							+ "' " + "AND '" + viewAsDate + "' BETWEEN " + "BSD.EFFECTIVE_DATE AND BSD.TERM_DATE "
							+ "AND BSR.INTERNAL_FLAG != 'YES' AND BSD.SERVICE_REF_ID NOT IN "
							+ "(SELECT DISTINCT BC.FIELD_SERVICE_VALUE FROM  SS_SQL.BENEFIT_CONFIG BC "
							+ "INNER JOIN SS_SQL.MEMBER_PLAN_PACKAGES MPP " + "ON MPP.PRODUCT_TYPE = BC.FIELD_TYPE "
							+ "WHERE MPP.LEGACY_PRODUCT_ID = '" + productID + "' ) "
							+ "ORDER BY BSD.SERVICE_DISPLAY_NAME";
				}

				String serviceDetails = "serviceListResponse";
				String[] UniqueColumn = { "CategoryID", "ServiceName" };

				ValidateMethods.validateJsonArrayDataWithDb1(benefitObj, serviceDetails, dynamicQuery, UniqueColumn,
						"Microsoft", ReportFilePath);

			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Assert.done("Test ID: " + testID);
			Assert.done("Test Description: " + testDesc);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg");
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {

					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
			}
		}
	}

	/**
	 * 
	 * @param ClaimObj
	 *            = JSON Object
	 * @param strArrayName
	 *            = JSON Arrayname
	 * @param strQuery
	 *            = DB query
	 * @param strUniqueColName
	 *            = Unique column name
	 * @param DB
	 *            = DB name
	 * @param k
	 *            = row number
	 * @param l
	 *            = column number
	 * @param ReportFilePath
	 *            = Excel report path
	 * @throws Exception
	 */

	public static void validateDynamicJsonArrayDataWithDb(JSONObject ClaimObj, String strArrayName, String strQuery,
			String[] strUniqueColName, String DB, int k, int l, String ReportFilePath) throws Exception {
		JSONArray responseClaimLineDetails = (JSONArray) ClaimObj.get(strArrayName);
		org.json.JSONArray dbClaimLineDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, DB);
		try {
			if (responseClaimLineDetails.size() == dbClaimLineDetails.length()) {

				Map<String, Object> strCLaimDetailsRes = null;
				JSONObject response = null;
				Map<String, Object> db_data = null;
				org.json.JSONObject db_response = null;

				boolean errorflag = false;
				boolean validateflag = true;

				// Comparing Response data with db row
				for (int j = 0; j < responseClaimLineDetails.size(); j++) {

					response = (JSONObject) responseClaimLineDetails.get(j);
					strCLaimDetailsRes = UtilMethod.readJsonData(response);
					Assert.done("Validating " + j + " row DB values with response");
					for (int i = 0; i < dbClaimLineDetails.length(); i++) {
						db_response = (org.json.JSONObject) dbClaimLineDetails.get(i);
						db_data = UtilMethod.readJsonData(db_response);
						// for (int x=0; x<strUniqueColName.length ;x++) {

						if (strCLaimDetailsRes.get(strUniqueColName[0]).toString()
								.equalsIgnoreCase(db_data.get(strUniqueColName[0]).toString())
								|| strCLaimDetailsRes.get(strUniqueColName[1]).toString()
										.equalsIgnoreCase(db_data.get(strUniqueColName[1]).toString())) {
							break;
						}
					}
					Set<String> jsonKeys = strCLaimDetailsRes.keySet();
					for (String tagname : jsonKeys) {
						Object Value = strCLaimDetailsRes.get(tagname);
						UtilMethod.setCellData(tagname, Value, k, ReportFilePath);

						UtilMethod.validateJSONObject(db_data, tagname, Value, l, ReportFilePath);

					}
					k = k + 2;
					l = l + 2;
				}

			} else {
				UtilMethod.Log(
						"Cannot validate as the Json response claim line details record size is not matching with DB response claim line details records.. please check the query you are passing",
						"FAIL", true);
			}
		} catch (Exception e) {

			Assert.fail(
					"Cannot validate claim line details with db as size is not matching.. please check the query you are passing...");
		}

	}

	/**
	 * 
	 * @param ClaimObj
	 *            = JSON Object
	 * @param strQuery
	 *            = DB query
	 * @param DB
	 *            = DB name
	 * @param json
	 *            = row number
	 * @param db
	 *            = column number
	 * @param ReportFilePath
	 *            = Excel report path
	 * @throws SQLException
	 * @throws IOException
	 */
	public static void validateDynamicFieldsWithDb(JSONObject ClaimObj, String strQuery, String DB, int json, int db,
			String ReportFilePath) throws SQLException, IOException {
		// String QueryDB =
		Map<String, Object> responseData = UtilMethod.readJsonData(ClaimObj);
		org.json.JSONArray dbData = ViewClaimsDBS.getMemberInfofromDBS(strQuery, DB);
		Set<String> keys = responseData.keySet();
		for (String key : keys) {
			org.json.JSONObject elements = dbData.getJSONObject(0);
			if (elements.has(key)) {
				if (elements.isNull(key)) {
					Assert.pass(key + " tag with DB  is having null value");
				} else {
					UtilMethod.setCellData(key, responseData.get(key), json, ReportFilePath);
					UtilMethod.validateDynamicTag(dbData, key, responseData.get(key), db, ReportFilePath);
				}
			}

		}
	}

	/**
	 * This method is used to validate the JSON data and DB data of GetAcculumator service
	 * 
	 * @param content = JSON response data
	 * @param testID = TestCase ID
	 * @throws Exception
	 */

	public static void validateGetAccumulator(String content, String testID,String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";  
		DataTable1 Dttestdata = new DataTable1(testdir + "GetAccumulator.xls", "GetAccumulator_Input", "" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String ReportFilePath = "";
		if(Environment.get("Jenkins_Run").equalsIgnoreCase("Yes")){
		String excelName = Environment.get("GetAccumulator_XML");		
		String excelReportName = excelName.replace(".xml", ".xslx");
		ReportFilePath = Environment.get("report_path")+"//"+excelReportName;
		}
		else {
			ReportFilePath = Environment.get("GetAccumulator_excel_path");
		}
		if (content.contains("ErrorCode")) {
			errorflag = false;
		} else {
			validateflag = true;
		}
		if (validateflag) {
			Object obj = jsonparser.parse(content);
			JSONObject ClaimObj = (JSONObject) obj;
			String service = "Accumulator";
			String inputtestID = Dttestdata.getValue("TestID");
			String testDesc = Dttestdata.getValue("Test_Description");
			String userId = Dttestdata.getValue("UserId");
			String subscriberContrivedKey = Dttestdata.getValue("SubscriberContrivedKey");
			String memberContrivedKey = Dttestdata.getValue("MemberContrivedKey");
			String productAccumulatorSuffix = Dttestdata.getValue("ProductAccumulatorSuffix");
			String benefitBeginDate = Dttestdata.getValue("BenefitBeginDate");
			String carryoverBenefitBeginDate = Dttestdata.getValue("CarryoverBenefitBeginDate");
			String showSensitivityIndicator = Dttestdata.getValue("ShowSensitivityIndicator");
			String benefitIdentifier = Dttestdata.getValue("BenefitIdentifier");
			String accumulatorType = Dttestdata.getValue("AccumulatorType");
			String accumulatorMethodology = Dttestdata.getValue("AccumulatorMethodology");
			String carryoverApplicableIndicator = Dttestdata.getValue("CarryoverApplicableIndicator");
			String isSensitiveIndicator = Dttestdata.getValue("IsSensitiveIndicator");
			String familyComposition = Dttestdata.getValue("FamilyComposition");
			String network = Dttestdata.getValue("Network");
			String tier = Dttestdata.getValue("Tier");
			String bucketNumber = Dttestdata.getValue("BucketNumber");
			String maximum = Dttestdata.getValue("Maximum");
			String accrual = Dttestdata.getValue("Accrual");
			float remaining ;
			String remaining1 = null ;
			String displayMaximum = null ;
			String displayAccrual = null;
			String displayRemaining1 = null;
			String limitDescription = Dttestdata.getValue("LimitDescription");
			String errorMessage = Dttestdata.getValue("ErrorMessage");
			String strQuery = "";
			String strQuery1 = "";
			String strQuery2 = "";
			String AccumulatorInformationQuery = "";
			try {
				Assert.done("Test ID: " + inputtestID);
				Assert.done("Test Description: " + testDesc);
                 
				if ((accumulatorMethodology.equalsIgnoreCase("IND"))) {
					
				strQuery ="SELECT top 1 PDPD_ACC_SFX AS ProductAccumulatorSuffix  FROM CMC_MATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+"";
				strQuery1 ="SELECT Top 1 MATX_AMT1  FROM CMC_MATX_ACCUM_TXN "
						+ "WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' "
						+ "AND ACAC_ACC_NO = "+bucketNumber+" AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"' "
						+ "AND MEME_CK = "+memberContrivedKey+" ORDER BY MATX_SEQ_NO DESC";
				
				org.json.JSONArray dbSubscriberDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery1, "Sybase");
				if(dbSubscriberDetails.length()>0) {
				accrual = dbSubscriberDetails.getJSONObject(0).getString("MATX_AMT1");
				}
				else
				{
					accrual="0.0";
				}
		if (carryoverApplicableIndicator.equalsIgnoreCase("Y")){
			
			strQuery2 ="SELECT Top 1  MATX_AMT2 FROM CMC_MATX_ACCUM_TXN "
					+ "WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' "
					+ "AND ACAC_ACC_NO = "+bucketNumber+" AND MATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"' "
					+ "AND MEME_CK = "+memberContrivedKey+" ORDER BY MATX_SEQ_NO DESC";	
		org.json.JSONArray dbSubscriberDetails1 = ViewClaimsDBS.getMemberInfofromDBS(strQuery2, "Sybase");		
		String	accrual1 = dbSubscriberDetails1.getJSONObject(0).getString("MATX_AMT2");
		float  accrual3;
		if(!(accrual1.startsWith("0.0")))
				{
		accrual3 = Float.parseFloat(accrual) + Float.parseFloat(accrual1);
		accrual =Float.toString(accrual3);
		if(Double.parseDouble(accrual) >= Double.parseDouble(maximum))
		{
			accrual = maximum;
			
		}
		
		
		}
		}
		 
				 if (showSensitivityIndicator.equalsIgnoreCase("N") && isSensitiveIndicator.equalsIgnoreCase("Y")  ){
						
						accrual ="0";
						remaining1 = "0.0";
						 displayMaximum = "$"+maximum;
						 displayAccrual = "Sensitive info";
						 displayRemaining1 =  "Sensitve info";
						}
				 
				 else {
					 remaining = Float.parseFloat(maximum) - Float.parseFloat(accrual);
					 remaining1 =  Float.toString(remaining);
					 displayMaximum = "$"+maximum;
					 
					 displayAccrual = accrual;
					 double displayAccrual1  = Double.parseDouble(displayAccrual);
					 NumberFormat formatter = NumberFormat.getCurrencyInstance();
					 displayAccrual = formatter.format(displayAccrual1);
					 displayRemaining1 =  Float.toString(remaining);
					 double displayRemaining2  = Float.parseFloat(displayRemaining1);
					 displayRemaining1 = formatter.format(displayRemaining2);
				 }
				 		 
				 AccumulatorInformationQuery ="SELECT distinct  MATX_ACC_TYPE AS AccumulatorType  FROM CMC_MATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+" AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND MEME_CK = "+memberContrivedKey+"";
				 org.json.JSONArray dbDyanamicDetails = ViewClaimsDBS.getMemberInfofromDBS(AccumulatorInformationQuery, "Sybase");
					if(dbDyanamicDetails.length()>0) {
				 AccumulatorInformationQuery ="SELECT distinct  MATX_ACC_TYPE AS AccumulatorType  FROM CMC_MATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+" AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND MEME_CK = "+memberContrivedKey+"";
					}
					else
					{
			     AccumulatorInformationQuery ="SELECT top 1  MATX_ACC_TYPE AS AccumulatorType  FROM CMC_MATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+"";

					}
				
				}
				
				
				else if((accumulatorMethodology.equalsIgnoreCase("AGGO")) ||(accumulatorMethodology.equalsIgnoreCase("AGG")) ||(accumulatorMethodology.equalsIgnoreCase("INDO")))  {
					
				strQuery ="SELECT top 1 PDPD_ACC_SFX AS ProductAccumulatorSuffix    FROM CMC_FATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND FATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+"";

				strQuery1 ="SELECT Top 1 FATX_AMT1  FROM CMC_FATX_ACCUM_TXN "
						+ "WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND FATX_ACC_TYPE =  '"+accumulatorType+"' "
						+ "AND ACAC_ACC_NO = "+bucketNumber+" AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"' "
						+ "AND SBSB_CK = "+subscriberContrivedKey+" ORDER BY FATX_SEQ_NO DESC";
				
				org.json.JSONArray dbSubscriberDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery1, "Sybase");	
				if(dbSubscriberDetails.length()>0) {
					accrual = dbSubscriberDetails.getJSONObject(0).getString("FATX_AMT1");
					}
					else
					{
						accrual="0.0";
					}
			
		if (carryoverApplicableIndicator.equalsIgnoreCase("Y")){
			strQuery2 ="SELECT Top 1 FATX_AMT2 FROM CMC_FATX_ACCUM_TXN "
					+ "WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND FATX_ACC_TYPE =  '"+accumulatorType+"' "
					+ "AND ACAC_ACC_NO = "+bucketNumber+" AND FATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"' "
					+ "AND SBSB_CK = "+subscriberContrivedKey+" ORDER BY FATX_SEQ_NO DESC";
			org.json.JSONArray dbSubscriberDetails1 = ViewClaimsDBS.getMemberInfofromDBS(strQuery2, "Sybase");
		String	accrual1 = dbSubscriberDetails1.getJSONObject(0).getString("FATX_AMT2");
		float  accrual3;
		if(!(accrual1.startsWith("0.0")))
				{
		accrual3 = Float.parseFloat(accrual) + Float.parseFloat(accrual1);
		accrual =Float.toString(accrual3);
		if(Double.parseDouble(accrual) >= Double.parseDouble(maximum))
		{
			accrual = maximum;
			
		}
		
		}
		}
		 
				 if (showSensitivityIndicator.equalsIgnoreCase("N") && isSensitiveIndicator.equalsIgnoreCase("Y")  ){
						
						accrual ="0";
						remaining1 = "0.0";
						 displayMaximum = "$"+maximum;
						 displayAccrual = "Sensitive info";
						 displayRemaining1 =  "Sensitve info";
						}
				 
				 else {
					 remaining = Float.parseFloat(maximum) - Float.parseFloat(accrual);
					 remaining1 =  Float.toString(remaining);
					 displayMaximum = "$"+maximum;
					 displayAccrual = accrual;
					 double displayAccrual1  = Double.parseDouble(displayAccrual);
					 NumberFormat formatter = NumberFormat.getCurrencyInstance();
					 displayAccrual = formatter.format(displayAccrual1);
					 displayRemaining1 =  Float.toString(remaining);
					 double displayRemaining2  = Float.parseFloat(displayRemaining1);
					 displayRemaining1 = formatter.format(displayRemaining2);
				 }
				 
				 AccumulatorInformationQuery ="SELECT distinct  FATX_ACC_TYPE AS AccumulatorType  FROM CMC_FATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND FATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+" AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND SBSB_CK = "+subscriberContrivedKey+"";

				 
				 org.json.JSONArray dbDyanamicDetails = ViewClaimsDBS.getMemberInfofromDBS(AccumulatorInformationQuery, "Sybase");
					if(dbDyanamicDetails.length()>0) {
			    AccumulatorInformationQuery ="SELECT distinct  FATX_ACC_TYPE AS AccumulatorType  FROM CMC_FATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND FATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+" AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND SBSB_CK = "+subscriberContrivedKey+"";
					}
					else
					{
			     AccumulatorInformationQuery ="SELECT top 1  FATX_ACC_TYPE AS AccumulatorType  FROM CMC_FATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND FATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+"";

					}

				}
				else if((accumulatorMethodology.equalsIgnoreCase("2PER")) ||(accumulatorMethodology.equalsIgnoreCase("3PER")))  {
					
					strQuery ="SELECT top 1 PDPD_ACC_SFX AS ProductAccumulatorSuffix    FROM CMC_FATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND FATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+"";

					strQuery1 ="SELECT Top 1 FATX_PERSON_CTR FROM CMC_FATX_ACCUM_TXN "
							+ "WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND FATX_ACC_TYPE =  '"+accumulatorType+"' "
							+ "AND ACAC_ACC_NO = "+bucketNumber+" AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"' "
							+ "AND SBSB_CK = "+subscriberContrivedKey+" ORDER BY FATX_SEQ_NO DESC";
					
					org.json.JSONArray dbSubscriberDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery1, "Sybase");
					
					if(dbSubscriberDetails.length()>0) {

						accrual = dbSubscriberDetails.getJSONObject(0).getString("FATX_PERSON_CTR");
						}
						else
						{
							accrual="0";
						}
				
			if (carryoverApplicableIndicator.equalsIgnoreCase("Y")){
				strQuery2 ="SELECT Top 1 FATX_PERSON_CTR_CO FROM CMC_FATX_ACCUM_TXN "
						+ "WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND FATX_ACC_TYPE =  '"+accumulatorType+"' "
						+ "AND ACAC_ACC_NO = "+bucketNumber+" AND FATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"' "
						+ "AND SBSB_CK = "+subscriberContrivedKey+" ORDER BY FATX_SEQ_NO DESC";
				org.json.JSONArray dbSubscriberDetails1 = ViewClaimsDBS.getMemberInfofromDBS(strQuery2, "Sybase");
			String	accrual1 = dbSubscriberDetails1.getJSONObject(0).getString("FATX_PERSON_CTR_CO");
			float  accrual3;
			if(!(accrual1.startsWith("0.0")))
					{
			accrual3 = Float.parseFloat(accrual) + Float.parseFloat(accrual1);
			accrual =Float.toString(accrual3);
			if(Double.parseDouble(accrual) >= Double.parseDouble(maximum))
			{
				accrual = maximum;
				
			}
			
			}
			}
			 
					 if (showSensitivityIndicator.equalsIgnoreCase("N") && isSensitiveIndicator.equalsIgnoreCase("Y")  ){
							
							accrual ="0";
							remaining1 = "0.0";
							 displayMaximum = maximum;
							 displayAccrual = "Sensitive info";
							 displayRemaining1 =  "Sensitve info";
							}
					 
					 else {
						 remaining = Float.parseFloat(maximum) - Float.parseFloat(accrual);
						 remaining1 =  Float.toString(remaining);
						 displayMaximum =maximum;
						 displayAccrual = accrual;
					     String[] displayRemainingValue =  Float.toString(remaining).split("\\.");
						 displayRemaining1 =  displayRemainingValue[0];								 
					 }
					 
					 AccumulatorInformationQuery ="SELECT distinct  FATX_ACC_TYPE AS AccumulatorType  FROM CMC_FATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND FATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+" AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND SBSB_CK = "+subscriberContrivedKey+"";
					 
					 org.json.JSONArray dbDyanamicDetails = ViewClaimsDBS.getMemberInfofromDBS(AccumulatorInformationQuery, "Sybase");
						if(dbDyanamicDetails.length()>0) {
			         AccumulatorInformationQuery ="SELECT distinct  FATX_ACC_TYPE AS AccumulatorType  FROM CMC_FATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND FATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+" AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND SBSB_CK = "+subscriberContrivedKey+"";
						}
						else
						{
				     AccumulatorInformationQuery ="SELECT top 1  FATX_ACC_TYPE AS AccumulatorType  FROM CMC_FATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND FATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+"";

						}
					 
					}
				
				else if((accumulatorMethodology.equalsIgnoreCase("ACDOL"))){
					
			    strQuery ="SELECT top 1 PDPD_ACC_SFX AS ProductAccumulatorSuffix  FROM CMC_MATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+"";
				strQuery1 ="SELECT Top 1 MATX_AMT1  FROM CMC_MATX_ACCUM_TXN "
						+ "WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' "
						+ "AND ACAC_ACC_NO = "+bucketNumber+" AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"' "
						+ "AND MEME_CK = "+memberContrivedKey+" ORDER BY MATX_SEQ_NO DESC";
				
				org.json.JSONArray dbSubscriberDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery1, "Sybase");
				
				
				if(dbSubscriberDetails.length()>0) {
					accrual = dbSubscriberDetails.getJSONObject(0).getString("MATX_AMT1");
					}
					else
					{
						accrual="0.0";
					}

		 
				 if (showSensitivityIndicator.equalsIgnoreCase("N") && isSensitiveIndicator.equalsIgnoreCase("Y")  ){
						
						accrual ="0";
						remaining1 = "0.0";
						 displayMaximum = "$"+maximum;
						 displayAccrual = "Sensitive info";
						 displayRemaining1 =  "Sensitve info";
						}
				 
				 else {
					 remaining = Float.parseFloat(maximum) - Float.parseFloat(accrual);
					 remaining1 =  Float.toString(remaining);
					 displayMaximum = "$"+maximum;
					 displayAccrual = accrual;
					 double displayAccrual1  = Double.parseDouble(displayAccrual);
					 NumberFormat formatter = NumberFormat.getCurrencyInstance();
					 displayAccrual = formatter.format(displayAccrual1);
					 displayRemaining1 =  Float.toString(remaining);
					 double displayRemaining2  = Float.parseFloat(displayRemaining1);
					 displayRemaining1 = formatter.format(displayRemaining2);
					// limitDescription =  limitDescription+" "+ "with" +" "+ "$"+accrual +" "+ "of" +" "+ "$"+maximum;
				 }
				 
				 AccumulatorInformationQuery ="SELECT distinct  MATX_ACC_TYPE AS AccumulatorType  FROM CMC_MATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+" AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND MEME_CK = "+memberContrivedKey+"";

				 org.json.JSONArray dbDyanamicDetails = ViewClaimsDBS.getMemberInfofromDBS(AccumulatorInformationQuery, "Sybase");
					if(dbDyanamicDetails.length()>0) {
			AccumulatorInformationQuery ="SELECT distinct  MATX_ACC_TYPE AS AccumulatorType  FROM CMC_MATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+" AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND MEME_CK = "+memberContrivedKey+"";
					}
					else
					{
			     AccumulatorInformationQuery ="SELECT top 1  MATX_ACC_TYPE AS AccumulatorType  FROM CMC_MATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+"";

					}
				 
				 
				 
				 
				
				}
				
				else {
					
				    strQuery ="SELECT top 1 PDPD_ACC_SFX AS ProductAccumulatorSuffix  FROM CMC_MATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+"";
					strQuery1 ="SELECT Top 1 MATX_CTR1  FROM CMC_MATX_ACCUM_TXN "
							+ "WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' "
							+ "AND ACAC_ACC_NO = "+bucketNumber+" AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"' "
							+ "AND MEME_CK = "+memberContrivedKey+" ORDER BY MATX_SEQ_NO DESC";
					
					org.json.JSONArray dbSubscriberDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery1, "Sybase");
					
					
					if(dbSubscriberDetails.length()>0) {
						accrual = dbSubscriberDetails.getJSONObject(0).getString("MATX_CTR1");
						}
						else
						{
							accrual="0";
						}
			 
					 if (showSensitivityIndicator.equalsIgnoreCase("N") && isSensitiveIndicator.equalsIgnoreCase("Y")  ){
							
							accrual ="0";
							remaining1 = "0.0";
							 displayMaximum = maximum;
							 displayAccrual = "Sensitive info";
							 displayRemaining1 =  "Sensitve info";
							}
					 
					 else {
						 remaining = Float.parseFloat(maximum) - Float.parseFloat(accrual);
						 remaining1 =  Float.toString(remaining);
						 displayMaximum = maximum;
						 String[] accrualValue =  accrual.split("\\.");
						 displayAccrual = accrualValue[0];
						 String[] displayRemainingValue =  Float.toString(remaining).split("\\.");
						displayRemaining1 =  displayRemainingValue[0];	
						// limitDescription =  limitDescription+" "+ "with" +" "+ "$"+accrual +" "+ "of" +" "+ "$"+maximum;
					 }
					 
					 AccumulatorInformationQuery ="SELECT distinct  MATX_ACC_TYPE AS AccumulatorType  FROM CMC_MATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+" AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND MEME_CK = "+memberContrivedKey+"";
					 org.json.JSONArray dbDyanamicDetails = ViewClaimsDBS.getMemberInfofromDBS(AccumulatorInformationQuery, "Sybase");
						if(dbDyanamicDetails.length()>0) {
					AccumulatorInformationQuery ="SELECT distinct  MATX_ACC_TYPE AS AccumulatorType  FROM CMC_MATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+" AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND MEME_CK = "+memberContrivedKey+"";
						}
						else
						{
				     AccumulatorInformationQuery ="SELECT top 1  MATX_ACC_TYPE AS AccumulatorType  FROM CMC_MATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+bucketNumber+"";

						}
					 
					
				}

				Assert.done("Start-> Validation of the Static Data");
				Map<String, String> map = new HashMap<>();
				if (carryoverApplicableIndicator.equalsIgnoreCase("Y")) {
				
				map.put("SubscriberContrivedKey", subscriberContrivedKey);
				map.put("MemberContrivedKey", memberContrivedKey);
				map.put("UserId", userId);
				//map.put("ProductAccumulatorSuffix", productAccumulatorSuffix);
				map.put("BenefitBeginDate", benefitBeginDate);
				map.put("CarryoverBenefitBeginDate", carryoverBenefitBeginDate);
				map.put("ShowSensitivityIndicator", showSensitivityIndicator);
				}
				else {
					
					map.put("SubscriberContrivedKey", subscriberContrivedKey);
					map.put("MemberContrivedKey", memberContrivedKey);
					map.put("UserId", userId);
					//map.put("ProductAccumulatorSuffix", productAccumulatorSuffix);
					map.put("BenefitBeginDate", benefitBeginDate);
					map.put("CarryoverBenefitBeginDate", carryoverBenefitBeginDate);
					map.put("ShowSensitivityIndicator", showSensitivityIndicator);
					
				}
				
				ValidateMethods.validateStaticFieldsWithDbUsingMap(ClaimObj, strQuery, "Sybase", ReportFilePath, map);

				// Validating Dynamic Fields With DB for Accumulator Information
				Assert.done("Start-> Validation of the Dynamic Data for Accumulator Information");
				Map<String, String> map1 = new HashMap<>();
				map1.put("BenefitIdentifier", benefitIdentifier);
				map1.put("AccumulatorMethodology", accumulatorMethodology);
				map1.put("CarryoverApplicableIndicator", carryoverApplicableIndicator);
				map1.put("IsSensitiveIndicator", isSensitiveIndicator);
				map1.put("FamilyComposition", familyComposition);
				map1.put("Network", network);
				map1.put("Tier", tier);
				map1.put("BucketNumber", bucketNumber);
				map1.put("Remaining", remaining1);
				map1.put("DisplayMaximum", displayMaximum);
				map1.put("DisplayAccrual", displayAccrual);
				map1.put("DisplayRemaining", displayRemaining1);
				map1.put("ErrorMessage", errorMessage);
				DecimalFormat s = new DecimalFormat("0.############");
				double accuraltemp= Double.parseDouble(accrual);
				  String n= s.format(accuraltemp);
				    String accural1="";
				    if(n.contains("."))
				    {
				    	accural1=n;					    	
				    }
				    	
				    else
				    {
				    	accural1=n+".0";
				    }
				     if(accumulatorMethodology.equalsIgnoreCase("ACDOL")) {
					 limitDescription =  limitDescription+" "+ "with" +" "+ displayAccrual+" "+ "of" +" "+ "$"+maximum;
				     }
				     if (accumulatorMethodology.equalsIgnoreCase("ACQTY")) {
				    	 if (!(showSensitivityIndicator.equalsIgnoreCase("N") && isSensitiveIndicator.equalsIgnoreCase("Y"))) { 
						 limitDescription =  limitDescription+" "+ "with" +" "+displayAccrual+" "+ "of" +" "+maximum;
					     }
				    	 }
				     
				map1.put("LimitDescription", limitDescription);
				map1.put("Accrual", accural1);
				double maximumtemp= Double.parseDouble(maximum);
				  String n1= s.format(maximumtemp);
				    String maximum1="";
				    if(n1.contains("."))
				    {
				    	maximum1=n1; 	
				    }				    	
				    else
				    {
				    	maximum1=n1+".0";
				    }
				    map1.put("Maximum", maximum1);
				String AccumulatorInformation = "AccumulatorInformation";
				String uniqueColumn = null;
				
					uniqueColumn = "AccumulatorType";
			
				ValidateMethods.validateJsonArrayDataWithDBUsingMap(ClaimObj, AccumulatorInformation,
						AccumulatorInformationQuery, uniqueColumn, "Sybase", ReportFilePath,map1,service);

			} catch (Exception e) {
				Assert.done("Completed");
			}
		} else {

			Assert.done("Test ID: " + testID);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg");
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {
					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
			}
		}
	}	
	
	
	/**
	 * This method is used to validate the static fields with DB
	 * 
	 * @param ClaimObj =  JSON Object
	 * @param strQuery =  DB query used
	 * @param DB = Database name
	 * @param ReportFilePath = Excel report file path
	 * @param map = mapping value
	 * @param countQuery = counting the records query
	 * @throws SQLException 
	 * @throws IOException
	 */
	public static void validateStaticFieldsWithDbUsingMap(JSONObject ClaimObj, String strQuery, String DB,
			String ReportFilePath, Map<String, String> map) throws SQLException, IOException {
		// String QueryDB =
		Object value = null;
		Map<String, Object> responseData = UtilMethod.readJsonData(ClaimObj);
		org.json.JSONArray dbData = ViewClaimsDBS.getMemberInfofromDBS(strQuery, DB);
		Set<String> keys = responseData.keySet();
		for (String key : keys) {
		    UtilMethod.setCellData(key, responseData.get(key),1,ReportFilePath);
			value = responseData.get(key);
			if (value != null) {
				UtilMethod.validateStaticFieldWithDbUsingMap(dbData, key, value, ReportFilePath, map);
			}

		}
	}

	/**
	 * This method is used to validate the JSON Array Data with DB data having three
	 * columns
	 * 
	 * @param ClaimObj
	 *            = JSON object
	 * @param strArrayName
	 *            = JSON array name
	 * @param strQuery
	 *            = DB query used
	 * @param strUniqueColName
	 *            = Unique column name
	 * @param DB
	 *            = Database name
	 * @param ReportFilePath
	 *            = Excel report file path
	 * @param map
	 * @throws Exception
	 */
	public static void validateJsonArrayDataWithDBUsingMap(JSONObject ClaimObj, String strArrayName, String strQuery,
			String strUniqueColName, String DB, String ReportFilePath, Map<String, String> map1, String Service)
			throws Exception {
		JSONArray responseClaimLineDetails = (JSONArray) ClaimObj.get(strArrayName);
		org.json.JSONArray dbClaimLineDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, DB);

		if (responseClaimLineDetails.size() == dbClaimLineDetails.length()) {

			Map<String, Object> strCLaimDetailsRes = null;
			JSONObject response = null;
			Map<String, Object> db_data = null;
			org.json.JSONObject db_response = null;

			boolean errorflag = false;
			boolean validateflag = true;

			// Comparing Response data with db row
			for (int j = 0; j < responseClaimLineDetails.size(); j++) {
				int k = j * 2 + 1; // 1,3,5
				int l = j * 2 + 2; // 2,4,6
				response = (JSONObject) responseClaimLineDetails.get(j);
				strCLaimDetailsRes = UtilMethod.readJsonData(response);
				// Assert.done("Validating " + j + " row DB values with response");
				for (int i = 0; i < dbClaimLineDetails.length(); i++) {
					db_response = (org.json.JSONObject) dbClaimLineDetails.get(i);
					db_data = UtilMethod.readJsonData(db_response);
					if (Service.equalsIgnoreCase("Accumulator")) {
						if (strCLaimDetailsRes.get(strUniqueColName).toString()
								.equalsIgnoreCase(db_data.get(strUniqueColName).toString())) {
							break;
						}
					} else {
						break;
					}
				}

				Set<String> jsonKeys = strCLaimDetailsRes.keySet();
				for (String tagname : jsonKeys) {
					Object Value = strCLaimDetailsRes.get(tagname);
					 UtilMethod.setCellData(tagname, Value,k, ReportFilePath);

					UtilMethod.validateJSONObjectUsingMaps(db_data, tagname, Value, l, ReportFilePath, map1);

				}
			}

		} else {
			UtilMethod.Log(
					"Cannot validate as the Json response claim line details record size is not matching with DB response claim line details records.. please check the query you are passing",
					"FAIL", true);
			throw new Exception(
					"Cannot validate claim line details with db as size is not matching.. please check the query you are passing...");
		}

	}

	/**
	 * This method is used to validate the JSON data and DB data of GetAcculumator service
	 * 
	 * @param content = JSON response data
	 * @param testID = TestCase ID
	 * @throws Exception
	 */

	public static void validateGetAccumulatorBreakdown(String content, String testID,String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\"; 
		DataTable1 Dttestdata = new DataTable1(testdir + "GetAccumulator.xls", "GetAccumulatorBreakdown_Input", "" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String ReportFilePath = "";
		if(Environment.get("Jenkins_Run").equalsIgnoreCase("Yes")){
			String excelName = Environment.get("GetAccumulatorBreakdown_XML");		
			String excelReportName = excelName.replace(".xml", ".xslx");
			ReportFilePath = Environment.get("report_path")+"//"+excelReportName;
			}
			else {
				ReportFilePath = Environment.get("GetAccumulatorBreakdown_excel_path");
			}
		if (content.contains("ErrorCode")) {
			errorflag = false;
		} else {
			validateflag = true;
		}
		if (validateflag) {
			Object obj = jsonparser.parse(content);
			JSONObject ClaimObj = (JSONObject) obj;
			String service = "Breakdown";
			String inputtestID = Dttestdata.getValue("TestID");
			String testDesc = Dttestdata.getValue("Test_Description");
			String userId = Dttestdata.getValue("UserId");
			String subscriberContrivedKey = Dttestdata.getValue("SubscriberContrivedKey");
			String memberContrivedKey = Dttestdata.getValue("MemberContrivedKey");
			String showSensitivityIndicator = Dttestdata.getValue("ShowSensitivityIndicator");
			String productAccumulatorSuffix = Dttestdata.getValue("ProductAccumulatorSuffix");
			String accumulatorType = Dttestdata.getValue("AccumulatorType");
			String accumulatorBucketNumber = Dttestdata.getValue("AccumulatorBucketNumber");
			String benefitBeginDate = Dttestdata.getValue("BenefitBeginDate");
			String accumulatorMethodology = Dttestdata.getValue("AccumulatorMethodology");
			String carryoverApplicableIndicator = Dttestdata.getValue("CarryoverApplicableIndicator");
			String carryoverBenefitBeginDate = Dttestdata.getValue("CarryoverBenefitBeginDate");
			String isSensitiveIndicator = Dttestdata.getValue("IsSensitiveIndicator");
			String accumulatorMaximum = Dttestdata.getValue("AccumulatorMaximum");
			String Indicator = Dttestdata.getValue("Indicator");
			String responseType = "MESSAGE";
			String responseDescription = "No Contribution";
			String responseValue = "";
			String displayResponseDescription = "No Contribution";;
			String displayResponseValue ="";
			String claimType = "";
			String claimStartDateOfService = "";
			String claimEndDateOfService ="";
			String claimAdjudicationDate = "";
			String claimServiceProviderId = "";
			String claimServiceProviderName = "";
			String MessageQuery = "";
			String strQuery = "";
			String ClaimsQuery = "";
			String BreakdownInformationQuery = "";
			try {
				Assert.done("Test ID: " + inputtestID);
				Assert.done("Test Description: " + testDesc);
                  if(showSensitivityIndicator.equalsIgnoreCase(""))
                  {
                	  showSensitivityIndicator = "N";
                	
                  }
                  if(carryoverApplicableIndicator.equalsIgnoreCase(""))
                  {
                	 
                	  carryoverApplicableIndicator = "N";
                  }
				
                  
				if ((accumulatorMethodology.equalsIgnoreCase("IND")) || accumulatorMethodology.equalsIgnoreCase("ACDOL")
					|| accumulatorMethodology.equalsIgnoreCase("ACQTY"))  {
				
		
				if (Indicator.equalsIgnoreCase("M")) {	
				strQuery ="SELECT  TOP 1 GRGR_CK AS GRGRCK FROM CMC_MATX_ACCUM_TXN WHERE   MATX_ACC_TYPE = 'L'	";
				}
				else {
					if (!(accumulatorMethodology.equalsIgnoreCase("ACQTY"))) {
			//	strQuery ="SELECT distinct MEME_CK AS MemberContrivedKey  FROM CMC_MATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+accumulatorBucketNumber+" AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND MEME_CK = "+memberContrivedKey+" AND MATX_TXN_AMT1!=0";
				strQuery = "SELECT distinct PDPD_ACC_SFX AS ProductAccumulatorSuffix  FROM CMC_MATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+accumulatorBucketNumber+" AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"'";
				}
					else {
						strQuery = "SELECT distinct PDPD_ACC_SFX AS ProductAccumulatorSuffix  FROM CMC_MATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+accumulatorBucketNumber+" AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"'";

					}
					}
				if(Indicator.equalsIgnoreCase("C")) {
					 if (showSensitivityIndicator.equalsIgnoreCase("N") && isSensitiveIndicator.equalsIgnoreCase("Y")  ){
						 BreakdownInformationQuery="DECLARE @V_MEME_CK  BIGINT     DECLARE @V_SBSB_CK  INT     DECLARE @V_BUCKET   INT     DECLARE @V_MAXIMUM  VARCHAR(10)       SELECT @V_MEME_CK =  "+memberContrivedKey+"     SELECT @V_BUCKET = "+accumulatorBucketNumber+"     SELECT  @V_MAXIMUM = '"+accumulatorMaximum+"'  select  'MAXIMUM' ResponseDescription,         @V_MAXIMUM ResponseValue,         'MAXIMUM'  DisplayResponseDescription,         @V_MAXIMUM  DisplayResponseValue,         '' ClaimType,         '' ClaimStartDateOfService,         '' ClaimEndDateOfService,         '' ClaimAdjudicationDate,         '' ClaimServiceProviderId,         '' ClaimServiceProviderName, '' ClaimServiceProviderNPI  FROM CMC_MATX_ACCUM_TXN MATX WHERE MATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"' AND MATX.MATX_ACC_TYPE = '"+accumulatorType+"' AND MATX.ACAC_ACC_NO = @V_BUCKET AND MATX.MATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND MATX.MEME_CK = @V_MEME_CK";
					 }
					 else {
					if (!(accumulatorMethodology.equalsIgnoreCase("ACQTY"))) {
						
						ClaimsQuery= "Select distinct CLCL_PRE_PRICE_IND FROM CMC_MATX_ACCUM_TXN MATX INNER JOIN CMC_CLCL_CLAIM CLCL ON MATX.CLCL_ID = CLCL.CLCL_ID  AND MATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"' AND MATX.MATX_ACC_TYPE = '"+accumulatorType+"' AND MATX.ACAC_ACC_NO = "+accumulatorBucketNumber+" AND MATX.MATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND MATX.MEME_CK = "+memberContrivedKey+" AND MATX.MATX_TXN_AMT1!=0";
						
						org.json.JSONArray itsClaims = ViewClaimsDBS.getMemberInfofromDBS(ClaimsQuery, "Sybase");
						
						if (itsClaims.length()>0) {
							
						String its = itsClaims.getJSONObject(0).getString("CLCL_PRE_PRICE_IND");
						
						if(its.equalsIgnoreCase("H") || (its.equalsIgnoreCase("T"))) {
							
						if(carryoverApplicableIndicator.equalsIgnoreCase("Y")  && (accumulatorMethodology.equalsIgnoreCase("IND"))) {
					
						//	benefitBeginDate = carryoverBenefitBeginDate;
							
				  BreakdownInformationQuery= "SELECT LINE_DESC, CASE   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END ResponseDescription,                 CASE                   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END DisplayResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName,ClaimServiceProviderNPI FROM (  SELECT   'LINE ITEM' LINE_DESC,   MATX.CLCL_ID, MATX.MATX_TXN_AMT2 ResponseValue, MATX.USUS_ID, MATX.MATX_STS_IND, MATX.MATX_MCTR_RSN,         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLPP.CLPP_BCBS_PR_ID ClaimServiceProviderId, CLPP.CLPP_PR_NAME ClaimServiceProviderName , CLPP.CLPP_BCBS_PR_NPI ClaimServiceProviderNPI FROM CMC_MATX_ACCUM_TXN MATX INNER JOIN CMC_CLCL_CLAIM CLCL ON MATX.CLCL_ID = CLCL.CLCL_ID  AND MATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"' AND MATX.MATX_ACC_TYPE = '"+accumulatorType+"' AND MATX.ACAC_ACC_NO ="+accumulatorBucketNumber+" AND MATX.MATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"' AND MATX.MEME_CK = "+memberContrivedKey+" AND MATX.MATX_TXN_AMT2!=0 INNER JOIN CMC_CLPP_ITS_PROV CLPP ON CLCL.CLCL_ID = CLPP.CLCL_ID UNION ALL SELECT 'AGGREGATE' LINE_DESC,  '' CLCL_ID, MATX_TXN_AMT2, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' CLPP_BCBS_PR_ID, '' CLPP_PR_NAME   ,'' CLPP_BCBS_PR_NPI   FROM (         SELECT SUM (MATX_TXN_AMT2) MATX_TXN_AMT2, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN                FROM CMC_MATX_ACCUM_TXN         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'         AND MATX_ACC_TYPE = '"+accumulatorType+"'      AND ACAC_ACC_NO = "+accumulatorBucketNumber+"         AND MATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"'         AND MEME_CK = "+memberContrivedKey+"      AND MATX_TXN_AMT2!= 0         AND (CLCL_ID='' OR CLCL_ID=NULL)         GROUP BY USUS_ID, MATX_STS_IND, MATX_MCTR_RSN     ) subq ) subq2";

						}	
						else {
				  BreakdownInformationQuery= "SELECT LINE_DESC, CASE   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END ResponseDescription,                 CASE                   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END DisplayResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName,ClaimServiceProviderNPI FROM (  SELECT   'LINE ITEM' LINE_DESC,   MATX.CLCL_ID, MATX.MATX_TXN_AMT1 ResponseValue, MATX.USUS_ID, MATX.MATX_STS_IND, MATX.MATX_MCTR_RSN,         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLPP.CLPP_BCBS_PR_ID ClaimServiceProviderId, CLPP.CLPP_PR_NAME ClaimServiceProviderName , CLPP.CLPP_BCBS_PR_NPI ClaimServiceProviderNPI FROM CMC_MATX_ACCUM_TXN MATX INNER JOIN CMC_CLCL_CLAIM CLCL ON MATX.CLCL_ID = CLCL.CLCL_ID  AND MATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"' AND MATX.MATX_ACC_TYPE = '"+accumulatorType+"' AND MATX.ACAC_ACC_NO ="+accumulatorBucketNumber+" AND MATX.MATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND MATX.MEME_CK = "+memberContrivedKey+" AND MATX.MATX_TXN_AMT1!=0 INNER JOIN CMC_CLPP_ITS_PROV CLPP ON CLCL.CLCL_ID = CLPP.CLCL_ID UNION ALL SELECT 'AGGREGATE' LINE_DESC,  '' CLCL_ID, MATX_TXN_AMT1, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' CLPP_BCBS_PR_ID, '' CLPP_PR_NAME   ,'' CLPP_BCBS_PR_NPI   FROM (         SELECT SUM (MATX_TXN_AMT1) MATX_TXN_AMT1, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN                FROM CMC_MATX_ACCUM_TXN         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'         AND MATX_ACC_TYPE = '"+accumulatorType+"'      AND ACAC_ACC_NO = "+accumulatorBucketNumber+"         AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"'         AND MEME_CK = "+memberContrivedKey+"      AND MATX_TXN_AMT1!= 0         AND (CLCL_ID='' OR CLCL_ID=NULL)         GROUP BY USUS_ID, MATX_STS_IND, MATX_MCTR_RSN     ) subq ) subq2";
						}
						}
						else {
							
						if(carryoverApplicableIndicator.equalsIgnoreCase("Y")  && (accumulatorMethodology.equalsIgnoreCase("IND"))) {
				  
							//benefitBeginDate = carryoverBenefitBeginDate;
							BreakdownInformationQuery= "SELECT LINE_DESC, CASE   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END ResponseDescription,                 CASE                   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END DisplayResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName,ClaimServiceProviderNPI FROM (  SELECT   'LINE ITEM' LINE_DESC,   MATX.CLCL_ID, MATX.MATX_TXN_AMT2 ResponseValue, MATX.USUS_ID, MATX.MATX_STS_IND, MATX.MATX_MCTR_RSN,         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLCL.PRPR_ID ClaimServiceProviderId, PRPR.PRPR_NAME ClaimServiceProviderName , PRPR.PRPR_NPI ClaimServiceProviderNPI FROM CMC_MATX_ACCUM_TXN MATX INNER JOIN CMC_CLCL_CLAIM CLCL ON MATX.CLCL_ID = CLCL.CLCL_ID  AND MATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"' AND MATX.MATX_ACC_TYPE = '"+accumulatorType+"' AND MATX.ACAC_ACC_NO ="+accumulatorBucketNumber+" AND MATX.MATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"' AND MATX.MEME_CK = "+memberContrivedKey+" AND MATX.MATX_TXN_AMT2!=0 INNER JOIN CMC_PRPR_PROV PRPR ON CLCL.PRPR_ID = PRPR.PRPR_ID UNION ALL SELECT 'AGGREGATE' LINE_DESC,  '' CLCL_ID, MATX_TXN_AMT2, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI   FROM (         SELECT SUM (MATX_TXN_AMT2) MATX_TXN_AMT2, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN                FROM CMC_MATX_ACCUM_TXN         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'         AND MATX_ACC_TYPE = '"+accumulatorType+"'         AND ACAC_ACC_NO = "+accumulatorBucketNumber+"         AND MATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"'         AND MEME_CK = "+memberContrivedKey+"         AND MATX_TXN_AMT2!= 0         AND (CLCL_ID='' OR CLCL_ID=NULL)         GROUP BY USUS_ID, MATX_STS_IND, MATX_MCTR_RSN     ) subq ) subq2";
							
							org.json.JSONArray carrOver = ViewClaimsDBS.getMemberInfofromDBS(BreakdownInformationQuery, "Sybase");

							if (carrOver.length()<=0) {
								
								BreakdownInformationQuery= "SELECT LINE_DESC, CASE   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END ResponseDescription,                 CASE                   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END DisplayResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName,ClaimServiceProviderNPI FROM (  SELECT   'LINE ITEM' LINE_DESC,   MATX.CLCL_ID, MATX.MATX_TXN_AMT1 ResponseValue, MATX.USUS_ID, MATX.MATX_STS_IND, MATX.MATX_MCTR_RSN,         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLCL.PRPR_ID ClaimServiceProviderId, PRPR.PRPR_NAME ClaimServiceProviderName , PRPR.PRPR_NPI ClaimServiceProviderNPI FROM CMC_MATX_ACCUM_TXN MATX INNER JOIN CMC_CLCL_CLAIM CLCL ON MATX.CLCL_ID = CLCL.CLCL_ID  AND MATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"' AND MATX.MATX_ACC_TYPE = '"+accumulatorType+"' AND MATX.ACAC_ACC_NO ="+accumulatorBucketNumber+" AND MATX.MATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND MATX.MEME_CK = "+memberContrivedKey+" AND MATX.MATX_TXN_AMT1!=0 INNER JOIN CMC_PRPR_PROV PRPR ON CLCL.PRPR_ID = PRPR.PRPR_ID UNION ALL SELECT 'AGGREGATE' LINE_DESC,  '' CLCL_ID, MATX_TXN_AMT1, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI   FROM (         SELECT SUM (MATX_TXN_AMT1) MATX_TXN_AMT1, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN                FROM CMC_MATX_ACCUM_TXN         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'         AND MATX_ACC_TYPE = '"+accumulatorType+"'         AND ACAC_ACC_NO = "+accumulatorBucketNumber+"         AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"'         AND MEME_CK = "+memberContrivedKey+"         AND MATX_TXN_AMT1!= 0         AND (CLCL_ID='' OR CLCL_ID=NULL)         GROUP BY USUS_ID, MATX_STS_IND, MATX_MCTR_RSN     ) subq ) subq2";

										}
							}
							else {
								//change here
			      BreakdownInformationQuery= "SELECT LINE_DESC, CASE   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END ResponseDescription,                 CASE                   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END DisplayResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName,ClaimServiceProviderNPI FROM (  SELECT   'LINE ITEM' LINE_DESC,   MATX.CLCL_ID, MATX.MATX_TXN_AMT1 ResponseValue, MATX.USUS_ID, MATX.MATX_STS_IND, MATX.MATX_MCTR_RSN,         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLCL.PRPR_ID ClaimServiceProviderId, PRPR.PRPR_NAME ClaimServiceProviderName , PRPR.PRPR_NPI ClaimServiceProviderNPI FROM CMC_MATX_ACCUM_TXN MATX INNER JOIN CMC_CLCL_CLAIM CLCL ON MATX.CLCL_ID = CLCL.CLCL_ID  AND MATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"' AND MATX.MATX_ACC_TYPE = '"+accumulatorType+"' AND MATX.ACAC_ACC_NO ="+accumulatorBucketNumber+" AND MATX.MATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND MATX.MEME_CK = "+memberContrivedKey+" AND MATX.MATX_TXN_AMT1!=0 INNER JOIN CMC_PRPR_PROV PRPR ON CLCL.PRPR_ID = PRPR.PRPR_ID UNION ALL SELECT 'AGGREGATE' LINE_DESC,  '' CLCL_ID, MATX_TXN_AMT1, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI   FROM (         SELECT SUM (MATX_TXN_AMT1) MATX_TXN_AMT1, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN                FROM CMC_MATX_ACCUM_TXN         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'         AND MATX_ACC_TYPE = '"+accumulatorType+"'         AND ACAC_ACC_NO = "+accumulatorBucketNumber+"         AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"'         AND MEME_CK = "+memberContrivedKey+"         AND MATX_TXN_AMT1!= 0         AND (CLCL_ID='' OR CLCL_ID=NULL)         GROUP BY USUS_ID, MATX_STS_IND, MATX_MCTR_RSN     ) subq ) subq2";
					}
							}
						}
						else {
							
							if(carryoverApplicableIndicator.equalsIgnoreCase("Y")  && (accumulatorMethodology.equalsIgnoreCase("IND"))) {
								//benefitBeginDate = carryoverBenefitBeginDate;
								
								
								
								BreakdownInformationQuery= "SELECT LINE_DESC, CASE   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END ResponseDescription,                 CASE                   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END DisplayResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName,ClaimServiceProviderNPI FROM (  SELECT   'LINE ITEM' LINE_DESC,   MATX.CLCL_ID, MATX.MATX_TXN_AMT2 ResponseValue, MATX.USUS_ID, MATX.MATX_STS_IND, MATX.MATX_MCTR_RSN,         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLCL.PRPR_ID ClaimServiceProviderId, PRPR.PRPR_NAME ClaimServiceProviderName , PRPR.PRPR_NPI ClaimServiceProviderNPI FROM CMC_MATX_ACCUM_TXN MATX INNER JOIN CMC_CLCL_CLAIM CLCL ON MATX.CLCL_ID = CLCL.CLCL_ID  AND MATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"' AND MATX.MATX_ACC_TYPE = '"+accumulatorType+"' AND MATX.ACAC_ACC_NO ="+accumulatorBucketNumber+" AND MATX.MATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"' AND MATX.MEME_CK = "+memberContrivedKey+" AND MATX.MATX_TXN_AMT2!=0 INNER JOIN CMC_PRPR_PROV PRPR ON CLCL.PRPR_ID = PRPR.PRPR_ID UNION ALL SELECT 'AGGREGATE' LINE_DESC,  '' CLCL_ID, MATX_TXN_AMT2, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI   FROM (         SELECT SUM (MATX_TXN_AMT2) MATX_TXN_AMT2, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN                FROM CMC_MATX_ACCUM_TXN         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'         AND MATX_ACC_TYPE = '"+accumulatorType+"'         AND ACAC_ACC_NO = "+accumulatorBucketNumber+"         AND MATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"'         AND MEME_CK = "+memberContrivedKey+"         AND MATX_TXN_AMT2!= 0         AND (CLCL_ID='' OR CLCL_ID=NULL)         GROUP BY USUS_ID, MATX_STS_IND, MATX_MCTR_RSN     ) subq ) subq2";

								org.json.JSONArray carrOver = ViewClaimsDBS.getMemberInfofromDBS(BreakdownInformationQuery, "Sybase");

								if (carrOver.length()<=0) {
								
						             BreakdownInformationQuery= "SELECT LINE_DESC, CASE   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END ResponseDescription,                 CASE                   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END DisplayResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName,ClaimServiceProviderNPI FROM (  SELECT   'LINE ITEM' LINE_DESC,   MATX.CLCL_ID, MATX.MATX_TXN_AMT1 ResponseValue, MATX.USUS_ID, MATX.MATX_STS_IND, MATX.MATX_MCTR_RSN,         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLCL.PRPR_ID ClaimServiceProviderId, PRPR.PRPR_NAME ClaimServiceProviderName , PRPR.PRPR_NPI ClaimServiceProviderNPI FROM CMC_MATX_ACCUM_TXN MATX INNER JOIN CMC_CLCL_CLAIM CLCL ON MATX.CLCL_ID = CLCL.CLCL_ID  AND MATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"' AND MATX.MATX_ACC_TYPE = '"+accumulatorType+"' AND MATX.ACAC_ACC_NO ="+accumulatorBucketNumber+" AND MATX.MATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND MATX.MEME_CK = "+memberContrivedKey+" AND MATX.MATX_TXN_AMT1!=0 INNER JOIN CMC_PRPR_PROV PRPR ON CLCL.PRPR_ID = PRPR.PRPR_ID UNION ALL SELECT 'AGGREGATE' LINE_DESC,  '' CLCL_ID, MATX_TXN_AMT1, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI   FROM (         SELECT SUM (MATX_TXN_AMT1) MATX_TXN_AMT1, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN                FROM CMC_MATX_ACCUM_TXN         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'         AND MATX_ACC_TYPE = '"+accumulatorType+"'         AND ACAC_ACC_NO = "+accumulatorBucketNumber+"         AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"'         AND MEME_CK = "+memberContrivedKey+"         AND MATX_TXN_AMT1!= 0         AND (CLCL_ID='' OR CLCL_ID=NULL)         GROUP BY USUS_ID, MATX_STS_IND, MATX_MCTR_RSN     ) subq ) subq2";

								}
								
							}
							else {
	             BreakdownInformationQuery= "SELECT LINE_DESC, CASE   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END ResponseDescription,                 CASE                   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END DisplayResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName,ClaimServiceProviderNPI FROM (  SELECT   'LINE ITEM' LINE_DESC,   MATX.CLCL_ID, MATX.MATX_TXN_AMT1 ResponseValue, MATX.USUS_ID, MATX.MATX_STS_IND, MATX.MATX_MCTR_RSN,         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLCL.PRPR_ID ClaimServiceProviderId, PRPR.PRPR_NAME ClaimServiceProviderName , PRPR.PRPR_NPI ClaimServiceProviderNPI FROM CMC_MATX_ACCUM_TXN MATX INNER JOIN CMC_CLCL_CLAIM CLCL ON MATX.CLCL_ID = CLCL.CLCL_ID  AND MATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"' AND MATX.MATX_ACC_TYPE = '"+accumulatorType+"' AND MATX.ACAC_ACC_NO ="+accumulatorBucketNumber+" AND MATX.MATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND MATX.MEME_CK = "+memberContrivedKey+" AND MATX.MATX_TXN_AMT1!=0 INNER JOIN CMC_PRPR_PROV PRPR ON CLCL.PRPR_ID = PRPR.PRPR_ID UNION ALL SELECT 'AGGREGATE' LINE_DESC,  '' CLCL_ID, MATX_TXN_AMT1, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI   FROM (         SELECT SUM (MATX_TXN_AMT1) MATX_TXN_AMT1, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN                FROM CMC_MATX_ACCUM_TXN         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'         AND MATX_ACC_TYPE = '"+accumulatorType+"'         AND ACAC_ACC_NO = "+accumulatorBucketNumber+"         AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"'         AND MEME_CK = "+memberContrivedKey+"         AND MATX_TXN_AMT1!= 0         AND (CLCL_ID='' OR CLCL_ID=NULL)         GROUP BY USUS_ID, MATX_STS_IND, MATX_MCTR_RSN     ) subq ) subq2";
							}
						}
						
						}
					else {
				  BreakdownInformationQuery= "SELECT LINE_DESC, CASE   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END ResponseDescription,                 CASE                   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (MATX_MCTR_RSN = 'PRIM' AND MATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'CARV' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (MATX_MCTR_RSN = 'TYP8' AND MATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN MATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (MATX_MCTR_RSN = 'BLUE' AND MATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN MATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (MATX_MCTR_RSN = 'CRED' AND MATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN MATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN MATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END DisplayResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName,ClaimServiceProviderNPI FROM (  SELECT   'LINE ITEM' LINE_DESC,   MATX.CLCL_ID, MATX.MATX_TXN_CTR1 ResponseValue, MATX.USUS_ID, MATX.MATX_STS_IND, MATX.MATX_MCTR_RSN,         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLCL.PRPR_ID ClaimServiceProviderId, PRPR.PRPR_NAME ClaimServiceProviderName , PRPR.PRPR_NPI ClaimServiceProviderNPI FROM CMC_MATX_ACCUM_TXN MATX INNER JOIN CMC_CLCL_CLAIM CLCL ON MATX.CLCL_ID = CLCL.CLCL_ID  AND MATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"' AND MATX.MATX_ACC_TYPE = '"+accumulatorType+"' AND MATX.ACAC_ACC_NO ="+accumulatorBucketNumber+" AND MATX.MATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND MATX.MEME_CK = "+memberContrivedKey+" AND MATX.MATX_TXN_CTR1!=0 INNER JOIN CMC_PRPR_PROV PRPR ON CLCL.PRPR_ID = PRPR.PRPR_ID UNION ALL SELECT 'AGGREGATE' LINE_DESC,  '' CLCL_ID, MATX_TXN_CTR1, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI    FROM (         SELECT SUM (MATX_TXN_CTR1) MATX_TXN_CTR1, USUS_ID, MATX_STS_IND, MATX_MCTR_RSN                FROM CMC_MATX_ACCUM_TXN         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'         AND MATX_ACC_TYPE = '"+accumulatorType+"'         AND ACAC_ACC_NO = "+accumulatorBucketNumber+"         AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"'         AND MEME_CK = "+memberContrivedKey+"         AND MATX_TXN_CTR1!= 0         AND (CLCL_ID='' OR CLCL_ID=NULL)         GROUP BY USUS_ID, MATX_STS_IND, MATX_MCTR_RSN     ) subq ) subq2";

					}
					 }
				}
				
				else if(Indicator.equalsIgnoreCase("M")) {						
					MessageQuery ="SELECT  TOP 1 GRGR_CK AS GRGRCK FROM CMC_MATX_ACCUM_TXN WHERE   MATX_ACC_TYPE = 'L'	";

				}
				}
				else if ((accumulatorMethodology.equalsIgnoreCase("INDO"))) {
					
					if (Indicator.equalsIgnoreCase("M")) {	
						strQuery ="SELECT  TOP 1 GRGR_CK AS GRGRCK FROM CMC_FATX_ACCUM_TXN WHERE   FATX_ACC_TYPE = 'L'	";
						}					
					else {								
						strQuery= "SELECT distinct PDPD_ACC_SFX AS ProductAccumulatorSuffix FROM CMC_FATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND FATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+accumulatorBucketNumber+" AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"'";
						}
					
					if(Indicator.equalsIgnoreCase("C")) {
						 if (showSensitivityIndicator.equalsIgnoreCase("N") && isSensitiveIndicator.equalsIgnoreCase("Y")  ){
							 BreakdownInformationQuery = "DECLARE @V_MEME_CK  BIGINT     DECLARE @V_SBSB_CK  INT     DECLARE @V_BUCKET   INT     DECLARE @V_MAXIMUM  VARCHAR(10)     SELECT @V_SBSB_CK =  "+subscriberContrivedKey+"     SELECT @V_BUCKET = "+accumulatorBucketNumber+"     SELECT  @V_MAXIMUM = '"+accumulatorMaximum+"'  select  'MAXIMUM' ResponseDescription,         @V_MAXIMUM ResponseValue,         'MAXIMUM'  DisplayResponseDescription,         @V_MAXIMUM  DisplayResponseValue,         '' ClaimType,         '' ClaimStartDateOfService,         '' ClaimEndDateOfService,         '' ClaimAdjudicationDate,         '' ClaimServiceProviderId,         '' ClaimServiceProviderName, '' ClaimServiceProviderNPI  FROM CMC_FATX_ACCUM_TXN FATX WHERE FATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"' AND FATX.FATX_ACC_TYPE = '"+accumulatorType+"' AND FATX.ACAC_ACC_NO = @V_BUCKET AND FATX.FATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND FATX.SBSB_CK = @V_SBSB_CK";
						 }
						 else {
							 
								if(carryoverApplicableIndicator.equalsIgnoreCase("Y")) {
									//benefitBeginDate = carryoverBenefitBeginDate;
						BreakdownInformationQuery ="DECLARE @V_MEME_CK  BIGINT     DECLARE @V_SBSB_CK  INT     DECLARE @V_BUCKET   INT       SELECT @V_MEME_CK = "+memberContrivedKey+"     SELECT @V_SBSB_CK = "+subscriberContrivedKey+"     SELECT @V_BUCKET = "+accumulatorBucketNumber+"  SELECT LINE_DESC,         CASE                   WHEN LINE_DESC = 'AGGREGATE OTHER MEME' then 'Other Contributions'                 WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (FATX_MCTR_RSN = 'PRIM' AND FATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'CARV' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'TYP8' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN FATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (FATX_MCTR_RSN = 'BLUE' AND FATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN FATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (FATX_MCTR_RSN = 'CRED' AND FATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN FATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN FATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END ResponseDescription, CASE                   WHEN LINE_DESC = 'AGGREGATE OTHER MEME' then 'Other Contributions'                 WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (FATX_MCTR_RSN = 'PRIM' AND FATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'CARV' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'TYP8' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN FATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (FATX_MCTR_RSN = 'BLUE' AND FATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN FATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (FATX_MCTR_RSN = 'CRED' AND FATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN FATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN FATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                  ELSE CLCL_ID END DisplayResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName, ClaimServiceProviderNPI FROM (                                 SELECT   'LINE ITEM' LINE_DESC,   FATX.CLCL_ID, FATX.FATX_TXN_AMT2 ResponseValue, FATX.USUS_ID, FATX.FATX_STS_IND, FATX.FATX_MCTR_RSN,                         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,                         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLCL.PRPR_ID ClaimServiceProviderId, PRPR.PRPR_NAME ClaimServiceProviderName,   PRPR.PRPR_NPI  ClaimServiceProviderNPI      FROM CMC_FATX_ACCUM_TXN FATX INNER JOIN CMC_CLCL_CLAIM CLCL ON FATX.CLCL_ID = CLCL.CLCL_ID                  AND FATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                 AND FATX.FATX_ACC_TYPE = '"+accumulatorType+"'                 AND FATX.ACAC_ACC_NO = @V_BUCKET                 AND FATX.FATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"'                 AND FATX.SBSB_CK = @V_SBSB_CK                 AND FATX.MEME_CK= @V_MEME_CK                 AND FATX.FATX_TXN_AMT2!=0                 INNER JOIN CMC_PRPR_PROV PRPR ON CLCL.PRPR_ID = PRPR.PRPR_ID                 UNION ALL                     SELECT 'AGGREGATE' LINE_DESC,  '' CLCL_ID, FATX_TXN_AMT2, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, ''  PRPR_NPI      FROM (                         SELECT SUM (FATX_TXN_AMT2) FATX_TXN_AMT2, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                                FROM CMC_FATX_ACCUM_TXN                         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                         AND FATX_ACC_TYPE = '"+accumulatorType+"'                         AND ACAC_ACC_NO = @V_BUCKET                         AND FATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"'                         AND SBSB_CK = @V_SBSB_CK                         AND MEME_CK = @V_MEME_CK                         AND FATX_TXN_AMT2!= 0                         AND (CLCL_ID='' OR CLCL_ID=NULL)                         GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                     ) subq                 UNION ALL                      SELECT 'AGGREGATE OTHER MEME' LINE_DESC,  '' CLCL_ID, FATX_TXN_AMT2, ' ' USUS_ID, ' ' FATX_STS_IND, ' 'FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME      , '' PRPR_NPI    FROM (                             SELECT SUM(ResponseValue) FATX_TXN_AMT2 FROM (                                 SELECT   'SUM' LINE_DESC,   SUM(FATX.FATX_TXN_AMT2) ResponseValue, FATX.MEME_CK                                 FROM CMC_FATX_ACCUM_TXN FATX                                 WHERE FATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX.FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND FATX.ACAC_ACC_NO = @V_BUCKET                                 AND FATX.FATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"'                                 AND FATX.SBSB_CK = @V_SBSB_CK                                 AND FATX.FATX_TXN_AMT2!=0                                 GROUP BY FATX.MEME_CK                             ) subq3                             WHERE subq3.MEME_CK <> @V_MEME_CK                     ) subq_agg_other_meme  ) subq2 WHERE ResponseValue is not NULL";

								}
								else {
						BreakdownInformationQuery ="DECLARE @V_MEME_CK  BIGINT     DECLARE @V_SBSB_CK  INT     DECLARE @V_BUCKET   INT       SELECT @V_MEME_CK = "+memberContrivedKey+"     SELECT @V_SBSB_CK = "+subscriberContrivedKey+"     SELECT @V_BUCKET = "+accumulatorBucketNumber+"  SELECT LINE_DESC,         CASE                   WHEN LINE_DESC = 'AGGREGATE OTHER MEME' then 'Other Contributions'                 WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (FATX_MCTR_RSN = 'PRIM' AND FATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'CARV' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'TYP8' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN FATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (FATX_MCTR_RSN = 'BLUE' AND FATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN FATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (FATX_MCTR_RSN = 'CRED' AND FATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN FATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN FATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 ELSE CLCL_ID END ResponseDescription, CASE                   WHEN LINE_DESC = 'AGGREGATE OTHER MEME' then 'Other Contributions'                 WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (FATX_MCTR_RSN = 'PRIM' AND FATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'CARV' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'TYP8' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN FATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (FATX_MCTR_RSN = 'BLUE' AND FATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN FATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (FATX_MCTR_RSN = 'CRED' AND FATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN FATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN FATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                  ELSE CLCL_ID END DisplayResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName, ClaimServiceProviderNPI FROM (                                 SELECT   'LINE ITEM' LINE_DESC,   FATX.CLCL_ID, FATX.FATX_TXN_AMT1 ResponseValue, FATX.USUS_ID, FATX.FATX_STS_IND, FATX.FATX_MCTR_RSN,                         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,                         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLCL.PRPR_ID ClaimServiceProviderId, PRPR.PRPR_NAME ClaimServiceProviderName,   PRPR.PRPR_NPI  ClaimServiceProviderNPI      FROM CMC_FATX_ACCUM_TXN FATX INNER JOIN CMC_CLCL_CLAIM CLCL ON FATX.CLCL_ID = CLCL.CLCL_ID                  AND FATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                 AND FATX.FATX_ACC_TYPE = '"+accumulatorType+"'                 AND FATX.ACAC_ACC_NO = @V_BUCKET                 AND FATX.FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                 AND FATX.SBSB_CK = @V_SBSB_CK                 AND FATX.MEME_CK= @V_MEME_CK                 AND FATX.FATX_TXN_AMT1!=0                 INNER JOIN CMC_PRPR_PROV PRPR ON CLCL.PRPR_ID = PRPR.PRPR_ID                 UNION ALL                     SELECT 'AGGREGATE' LINE_DESC,  '' CLCL_ID, FATX_TXN_AMT1, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, ''  PRPR_NPI      FROM (                         SELECT SUM (FATX_TXN_AMT1) FATX_TXN_AMT1, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                                FROM CMC_FATX_ACCUM_TXN                         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                         AND FATX_ACC_TYPE = '"+accumulatorType+"'                         AND ACAC_ACC_NO = @V_BUCKET                         AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                         AND SBSB_CK = @V_SBSB_CK                         AND MEME_CK = @V_MEME_CK                         AND FATX_TXN_AMT1!= 0                         AND (CLCL_ID='' OR CLCL_ID=NULL)                         GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                     ) subq                 UNION ALL                      SELECT 'AGGREGATE OTHER MEME' LINE_DESC,  '' CLCL_ID, FATX_TXN_AMT1, ' ' USUS_ID, ' ' FATX_STS_IND, ' 'FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME      , '' PRPR_NPI    FROM (                             SELECT SUM(ResponseValue) FATX_TXN_AMT1 FROM (                                 SELECT   'SUM' LINE_DESC,   SUM(FATX.FATX_TXN_AMT1) ResponseValue, FATX.MEME_CK                                 FROM CMC_FATX_ACCUM_TXN FATX                                 WHERE FATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX.FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND FATX.ACAC_ACC_NO = @V_BUCKET                                 AND FATX.FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                                 AND FATX.SBSB_CK = @V_SBSB_CK                                 AND FATX.FATX_TXN_AMT1!=0                                 GROUP BY FATX.MEME_CK                             ) subq3                             WHERE subq3.MEME_CK <> @V_MEME_CK                     ) subq_agg_other_meme  ) subq2 WHERE ResponseValue is not NULL";
					}
								}
					}
					else if(Indicator.equalsIgnoreCase("M")) {						
						MessageQuery ="SELECT  TOP 1 GRGR_CK AS GRGRCK FROM CMC_MATX_ACCUM_TXN WHERE   MATX_ACC_TYPE = 'L'	";

					}
					
				}
          else if ((accumulatorMethodology.equalsIgnoreCase("AGGO")) || accumulatorMethodology.equalsIgnoreCase("AGG")) {
					
					if (Indicator.equalsIgnoreCase("M")) {	
						strQuery ="SELECT  TOP 1 GRGR_CK AS GRGRCK FROM CMC_FATX_ACCUM_TXN WHERE   FATX_ACC_TYPE = 'L'	";
						}					
					else {								
						//strQuery ="SELECT distinct MEME_CK AS MemberContrivedKey  FROM CMC_FATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND FATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+accumulatorBucketNumber+" AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND SBSB_CK = "+subscriberContrivedKey+" AND MEME_CK = "+memberContrivedKey+" AND FATX_TXN_AMT1!=0";
						strQuery= "SELECT distinct PDPD_ACC_SFX AS ProductAccumulatorSuffix FROM CMC_FATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND FATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+accumulatorBucketNumber+" AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"'";
					}
					
					if(Indicator.equalsIgnoreCase("C")) {
						 if (showSensitivityIndicator.equalsIgnoreCase("N") && isSensitiveIndicator.equalsIgnoreCase("Y")  ){
							 BreakdownInformationQuery = "DECLARE @V_MEME_CK  BIGINT     DECLARE @V_SBSB_CK  INT     DECLARE @V_BUCKET   INT     DECLARE @V_MAXIMUM  VARCHAR(10)        SELECT @V_SBSB_CK =  "+subscriberContrivedKey+"     SELECT @V_BUCKET = "+accumulatorBucketNumber+"     SELECT  @V_MAXIMUM = '"+accumulatorMaximum+"'  select  'MAXIMUM' ResponseDescription,         @V_MAXIMUM ResponseValue,         'MAXIMUM'  DisplayResponseDescription,         @V_MAXIMUM  DisplayResponseValue,         '' ClaimType,         '' ClaimStartDateOfService,         '' ClaimEndDateOfService,         '' ClaimAdjudicationDate,         '' ClaimServiceProviderId,         '' ClaimServiceProviderName, '' ClaimServiceProviderNPI  FROM CMC_FATX_ACCUM_TXN FATX WHERE FATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"' AND FATX.FATX_ACC_TYPE = '"+accumulatorType+"' AND FATX.ACAC_ACC_NO = @V_BUCKET AND FATX.FATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND FATX.SBSB_CK = @V_SBSB_CK";
						 }
						
						 else {
							 ClaimsQuery= "Select distinct CLCL_PRE_PRICE_IND FROM CMC_FATX_ACCUM_TXN FATX INNER JOIN CMC_CLCL_CLAIM CLCL ON FATX.CLCL_ID = CLCL.CLCL_ID  AND FATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"' AND FATX.FATX_ACC_TYPE = '"+accumulatorType+"' AND FATX.ACAC_ACC_NO = "+accumulatorBucketNumber+" AND FATX.FATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND FATX.MEME_CK = "+memberContrivedKey+" AND FATX.FATX_TXN_AMT1!=0";
								
								org.json.JSONArray itsClaims = ViewClaimsDBS.getMemberInfofromDBS(ClaimsQuery, "Sybase");
								
								if (itsClaims.length()>0) {
									
								String its = itsClaims.getJSONObject(0).getString("CLCL_PRE_PRICE_IND");
								
								if(its.equalsIgnoreCase("H") || (its.equalsIgnoreCase("T"))) {
									
									if(carryoverApplicableIndicator.equalsIgnoreCase("Y")) {
									//	benefitBeginDate = carryoverBenefitBeginDate;
						        BreakdownInformationQuery= "DECLARE @V_MEME_CK  BIGINT     DECLARE @V_SBSB_CK  INT     DECLARE @V_BUCKET   INT      SELECT @V_MEME_CK = "+memberContrivedKey+"     SELECT @V_SBSB_CK =  "+subscriberContrivedKey+"     SELECT @V_BUCKET = "+accumulatorBucketNumber+"   SELECT LINE_DESC, ResponseDescription, ResponseDescription as DisplayResponseDescription, CLCL_ID, ResponseValue, DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName ,ClaimServiceProviderNPI FROM (      SELECT      LINE_DESC,         CASE                   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (FATX_MCTR_RSN = 'PRIM' AND FATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'CARV' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'TYP8' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN FATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (FATX_MCTR_RSN = 'BLUE' AND FATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN FATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (FATX_MCTR_RSN = 'CRED' AND FATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN FATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN FATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 WHEN LINE_DESC = 'AGGREGATE OTHER MEME' THEN OTHER_MESSAGE                 ELSE CLCL_ID END ResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName, ClaimServiceProviderNPI     FROM (                                 SELECT   'LINE ITEM' LINE_DESC,  '' OTHER_MESSAGE, FATX.CLCL_ID, FATX.FATX_TXN_AMT2 ResponseValue, FATX.USUS_ID, FATX.FATX_STS_IND, FATX.FATX_MCTR_RSN,                         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,                         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLPP.CLPP_BCBS_PR_ID ClaimServiceProviderId, CLPP.CLPP_PR_NAME ClaimServiceProviderName  , CLPP.CLPP_BCBS_PR_NPI ClaimServiceProviderNPI     FROM CMC_FATX_ACCUM_TXN FATX INNER JOIN CMC_CLCL_CLAIM CLCL ON FATX.CLCL_ID = CLCL.CLCL_ID                  AND FATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                 AND FATX.FATX_ACC_TYPE = '"+accumulatorType+"'                 AND FATX.ACAC_ACC_NO = @V_BUCKET                 AND FATX.FATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"'                 AND FATX.SBSB_CK = @V_SBSB_CK                 AND FATX.MEME_CK= @V_MEME_CK                 AND FATX.FATX_TXN_AMT2!=0                 INNER JOIN CMC_CLPP_ITS_PROV CLPP ON CLCL.CLCL_ID = CLPP.CLCL_ID               UNION ALL                     SELECT 'AGGREGATE' LINE_DESC,  '' OTHER_MESSAGE,  '' CLCL_ID, FATX_TXN_AMT2, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' CLPP_BCBS_PR_ID, '' CLPP_PR_NAME, '' CLPP_BCBS_PR_NPI     FROM (  SELECT SUM (FATX_TXN_AMT2) FATX_TXN_AMT2, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN   FROM CMC_FATX_ACCUM_TXN                         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                         AND FATX_ACC_TYPE =  '"+accumulatorType+"'                         AND ACAC_ACC_NO = @V_BUCKET                         AND FATX_BEN_BEG_DT =  '"+carryoverBenefitBeginDate+"'                         AND SBSB_CK = @V_SBSB_CK         AND MEME_CK = @V_MEME_CK                         AND FATX_TXN_AMT2!= 0                         AND (CLCL_ID='' OR CLCL_ID=NULL)                         GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                     ) subq                 UNION ALL                      SELECT 'AGGREGATE OTHER MEME' LINE_DESC,  OTHER_MESSAGE, '' CLCL_ID, FATX_TXN_AMT2, USUS_ID, FATX_STS_IND,  FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' CLPP_BCBS_PR_ID, '' CLPP_PR_NAME , '' CLPP_BCBS_PR_NPI      FROM (                                 SELECT SUM (FATX_TXN_AMT2) FATX_TXN_AMT2,  '' USUS_ID, '' FATX_STS_IND, '' FATX_MCTR_RSN, CONVERT(VARCHAR(15), MEME_CK)  OTHER_MESSAGE      FROM CMC_FATX_ACCUM_TXN           WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND ACAC_ACC_NO = @V_BUCKET                                 AND FATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"'                                 AND SBSB_CK = @V_SBSB_CK                                 AND MEME_CK <> @V_MEME_CK                                 AND MEME_CK <> 0                                 AND FATX_TXN_AMT2!= 0                                 GROUP BY CONVERT(VARCHAR(15), MEME_CK)                                 UNION ALL                                 SELECT SUM (FATX_TXN_AMT2) FATX_TXN_AMT2, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN, '' OTHER_MESSAGE                                        FROM CMC_FATX_ACCUM_TXN                                 WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND ACAC_ACC_NO = @V_BUCKET                                 AND FATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"'                                 AND SBSB_CK = @V_SBSB_CK                                 AND MEME_CK = 0                                 AND FATX_TXN_AMT2!= 0                                 GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                             ) subq3      ) subq2  ) subq_main WHERE ResponseValue is not NULL";

									}
									else {
							   BreakdownInformationQuery= "DECLARE @V_MEME_CK  BIGINT     DECLARE @V_SBSB_CK  INT     DECLARE @V_BUCKET   INT      SELECT @V_MEME_CK = "+memberContrivedKey+"     SELECT @V_SBSB_CK =  "+subscriberContrivedKey+"     SELECT @V_BUCKET = "+accumulatorBucketNumber+"   SELECT LINE_DESC, ResponseDescription, ResponseDescription as DisplayResponseDescription, CLCL_ID, ResponseValue, DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName ,ClaimServiceProviderNPI FROM (      SELECT      LINE_DESC,         CASE                   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (FATX_MCTR_RSN = 'PRIM' AND FATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'CARV' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'TYP8' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN FATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (FATX_MCTR_RSN = 'BLUE' AND FATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN FATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (FATX_MCTR_RSN = 'CRED' AND FATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN FATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN FATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 WHEN LINE_DESC = 'AGGREGATE OTHER MEME' THEN OTHER_MESSAGE                 ELSE CLCL_ID END ResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName, ClaimServiceProviderNPI     FROM (                                 SELECT   'LINE ITEM' LINE_DESC,  '' OTHER_MESSAGE, FATX.CLCL_ID, FATX.FATX_TXN_AMT1 ResponseValue, FATX.USUS_ID, FATX.FATX_STS_IND, FATX.FATX_MCTR_RSN,                         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,                         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLPP.CLPP_BCBS_PR_ID ClaimServiceProviderId, CLPP.CLPP_PR_NAME ClaimServiceProviderName  , CLPP.CLPP_BCBS_PR_NPI ClaimServiceProviderNPI     FROM CMC_FATX_ACCUM_TXN FATX INNER JOIN CMC_CLCL_CLAIM CLCL ON FATX.CLCL_ID = CLCL.CLCL_ID                  AND FATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                 AND FATX.FATX_ACC_TYPE = '"+accumulatorType+"'                 AND FATX.ACAC_ACC_NO = @V_BUCKET                 AND FATX.FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                 AND FATX.SBSB_CK = @V_SBSB_CK                 AND FATX.MEME_CK= @V_MEME_CK                 AND FATX.FATX_TXN_AMT1!=0                 INNER JOIN CMC_CLPP_ITS_PROV CLPP ON CLCL.CLCL_ID = CLPP.CLCL_ID               UNION ALL                     SELECT 'AGGREGATE' LINE_DESC,  '' OTHER_MESSAGE,  '' CLCL_ID, FATX_TXN_AMT1, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' CLPP_BCBS_PR_ID, '' CLPP_PR_NAME, '' CLPP_BCBS_PR_NPI     FROM (  SELECT SUM (FATX_TXN_AMT1) FATX_TXN_AMT1, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN   FROM CMC_FATX_ACCUM_TXN                         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                         AND FATX_ACC_TYPE =  '"+accumulatorType+"'                         AND ACAC_ACC_NO = @V_BUCKET                         AND FATX_BEN_BEG_DT =  '"+benefitBeginDate+"'                         AND SBSB_CK = @V_SBSB_CK         AND MEME_CK = @V_MEME_CK                         AND FATX_TXN_AMT1!= 0                         AND (CLCL_ID='' OR CLCL_ID=NULL)                         GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                     ) subq                 UNION ALL                      SELECT 'AGGREGATE OTHER MEME' LINE_DESC,  OTHER_MESSAGE, '' CLCL_ID, FATX_TXN_AMT1, USUS_ID, FATX_STS_IND,  FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' CLPP_BCBS_PR_ID, '' CLPP_PR_NAME , '' CLPP_BCBS_PR_NPI      FROM (                                 SELECT SUM (FATX_TXN_AMT1) FATX_TXN_AMT1,  '' USUS_ID, '' FATX_STS_IND, '' FATX_MCTR_RSN, CONVERT(VARCHAR(15), MEME_CK)  OTHER_MESSAGE      FROM CMC_FATX_ACCUM_TXN           WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND ACAC_ACC_NO = @V_BUCKET                                 AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                                 AND SBSB_CK = @V_SBSB_CK                                 AND MEME_CK <> @V_MEME_CK                                 AND MEME_CK <> 0                                 AND FATX_TXN_AMT1!= 0                                 GROUP BY CONVERT(VARCHAR(15), MEME_CK)                                 UNION ALL                                 SELECT SUM (FATX_TXN_AMT1) FATX_TXN_AMT1, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN, '' OTHER_MESSAGE                                        FROM CMC_FATX_ACCUM_TXN                                 WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND ACAC_ACC_NO = @V_BUCKET                                 AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                                 AND SBSB_CK = @V_SBSB_CK                                 AND MEME_CK = 0                                 AND FATX_TXN_AMT1!= 0                                 GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                             ) subq3      ) subq2  ) subq_main WHERE ResponseValue is not NULL";
								}
									}
								else {	
									if(carryoverApplicableIndicator.equalsIgnoreCase("Y")) {
										//benefitBeginDate = carryoverBenefitBeginDate;
					            BreakdownInformationQuery= "DECLARE @V_MEME_CK  BIGINT     DECLARE @V_SBSB_CK  INT     DECLARE @V_BUCKET   INT      SELECT @V_MEME_CK = "+memberContrivedKey+"     SELECT @V_SBSB_CK =  "+subscriberContrivedKey+"     SELECT @V_BUCKET = "+accumulatorBucketNumber+"   SELECT LINE_DESC, ResponseDescription, ResponseDescription as DisplayResponseDescription, CLCL_ID, ResponseValue, DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName ,ClaimServiceProviderNPI FROM (      SELECT      LINE_DESC,         CASE                   WHEN USUS_ID = 'FA_ACC_SYN' then Pharmacy'                 WHEN (FATX_MCTR_RSN = 'PRIM' AND FATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'CARV' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'TYP8' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN FATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (FATX_MCTR_RSN = 'BLUE' AND FATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN FATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (FATX_MCTR_RSN = 'CRED' AND FATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN FATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN FATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 WHEN LINE_DESC = 'AGGREGATE OTHER MEME' THEN OTHER_MESSAGE                 ELSE CLCL_ID END ResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName, ClaimServiceProviderNPI     FROM (                                 SELECT   'LINE ITEM' LINE_DESC,  '' OTHER_MESSAGE, FATX.CLCL_ID, FATX.FATX_TXN_AMT2 ResponseValue, FATX.USUS_ID, FATX.FATX_STS_IND, FATX.FATX_MCTR_RSN,                         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,                         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLCL.PRPR_ID ClaimServiceProviderId, PRPR.PRPR_NAME ClaimServiceProviderName, PRPR.PRPR_NPI ClaimServiceProviderNPI    FROM CMC_FATX_ACCUM_TXN FATX INNER JOIN CMC_CLCL_CLAIM CLCL ON FATX.CLCL_ID = CLCL.CLCL_ID                  AND FATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                 AND FATX.FATX_ACC_TYPE = '"+accumulatorType+"'                 AND FATX.ACAC_ACC_NO = @V_BUCKET                 AND FATX.FATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"'                 AND FATX.SBSB_CK = @V_SBSB_CK                 AND FATX.MEME_CK= @V_MEME_CK                 AND FATX.FATX_TXN_AMT2!=0                 INNER JOIN CMC_PRPR_PROV PRPR ON CLCL.PRPR_ID = PRPR.PRPR_ID                 UNION ALL                     SELECT 'AGGREGATE' LINE_DESC,  '' OTHER_MESSAGE,  '' CLCL_ID, FATX_TXN_AMT2, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI       FROM (                         SELECT SUM (FATX_TXN_AMT2) FATX_TXN_AMT2, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                                FROM CMC_FATX_ACCUM_TXN                         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                         AND FATX_ACC_TYPE =  '"+accumulatorType+"'                         AND ACAC_ACC_NO = @V_BUCKET                         AND FATX_BEN_BEG_DT =  '"+carryoverBenefitBeginDate+"'                         AND SBSB_CK = @V_SBSB_CK                         AND MEME_CK = @V_MEME_CK                         AND FATX_TXN_AMT2!= 0                         AND (CLCL_ID='' OR CLCL_ID=NULL)                         GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                     ) subq                 UNION ALL                      SELECT 'AGGREGATE OTHER MEME' LINE_DESC,  OTHER_MESSAGE, '' CLCL_ID, FATX_TXN_AMT2, USUS_ID, FATX_STS_IND,  FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI                      FROM (                                 SELECT SUM (FATX_TXN_AMT2) FATX_TXN_AMT2,  '' USUS_ID, '' FATX_STS_IND, '' FATX_MCTR_RSN, CONVERT(VARCHAR(15), MEME_CK)  OTHER_MESSAGE                                        FROM CMC_FATX_ACCUM_TXN                                 WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND ACAC_ACC_NO = @V_BUCKET                                 AND FATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"'                                 AND SBSB_CK = @V_SBSB_CK                                 AND MEME_CK <> @V_MEME_CK                                 AND MEME_CK <> 0                                 AND FATX_TXN_AMT2!= 0                                 GROUP BY CONVERT(VARCHAR(15), MEME_CK)                                 UNION ALL                                 SELECT SUM (FATX_TXN_AMT2) FATX_TXN_AMT2, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN, '' OTHER_MESSAGE                                        FROM CMC_FATX_ACCUM_TXN                                 WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND ACAC_ACC_NO = @V_BUCKET                                 AND FATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"'                                 AND SBSB_CK = @V_SBSB_CK                                 AND MEME_CK = 0                                 AND FATX_TXN_AMT2!= 0                                 GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                             ) subq3      ) subq2  ) subq_main WHERE ResponseValue is not NULL";
					        	org.json.JSONArray carrOver = ViewClaimsDBS.getMemberInfofromDBS(BreakdownInformationQuery, "Sybase");

								if (carrOver.length()<=0) {
									
									   BreakdownInformationQuery= "DECLARE @V_MEME_CK  BIGINT     DECLARE @V_SBSB_CK  INT     DECLARE @V_BUCKET   INT      SELECT @V_MEME_CK = "+memberContrivedKey+"     SELECT @V_SBSB_CK =  "+subscriberContrivedKey+"     SELECT @V_BUCKET = "+accumulatorBucketNumber+"   SELECT LINE_DESC, ResponseDescription, ResponseDescription as DisplayResponseDescription, CLCL_ID, ResponseValue, DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName ,ClaimServiceProviderNPI FROM (      SELECT      LINE_DESC,         CASE                   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (FATX_MCTR_RSN = 'PRIM' AND FATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'CARV' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'TYP8' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN FATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (FATX_MCTR_RSN = 'BLUE' AND FATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN FATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (FATX_MCTR_RSN = 'CRED' AND FATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN FATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN FATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 WHEN LINE_DESC = 'AGGREGATE OTHER MEME' THEN OTHER_MESSAGE                 ELSE CLCL_ID END ResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName, ClaimServiceProviderNPI     FROM (                                 SELECT   'LINE ITEM' LINE_DESC,  '' OTHER_MESSAGE, FATX.CLCL_ID, FATX.FATX_TXN_AMT1 ResponseValue, FATX.USUS_ID, FATX.FATX_STS_IND, FATX.FATX_MCTR_RSN,                         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,                         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLCL.PRPR_ID ClaimServiceProviderId, PRPR.PRPR_NAME ClaimServiceProviderName, PRPR.PRPR_NPI ClaimServiceProviderNPI    FROM CMC_FATX_ACCUM_TXN FATX INNER JOIN CMC_CLCL_CLAIM CLCL ON FATX.CLCL_ID = CLCL.CLCL_ID                  AND FATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                 AND FATX.FATX_ACC_TYPE = '"+accumulatorType+"'                 AND FATX.ACAC_ACC_NO = @V_BUCKET                 AND FATX.FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                 AND FATX.SBSB_CK = @V_SBSB_CK                 AND FATX.MEME_CK= @V_MEME_CK                 AND FATX.FATX_TXN_AMT1!=0                 INNER JOIN CMC_PRPR_PROV PRPR ON CLCL.PRPR_ID = PRPR.PRPR_ID                 UNION ALL                     SELECT 'AGGREGATE' LINE_DESC,  '' OTHER_MESSAGE,  '' CLCL_ID, FATX_TXN_AMT1, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI       FROM (                         SELECT SUM (FATX_TXN_AMT1) FATX_TXN_AMT1, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                                FROM CMC_FATX_ACCUM_TXN                         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                         AND FATX_ACC_TYPE =  '"+accumulatorType+"'                         AND ACAC_ACC_NO = @V_BUCKET                         AND FATX_BEN_BEG_DT =  '"+benefitBeginDate+"'                         AND SBSB_CK = @V_SBSB_CK                         AND MEME_CK = @V_MEME_CK                         AND FATX_TXN_AMT1!= 0                         AND (CLCL_ID='' OR CLCL_ID=NULL)                         GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                     ) subq                 UNION ALL                      SELECT 'AGGREGATE OTHER MEME' LINE_DESC,  OTHER_MESSAGE, '' CLCL_ID, FATX_TXN_AMT1, USUS_ID, FATX_STS_IND,  FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI                      FROM (                                 SELECT SUM (FATX_TXN_AMT1) FATX_TXN_AMT1,  '' USUS_ID, '' FATX_STS_IND, '' FATX_MCTR_RSN, CONVERT(VARCHAR(15), MEME_CK)  OTHER_MESSAGE                                        FROM CMC_FATX_ACCUM_TXN                                 WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND ACAC_ACC_NO = @V_BUCKET                                 AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                                 AND SBSB_CK = @V_SBSB_CK                                 AND MEME_CK <> @V_MEME_CK                                 AND MEME_CK <> 0                                 AND FATX_TXN_AMT1!= 0                                 GROUP BY CONVERT(VARCHAR(15), MEME_CK)                                 UNION ALL                                 SELECT SUM (FATX_TXN_AMT1) FATX_TXN_AMT1, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN, '' OTHER_MESSAGE                                        FROM CMC_FATX_ACCUM_TXN                                 WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND ACAC_ACC_NO = @V_BUCKET                                 AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                                 AND SBSB_CK = @V_SBSB_CK                                 AND MEME_CK = 0                                 AND FATX_TXN_AMT1!= 0                                 GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                             ) subq3      ) subq2  ) subq_main WHERE ResponseValue is not NULL";

								}
								}
									else {
							   BreakdownInformationQuery= "DECLARE @V_MEME_CK  BIGINT     DECLARE @V_SBSB_CK  INT     DECLARE @V_BUCKET   INT      SELECT @V_MEME_CK = "+memberContrivedKey+"     SELECT @V_SBSB_CK =  "+subscriberContrivedKey+"     SELECT @V_BUCKET = "+accumulatorBucketNumber+"   SELECT LINE_DESC, ResponseDescription, ResponseDescription as DisplayResponseDescription, CLCL_ID, ResponseValue, DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName ,ClaimServiceProviderNPI FROM (      SELECT      LINE_DESC,         CASE                   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (FATX_MCTR_RSN = 'PRIM' AND FATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'CARV' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'TYP8' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN FATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (FATX_MCTR_RSN = 'BLUE' AND FATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN FATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (FATX_MCTR_RSN = 'CRED' AND FATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN FATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN FATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 WHEN LINE_DESC = 'AGGREGATE OTHER MEME' THEN OTHER_MESSAGE                 ELSE CLCL_ID END ResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName, ClaimServiceProviderNPI     FROM (                                 SELECT   'LINE ITEM' LINE_DESC,  '' OTHER_MESSAGE, FATX.CLCL_ID, FATX.FATX_TXN_AMT1 ResponseValue, FATX.USUS_ID, FATX.FATX_STS_IND, FATX.FATX_MCTR_RSN,                         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,                         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLCL.PRPR_ID ClaimServiceProviderId, PRPR.PRPR_NAME ClaimServiceProviderName, PRPR.PRPR_NPI ClaimServiceProviderNPI    FROM CMC_FATX_ACCUM_TXN FATX INNER JOIN CMC_CLCL_CLAIM CLCL ON FATX.CLCL_ID = CLCL.CLCL_ID                  AND FATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                 AND FATX.FATX_ACC_TYPE = '"+accumulatorType+"'                 AND FATX.ACAC_ACC_NO = @V_BUCKET                 AND FATX.FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                 AND FATX.SBSB_CK = @V_SBSB_CK                 AND FATX.MEME_CK= @V_MEME_CK                 AND FATX.FATX_TXN_AMT1!=0                 INNER JOIN CMC_PRPR_PROV PRPR ON CLCL.PRPR_ID = PRPR.PRPR_ID                 UNION ALL                     SELECT 'AGGREGATE' LINE_DESC,  '' OTHER_MESSAGE,  '' CLCL_ID, FATX_TXN_AMT1, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI       FROM (                         SELECT SUM (FATX_TXN_AMT1) FATX_TXN_AMT1, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                                FROM CMC_FATX_ACCUM_TXN                         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                         AND FATX_ACC_TYPE =  '"+accumulatorType+"'                         AND ACAC_ACC_NO = @V_BUCKET                         AND FATX_BEN_BEG_DT =  '"+benefitBeginDate+"'                         AND SBSB_CK = @V_SBSB_CK                         AND MEME_CK = @V_MEME_CK                         AND FATX_TXN_AMT1!= 0                         AND (CLCL_ID='' OR CLCL_ID=NULL)                         GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                     ) subq                 UNION ALL                      SELECT 'AGGREGATE OTHER MEME' LINE_DESC,  OTHER_MESSAGE, '' CLCL_ID, FATX_TXN_AMT1, USUS_ID, FATX_STS_IND,  FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI                      FROM (                                 SELECT SUM (FATX_TXN_AMT1) FATX_TXN_AMT1,  '' USUS_ID, '' FATX_STS_IND, '' FATX_MCTR_RSN, CONVERT(VARCHAR(15), MEME_CK)  OTHER_MESSAGE                                        FROM CMC_FATX_ACCUM_TXN                                 WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND ACAC_ACC_NO = @V_BUCKET                                 AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                                 AND SBSB_CK = @V_SBSB_CK                                 AND MEME_CK <> @V_MEME_CK                                 AND MEME_CK <> 0                                 AND FATX_TXN_AMT1!= 0                                 GROUP BY CONVERT(VARCHAR(15), MEME_CK)                                 UNION ALL                                 SELECT SUM (FATX_TXN_AMT1) FATX_TXN_AMT1, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN, '' OTHER_MESSAGE                                        FROM CMC_FATX_ACCUM_TXN                                 WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND ACAC_ACC_NO = @V_BUCKET                                 AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                                 AND SBSB_CK = @V_SBSB_CK                                 AND MEME_CK = 0                                 AND FATX_TXN_AMT1!= 0                                 GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                             ) subq3      ) subq2  ) subq_main WHERE ResponseValue is not NULL";
								}
									}
								}
								else {
									if(carryoverApplicableIndicator.equalsIgnoreCase("Y")) {
									//	benefitBeginDate = carryoverBenefitBeginDate;
					           BreakdownInformationQuery= "DECLARE @V_MEME_CK  BIGINT     DECLARE @V_SBSB_CK  INT     DECLARE @V_BUCKET   INT      SELECT @V_MEME_CK = "+memberContrivedKey+"     SELECT @V_SBSB_CK =  "+subscriberContrivedKey+"     SELECT @V_BUCKET = "+accumulatorBucketNumber+"   SELECT LINE_DESC, ResponseDescription, ResponseDescription as DisplayResponseDescription, CLCL_ID, ResponseValue, DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName ,ClaimServiceProviderNPI FROM (      SELECT      LINE_DESC,         CASE                   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (FATX_MCTR_RSN = 'PRIM' AND FATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'CARV' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'TYP8' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN FATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (FATX_MCTR_RSN = 'BLUE' AND FATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN FATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (FATX_MCTR_RSN = 'CRED' AND FATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN FATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN FATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 WHEN LINE_DESC = 'AGGREGATE OTHER MEME' THEN OTHER_MESSAGE                 ELSE CLCL_ID END ResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName, ClaimServiceProviderNPI     FROM (                                 SELECT   'LINE ITEM' LINE_DESC,  '' OTHER_MESSAGE, FATX.CLCL_ID, FATX.FATX_TXN_AMT2 ResponseValue, FATX.USUS_ID, FATX.FATX_STS_IND, FATX.FATX_MCTR_RSN,                         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,                         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLCL.PRPR_ID ClaimServiceProviderId, PRPR.PRPR_NAME ClaimServiceProviderName, PRPR.PRPR_NPI ClaimServiceProviderNPI      FROM CMC_FATX_ACCUM_TXN FATX INNER JOIN CMC_CLCL_CLAIM CLCL ON FATX.CLCL_ID = CLCL.CLCL_ID                  AND FATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                 AND FATX.FATX_ACC_TYPE = '"+accumulatorType+"'                 AND FATX.ACAC_ACC_NO = @V_BUCKET                 AND FATX.FATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"'                 AND FATX.SBSB_CK = @V_SBSB_CK                 AND FATX.MEME_CK= @V_MEME_CK                 AND FATX.FATX_TXN_AMT2!=0                 INNER JOIN CMC_PRPR_PROV PRPR ON CLCL.PRPR_ID = PRPR.PRPR_ID                 UNION ALL                     SELECT 'AGGREGATE' LINE_DESC,  '' OTHER_MESSAGE,  '' CLCL_ID, FATX_TXN_AMT2, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI      FROM (                         SELECT SUM (FATX_TXN_AMT2) FATX_TXN_AMT2, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                                FROM CMC_FATX_ACCUM_TXN                         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                         AND FATX_ACC_TYPE =  '"+accumulatorType+"'                         AND ACAC_ACC_NO = @V_BUCKET                         AND FATX_BEN_BEG_DT =  '"+carryoverBenefitBeginDate+"'                         AND SBSB_CK = @V_SBSB_CK                         AND MEME_CK = @V_MEME_CK                         AND FATX_TXN_AMT2!= 0                         AND (CLCL_ID='' OR CLCL_ID=NULL)                         GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                     ) subq                 UNION ALL                      SELECT 'AGGREGATE OTHER MEME' LINE_DESC,  OTHER_MESSAGE, '' CLCL_ID, FATX_TXN_AMT2, USUS_ID, FATX_STS_IND,  FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI                      FROM (                                 SELECT SUM (FATX_TXN_AMT2) FATX_TXN_AMT2,  '' USUS_ID, '' FATX_STS_IND, '' FATX_MCTR_RSN, CONVERT(VARCHAR(15), MEME_CK)  OTHER_MESSAGE                                        FROM CMC_FATX_ACCUM_TXN                                 WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND ACAC_ACC_NO = @V_BUCKET                                 AND FATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"'                                 AND SBSB_CK = @V_SBSB_CK                                 AND MEME_CK <> @V_MEME_CK                                 AND MEME_CK <> 0                                 AND FATX_TXN_AMT2!= 0                                 GROUP BY CONVERT(VARCHAR(15), MEME_CK)                                 UNION ALL                                 SELECT SUM (FATX_TXN_AMT2) FATX_TXN_AMT2, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN, '' OTHER_MESSAGE                                        FROM CMC_FATX_ACCUM_TXN                                 WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND ACAC_ACC_NO = @V_BUCKET                                 AND FATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"'                                 AND SBSB_CK = @V_SBSB_CK                                 AND MEME_CK = 0                                 AND FATX_TXN_AMT2!= 0                                 GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                             ) subq3      ) subq2  ) subq_main WHERE ResponseValue is not NULL";
					           org.json.JSONArray carrOver = ViewClaimsDBS.getMemberInfofromDBS(BreakdownInformationQuery, "Sybase");

								if (carrOver.length()<=0) {
									   BreakdownInformationQuery= "DECLARE @V_MEME_CK  BIGINT     DECLARE @V_SBSB_CK  INT     DECLARE @V_BUCKET   INT      SELECT @V_MEME_CK = "+memberContrivedKey+"     SELECT @V_SBSB_CK =  "+subscriberContrivedKey+"     SELECT @V_BUCKET = "+accumulatorBucketNumber+"   SELECT LINE_DESC, ResponseDescription, ResponseDescription as DisplayResponseDescription, CLCL_ID, ResponseValue, DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName ,ClaimServiceProviderNPI FROM (      SELECT      LINE_DESC,         CASE                   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (FATX_MCTR_RSN = 'PRIM' AND FATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'CARV' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'TYP8' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN FATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (FATX_MCTR_RSN = 'BLUE' AND FATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN FATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (FATX_MCTR_RSN = 'CRED' AND FATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN FATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN FATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 WHEN LINE_DESC = 'AGGREGATE OTHER MEME' THEN OTHER_MESSAGE                 ELSE CLCL_ID END ResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName, ClaimServiceProviderNPI     FROM (                                 SELECT   'LINE ITEM' LINE_DESC,  '' OTHER_MESSAGE, FATX.CLCL_ID, FATX.FATX_TXN_AMT1 ResponseValue, FATX.USUS_ID, FATX.FATX_STS_IND, FATX.FATX_MCTR_RSN,                         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,                         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLCL.PRPR_ID ClaimServiceProviderId, PRPR.PRPR_NAME ClaimServiceProviderName, PRPR.PRPR_NPI ClaimServiceProviderNPI      FROM CMC_FATX_ACCUM_TXN FATX INNER JOIN CMC_CLCL_CLAIM CLCL ON FATX.CLCL_ID = CLCL.CLCL_ID                  AND FATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                 AND FATX.FATX_ACC_TYPE = '"+accumulatorType+"'                 AND FATX.ACAC_ACC_NO = @V_BUCKET                 AND FATX.FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                 AND FATX.SBSB_CK = @V_SBSB_CK                 AND FATX.MEME_CK= @V_MEME_CK                 AND FATX.FATX_TXN_AMT1!=0                 INNER JOIN CMC_PRPR_PROV PRPR ON CLCL.PRPR_ID = PRPR.PRPR_ID                 UNION ALL                     SELECT 'AGGREGATE' LINE_DESC,  '' OTHER_MESSAGE,  '' CLCL_ID, FATX_TXN_AMT1, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI      FROM (                         SELECT SUM (FATX_TXN_AMT1) FATX_TXN_AMT1, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                                FROM CMC_FATX_ACCUM_TXN                         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                         AND FATX_ACC_TYPE =  '"+accumulatorType+"'                         AND ACAC_ACC_NO = @V_BUCKET                         AND FATX_BEN_BEG_DT =  '"+benefitBeginDate+"'                         AND SBSB_CK = @V_SBSB_CK                         AND MEME_CK = @V_MEME_CK                         AND FATX_TXN_AMT1!= 0                         AND (CLCL_ID='' OR CLCL_ID=NULL)                         GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                     ) subq                 UNION ALL                      SELECT 'AGGREGATE OTHER MEME' LINE_DESC,  OTHER_MESSAGE, '' CLCL_ID, FATX_TXN_AMT1, USUS_ID, FATX_STS_IND,  FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI                      FROM (                                 SELECT SUM (FATX_TXN_AMT1) FATX_TXN_AMT1,  '' USUS_ID, '' FATX_STS_IND, '' FATX_MCTR_RSN, CONVERT(VARCHAR(15), MEME_CK)  OTHER_MESSAGE                                        FROM CMC_FATX_ACCUM_TXN                                 WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND ACAC_ACC_NO = @V_BUCKET                                 AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                                 AND SBSB_CK = @V_SBSB_CK                                 AND MEME_CK <> @V_MEME_CK                                 AND MEME_CK <> 0                                 AND FATX_TXN_AMT1!= 0                                 GROUP BY CONVERT(VARCHAR(15), MEME_CK)                                 UNION ALL                                 SELECT SUM (FATX_TXN_AMT1) FATX_TXN_AMT1, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN, '' OTHER_MESSAGE                                        FROM CMC_FATX_ACCUM_TXN                                 WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND ACAC_ACC_NO = @V_BUCKET                                 AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                                 AND SBSB_CK = @V_SBSB_CK                                 AND MEME_CK = 0                                 AND FATX_TXN_AMT1!= 0                                 GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                             ) subq3      ) subq2  ) subq_main WHERE ResponseValue is not NULL";

									}}
									else {
							   BreakdownInformationQuery= "DECLARE @V_MEME_CK  BIGINT     DECLARE @V_SBSB_CK  INT     DECLARE @V_BUCKET   INT      SELECT @V_MEME_CK = "+memberContrivedKey+"     SELECT @V_SBSB_CK =  "+subscriberContrivedKey+"     SELECT @V_BUCKET = "+accumulatorBucketNumber+"   SELECT LINE_DESC, ResponseDescription, ResponseDescription as DisplayResponseDescription, CLCL_ID, ResponseValue, DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName ,ClaimServiceProviderNPI FROM (      SELECT      LINE_DESC,         CASE                   WHEN USUS_ID = 'FA_ACC_SYN' then 'Pharmacy'                 WHEN (FATX_MCTR_RSN = 'PRIM' AND FATX_STS_IND = 'M') then 'Pharmacy'                 WHEN USUS_ID = 'ACCUMDENTA' then 'Dental (click to view claims)'                   WHEN USUS_ID = 'ACCUMVSN' then 'Vision (click to view claims)'                 WHEN USUS_ID = 'ACCUMCAT' then 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'CARV' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN (FATX_MCTR_RSN = 'TYP8' AND FATX_STS_IND = 'M') THEN 'Opt-out Pharmacy'                 WHEN FATX_STS_IND = 'Z' then 'Historically Converted'                 WHEN (FATX_MCTR_RSN = 'BLUE' AND FATX_STS_IND = 'M') THEN 'Historically Converted'                 WHEN FATX_STS_IND = 'X'  then 'Prior Insurer Transferred'                 WHEN (FATX_MCTR_RSN = 'CRED' AND FATX_STS_IND = 'M') THEN 'Prior Insurer Transferred'                 WHEN FATX_MCTR_RSN = 'MADJ' THEN 'Manually Entered'                 WHEN FATX_MCTR_RSN = 'SYST' THEN 'Manually Entered'                 WHEN LINE_DESC = 'AGGREGATE OTHER MEME' THEN OTHER_MESSAGE                 ELSE CLCL_ID END ResponseDescription,         CLCL_ID, ResponseValue, ResponseValue as DisplayResponseValue, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,         ClaimType, ClaimStartDateOfService, ClaimEndDateOfService,         ClaimAdjudicationDate, ClaimServiceProviderId, ClaimServiceProviderName, ClaimServiceProviderNPI     FROM (                                 SELECT   'LINE ITEM' LINE_DESC,  '' OTHER_MESSAGE, FATX.CLCL_ID, FATX.FATX_TXN_AMT1 ResponseValue, FATX.USUS_ID, FATX.FATX_STS_IND, FATX.FATX_MCTR_RSN,                         CLCL.CLCL_CL_TYPE ClaimType, CLCL.CLCL_LOW_SVC_DT ClaimStartDateOfService, CLCL.CLCL_HIGH_SVC_DT ClaimEndDateOfService,                         CLCL.CLCL_ACPT_DTM  ClaimAdjudicationDate, CLCL.PRPR_ID ClaimServiceProviderId, PRPR.PRPR_NAME ClaimServiceProviderName, PRPR.PRPR_NPI ClaimServiceProviderNPI      FROM CMC_FATX_ACCUM_TXN FATX INNER JOIN CMC_CLCL_CLAIM CLCL ON FATX.CLCL_ID = CLCL.CLCL_ID                  AND FATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                 AND FATX.FATX_ACC_TYPE = '"+accumulatorType+"'                 AND FATX.ACAC_ACC_NO = @V_BUCKET                 AND FATX.FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                 AND FATX.SBSB_CK = @V_SBSB_CK                 AND FATX.MEME_CK= @V_MEME_CK                 AND FATX.FATX_TXN_AMT1!=0                 INNER JOIN CMC_PRPR_PROV PRPR ON CLCL.PRPR_ID = PRPR.PRPR_ID                 UNION ALL                     SELECT 'AGGREGATE' LINE_DESC,  '' OTHER_MESSAGE,  '' CLCL_ID, FATX_TXN_AMT1, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI      FROM (                         SELECT SUM (FATX_TXN_AMT1) FATX_TXN_AMT1, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                                FROM CMC_FATX_ACCUM_TXN                         WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                         AND FATX_ACC_TYPE =  '"+accumulatorType+"'                         AND ACAC_ACC_NO = @V_BUCKET                         AND FATX_BEN_BEG_DT =  '"+benefitBeginDate+"'                         AND SBSB_CK = @V_SBSB_CK                         AND MEME_CK = @V_MEME_CK                         AND FATX_TXN_AMT1!= 0                         AND (CLCL_ID='' OR CLCL_ID=NULL)                         GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                     ) subq                 UNION ALL                      SELECT 'AGGREGATE OTHER MEME' LINE_DESC,  OTHER_MESSAGE, '' CLCL_ID, FATX_TXN_AMT1, USUS_ID, FATX_STS_IND,  FATX_MCTR_RSN,  '' CLCL_CL_TYPE ,  NULL CLCL_LOW_SVC_DT, NULL CLCL_HIGH_SVC_DT, NULL  CLCL_ACPT_DTM, '' PRPR_ID, '' PRPR_NAME, '' PRPR_NPI                      FROM (                                 SELECT SUM (FATX_TXN_AMT1) FATX_TXN_AMT1,  '' USUS_ID, '' FATX_STS_IND, '' FATX_MCTR_RSN, CONVERT(VARCHAR(15), MEME_CK)  OTHER_MESSAGE                                        FROM CMC_FATX_ACCUM_TXN                                 WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND ACAC_ACC_NO = @V_BUCKET                                 AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                                 AND SBSB_CK = @V_SBSB_CK                                 AND MEME_CK <> @V_MEME_CK                                 AND MEME_CK <> 0                                 AND FATX_TXN_AMT1!= 0                                 GROUP BY CONVERT(VARCHAR(15), MEME_CK)                                 UNION ALL                                 SELECT SUM (FATX_TXN_AMT1) FATX_TXN_AMT1, USUS_ID, FATX_STS_IND, FATX_MCTR_RSN, '' OTHER_MESSAGE                                        FROM CMC_FATX_ACCUM_TXN                                 WHERE PDPD_ACC_SFX = '"+productAccumulatorSuffix+"'                                 AND FATX_ACC_TYPE = '"+accumulatorType+"'                                 AND ACAC_ACC_NO = @V_BUCKET                                 AND FATX_BEN_BEG_DT = '"+benefitBeginDate+"'                                 AND SBSB_CK = @V_SBSB_CK                                 AND MEME_CK = 0                                 AND FATX_TXN_AMT1!= 0                                 GROUP BY USUS_ID, FATX_STS_IND, FATX_MCTR_RSN                             ) subq3      ) subq2  ) subq_main WHERE ResponseValue is not NULL";
									}
								}

								}
					}
					else if(Indicator.equalsIgnoreCase("M")) {						
						MessageQuery ="SELECT  TOP 1 GRGR_CK AS GRGRCK FROM CMC_MATX_ACCUM_TXN WHERE   MATX_ACC_TYPE = 'L'	";

					}
					
				}
						
          else {
        	  
        	  
        	  if (Indicator.equalsIgnoreCase("M")) {	
					strQuery ="SELECT  TOP 1 GRGR_CK AS GRGRCK FROM CMC_MATX_ACCUM_TXN WHERE   MATX_ACC_TYPE = 'L'	";
					}
					else {  						
					strQuery = "SELECT distinct PDPD_ACC_SFX AS ProductAccumulatorSuffix  FROM CMC_MATX_ACCUM_TXN WHERE PDPD_ACC_SFX =  '"+productAccumulatorSuffix+"' AND MATX_ACC_TYPE =  '"+accumulatorType+"' AND ACAC_ACC_NO = "+accumulatorBucketNumber+" AND MATX_BEN_BEG_DT = '"+benefitBeginDate+"'";
					}
        	  
     	  
        	  if(Indicator.equalsIgnoreCase("C")) {
        		  if (showSensitivityIndicator.equalsIgnoreCase("N") && isSensitiveIndicator.equalsIgnoreCase("Y")  ){
						 BreakdownInformationQuery = "DECLARE @V_MEME_CK  BIGINT     DECLARE @V_SBSB_CK  INT     DECLARE @V_BUCKET   INT     DECLARE @V_MAXIMUM  VARCHAR(10)        SELECT @V_SBSB_CK =  "+subscriberContrivedKey+"     SELECT @V_BUCKET = "+accumulatorBucketNumber+"     SELECT  @V_MAXIMUM = '"+accumulatorMaximum+"'  select  'MAXIMUM' ResponseDescription,         @V_MAXIMUM ResponseValue,         'MAXIMUM'  DisplayResponseDescription,         @V_MAXIMUM  DisplayResponseValue,         '' ClaimType,         '' ClaimStartDateOfService,         '' ClaimEndDateOfService,         '' ClaimAdjudicationDate,         '' ClaimServiceProviderId,         '' ClaimServiceProviderName, '' ClaimServiceProviderNPI  FROM CMC_FATX_ACCUM_TXN FATX WHERE FATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"' AND FATX.FATX_ACC_TYPE = '"+accumulatorType+"' AND FATX.ACAC_ACC_NO = @V_BUCKET AND FATX.FATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND FATX.SBSB_CK = @V_SBSB_CK";
        		  }
        		  
        		  else {
        			  if(carryoverApplicableIndicator.equalsIgnoreCase("Y")) {
        				//	benefitBeginDate = carryoverBenefitBeginDate;
	          BreakdownInformationQuery = "DECLARE @V_MEME_CK  BIGINT     DECLARE @V_SBSB_CK  INT     DECLARE @V_BUCKET   INT     DECLARE @V_MAXIMUM  INT      SELECT @V_SBSB_CK =  "+subscriberContrivedKey+"     SELECT @V_BUCKET = "+accumulatorBucketNumber+"     SELECT  @V_MAXIMUM = "+accumulatorMaximum+"  select  MEME_CK             ResponseDescription,         '1' ResponseValue,         MEME_CK  DisplayResponseDescription,         '1'  DisplayResponseValue,         '' ClaimType,         '' ClaimStartDateOfService,         '' ClaimEndDateOfService,         '' ClaimAdjudicationDate,         '' ClaimServiceProviderId,         '' ClaimServiceProviderName,    '' ClaimServiceProviderNPI from ( select MATX.MEME_CK, SUM(MATX_TXN_AMT2) max_txn FROM CMC_MATX_ACCUM_TXN MATX INNER JOIN CMC_MEME_MEMBER meme on meme.MEME_CK = MATX.MEME_CK INNER JOIN CMC_SBSB_SUBSC sbsb on sbsb.SBSB_CK = meme.SBSB_CK WHERE MATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"' AND MATX.MATX_ACC_TYPE = '"+accumulatorType+"' AND MATX.ACAC_ACC_NO = @V_BUCKET AND MATX.MATX_BEN_BEG_DT = '"+carryoverBenefitBeginDate+"' AND sbsb.SBSB_CK = @V_SBSB_CK GROUP BY MATX.MEME_CK ) subq where subq.max_txn >= @V_MAXIMUM";							
  
        			  }
        			  else {
              BreakdownInformationQuery = "DECLARE @V_MEME_CK  BIGINT     DECLARE @V_SBSB_CK  INT     DECLARE @V_BUCKET   INT     DECLARE @V_MAXIMUM  INT      SELECT @V_SBSB_CK =  "+subscriberContrivedKey+"     SELECT @V_BUCKET = "+accumulatorBucketNumber+"     SELECT  @V_MAXIMUM = "+accumulatorMaximum+"  select  MEME_CK             ResponseDescription,         '1' ResponseValue,         MEME_CK  DisplayResponseDescription,         '1'  DisplayResponseValue,         '' ClaimType,         '' ClaimStartDateOfService,         '' ClaimEndDateOfService,         '' ClaimAdjudicationDate,         '' ClaimServiceProviderId,         '' ClaimServiceProviderName,    '' ClaimServiceProviderNPI from ( select MATX.MEME_CK, SUM(MATX_TXN_AMT1) max_txn FROM CMC_MATX_ACCUM_TXN MATX INNER JOIN CMC_MEME_MEMBER meme on meme.MEME_CK = MATX.MEME_CK INNER JOIN CMC_SBSB_SUBSC sbsb on sbsb.SBSB_CK = meme.SBSB_CK WHERE MATX.PDPD_ACC_SFX = '"+productAccumulatorSuffix+"' AND MATX.MATX_ACC_TYPE = '"+accumulatorType+"' AND MATX.ACAC_ACC_NO = @V_BUCKET AND MATX.MATX_BEN_BEG_DT = '"+benefitBeginDate+"' AND sbsb.SBSB_CK = @V_SBSB_CK GROUP BY MATX.MEME_CK ) subq where subq.max_txn >= @V_MAXIMUM";							
				}}
        	  }
				else if(Indicator.equalsIgnoreCase("M")) {						
					MessageQuery ="SELECT  TOP 1 GRGR_CK AS GRGRCK FROM CMC_MATX_ACCUM_TXN WHERE   MATX_ACC_TYPE = 'L'	";

				}
        	  
          }
				
				Assert.done("Start-> Validation of the Static Data");
				Map<String, String> map = new HashMap<>();
				map.put("SubscriberContrivedKey", subscriberContrivedKey);
			//	if(Indicator.equalsIgnoreCase("M")) {
					map.put("MemberContrivedKey", memberContrivedKey);
				//	}
				map.put("UserId", userId);
				map.put("ProductAccumulatorSuffix", productAccumulatorSuffix);
				map.put("BenefitBeginDate", benefitBeginDate);
				map.put("ShowSensitivityIndicator", showSensitivityIndicator);
				map.put("AccumulatorType", accumulatorType);
				map.put("AccumulatorBucketNumber", accumulatorBucketNumber);
				map.put("BenefitBeginDate", benefitBeginDate);
				map.put("AccumulatorMethodology", accumulatorMethodology);
				map.put("CarryoverApplicableIndicator", carryoverApplicableIndicator);
				map.put("CarryoverBenefitBeginDate", carryoverBenefitBeginDate);
				map.put("IsSensitiveIndicator", isSensitiveIndicator);
				map.put("AccumulatorMaximum", accumulatorMaximum);

				ValidateMethods.validateStaticFieldsWithDbUsingMap(ClaimObj, strQuery, "Sybase", ReportFilePath, map);

				Assert.done("Start-> Validation of the Dynamic Data with DB");

				String AccumDetail = "ResponseFields";
				String uniqueColumn = null;
				if(Indicator.equalsIgnoreCase("C")) {
					uniqueColumn = "ResponseDescription";
					ValidateMethods.validateJsonArrayDataWithDbAccum(ClaimObj, AccumDetail, BreakdownInformationQuery,
							uniqueColumn, "Sybase", ReportFilePath,showSensitivityIndicator,accumulatorMethodology, isSensitiveIndicator);
					
				
				}
				else if (Indicator.equalsIgnoreCase("M")) {
					Map<String, String> map1 = new HashMap<>();
					map1.put("ResponseType", responseType);
					map1.put("ResponseDescription", responseDescription);
					map1.put("ResponseValue", responseValue);
					map1.put("DisplayResponseDescription", displayResponseDescription);
					map1.put("DisplayResponseValue", displayResponseValue);
					map1.put("ClaimType", claimType);
					map1.put("ClaimStartDateOfService", claimStartDateOfService);
					map1.put("ClaimEndDateOfService", claimEndDateOfService);
					map1.put("ClaimAdjudicationDate", claimAdjudicationDate);
					map1.put("ClaimServiceProviderId", claimServiceProviderId);
					map1.put("ClaimServiceProviderName", claimServiceProviderName);
						uniqueColumn = "AccumulatorType";
				
					ValidateMethods.validateJsonArrayDataWithDBUsingMap(ClaimObj, AccumDetail,
							MessageQuery, uniqueColumn, "Sybase", ReportFilePath,map1,service);
					
				}
			} catch (Exception e) {
				Assert.done("Completed");
			}
		} else {

			Assert.done("Test ID: " + testID);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg");
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {
					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
				Assert.fail(content);
			}
		}
	}

	/**
	 * Validate the JSon Array with DB data
	 * 
	 * @param ClaimObj
	 *            = JSON Object
	 * @param strArrayName
	 *            = JSON Array name
	 * @param strQuery
	 *            = DB Query used
	 * @param strUniqueColName
	 *            = Unique column name
	 * @throws Exception
	 */

	public static void validateJsonArrayDataWithDbAccum(JSONObject ClaimObj, String strArrayName, String strQuery,
			String strUniqueColName, String DB, String ReportFilePath, String showSensitivityIndicator,
			String accumulatorMethodology, String isSensitiveIndicator) throws Exception {
		JSONArray responseClaimLineDetails = (JSONArray) ClaimObj.get(strArrayName);
		org.json.JSONArray dbClaimLineDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, DB);

		if (responseClaimLineDetails.size() == dbClaimLineDetails.length()) {

			Map<String, Object> strCLaimDetailsRes = null;
			JSONObject response = null;
			Map<String, Object> db_data = null;
			org.json.JSONObject db_response = null;

			boolean errorflag = false;
			boolean validateflag = true;

			// Comparing Response data with db row
			for (int j = 0; j < responseClaimLineDetails.size(); j++) {
				int k = j * 2 + 1; // 1,3,5
				int l = j * 2 + 2; // 2,4,6
				response = (JSONObject) responseClaimLineDetails.get(j);
				strCLaimDetailsRes = UtilMethod.readJsonData(response);
				Assert.done("Validating " + j + " row DB values with response");
				for (int i = 0; i < dbClaimLineDetails.length(); i++) {
					db_response = (org.json.JSONObject) dbClaimLineDetails.get(i);
					db_data = UtilMethod.readJsonData(db_response);
					if (strCLaimDetailsRes.get(strUniqueColName).toString()
							.equalsIgnoreCase(db_data.get(strUniqueColName).toString())) {
						break;
					}
				}
				Set<String> jsonKeys = strCLaimDetailsRes.keySet();
				for (String tagname : jsonKeys) {
					Object Value = strCLaimDetailsRes.get(tagname);
					 UtilMethod.setCellData(tagname, Value, k, ReportFilePath);

					UtilMethod.validateJSONObjectAccum(db_data, tagname, Value, l, ReportFilePath,
							showSensitivityIndicator, accumulatorMethodology, isSensitiveIndicator);

				}
			}

		} else {
			UtilMethod.Log(
					"Cannot validate as the Json response claim line details record size is not matching with DB response claim line details records.. please check the query you are passing",
					"FAIL", true);
			throw new Exception(
					"Cannot validate claim line details with db as size is not matching.. please check the query you are passing...");
		}

	}
	
	public static void validateGetCDHPSummary(String content, String testID, String env) throws Exception {
		boolean flag = true;
		boolean flag1 = false;
		int i=0, j=0, k=0;
		//String testdir = Environment.get("GetCDHPSummary_Base_Dir");
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";
		DataTable1 Dttestdata = new DataTable1(testdir + "CDHPSummary.xls", "GetCDHPSummary","" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String testDesc = Dttestdata.getValue("Test_Description");
		
		String staticQuery = "";
		String ReportFilePath = "";
		String value="";
		if (!content.contains("\"errorCode\"")) {
			flag1 = true;
		}  
		if (flag1) {
			Assert.done("TestCaseID :"+testID);
			Assert.done("Test Description "+testDesc);	
			Assert.done("Validating static fields");
			String ParentGroupId = Dttestdata.getValue("ParentGroupId");
			String SubscriberId = Dttestdata.getValue("SubscriberId");
			String TestData[]= {ParentGroupId, SubscriberId};
			System.out.println(content);
			Object obj = jsonparser.parse(content);
			JSONObject CDHPObj = (JSONObject) obj; 			
		
			String subid=CDHPObj.get("SubscriberId").toString();
			
			String parentID=CDHPObj.get("ParentGroupId").toString();

			if(parentID.equalsIgnoreCase(ParentGroupId)) {
				
					Assert.pass("ParentGroupId is matching  [Expected Result is "+ParentGroupId+"  AND Actual Result is "+parentID+"]");
						}
				else {
					Assert.fail("ParentGroupId is not matching  [Expected Result is "+ParentGroupId+"  AND Actual Result is "+parentID+"]");	
				}
				if(subid.equalsIgnoreCase(SubscriberId)) {
					Assert.pass("SubscriberID is matching  [Expected Result is "+SubscriberId+"  AND Actual Result is "+subid+"]");	
				}
				else {
					Assert.pass("SubscriberID is not matching  [Expected Result is "+SubscriberId+"  AND Actual Result is "+subid+"]");
			}
		}	
		else {				
			Assert.done("Test Case ID : "+ testID);
			Assert.done("Test Description "+testDesc);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg").trim();
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {

					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
				Assert.fail(content);
			}}
		}

	public static void validateGetCDHPTransaction(String content, String testID, String env) throws Exception {
		boolean flag = true;
		boolean flag1 = false;
		int i=0, j=0, k=0;
		//String testdir = Environment.get("GetCDHPTransaction_Base_Dir");
		String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";
		DataTable1 Dttestdata = new DataTable1(testdir + "CDHPTransaction.xls", "GetCDHPTransaction","" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String testDesc = Dttestdata.getValue("Test_Description");
		
		String staticQuery = "";
		String ReportFilePath = "";
		String value="";
		if (!content.contains("\"errorCode\"")) {
			flag1 = true;
		}  
		if (flag1) {
			Assert.done("TestCaseID :"+testID);
			Assert.done("Test Description "+testDesc);	
			Assert.done("Validating static fields");
			String ParentGroupId = Dttestdata.getValue("ParentGroupId");
			String SubscriberId = Dttestdata.getValue("SubscriberId");
			String RecordCount = Dttestdata.getValue("RecordCount");
			System.out.println(content);
			Object obj = jsonparser.parse(content);
			JSONObject CDHPObj = (JSONObject) obj; 			
		
			String subid=CDHPObj.get("subscriberId").toString();
			
			String parentID=CDHPObj.get("parentGroupId").toString();
			String recordCount=CDHPObj.get("recordCount").toString();
			if(recordCount.equalsIgnoreCase(RecordCount)) {
				
				Assert.pass("RecordCount is matching  [Expected Result is "+RecordCount+"  AND Actual Result is "+recordCount+"]");
					}
			else {
				Assert.fail("RecordCount is not matching  [Expected Result is "+RecordCount+"  AND Actual Result is "+recordCount+"]");	
			}
		

			if(parentID.equalsIgnoreCase(ParentGroupId)) {
				
					Assert.pass("ParentGroupId is matching  [Expected Result is "+ParentGroupId+"  AND Actual Result is "+parentID+"]");
						}
				else {
					Assert.fail("ParentGroupId is not matching  [Expected Result is "+ParentGroupId+"  AND Actual Result is "+parentID+"]");	
				}
				if(subid.equalsIgnoreCase(SubscriberId)) {
					Assert.pass("SubscriberID is matching  [Expected Result is "+SubscriberId+"  AND Actual Result is "+subid+"]");	
				}
				else {
					Assert.pass("SubscriberID is not matching  [Expected Result is "+SubscriberId+"  AND Actual Result is "+subid+"]");
			}
		}	
		else {				
			Assert.done("Test Case ID : "+ testID);
			Assert.done("Test Description "+testDesc);
			String errorCode = Dttestdata.getValue("ErrorCode");
			String errorMsg = Dttestdata.getValue("ErrorMsg").trim();
			if (!(errorCode.equalsIgnoreCase(""))) {
				if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
					UtilMethod.Log("Valid Error Code", "PASS", true);
					Assert.done("Returns Error: " + content);
				} else {

					UtilMethod.Log("Invalid Error Code", "FAIL", true);
				}
			} else {
				UtilMethod.Log("Unexpected Error Code", "FAIL", true);
				Assert.fail(content);
			}}
		}
	
	public static void validateJsonArrayDataWithDB3(JSONObject ClaimObj, String strArrayName,
			String strQuery, String[] strUniqueColName, String DB, String ReportFilePath) throws Exception {
		JSONArray responseClaimLineDetails = (JSONArray) ClaimObj.get(strArrayName);
		org.json.JSONArray dbClaimLineDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, DB);

		if (responseClaimLineDetails.size() == dbClaimLineDetails.length()) {

			Map<String, Object> strCLaimDetailsRes = null;
			JSONObject response = null;
			Map<String, Object> db_data = null;
			org.json.JSONObject db_response = null;

			boolean errorflag = false;
			boolean validateflag = true;

			// Comparing Response data with db row
			for (int j = 0; j < responseClaimLineDetails.size(); j++) {
				int k = j * 2 + 1; // 1,3,5
				int l = j * 2 + 2; // 2,4,6
				response = (JSONObject) responseClaimLineDetails.get(j);
				strCLaimDetailsRes = UtilMethod.readJsonData(response);
				Assert.done("Validating " + j + " row DB values with response");
				for (int i = 0; i < dbClaimLineDetails.length(); i++) {
					db_response = (org.json.JSONObject) dbClaimLineDetails.get(i);
					db_data = UtilMethod.readJsonData(db_response);
					// for (int x=0; x<strUniqueColName.length ;x++) {
					if (strCLaimDetailsRes.get(strUniqueColName[0]).toString().trim()
							.equalsIgnoreCase(db_data.get(strUniqueColName[0]).toString().trim())
							&& strCLaimDetailsRes.get(strUniqueColName[1]).toString().trim()
									.equalsIgnoreCase(db_data.get(strUniqueColName[1]).toString().trim())
							&& strCLaimDetailsRes.get(strUniqueColName[2]).toString().trim()
									.equalsIgnoreCase(db_data.get(strUniqueColName[2]).toString().trim())) {
						break;
					}
				}

				Set<String> jsonKeys = strCLaimDetailsRes.keySet();
				for (String tagname : jsonKeys) {
					Object Value = strCLaimDetailsRes.get(tagname);
					UtilMethod.setCellData(tagname, Value, k, ReportFilePath);
					
					UtilMethod.validateJSONObject(db_data, tagname, Value, l, ReportFilePath);
					

				}
			}

		} else {
			UtilMethod.Log(
					"Cannot validate as the Json response claim line details record size is not matching with DB response claim line details records.. please check the query you are passing",
					"FAIL", true);
			throw new Exception(
					"Cannot validate claim line details with db as size is not matching.. please check the query you are passing...");
	}
	}
	public static void validateEDIEligibilityOrch(String content, String testID, String env) throws Exception {
        boolean errorflag = true;
        boolean validateflag = false;
        //String testdir = Environment.get("PCP_BASE_DIR");
        String testdir =  Environment.get("test_data_path")+"\\"+env+"\\";
        DataTable1 Dttestdata = new DataTable1(testdir + "EDIEligibility.xls", "EDIEligibility", "" + testID + "");//Pravisha
        UtilMethod.SetTestDataFile(Dttestdata);
        String ReportFilePath = "";
        /*if(Environment.get("Jenkins_Run").equalsIgnoreCase("Yes")) {
        String excelName = Environment.get("EDIEligibiltyOrch_XML");             
        String excelReportName = excelName.replace(".xml", ".xslx");
        ReportFilePath = Environment.get("report_path")+"//"+excelReportName;
        }
        else {
        ReportFilePath = Environment.get("FindPCP_Excel_path");//Pravisha
        }*/
        //String ReportFilePath = Environment.get("FindPCP_Excel_path");
        String testDesc = Dttestdata.getValue("TestDescription");
        if (content.contains("errorCode")) {
               errorflag = false;
        } else {
               validateflag = true;
        }
        if (validateflag) {
               /*Object obj = jsonparser.parse(content);
               JSONObject PCPobj = (JSONObject) obj;*/
               //JSONObject soapDatainJsonObject = XML.toJSONObject(content);
               
               Object xmlJSONObj = XML.toJSONObject(content);
               String xml = xmlJSONObj.toString();
               System.out.println(xml);
               //JSONObject EDIOrchobj = (JSONObject) xmlJSONObj;
    //  String jsonPrettyPrintString = xmlJSONObj.toString();
     // System.out.println(jsonPrettyPrintString);

               String TestCaseID = Dttestdata.getValue("TestCaseID");

               //String TestDescription = Dttestdata.getValue("TestDescription");
               String Source = Dttestdata.getValue("Source");
               String ID = Dttestdata.getValue("ID");
               String SubscriberId = Dttestdata.getValue("SubscriberId");
               String FirstName = Dttestdata.getValue("FirstName");
               String LastName = Dttestdata.getValue("LastName");
               String InquiryDate = Dttestdata.getValue("InquiryDate");
               String ServiceType= Dttestdata.getValue("ServiceType");
        
               try {
                     Assert.done("Test ID: " + TestCaseID);
                     Assert.done("Test Description: " + testDesc);
                            String strQuery = "SELECT DISTINCT SBSB.SBSB_FIRST_NAME AS SubFirstName,\r\n" + 
                                          "SBSB.SBSB_LAST_NAME AS SubLastName,\r\n" + 
                                          "CSPI.CSPI_ITS_PREFIX+SBSB.SBSB_ID AS SubscriberId,\r\n" + 
                                          "'00'+ MEME.MEME_SFX AS DependentId,MEME.MEME_FIRST_NAME AS DepFirstName,\r\n" + 
                                          "MEME.MEME_MID_INIT AS DepMiddleInitial, MEME.MEME_LAST_NAME AS DepLastName,\r\n" + 
                                          "CONVERT(VARCHAR(10),MEME.MEME_BIRTH_DT,112) AS PatientDOB,MEME.MEME_SEX AS GenderCode,\r\n" + 
                                          "MEME.MEME_SSN AS SSN, MEME.MEME_REL AS UDRelationshipCode, \r\n" + 
                                          "SBAD.SBAD_ADDR1 AS Address_1, SBAD.SBAD_ADDR2 AS Address_2,\r\n" + 
                                          "SBAD.SBAD_ADDR3 AS Address_3, '' AS Address_4, SBAD.SBAD_CITY AS City,\r\n" + 
                                          "SBAD.SBAD_STATE AS State, SBAD.SBAD_ZIP AS Zip\r\n" + 
                                          "\r\n" + 
                                          "FROM CMC_SBSB_SUBSC SBSB\r\n" + 
                                          "INNER JOIN CMC_MEME_MEMBER MEME ON \r\n" + 
                                          "SBSB.SBSB_CK=MEME.SBSB_CK\r\n" + 
                                          "INNER JOIN CMC_CSPI_CS_PLAN CSPI ON\r\n" + 
                                          "CSPI.GRGR_CK=SBSB.GRGR_CK\r\n" + 
                                          "INNER JOIN CMC_SBAD_ADDR SBAD ON\r\n" + 
                                          "SBAD.SBSB_CK=SBSB.SBSB_CK\r\n" + 
                                          "INNER JOIN CMC_PDPD_PRODUCT PDPD ON\r\n" + 
                                          "PDPD.PDPD_ID=CSPI.PDPD_ID\r\n" + 
                                          "WHERE SBSB.SBSB_ID='"+SubscriberId+"'\r\n" + 
                                          "AND MEME.MEME_FIRST_NAME='"+FirstName+"' AND CSPI_ITS_PREFIX='ZBA'";
                            
                            //org.json.JSONArray dbDetails = ViewClaimsDBS.getMemberInfofromDBS(subQuery, "Sybase");
                     //     memeCK = dbDetails.getJSONObject(0).getString("MEME_CK");
                     //}
                     /*JSONParser parser = new JSONParser();
                     JSONArray PCPArray = (JSONArray) parser.parse(PCPobj.get("PCP_INFO").toString());
                     PCP_InfoSize = PCPArray.size();
                     if (PCP_InfoSize < 200) {
                            PCP_count = "F";
                     } else {
                            PCP_count = "T";
                     }*/

                     /*if (!pcpfname.equalsIgnoreCase("")) {
                            city = "";
                            state = "";
                     }
                     zip = zip.replace(",", "','");

                     if (date.equalsIgnoreCase("")) {
                            Date currentDate = new Date();
                            date = dateFormat.format(currentDate);
                     }
                     if(npi.equalsIgnoreCase("")) {
                            npi = "NULL";
                     }
*/
                     /*staticQuery = "SELECT UserID = 'CHNLESBMEP',SBSB.SBSB_ID AS SUBSCRIBER_ID, MEME.MEME_SFX AS DEPENDENT_ID, PCP_COUNT_FLAG = '"
                                   + PCP_count + "' "
                                   + " FROM CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME ON SBSB.SBSB_CK = MEME.MEME_CK "
                                   + "WHERE  MEME.MEME_CK = " + memeCK + " ";

                     ValidateMethods.validateStaticFieldsWithDb(PCPobj, staticQuery, "Sybase", ReportFilePath);
                     if (pcpfname.equalsIgnoreCase("") && (!pcplname.equalsIgnoreCase(""))) {

                     } else if ((!pcpfname.equalsIgnoreCase("") && (!pcplname.equalsIgnoreCase("")))
                                   || (!zip.equalsIgnoreCase("") && (speciality.equalsIgnoreCase("")))) {

                     } else {
        
                     }*/
                     String ediDetails = "EDIEligibilityOrchResponse";// Check with debug
                     String[] UniqueColumn = {"HIPAACategoryDescription","pcp_FIRST_NAME","address1"};

                     ValidateMethods.validateJsonArrayDataWithDB3((JSONObject) xmlJSONObj, ediDetails, strQuery, UniqueColumn, "Sybase",
                                   ReportFilePath);
               } catch (Exception e) {
                     e.printStackTrace();
               }
        } else {
               Assert.done("Test ID: " + testID);
               Assert.done("Test Description: " + testDesc);
               String errorCode = Dttestdata.getValue("ErrorCode");
               String errorMsg = Dttestdata.getValue("ErrorMsg");
               if (!(errorCode.equalsIgnoreCase(""))) {
                     if ((content.contains(errorCode)) && (content.contains(errorMsg))) {
                            UtilMethod.Log("Valid Error Code", "PASS", true);
                            Assert.done("Returns Error: " + content);
                     } else {

                            UtilMethod.Log("Invalid Error Code", "FAIL", true);
                     }
               } else {
                     UtilMethod.Log("Unexpected Error Code", "FAIL", true);
                     Assert.fail(content);
               }
        }
 }

	public static void validateJsonObject(org.json.JSONObject ClaimObj, String strArrayName,
			String strQuery, String[] strUniqueColName, String[] DBUniqueColumn, String DB, String ReportFilePath) throws Exception {
		org.json.JSONArray responseClaimLineDetails = (org.json.JSONArray) ClaimObj.get(strArrayName);
		org.json.JSONArray dbClaimLineDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, DB);

		if (responseClaimLineDetails.length() == dbClaimLineDetails.length()) {

			Map<String, Object> strCLaimDetailsRes = null;
			org.json.JSONObject response = null;
			Map<String, Object> db_data = null;
			org.json.JSONObject db_response = null;


			// Comparing Response data with db row
			for (int j = 0; j < responseClaimLineDetails.length(); j++) {
				int k = j * 2 + 1; // 1,3,5
				int l = j * 2 + 2; // 2,4,6
				response = (org.json.JSONObject) responseClaimLineDetails.get(j);
				strCLaimDetailsRes = UtilMethod.readJsonData(response);
				Assert.done("Validating " + j + " row DB values with response");
				for (int i = 0; i < dbClaimLineDetails.length(); i++) {
					db_response = (org.json.JSONObject) dbClaimLineDetails.get(i);
					db_data = UtilMethod.readJsonData(db_response);
					// for (int x=0; x<strUniqueColName.length ;x++) {
					if (strCLaimDetailsRes.get(strUniqueColName[0]).toString().trim()
							.equalsIgnoreCase(db_data.get(DBUniqueColumn[0]).toString().trim())
							&& strCLaimDetailsRes.get(strUniqueColName[1]).toString().trim()
									.equalsIgnoreCase(db_data.get(DBUniqueColumn[1]).toString().trim())) {
						break;
					}
				}

				Set<String> jsonKeys = strCLaimDetailsRes.keySet();
				for (String tagname : jsonKeys) {
					Object Value = strCLaimDetailsRes.get(tagname);
					if(DB.equalsIgnoreCase("Oracle")) {
					tagname = tagname.toUpperCase();
					}
					UtilMethod.setCellData(tagname, Value, k, ReportFilePath);
					
					UtilMethod.validateJSONObject(db_data, tagname, Value, l, ReportFilePath);
					

				}
			}

		} else {
			UtilMethod.Log(
					"Cannot validate as the Json response claim line details record size is not matching with DB response claim line details records.. please check the query you are passing",
					"FAIL", true);
			throw new Exception(
					"Cannot validate claim line details with db as size is not matching.. please check the query you are passing...");
	}
	}
	
	public static void validateViewIDCardBenefits(String content, String testID, String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		//String testdir = Environment.get("PCP_BASE_DIR");
		String testdir =  Environment.get("test_data_path")+"/"+env+"/";
		DataTable1 Dttestdata = new DataTable1(testdir + "ViewIDCardBenefits.xls", "ViewIDCardBenefit_Input", "" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String ReportFilePath = Environment.get("ViewIDCardBenefits_Excel_path");
		String inputtestID = Dttestdata.getValue("TestID");
		String testDesc = Dttestdata.getValue("Test_Description");
		if (content.contains("ErrorCode") || !content.contains("<Body>")) {
			errorflag = false;
		} else {
			validateflag = true;
		}
		if (validateflag) {
			String subQuery = "";
			
			String productID = "";
			String strQuery = null;
			String subscriberID = Dttestdata.getValue("SubscriberID");
			String dependentID = Dttestdata.getValue("DependentID");
			String asOfDate = Dttestdata.getValue("AsOfDate");
			String jsonasOfDate = null;
			String portfolioQuery = null;
			String dbPortfolioInd = null;
			String jsonPortfolioInd = null;
			String dbRenewalDate = null;
			String jsonRenewalDate = null;
			String lineValQuery = null;
			String jsonLineVal = null;
			String dbLineVal = null;
			String jsonIDCardBodyDetails = null;
			String dbLineNumber = null;
			String jsonLineNumber = null;
			
			Assert.done("Test ID: " + inputtestID);
			Assert.done("Test Description: " + testDesc);
			org.json.JSONObject json = XML.toJSONObject(content); 
			org.json.JSONObject subscriberDetails = (org.json.JSONObject) json.get("Body");
			org.json.JSONObject subscriberList = subscriberDetails.getJSONObject("SubscriberInput");
	        jsonasOfDate = subscriberList.get("DateRequested").toString();
	        Assert.done("--Validating the Static fields--");
	        subQuery ="SELECT DISTINCT top 1 SBSB.SBSB_ID AS SubscriberID, '00'+convert(varchar(2),MEME.MEME_SFX) AS DependentID, \r\n" + 
	        		"CSPI_MCTR_CTYP , MEPE.PDPD_ID,'"+asOfDate+"' as DateRequested\r\n" + 
	        		"FROM  CMC_SBSB_SUBSC SBSB INNER JOIN CMC_MEME_MEMBER MEME \r\n" + 
	        		" ON MEME.SBSB_CK = SBSB.SBSB_CK INNER JOIN\r\n" + 
	        		" CMC_MEPE_PRCS_ELIG MEPE ON MEPE.MEME_CK =MEME.MEME_CK\r\n" + 
	        		" INNER JOIN CMC_CSPI_CS_PLAN  CSPI ON CSPI.CSPI_ID=MEPE.CSPI_ID\r\n" + 
	        		" WHERE SBSB.SBSB_ID IN ('"+subscriberID+"') AND MEME.MEME_SFX = "+dependentID+"\r\n" + 
	        		" AND '"+asOfDate+"' BETWEEN MEPE.MEPE_EFF_DT AND MEPE.MEPE_TERM_DT\r\n" + 
	        		" AND MEPE.MEPE_ELIG_IND='Y' order by MEPE.PDPD_ID desc";
	        
	        String Uniquename = "SubscriberID";
	        ValidateMethods.validateViewMemberAccountJsonObject(subQuery, "Sybase", subscriberList,Uniquename, ReportFilePath);
			
	        org.json.JSONArray dbSubDetails = ViewClaimsDBS.getMemberInfofromDBS(subQuery,"Sybase");
			if (dbSubDetails.length() > 0) {
				
				productID = dbSubDetails.getJSONObject(0).getString("PDPD_ID").trim();
			}
	        org.json.JSONObject IDCardDetails = (org.json.JSONObject) subscriberList.get("IDCardInformation");
	        org.json.JSONObject IDCardInfo = (org.json.JSONObject) IDCardDetails.get("IDCardProductName");
	        jsonPortfolioInd = IDCardInfo.get("PortfolioIndicator").toString();
	        jsonRenewalDate = IDCardInfo.get("RenewalDate").toString();
	        	        
	        portfolioQuery = "SELECT DISTINCT BNPK.LGCY_BNFT_PKG_ID AS PRODUCT_ID, RICD_1.RIC_CD AS RIC_CD1, RICV_1.RV_cd, RICV_1.RV_DESC AS BENEFITLABEL1,BNPB.BNFT_STRT_DT,BNPB.BNFT_END_DT, '"+asOfDate+"' as RenewalDate\r\n" + 
	        		" FROM ROUTER.HI70BPXR BPXR  \r\n" + 
	        		"INNER JOIN ROUTER.HI70BNPK BNPK ON BNPK.BNFT_PKG_ID = BPXR.EDR_BNFT_PKG \r\n" + 
	        		"INNER JOIN ROUTER.HI70BNPB BNPB ON BPXR.BR_BNFT_PKG_ID = BNPB.BR_BNFT_PKG_ID  \r\n" + 
	        		"INNER JOIN ROUTER.HI70BNDF BNDF ON BNPB.BNFT_DEFTN_ID = BNDF.BNFT_DEFTN_ID \r\n" + 
	        		"INNER JOIN ROUTER.HI70BNDQ BNDQ ON BNDQ.BNFT_DEFTN_ID = BNDF.BNFT_DEFTN_ID \r\n" + 
	        		"INNER JOIN ROUTER.HI70BNQL BNQL ON BNDQ.BNFT_QUAL_ID = BNQL.BNFT_QUAL_ID \r\n" + 
	        		"INNER JOIN ROUTER.HI70BNFT BNFT ON BNDF.BNFT_VAL_ID = BNFT.BNFT_VAL_ID  \r\n" + 
	        		"INNER JOIN ROUTER.HI70RICV RICV ON RICV.RV_ID = BNFT.BNFT_INFO_RV_ID  \r\n" + 
	        		"INNER JOIN ROUTER.HI70RICV RICV_1 ON RICV_1.RV_ID = BNQL.QUAL_INFO_RV \r\n" + 
	        		"INNER JOIN ROUTER.HI70RICD RICD_1 ON (RICV_1.RIC_ID = RICD_1.RIC_ID \r\n" + 
	        		"AND (RICD_1.RIC_CD IN ( 'STANDARD'))) \r\n" + 
	        		"LEFT OUTER JOIN ROUTER.HI70RICV RICV_COV ON RICV_COV.RV_ID = BNFT.CVG_LVL_RV_ID \r\n" + 
	        		"WHERE (BNPK.LGCY_BNFT_PKG_ID IN ('"+productID+"') AND ( RICV.RV_CD = 'PORTFOLIO') )\r\n" + 
	        		"AND (sysdate between BNPB.BNFT_STRT_DT  AND BNPB.BNFT_END_DT )\r\n" + 
	        		"ORDER BY PRODUCT_ID\r\n" ;
	        org.json.JSONArray dbportfolioDetails = ViewClaimsDBS.getMemberInfofromDBS(portfolioQuery,"Oracle");
			if (dbportfolioDetails.length() > 0) {
				 dbPortfolioInd = dbportfolioDetails.getJSONObject(0).getString("BENEFITLABEL1").trim();
				 //dbRenewalDate = dbportfolioDetails.getJSONObject(0).getString("RENEWALDATE").trim();
				 
			}
			if(jsonPortfolioInd.equalsIgnoreCase(dbPortfolioInd) ) {
				Assert.pass("PortfolioIndicator is matching [ Expected Result is " +dbPortfolioInd+" AND Actual Result is "+jsonPortfolioInd+" ]");
				//Assert.pass("RenewalDate is matching [ Expected Result is "+dbRenewalDate+" AND Actual Result is "+jsonRenewalDate +" ]");
			}
			UtilMethod.setCellData("PORTFOLIOINDICATOR", jsonPortfolioInd, 1, ReportFilePath);
			UtilMethod.setCellData("PORTFOLIOINDICATOR", dbPortfolioInd, 2, ReportFilePath);
			/*UtilMethod.setCellData("RENEWALDATE", jsonRenewalDate, 1, ReportFilePath);
			UtilMethod.setCellData("RENEWALDATE", dbRenewalDate, 2, ReportFilePath);*/
			
	        org.json.JSONObject ProdNameLineInfo = (org.json.JSONObject) IDCardInfo.get("ProdNameLine");
	        Assert.done("LineNumber:"+ProdNameLineInfo.get("LineNumber")); 
	        System.out.println("LineValue:"+ProdNameLineInfo.get("LineValue"));
	        jsonLineVal = ProdNameLineInfo.get("LineValue").toString();
	        
	        lineValQuery = "SELECT DISTINCT substring(plds.PLDS_DESC,1,14) AS LineValue FROM CMC_MEPE_PRCS_ELIG  mepe\r\n" + 
	        		"INNER JOIN  CMC_PLDS_PLAN_DESC plds\r\n" + 
	        		"ON plds.CSPI_ID = mepe.CSPI_ID\r\n" + 
	        		"WHERE PDPD_ID='"+productID+"'";
	        org.json.JSONArray dbLineValDetails = ViewClaimsDBS.getMemberInfofromDBS(lineValQuery,"Sybase");
			if (dbLineValDetails.length() > 0) {
				 dbLineVal = dbLineValDetails.getJSONObject(0).getString("LineValue").trim();
			}
			if(dbLineVal.equalsIgnoreCase(jsonLineVal) ) {
				Assert.pass("LineValue is matching [ Expected Result is " +dbLineVal+" AND Actual Result is "+jsonLineVal +" ]");
			}
			UtilMethod.setCellData("LINEVALUE", jsonLineVal, 1, ReportFilePath);
			UtilMethod.setCellData("LINEVALUE", dbLineVal, 2, ReportFilePath);
			
			Assert.done("Validating the IDCard BenefitDetails");
	        org.json.JSONObject IDCardBody = (org.json.JSONObject) IDCardDetails.get("IDCardBody");
	        org.json.JSONObject IDCardBodyDetails = (org.json.JSONObject) IDCardBody.get("IDBodyLine");
	        String IDdetails = "IDBodyLine";
			String[] UniqueColumn = {"BenefitAmount","BenefitLabel"};
			String[] DBUniqueColumn = {"BENEFITAMOUNT","BENEFITLABEL"};
			strQuery = "SELECT  LineNumber, MAX(BENEFITLABEL) BenefitLabel, MAX(BenefitAmount) BenefitAmount\r\n" + 
					"FROM ( SELECT BNFT.VAL_AMT AS LineNumber , \r\n" + 
					"      CASE WHEN RICD_1.RIC_CD = 'IDBENTXT' THEN RICV_1.RV_DESC END BenefitLabel,\r\n" + 
					"      CASE WHEN RICD_1.RIC_CD = 'IDVALUE' THEN RICV_1.RV_DESC END BenefitAmount     \r\n" + 
					"FROM ROUTER.HI70BPXR BPXR  \r\n" + 
					"INNER JOIN ROUTER.HI70BNPK BNPK ON BNPK.BNFT_PKG_ID = BPXR.EDR_BNFT_PKG \r\n" + 
					"INNER JOIN ROUTER.HI70BNPB BNPB ON BPXR.BR_BNFT_PKG_ID = BNPB.BR_BNFT_PKG_ID  \r\n" + 
					"INNER JOIN ROUTER.HI70BNDF BNDF ON BNPB.BNFT_DEFTN_ID = BNDF.BNFT_DEFTN_ID\r\n" + 
					"INNER JOIN ROUTER.HI70BNDQ BNDQ ON BNDQ.BNFT_DEFTN_ID = BNDF.BNFT_DEFTN_ID\r\n" + 
					"INNER JOIN ROUTER.HI70BNQL BNQL ON BNDQ.BNFT_QUAL_ID = BNQL.BNFT_QUAL_ID \r\n" + 
					"INNER JOIN ROUTER.HI70BNFT BNFT ON BNDF.BNFT_VAL_ID = BNFT.BNFT_VAL_ID  \r\n" + 
					"INNER JOIN ROUTER.HI70RICV RICV ON RICV.RV_ID = BNFT.BNFT_INFO_RV_ID  \r\n" + 
					"INNER JOIN ROUTER.HI70RICV RICV_1 ON RICV_1.RV_ID = BNQL.QUAL_INFO_RV \r\n" + 
					"INNER JOIN ROUTER.HI70RICD RICD_1 ON (RICV_1.RIC_ID = RICD_1.RIC_ID \r\n" + 
					"AND (RICD_1.RIC_CD IN ( 'IDVALUE' ,'IDBENTXT','FAMCOMP'))) \r\n" + 
					"LEFT OUTER JOIN ROUTER.HI70RICV RICV_COV ON RICV_COV.RV_ID = BNFT.CVG_LVL_RV_ID \r\n" + 
					"WHERE (BNPK.LGCY_BNFT_PKG_ID IN ('"+productID+"') AND RICV.RV_CD = 'IDCARD' )\r\n" + 
					"AND BNPB.BNFT_END_DT >= SYSDATE \r\n" + 
					")\r\n" + 
					"GROUP BY LineNumber\r\n" + 
					"ORDER BY LineNumber";
			org.json.JSONArray dbIDCardDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery,"Oracle");
			if (dbIDCardDetails.length() > 1) {
			ValidateMethods.validateJsonObject(IDCardBody, IDdetails, strQuery, UniqueColumn, DBUniqueColumn,"Oracle",
					ReportFilePath);
			}
			else if (dbIDCardDetails.length() > 0){
				String UniqueCol  = "BenefitLabel";
				ValidateMethods.validateViewMemberAccountJsonObject(strQuery, "Oracle", IDCardBodyDetails,UniqueCol, ReportFilePath);
				}
				else {
					Assert.fail("IDCard Benefits values are not present");
				}
			
		}
		else {
			Assert.done("Test ID: " + inputtestID);
			Assert.done("Test Description: " + testDesc);
			UtilMethod.Log("Unexpected Error Code", "FAIL", true);
			Assert.fail(content);
		}
		
	}
	
	public static void validateViewMemberAccount(String content, String testID, String env) throws Exception {
		boolean errorflag = true;
		boolean validateflag = false;
		//String testdir = Environment.get("PCP_BASE_DIR");
		String testdir =  Environment.get("test_data_path")+"/"+env+"/";
		DataTable1 Dttestdata = new DataTable1(testdir + "ViewMemberAccount.xls", "ViewMemberAccount_Input", "" + testID + "");
		UtilMethod.SetTestDataFile(Dttestdata);
		String ReportFilePath = Environment.get("ViewMemberAccount_Excel_path");
		String inputtestID = Dttestdata.getValue("TestID");
		String testDesc = Dttestdata.getValue("Test_Description");
		if (content.contains("ErrorCode") || !content.contains("<FacetsBody>")) {
			errorflag = false;
		} else {
			validateflag = true;
		}
		if (validateflag) {
			
			String subscriberCK = Dttestdata.getValue("SubscriberCK");
			String memeCK = null;
			String memberGroupIndicQuery = null;
			String billingQuery = null;
			org.json.JSONObject subscriberDetails = null;
			org.json.JSONObject subscriberList = null;
			Assert.done("Test ID: " + inputtestID);
			Assert.done("Test Description: " + testDesc);
			String subGroupID = null;
			String memeCKQuery = "SELECT MEME_CK FROM CMC_MEME_MEMBER WHERE SBSB_CK="+subscriberCK+"";
			org.json.JSONArray dbMemeCK = ViewClaimsDBS.getMemberInfofromDBS(memeCKQuery,"Sybase");
			if (dbMemeCK.length() > 1) {
				memeCK = dbMemeCK.getJSONObject(0).getString("MEME_CK").trim();
			}
			for(int i = 0 ; i < dbMemeCK.length() ; i++) {
				memeCK = dbMemeCK.getJSONObject(i).getString("MEME_CK").trim();
			
			org.json.JSONObject json = XML.toJSONObject(content); 
			if (dbMemeCK.length() > 1) {
				org.json.JSONArray subscriberDetails1 = (org.json.JSONArray) json.getJSONArray("FacetsBody");
				subscriberDetails = (org.json.JSONObject) subscriberDetails1.get(i);
				subscriberList = subscriberDetails.getJSONObject("MemberGroupIndic");
				subGroupID = subscriberList.get("SubgroupID").toString();
			}
			else {
			subscriberDetails = (org.json.JSONObject) json.get("FacetsBody");
			subscriberList = subscriberDetails.getJSONObject("MemberGroupIndic");
			subGroupID = subscriberList.get("SubgroupID").toString();
			}
						
			Assert.done("----Validating the Member with MemeCK : " + "'"+memeCK+"'" +" Group Details----");
			memberGroupIndicQuery = "SELECT DISTINCT TOP 1 MEME.MEME_CK AS MemberCK,MEME.MEME_WRK_PHONE AS WorkPhone,\r\n" + 
					"CASE when SBAD.SBAD_EMAIL IS NULL THEN '' else SBAD.SBAD_EMAIL end AS HomeEmail, GRGR.GRGR_ID AS GroupID,GRGR.GRGR_NAME AS GroupName,\r\n" + 
					"GRGR.GRGR_CK AS GroupCK,SGSG.SGSG_ID AS SubgroupID,SGSG.SGSG_NAME AS SubgroupName,\r\n" + 
					"CONVERT(char(8), MEME.MEME_ORIG_EFF_DT,112)  AS MemOrigEffDate,SGSG.SGSG_CK AS SubgroupCK,\r\n" + 
					"MEME.MEME_HIST_LINK_ID AS HistoryLinkID,MEME.MEME_FAM_LINK_ID AS FamilyLinkID,\r\n" + 
					"CASE WHEN ATUF.ATUF_TEXT1 IS NULL THEN '' ELSE ATUF.ATUF_TEXT1 END AS LRSPSubID,'N' AS COBPresent\r\n" + 
					"FROM CMC_SBSB_SUBSC SBSB LEFT OUTER JOIN\r\n" + 
					"CMC_MEME_MEMBER MEME ON SBSB.SBSB_CK=MEME.SBSB_CK\r\n" + 
					"LEFT OUTER JOIN CMC_SBAD_ADDR SBAD ON SBAD.SBSB_CK = MEME.SBSB_CK\r\n" + 
					"AND (MEME.SBAD_TYPE_HOME=SBAD.SBAD_TYPE) AND MEME.MEME_SFX=0\r\n" + 
					"LEFT OUTER JOIN CMC_GRGR_GROUP GRGR ON GRGR.GRGR_CK = SBSB.GRGR_CK\r\n" + 
					"LEFT OUTER JOIN CMC_SGSG_SUB_GROUP SGSG ON SGSG.GRGR_CK = SBSB.GRGR_CK\r\n" + 
					"LEFT OUTER JOIN CMC_SBSG_RELATION SBSG ON SBSG.SBSB_CK=SBSB.SBSB_CK\r\n" + 
					"LEFT OUTER JOIN CMC_BLEI_ENTY_INFO BLEI ON BLEI.BLEI_BILL_LEVEL_CK = MEME.SBSB_CK\r\n" + 
					"AND BLEI_BILL_LEVEL = 'I' LEFT OUTER JOIN CMC_BLAD_ADDR BLAD ON \r\n" + 
					"BLEI.BLEI_CK = BLAD.BLEI_CK LEFT OUTER JOIN CMC_MEPE_PRCS_ELIG MEPE\r\n" + 
					"ON (MEME.MEME_CK = MEPE.MEME_CK) AND (GETDATE() BETWEEN MEPE.MEPE_EFF_DT AND MEPE.MEPE_TERM_DT)	\r\n" + 
					"LEFT OUTER JOIN CER_ATXR_ATTACH_U ATXR ON ATXR.ATXR_SOURCE_ID = MEME.ATXR_SOURCE_ID AND ATXR.ATSY_ID = 'LSID'\r\n" + 
					"LEFT OUTER JOIN CER_ATUF_USERFLD_D ATUF ON  ( ATUF.ATXR_DEST_ID = ATXR.ATXR_DEST_ID ) AND ( ATUF.ATSY_ID = ATXR.ATSY_ID )	\r\n" + 
					"AND GETDATE() BETWEEN SBSG.SBSG_EFF_DT AND SBSG.SBSG_TERM_DT \r\n" + 
					"WHERE MEME.MEME_CK= "+memeCK+" and SGSG.SGSG_ID ='"+subGroupID+"' ";
			String Uniquename = "MemberCK";
			ValidateMethods.validateViewMemberAccountJsonObject(memberGroupIndicQuery, "Sybase", subscriberList,Uniquename, ReportFilePath);
			Assert.done("----Validating the Billing address details----");
			org.json.JSONObject billingList = subscriberList.getJSONObject("BillingAddress");
			billingQuery = "SELECT BLAD.BLAD_ADDR1 AS Address_1,\r\n" + 
					"BLAD.BLAD_CITY  AS City, BLAD.BLAD_STATE AS State, BLAD.BLAD_ZIP AS Zip\r\n" + 
					"FROM CMC_MEME_MEMBER MEME\r\n" + 
					"INNER JOIN CMC_BLEI_ENTY_INFO BLEI\r\n" + 
					"ON BLEI.BLEI_BILL_LEVEL_CK = MEME.SBSB_CK\r\n" + 
					"INNER JOIN CMC_BLAD_ADDR BLAD ON \r\n" + 
					"BLEI.BLEI_CK = BLAD.BLEI_CK\r\n" + 
					"WHERE MEME.MEME_CK= "+memeCK+" ";
			org.json.JSONArray dbBillingDetails = ViewClaimsDBS.getMemberInfofromDBS(billingQuery,"Sybase");
			String Uniquecol2 = "Address_1";
			if (dbBillingDetails.length() >= 1) {
				ValidateMethods.validateViewMemberAccountJsonObject(billingQuery, "Sybase", billingList,Uniquecol2, ReportFilePath);
				
			}
			else {
				Assert.done("The Member does not have billing address details");
			}
			String dbPCPRequired = null;
			String planDetails = "PlanInfo";
			String[] UniqueColumn = {"ProductID","ProductCat"};
			String[] DBUniqueColumn = {"ProductID","ProductCat"};
			
			
			Assert.done("-----Validating the PlanInfo Details-----");
			String planQuery = "DECLARE @V_AS_OF_DT DATE\r\n" + 
					"DECLARE @CSPD_CAT CHAR(1) "+
					"SELECT @V_AS_OF_DT = getdate()\r\n" + 
					"SELECT				\r\n" + 
					"ISNULL(FamilyIndicator,		'') 	AS FamilyIndicator, ISNULL(FamilyIndicatorDesc,	'') 	AS FamilyIndicatorDesc,\r\n" + 
					"ISNULL(EligIndicator,		'') 	AS EligIndicator, ISNULL(EligIndicatorDesc,	'') 	AS EligIndicatorDesc,\r\n" + 
					"ISNULL(ChannelsEligInd,		'') 	AS ChannelsEligInd, ISNULL(ClassID,				'') 	AS ClassID,\r\n" + 
					"ISNULL(ClassDesc,			'') 	AS ClassDesc, ISNULL(ClassPlanID,			'') 	AS ClassPlanID,\r\n" + 
					"ISNULL(PlanDesc,			'') 	AS PlanDesc, ISNULL(ProductID, 			'') 	AS ProductID,\r\n" + 
					"ISNULL(ProductDesc, 		'') 	AS ProductDesc, ISNULL(ProductCat, 			'') 	AS ProductCat,\r\n" + 
					"ISNULL(ProductBusinessCategory, '') 	AS ProductBusinessCategory, ISNULL(CDHIndicator,		'') 	AS DHIndicator,\r\n" + 
					"ISNULL(CDHIndicatorDesc,	'') 	AS CDHIndicatorDesc, ISNULL(BenefitMonthDay,		'') 	AS BenefitMonthDay,\r\n" + 
					"ISNULL(BenefitYear,  		'') 	AS BenefitYear, ISNULL((BenefitYear + BenefitMonthDay), 	'')  AS BenefitStartDate,\r\n" + 
					"ISNULL((BenefitYear + BenefitMonthDayEnd), 	'')  AS BenefitEndDate, ISNULL(ProductCatDesc,		'') 	AS ProductCatDesc,\r\n" + 
					"ISNULL(EligEffDate,			'') 	AS EligEffDate, ISNULL(EligTermDate,		'') 	AS EligTermDate,\r\n" + 
					"ISNULL(EligReason,			'') 	AS EligReason, ISNULL(EligReasonDesc,		'') 	AS EligReasonDesc,\r\n" + 
					"ISNULL(ExplanationCode,		'') 	AS ExplanationCode, ISNULL(ExplanationCodeDesc,		'') 	AS ExplanationCodeDesc,\r\n" + 
					"ISNULL(MemberProcessStatusDesc,	'') 	AS MemberProcessStatusDesc, ISNULL(MembershipCardType, 		'') 	AS MembershipCardType,\r\n" + 
					"ISNULL(PCPRequired, 			'') 	AS PCPRequired from  ( SELECT DISTINCT \r\n" + 
					" CASE WHEN CMC_MCTR_CD_TRANS_1.MCTR_VALUE = 'D' THEN 'A' ELSE CMC_MCTR_CD_TRANS_1.MCTR_VALUE end AS FamilyIndicator,  \r\n" + 
					"CASE WHEN CMC_MCTR_CD_TRANS_1.MCTR_DESC = 'Subscriber and Dependents' THEN 'Family' else CMC_MCTR_CD_TRANS_1.MCTR_DESC end AS FamilyIndicatorDesc,  \r\n" + 
					"CMC_MEPE_PRCS_ELIG.MEPE_ELIG_IND AS EligIndicator, CMC_MCTR_CD_TRANS_2.MCTR_DESC AS EligIndicatorDesc,    \r\n" + 
					"CMC_MEPE_PRCS_ELIG.MEPE_ELIG_IND AS ChannelsEligInd, CMC_MEPE_PRCS_ELIG.CSCS_ID AS ClassID,\r\n" + 
					"CMC_CSCS_CLASS.CSCS_DESC AS ClassDesc, CMC_MEPE_PRCS_ELIG.CSPI_ID AS ClassPlanID,\r\n" + 
					"CMC_PLDS_PLAN_DESC.PLDS_DESC AS PlanDesc, CMC_MEPE_PRCS_ELIG.PDPD_ID AS ProductID,\r\n" + 
					"CMC_PDDS_PROD_DESC.PDDS_DESC AS ProductDesc, CMC_MEPE_PRCS_ELIG.CSPD_CAT AS ProductCat,   \r\n" + 
					"CMC_PDDS_PROD_DESC.PDDS_MCTR_BCAT AS ProductBusinessCategory, CMC_CSPI_CS_PLAN.GRDC_PFX   AS CDHIndicator,			\r\n" + 
					"CMC_GRDC_DCBK_REL.GRDC_DESC AS CDHIndicatorDesc, substring(CONVERT(VARCHAR(10),CMC_CSPB_PLAN_BENV.CSPB_BEG_DT,12),3,6) AS BenefitMonthDay, \r\n" + 
					"substring(CONVERT(VARCHAR(10),CMC_CSPB_PLAN_BENV.CSPB_END_DT,12),3,6) AS BenefitMonthDayEnd, \r\n" + 
					"CASE WHEN CMC_CSPB_PLAN_BENV.CSPB_TWELVE_MO_IND = 'N' THEN CONVERT(VARCHAR(10),DATEPART(YY,CMC_CSPB_PLAN_BENV.CSPB_BEG_DT)) ELSE\r\n" + 
					"CASE WHEN CONVERT(INT,substring(CONVERT(VARCHAR(10),CMC_CSPB_PLAN_BENV.CSPB_BEG_DT,12),3,6)) < = CONVERT(INT,substring(CONVERT(VARCHAR(10),GETDATE(),12),3,6))\r\n" + 
					"THEN CONVERT(VARCHAR(10),DATEPART(YY,GETDATE())) ELSE CONVERT(VARCHAR(10),DATEPART(YY,DATEADD(YEAR,-1,GETDATE()))) END END  AS BenefitYear,\r\n" + 
					"CMC_CSPB_PLAN_BENV.CSPB_BEG_DT AS BenefitStartDate, CMC_CSPB_PLAN_BENV.CSPB_END_DT AS BenefitEndDate, 		\r\n" + 
					"CMC_CSPD_DESC.CSPD_CAT_DESC AS ProductCatDesc, CONVERT(char(8),CMC_MEPE_PRCS_ELIG.MEPE_EFF_DT,112) AS EligEffDate,\r\n" + 
					"CONVERT(char(8),CMC_MEPE_PRCS_ELIG.MEPE_TERM_DT,112) AS EligTermDate, CMC_MEPE_PRCS_ELIG.MEPE_MCTR_RSN AS EligReason,\r\n" + 
					"CMC_MCTR_CD_TRANS_3.MCTR_DESC AS EligReasonDesc, CMC_MEPE_PRCS_ELIG.EXCD_ID AS ExplanationCode,\r\n" + 
					"CMC_EXCD_EXPL_CD.EXCD_LONG_TEXT1 + ' ' + CMC_EXCD_EXPL_CD.EXCD_LONG_TEXT2 AS ExplanationCodeDesc,\r\n" + 
					"CMC_MCTR_CD_TRANS_4.MCTR_DESC AS MemberProcessStatusDesc, CMC_CSPI_CS_PLAN.CSPI_MCTR_CTYP  AS MembershipCardType, \r\n" + 
					"CASE WHEN CMC_AIAI_ADM_INFO.AIAI_PCP_REQ_IND = 'Y' THEN CMC_AIAI_ADM_INFO.AIAI_PCP_REQ_IND ELSE 'N' END AS PCPRequired FROM dbo.CMC_MEME_MEMBER CMC_MEME_MEMBER\r\n" + 
					"	LEFT OUTER JOIN	dbo.CMC_MEPE_PRCS_ELIG CMC_MEPE_PRCS_ELIG\r\n" + 
					"		ON (CMC_MEME_MEMBER.MEME_CK = CMC_MEPE_PRCS_ELIG.MEME_CK) AND (@V_AS_OF_DT BETWEEN CMC_MEPE_PRCS_ELIG.MEPE_EFF_DT AND CMC_MEPE_PRCS_ELIG.MEPE_TERM_DT)\r\n" + 
					"LEFT OUTER JOIN	dbo.CMC_MCTR_CD_TRANS CMC_MCTR_CD_TRANS_1\r\n" + 
					"		ON (CMC_MEPE_PRCS_ELIG.MEPE_FI = CMC_MCTR_CD_TRANS_1.MCTR_VALUE AND CMC_MCTR_CD_TRANS_1.MCTR_ENTITY='!MPE' AND CMC_MCTR_CD_TRANS_1.MCTR_TYPE = 'MEFI' )\r\n" + 
					"LEFT OUTER JOIN	dbo.CMC_MCTR_CD_TRANS CMC_MCTR_CD_TRANS_2\r\n" + 
					"		ON (CMC_MEPE_PRCS_ELIG.MEPE_ELIG_IND = CMC_MCTR_CD_TRANS_2.MCTR_VALUE AND CMC_MCTR_CD_TRANS_2.MCTR_ENTITY='!MEL' AND CMC_MCTR_CD_TRANS_2.MCTR_TYPE = 'MEPE' )		\r\n" + 
					"LEFT OUTER JOIN	dbo.CMC_CSCS_CLASS CMC_CSCS_CLASS\r\n" + 
					"		ON (CMC_MEPE_PRCS_ELIG.CSCS_ID = CMC_CSCS_CLASS.CSCS_ID AND CMC_MEME_MEMBER.GRGR_CK = CMC_CSCS_CLASS.GRGR_CK)\r\n" + 
					"LEFT OUTER JOIN	dbo.CMC_PLDS_PLAN_DESC CMC_PLDS_PLAN_DESC\r\n" + 
					"		ON (CMC_MEPE_PRCS_ELIG.CSPI_ID = CMC_PLDS_PLAN_DESC.CSPI_ID)\r\n" + 
					"LEFT OUTER JOIN	dbo.CMC_PDDS_PROD_DESC CMC_PDDS_PROD_DESC\r\n" + 
					"		ON (CMC_MEPE_PRCS_ELIG.PDPD_ID = CMC_PDDS_PROD_DESC.PDPD_ID)\r\n" + 
					"LEFT OUTER JOIN	dbo.CMC_CSPD_DESC CMC_CSPD_DESC\r\n" + 
					"		ON (CMC_MEPE_PRCS_ELIG.CSPD_CAT = CMC_CSPD_DESC.CSPD_CAT) \r\n" + 
					"LEFT OUTER JOIN	dbo.CMC_CSPI_CS_PLAN CMC_CSPI_CS_PLAN\r\n" + 
					"		ON (CMC_CSPI_CS_PLAN.GRGR_CK = CMC_MEPE_PRCS_ELIG.GRGR_CK)\r\n" + 
					"		AND (CMC_CSPI_CS_PLAN.CSCS_ID = CMC_MEPE_PRCS_ELIG.CSCS_ID)\r\n" + 
					"		AND (CMC_CSPI_CS_PLAN.CSPD_CAT = CMC_MEPE_PRCS_ELIG.CSPD_CAT)\r\n" + 
					"		AND (CMC_CSPI_CS_PLAN.CSPI_ID = CMC_MEPE_PRCS_ELIG.CSPI_ID)\r\n" + 
					"		AND (CMC_CSPI_CS_PLAN.PDPD_ID = CMC_MEPE_PRCS_ELIG.PDPD_ID)\r\n" + 
					"		AND (@V_AS_OF_DT BETWEEN CMC_CSPI_CS_PLAN.CSPI_EFF_DT AND CMC_CSPI_CS_PLAN.CSPI_TERM_DT)\r\n" + 
					"LEFT OUTER JOIN	dbo.CMC_CSPB_PLAN_BENV CMC_CSPB_PLAN_BENV\r\n" + 
					"		ON  (CMC_CSPI_CS_PLAN.GRGR_CK  = CMC_CSPB_PLAN_BENV.GRGR_CK)\r\n" + 
					"		AND (CMC_CSPI_CS_PLAN.CSCS_ID  = CMC_CSPB_PLAN_BENV.CSCS_ID)\r\n" + 
					"		AND (CMC_CSPI_CS_PLAN.CSPD_CAT = CMC_CSPB_PLAN_BENV.CSPD_CAT)\r\n" + 
					"		AND (CMC_CSPI_CS_PLAN.CSPI_ID  = CMC_CSPB_PLAN_BENV.CSPI_ID)\r\n" + 
					"		AND (@V_AS_OF_DT BETWEEN CMC_CSPB_PLAN_BENV.CSPB_BEG_DT AND CMC_CSPB_PLAN_BENV.CSPB_END_DT)\r\n" + 
					"LEFT OUTER JOIN	dbo.CMC_GRDC_DCBK_REL CMC_GRDC_DCBK_REL\r\n" + 
					"	ON (CMC_GRDC_DCBK_REL.GRDC_PFX = CMC_CSPI_CS_PLAN.GRDC_PFX)\r\n" + 
					"LEFT OUTER JOIN	dbo.CMC_MCTR_CD_TRANS CMC_MCTR_CD_TRANS_3\r\n" + 
					"		ON (CMC_MEPE_PRCS_ELIG.MEPE_MCTR_RSN = CMC_MCTR_CD_TRANS_3.MCTR_VALUE AND CMC_MCTR_CD_TRANS_3.MCTR_ENTITY='MEPE' AND CMC_MCTR_CD_TRANS_3.MCTR_TYPE = 'INEL' )		\r\n" + 
					"LEFT OUTER JOIN	dbo.CMC_EXCD_EXPL_CD CMC_EXCD_EXPL_CD\r\n" + 
					"		ON (CMC_MEPE_PRCS_ELIG.EXCD_ID = CMC_EXCD_EXPL_CD.EXCD_ID)	\r\n" + 
					"LEFT OUTER JOIN	dbo.CMC_MCTR_CD_TRANS CMC_MCTR_CD_TRANS_4\r\n" + 
					"		ON (CMC_MEPE_PRCS_ELIG.MEPE_PRCS_STS = CMC_MCTR_CD_TRANS_4.MCTR_VALUE \r\n" + 
					"		AND CMC_MCTR_CD_TRANS_4.MCTR_ENTITY='!MPE' AND CMC_MCTR_CD_TRANS_4.MCTR_TYPE = 'PRST' )	\r\n" + 
					"LEFT OUTER JOIN	dbo.CMC_GRGR_GROUP CMC_GRGR_GROUP\r\n" + 
					"		ON (CMC_MEME_MEMBER.GRGR_CK = CMC_GRGR_GROUP.GRGR_CK)\r\n" + 
					"LEFT OUTER JOIN	dbo.CMC_PDBC_PROD_COMP CMC_PDBC_PROD_COMP\r\n" + 
					"		ON (CMC_MEPE_PRCS_ELIG.PDPD_ID = CMC_PDBC_PROD_COMP.PDPD_ID) AND (@V_AS_OF_DT BETWEEN CMC_PDBC_PROD_COMP.PDBC_EFF_DT AND CMC_PDBC_PROD_COMP.PDBC_TERM_DT) AND (CMC_PDBC_PROD_COMP.PDBC_TYPE = 'AIAI')\r\n" + 
					"LEFT OUTER JOIN	dbo.CMC_AIAI_ADM_INFO CMC_AIAI_ADM_INFO\r\n" + 
					"		ON (CMC_PDBC_PROD_COMP.PDBC_PFX = CMC_AIAI_ADM_INFO.PDBC_PFX)\r\n" + 
					"WHERE    CMC_MEME_MEMBER.MEME_CK = "+memeCK+" ) subq";
			org.json.JSONArray dbPlanInfoDetails = ViewClaimsDBS.getMemberInfofromDBS(planQuery,"Sybase");
			if(dbPlanInfoDetails.length() > 1 ) {
			dbPCPRequired = dbPlanInfoDetails.getJSONObject(0).getString("PCPRequired").trim();
			ValidateMethods.validateJsonObject(subscriberDetails, planDetails, planQuery, UniqueColumn, DBUniqueColumn,"Sybase",
					ReportFilePath);
			}
			else {
				org.json.JSONObject planInfoList = subscriberDetails.getJSONObject("PlanInfo");
				String Uniquename3 = "ProductID";
				 dbPCPRequired = dbPlanInfoDetails.getJSONObject(0).getString("PCPRequired").trim();
				ValidateMethods.validateViewMemberAccountJsonObject(planQuery, "Sybase", planInfoList,Uniquename3, ReportFilePath);
				
			}
	
			if(dbPCPRequired.equalsIgnoreCase("Y")) {
			Assert.done("-----Validating the PCPInfo details-----");
			org.json.JSONObject pcpInfoList = (org.json.JSONObject) subscriberDetails.get("PCPInfo");
			String Uniquename1 = "PCPID";
			String pcpQuery = "DECLARE @V_AS_OF_DT DATE\r\n" + 
					"DECLARE @CSPD_CAT CHAR(1) " +
					"SELECT @V_AS_OF_DT = getdate()\r\n" + 
					"SELECT				\r\n" + 
					"ISNULL(PCPID,				'') 	AS PCPID,\r\n" + 
					"ISNULL(PCPName,				'') 	AS PCPName,\r\n" + 
					"ISNULL(PCPNPI,				'') 	AS PCPNPI,\r\n" + 
					"ISNULL(PCPType,				'') 	AS PCPType,\r\n" + 
					"ISNULL(PCPEffDate,			'') 	AS PCPEffDate,\r\n" + 
					"ISNULL(PCPTermDate,			'') 	AS PCPTermDate,\r\n" + 
					"ISNULL(PCPTermReason,		'') 	AS PCPTermReason,\r\n" + 
					"ISNULL(PCPTermReasonDesc,	'') 	AS PCPTermReasonDesc,\r\n" + 
					"ISNULL(ShrdSvngPrgId,		'') 	AS ShrdSvngPrgId,\r\n" + 
					"ISNULL(ShrdSvngPrgIdDesc,	'') 	AS ShrdSvngPrgIdDesc		\r\n" + 
					"		 from  ( SELECT DISTINCT \r\n" + 
					"CMC_MEPR_PRIM_PROV.PRPR_ID AS PCPID,\r\n" + 
					"CMC_PRPR_PROV.PRPR_NAME AS PCPName,\r\n" + 
					"CMC_PRPR_PROV.PRPR_NPI AS PCPNPI,\r\n" + 
					"CMC_MEPR_PRIM_PROV.MEPR_PCP_TYPE AS PCPType,\r\n" + 
					"CONVERT(char(8),CMC_MEPR_PRIM_PROV.MEPR_EFF_DT,112) AS PCPEffDate,\r\n" + 
					"CONVERT(char(8),CMC_MEPR_PRIM_PROV.MEPR_TERM_DT,112) AS PCPTermDate,\r\n" + 
					"CMC_MEPR_PRIM_PROV.MEPR_MCTR_TRSN AS PCPTermReason,   \r\n" + 
					"CMC_MCTR_CD_TRANS_5.MCTR_DESC AS PCPTermReasonDesc,    \r\n" + 
					"CMC_PRPG_PROG.PRPG_ID AS ShrdSvngPrgId,  	\r\n" + 
					"CMC_PRPG_PROG.PRPG_NAME AS ShrdSvngPrgIdDesc  	\r\n" + 
					"FROM  dbo.CMC_MEME_MEMBER CMC_MEME_MEMBER\r\n" + 
					"	LEFT OUTER JOIN	dbo.CMC_MEPE_PRCS_ELIG CMC_MEPE_PRCS_ELIG\r\n" + 
					"		ON (CMC_MEME_MEMBER.MEME_CK = CMC_MEPE_PRCS_ELIG.MEME_CK) AND (@V_AS_OF_DT BETWEEN CMC_MEPE_PRCS_ELIG.MEPE_EFF_DT AND CMC_MEPE_PRCS_ELIG.MEPE_TERM_DT)	\r\n" + 
					"	LEFT OUTER JOIN	dbo.CMC_MCTR_CD_TRANS CMC_MCTR_CD_TRANS_1\r\n" + 
					"		ON (CMC_MEPE_PRCS_ELIG.MEPE_FI = CMC_MCTR_CD_TRANS_1.MCTR_VALUE AND CMC_MCTR_CD_TRANS_1.MCTR_ENTITY='!MPE' AND CMC_MCTR_CD_TRANS_1.MCTR_TYPE = 'MEFI' )\r\n" + 
					"	LEFT OUTER JOIN	dbo.CMC_MCTR_CD_TRANS CMC_MCTR_CD_TRANS_2\r\n" + 
					"		ON (CMC_MEPE_PRCS_ELIG.MEPE_ELIG_IND = CMC_MCTR_CD_TRANS_2.MCTR_VALUE AND CMC_MCTR_CD_TRANS_2.MCTR_ENTITY='!MEL' AND CMC_MCTR_CD_TRANS_2.MCTR_TYPE = 'MEPE' )		\r\n" + 
					"   LEFT OUTER JOIN 	dbo.CMC_MEPR_PRIM_PROV CMC_MEPR_PRIM_PROV\r\n" + 
					"		ON (CMC_MEME_MEMBER.MEME_CK = CMC_MEPR_PRIM_PROV.MEME_CK) AND (@V_AS_OF_DT BETWEEN CMC_MEPR_PRIM_PROV.MEPR_EFF_DT AND CMC_MEPR_PRIM_PROV.MEPR_TERM_DT) AND (CMC_MEPR_PRIM_PROV.MEPR_PCP_TYPE='MP')\r\n" + 
					"	LEFT OUTER JOIN\r\n" + 
					"	dbo.CMC_MCTR_CD_TRANS CMC_MCTR_CD_TRANS_5\r\n" + 
					"		ON (CMC_MEPR_PRIM_PROV.MEPR_MCTR_TRSN = CMC_MCTR_CD_TRANS_5.MCTR_VALUE AND CMC_MCTR_CD_TRANS_5.MCTR_ENTITY='MERP' AND CMC_MCTR_CD_TRANS_5.MCTR_TYPE = 'TRSN')	\r\n" + 
					"	LEFT OUTER JOIN\r\n" + 
					"	dbo.CMC_PRPR_PROV CMC_PRPR_PROV\r\n" + 
					"		ON (CMC_MEPR_PRIM_PROV.PRPR_ID = CMC_PRPR_PROV.PRPR_ID) AND (CMC_MEPR_PRIM_PROV.MEPR_PCP_TYPE='MP') AND CMC_PRPR_PROV.PRPR_NPI NOT IN ('','9999999999')\r\n" + 
					"	LEFT OUTER JOIN\r\n" + 
					"	dbo.CMC_PREP_RELATION CMC_PREP_RELATION\r\n" + 
					"		ON (CMC_MEPR_PRIM_PROV.PRPR_ID = CMC_PREP_RELATION.PRPR_ID) AND (@V_AS_OF_DT  BETWEEN CMC_PREP_RELATION.PREP_EFF_DT and CMC_PREP_RELATION.PREP_TERM_DT) AND (CMC_MEPR_PRIM_PROV.MEPR_PCP_TYPE = 'MP')\r\n" + 
					"	LEFT OUTER JOIN\r\n" + 
					"	dbo.CMC_PRPG_PROG CMC_PRPG_PROG\r\n" + 
					"		ON (CMC_PREP_RELATION.PRPG_ID = CMC_PRPG_PROG.PRPG_ID) AND CMC_PRPG_PROG.PRPG_MCTR_TYPE = 'SOC'	\r\n" + 
					"WHERE CMC_MEME_MEMBER.MEME_CK = "+memeCK+"	) subq";
			
			ValidateMethods.validateViewMemberAccountJsonObject(pcpQuery, "Sybase", pcpInfoList,Uniquename1, ReportFilePath);
			
			Assert.done("-----Validating the PRInfo Details------");
	        String prDetails = "PRInfo";
			String[] UniqueColumn2 = {"PRLastName","PRSSN"};
			String[] DBUniqueColumn2 = {"PRLastName","PRSSN"};
			String prQuery = "DECLARE @V_AS_OF_DT DATE\r\n" + 
					"DECLARE @CSPD_CAT CHAR(1)\r\n" + 
					"\r\n" + 
					"SELECT @V_AS_OF_DT = getdate()\r\n" + 
					"SELECT				\r\n" + 
					"ISNULL(PRLastName,			'') 	AS PRLastName,\r\n" + 
					"ISNULL(PRFirstName,			'') 	AS PRFirstName,\r\n" + 
					"ISNULL(PRMiddleInitial,		'') 	AS PRMiddleInitial,\r\n" + 
					"ISNULL(PRDesignation,		'') 	AS PRDesignation,\r\n" + 
					"ISNULL(PREffectiveDate,		'') 	AS PREffectiveDate,\r\n" + 
					"ISNULL(PRTerminationDate,	'') 	AS PRTerminationDate,\r\n" + 
					"ISNULL(PRSSN,				'') 	AS PRSSN,\r\n" + 
					"ISNULL(PRDOB,				'') 	AS PRDOB,\r\n" + 
					"ISNULL(PRPhone,				'') 	AS PRPhone,\r\n" + 
					"ISNULL(PRPhoneExt,			'') 	AS PRPhoneExt		\r\n" + 
					"from  (SELECT DISTINCT \r\n" + 
					"FHD_ENPD_PERSON_D.ENPD_LNAME AS PRLastName,\r\n" + 
					"FHD_ENPD_PERSON_D.ENPD_FNAME AS PRFirstName,\r\n" + 
					"FHD_ENPD_PERSON_D.ENPD_MID_INIT AS PRMiddleInitial,\r\n" + 
					"FHP_PMPR_REP_D.PMPR_PZCD_TYPE AS PRDesignation,\r\n" + 
					"CONVERT(char(8),FHP_PMER_MEMBER_R.PMER_EFF_DT,112) AS PREffectiveDate,\r\n" + 
					"CONVERT(char(8),FHP_PMER_MEMBER_R.PMER_TERM_DTM,112) AS PRTerminationDate,\r\n" + 
					"FHD_ENPD_PERSON_D.ENPD_SSN AS PRSSN,\r\n" + 
					"CONVERT(char(8),FHD_ENPD_PERSON_D.ENPD_DOB_DT,112) AS PRDOB,\r\n" + 
					"FHD_ENPH_PHONE_D.ENPH_PHONE AS PRPhone,\r\n" + 
					"FHD_ENPH_PHONE_D.ENPH_PHONE_EXT AS PRPhoneExt\r\n" + 
					"FROM  dbo.CMC_MEME_MEMBER CMC_MEME_MEMBER\r\n" + 
					"LEFT OUTER JOIN	dbo.CMC_SBSB_SUBSC CMC_SBSB_SUBSC\r\n" + 
					"		ON (CMC_MEME_MEMBER.SBSB_CK = CMC_SBSB_SUBSC.SBSB_CK)\r\n" + 
					"LEFT OUTER JOIN	dbo.CMC_GRGR_GROUP CMC_GRGR_GROUP\r\n" + 
					"		ON (CMC_MEME_MEMBER.GRGR_CK = CMC_GRGR_GROUP.GRGR_CK)\r\n" + 
					"LEFT OUTER JOIN	dbo.FHP_PMED_MEMBER_D FHP_PMED_MEMBER_D\r\n" + 
					"	ON (CMC_GRGR_GROUP.GRGR_ID + CMC_SBSB_SUBSC.SBSB_ID + convert(varchar,CMC_MEME_MEMBER.MEME_SFX) + CMC_MEME_MEMBER.MEME_REL = FHP_PMED_MEMBER_D.PMED_ID)\r\n" + 
					"LEFT OUTER JOIN	dbo.FHP_PMER_MEMBER_R FHP_PMER_MEMBER_R\r\n" + 
					"	ON (FHP_PMED_MEMBER_D.PMED_CKE = FHP_PMER_MEMBER_R.PMED_CKE)\r\n" + 
					"LEFT OUTER JOIN	dbo.FHP_PMPR_REP_D FHP_PMPR_REP_D\r\n" + 
					"	ON (FHP_PMER_MEMBER_R.PMER_ENEN_CKE = FHP_PMPR_REP_D.PMPR_CKE)\r\n" + 
					"LEFT OUTER JOIN	dbo.FHD_ENPD_PERSON_D FHD_ENPD_PERSON_D\r\n" + 
					"	ON (FHP_PMPR_REP_D.PMPR_CKE = FHD_ENPD_PERSON_D.ENEN_CKE)\r\n" + 
					"LEFT OUTER JOIN	dbo.FHD_ENPH_PHONE_D FHD_ENPH_PHONE_D\r\n" + 
					"	ON (FHP_PMPR_REP_D.PMPR_CKE = FHD_ENPH_PHONE_D.ENEN_CKE)                   				\r\n" + 
					"WHERE   CMC_MEME_MEMBER.MEME_CK = "+memeCK+" AND FHD_ENPD_PERSON_D.ENPD_DOB_DT <>'' ) subq";
			ValidateMethods.validateJsonObject(subscriberDetails, prDetails, prQuery, UniqueColumn2, DBUniqueColumn2,"Sybase",
					ReportFilePath);
			}
			else {
				Assert.done("The Member does not have PCPInfo and PRInfo");
			}
		}
		}
		else {
			Assert.done("Test ID: " + inputtestID);
			Assert.done("Test Description: " + testDesc);
			UtilMethod.Log("Unexpected Error Code", "FAIL", true);
			Assert.fail(content);
		}
		
	}
	
	public static void validateViewMemberAccountJsonObject(String strQuery,  String DB, org.json.JSONObject jsonObjectList, String UniqueCol, String ReportFilePath) throws Exception {
		org.json.JSONArray dbMemberDetails = ViewClaimsDBS.getMemberInfofromDBS(strQuery, DB);
					Map<String, Object> strCLaimDetailsRes = null;
			Map<String, Object> db_data = null;
			org.json.JSONObject db_response = null;

			for (int j = 0; j < dbMemberDetails.length(); j++) {
				int k = j * 2 + 1; // 1,3,5
				int l = j * 2 + 2; // 2,4,6

				strCLaimDetailsRes = UtilMethod.readJsonData(jsonObjectList);
				Assert.done("Validating " + j + " row DB values with response");
				for (int i = 0; i < dbMemberDetails.length(); i++) {
					db_response = (org.json.JSONObject) dbMemberDetails.get(i);
					db_data = UtilMethod.readJsonData(db_response);
					if(DB.equalsIgnoreCase("Oracle")) {
					if (strCLaimDetailsRes.get(UniqueCol).toString().trim()
							.equalsIgnoreCase(db_data.get(UniqueCol.toUpperCase()).toString().trim()))
						 {
						break;
					}
					}
					else {
						if (strCLaimDetailsRes.get(UniqueCol).toString().trim()
								.equalsIgnoreCase(db_data.get(UniqueCol).toString().trim()))
							 {
							break;
						}
					}
				}

				Set<String> jsonKeys = strCLaimDetailsRes.keySet();
				for (String tagname : jsonKeys) {
					Object Value = strCLaimDetailsRes.get(tagname);
					if(DB.equalsIgnoreCase("Oracle")) {
						tagname = tagname.toUpperCase();
					}
					UtilMethod.setCellData(tagname, Value, k, ReportFilePath);
					
					UtilMethod.validateJSONObject(db_data, tagname, Value, l, ReportFilePath);
					

				}

		} 
	}
}
