package org.bcbsri.selfservice.dbutility;
//package org.bcbsri.grid.dbutility;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.dell.acoe.framework.selenium.testdata.DataTable;
import com.dell.acoe.framework.selenium.testdata.DataTable1;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.dell.acoe.framework.config.Environment;

import com.dell.acoe.framework.selenium.util.DBUtil;
import com.dell.acoe.framework.selenium.util.TextFileUtilities;
import com.dell.acoe.framework.selenium.verify.Assert;
import com.ntt.cryptic.aesTest;

public class DbutilityConfigg {
	/**
	 * Method to Fetch the data from the Sybase Database by establishing the connection
	 * @return-Returns the resultset rs
	 * @throws Exception 
	 */
	public static ResultSet DbExecute(String sqlQuery) throws Exception {
		ResultSet rs = null;
		try {
	   Assert.done("Start->Sybase Execution");
		String username = Environment.get("DB.Minor.pbm.Username");
		String password = Environment.get("DB.Minor.pbm.Password");
		String pass=aesTest.decrypt(password);
		
		String dbURL = Environment.get("DB.MinorURL");
		String jdbcDriver = Environment.get("DB.JdbcDriver");

		
		
		DBUtil.getConnection(jdbcDriver, dbURL, username, pass);
		System.out.println("Connection Established");
		
		rs = DBUtil.getResultSet(jdbcDriver, dbURL, username, pass, sqlQuery);
		
		 Assert.done("JDBC Driver:"+jdbcDriver);
		 Assert.done("DB URL:"+dbURL);
		 Assert.done("SQL Query:"+sqlQuery);
		
		
		
		Assert.pass( "Connected to the database Succesfully");
		Assert.done("End->Sybase Execution");
		}
		catch(Exception e)
		{
			System.out.println(e);
			Assert.fail( "Unable to Connect to the database");
			TextFileUtilities.Log("DbExecute", "Fail");
		}
		return rs;
	}
	/**
	 * Method to validate Excel to database for backend validation
	 * @param sqlQuery
	 * @param SubScriberID
	 * @return
	 * @throws Exception
	 */
	public static ResultSet Day2_DbExecute(String Query) throws Exception {
		ResultSet rs=null;
		try {
	    Assert.done("Start->Sybase Execution");
		String username = Environment.get("DB.Minor.pbm.Username");
		String password = Environment.get("DB.Minor.pbm.Password");
		//String pass=aesTest.decrypt(password);
		String dbURL = Environment.get("DB.MinorURL");
		String jdbcDriver = Environment.get("DB.JdbcDriver");
		 

		
      
		//Query = "SELECT SBSB_ID,SBSB_LAST_NAME,SBSB_FIRST_NAME , A.CLCL_ID,A.PRPR_ID ,RCRC_ID AS Revencode,SESE_ID AS TOS, IPCD_ID AS proc_code,CDML_FROM_DT,CDML_TO_DT,CDML_CHG_AMT,CLCL_TOT_CHG FROM CMC_CDML_CL_LINE A INNER JOIN CMC_CLCL_CLAIM B ON A.CLCL_ID =B.CLCL_ID INNER JOIN CMC_SBSB_SUBSC C ON B.SBSB_CK = C.SBSB_CK WHERE SBSB_ID = '"+SubScriberID+"'";
		Assert.done(Query);
		 
		DBUtil.getConnection(jdbcDriver, dbURL, username, password);
		System.out.println("Connection Established");
		//int i = 0;
		rs = DBUtil.getResultSet(jdbcDriver, dbURL, username, password, Query);
		//ResultSet rs=null;
		
        System.out.println(rs);
        boolean value=rs.next();
        System.out.println(value);

		Assert.pass( "Connected to the database Succesfully");
		Assert.done("End->Sybase Execution");
		}
		catch(Exception e)
		{
			Assert.fail("Unable to Connect to the database");
			Assert.error(e, "Unable to Connect to the database");
			TextFileUtilities.Log("DbExecute", "Fail");
		}
		return rs;
	}

	
public static DataTable1 ResultSetWriteIntoExcelSheet(ResultSet rs,DataTable1 dt) throws Exception {

		

		try {
			Assert.done("Start->Write values Into ExcelSheet from database");
do
			 {

				int rowNo =dt.rowCount;
				System.out.println("Result Set from db table:" + rs.toString());
				String Charges = rs.getString(7);
				//String CHG_AMT = Charges.replaceAll(" ", "");
				System.out.println("Charges:" + Charges);
				String Copay = rs.getString(10);
				String COP_AMT = Copay.replaceAll(" ", "");
				System.out.println("CoPay:" + COP_AMT);
				String CoIns = rs.getString(11);
				String COINS = CoIns.replaceAll(" ", "");
				System.out.println("CoInsurance :" + COINS);
				String Deductible = rs.getString(12);
				String TOT_CHG = Deductible.replaceAll(" ", "");
				System.out.println("Expected Deductibles :" + TOT_CHG);
				
				/*Assert.done("Values from database:" + "Charges:" + CHG_AMT + " " + "Copay:" + COP_AMT + " "
						+ "CoInsurance:" + COINS + "Expected Deductibles :" + TOT_CHG+"");*/

				dt.setValue("CopayAfterDeductibles", rowNo, COP_AMT);
				dt.setValue("CoInsuranceAfterDeductibles", rowNo, COINS);
				dt.setValue("ExpectedDeductibles", rowNo, TOT_CHG);

			}
while (rs.next());
			Assert.done("End->Write values Into ExcelSheet from database");
			Assert.pass("Values written into excel sheet from database successfully");

		} catch (Exception e) {
			Assert.fail("Values written into excel sheet from database fail");
			 Assert.error(e, "Unable to Write in excel Sheet");
			TextFileUtilities.Log("TextFile", "Fail");
		}
		return dt;
	}

public static String fetch_Query(String claimid, String SubID) {
	String Query = null;
	
	String QueryforlineItem = "SELECT SESE_ID,PSCD_ID,IPCD_ID,IDCD_ID,CDML_FROM_DT,CDML_TO_DT,CDML_CHG_AMT,CDML_UNITS FROM  CMC_CDML_CL_LINE WHERE CLCL_ID='"+ claimid + "' ";
	Query = QueryforlineItem;
	return Query;
}
	public static void Copay_Coinsurance_Details(String claimid,String copay) throws Exception {

	String QueryforCopaycoinsurance = "SELECT A.SESE_ID,A.PSCD_ID,A.IPCD_ID,A.IDCD_ID,A.CDML_FROM_DT,A.CDML_TO_DT,A.CDML_CHG_AMT,A.CDML_UNITS,A.CDML_DISALL_EXCD CDML_DED_AMT,CDML_COPAY_AMT,CDML_PAID_AMT,CDML_DISALL_AMT,CDML_COINS_AMT,B.CLCL_TOT_CHG FROM CMC_CDML_CL_LINE A INNER JOIN CMC_CLCL_CLAIM B ON B.CLCL_ID=A.CLCL_ID WHERE A.CLCL_ID='"+ claimid + "'";
	ResultSet rsetforcopayandcoinsurance = DbutilityConfigg.Day2_DbExecute(QueryforCopaycoinsurance);
	do {
	String TypeOfService = rsetforcopayandcoinsurance.getString("SESE_ID");

	String ClaimAmount = rsetforcopayandcoinsurance.getString("CDML_CHG_AMT");
	Assert.done(" Total charge amount -> " + ClaimAmount);

	String CopayoflineItem = rsetforcopayandcoinsurance.getString("CDML_COPAY_AMT");
	Assert.done(" Deducted copay for the" + TypeOfService + " service is -> " + CopayoflineItem);

	String DisallowAmount = rsetforcopayandcoinsurance.getString("CDML_DISALL_AMT");
	Assert.done("Disallow amount is-> " + DisallowAmount);

	String BenefitAmount = rsetforcopayandcoinsurance.getString("CDML_PAID_AMT");
	Assert.done("Benefit amount is-> " + BenefitAmount);

	String Coinsuranceforlineitem = rsetforcopayandcoinsurance.getString("CDML_COINS_AMT");
	Assert.done(" Deducted coinsurance for the" + TypeOfService + " service is -> " + Coinsuranceforlineitem);
	
	if(copay.equals(null)) {
		Assert.fail("Copay is not available in mapping sheet");
		
	}
	else
	{
		if(copay.contains("$")) {
			String[] Copayment=copay.split("$");
			String copayvalue=Copayment[1];
			String trimcopayvalue=copayvalue.substring(0,2);
			System.out.println("trimcopayvalue"+trimcopayvalue);
			if(copay.equals(CopayoflineItem))
			{
				Assert.pass("Copay validations have complete");
			}
			else
			{
				Assert.fail("The copay from Query is not matching with the mapping sheet service");
			}
		}
		else {
			Assert.fail("The service is not applicable to copay");
			System.out.println("The service is not applicable to copay");
		}
	}
	} while (rsetforcopayandcoinsurance.next());

}

	public static String[] ReadExcel(String Sheetname)  {
		String[] rowvalues = null;
		try {
			String env ="testMajor";
			String testfilename ="PCP";
		//String ExcelFilePath = Grid_Config.Grid_Mappingdata;
			//String ExcelFilePath = Environment.get("test_data_path")+"\\"+env+"\\"+testfilename+".xls";
			String ExcelFilePath ="C:\\Users\\A152TSO\\SOA_ESB\\resources\\testdata"+"\\"+env+"\\"+testfilename+".xls";
		FileInputStream inputStream = new FileInputStream(ExcelFilePath);
		HSSFWorkbook wb = new HSSFWorkbook(inputStream);
		 //XSSFWorkbook wb = new XSSFWorkbook(inputStream);
		HSSFSheet sheet = wb.getSheet(Sheetname);
		int rowcount = sheet.getLastRowNum();
		String arr = null;
		for (int i = 1; i <= rowcount; i++) {
			String array;
			array = sheet.getRow(i).getCell(0).getStringCellValue();
			arr = arr + "," + array;
		}
		System.out.println("arr" + arr);
		rowvalues= arr.split(",");
		System.out.println("rowvalues" + rowvalues);
		return rowvalues;
		}catch(Exception e) {
			return rowvalues;
		}
	}
	public static String[] ReadExcelfromReciever(String Sheetname)  {
		String[] rowvalues = null;
		try {
			String mappingdatapath = Grid_Config.Grid_ReceiverPath;
			
			FileInputStream inputStream = new FileInputStream(mappingdatapath);
			HSSFWorkbook wb = new HSSFWorkbook(inputStream);
			HSSFSheet sheet = wb.getSheetAt(0);

			int rowcount = sheet.getLastRowNum();
			String arr = null;
			for (int i = 1; i <= rowcount; i++) {
				String array;
				array = sheet.getRow(i).getCell(0).getStringCellValue();
				arr = arr + "," + array;
			}
			System.out.println("arr" + arr);
			rowvalues= arr.split(",");
			System.out.println("rowvalues" + rowvalues);
			return rowvalues;
		}catch(Exception e) {
			System.out.println("rowvalues"+e.getMessage());
			return rowvalues;
		}
	}
	public static String[] Accumsvalidation_Query(String subscriberType,
			String AccumsTypeValue,String AccumsAmount,
			String claimid, String SubID,String BeginDate,String PDPDSFX, String DependantID) 
	{
		//String AccumsAmount=null;
		String AccumsTable=null;
		String AccumsTypeColumn=null;
		//String AccumsTypeValue=null;
		String AccumsOrder=null;
		String Dependant_ID=DependantID;

		
		if(subscriberType.equalsIgnoreCase("Individual")) 
		{
			//AccumsAmount="MATX_AMT1";
		    AccumsTable="CMC_MATX_ACCUM_TXN";
		    AccumsTypeColumn="MATX_ACC_TYPE";
		    //AccumsTypeValue="D";
			AccumsOrder="MATX_SEQ_NO";
		}	
		else if(subscriberType.equalsIgnoreCase("Family"))
		{
			//AccumsAmount="FATX_AMT1";
		    AccumsTable="CMC_FATX_ACCUM_TXN";
		    AccumsTypeColumn="FATX_ACC_TYPE";
		    //AccumsTypeValue="L";
			AccumsOrder="FATX_SEQ_NO";
		}
		else
		{
			Assert.fail("Subscriber Type is in correct please check");
		}
			 String Queryfor=Environment.get("QueryForIndividualBeforeProcess");
			// String Queryforpreprocess=Queryfor.replace("ClaimID", claimid);
			 String QueryForIndividualSuffixPreprocess=Queryfor.replace("PDPDSFX", PDPDSFX);
			 String QueryForIndividualDedAmount=QueryForIndividualSuffixPreprocess.replace("Begin_Date",BeginDate);
			 String QueryForIndividualPreprocessAccumsAmount=QueryForIndividualDedAmount.replace("AccumsAmount",AccumsAmount);
			 String QueryForIndividualPreprocessAccumsTable=QueryForIndividualPreprocessAccumsAmount.replace("AccumsTable", AccumsTable);
			 String QueryForIndividualPreprocessAccumsTypeColumn=QueryForIndividualPreprocessAccumsTable.replace("AccumsTypeColumn", AccumsTypeColumn);
			 String QueryForIndividualPreprocessAccumsTypeValue=QueryForIndividualPreprocessAccumsTypeColumn.replace("AccumsTypeValue", AccumsTypeValue);
			 String QueryForIndividualPreprocessAccumsOrder=QueryForIndividualPreprocessAccumsTypeValue.replace("AccumsOrder", AccumsOrder);
			 String QueryForIndividualPreprocessDependantID=QueryForIndividualPreprocessAccumsOrder.replace("Dep_ID", Dependant_ID);
			 String QueryForIndividualBeforeProcess=QueryForIndividualPreprocessDependantID.replace("SubscriberID", SubID);
			 
			 String QueryFor=Environment.get("QueryForFamilyBeforeProcess");
			// String QueryforFamilypreprocess=QueryFor.replace("ClaimID", claimid);
			 String QueryForFamilySuffixPreprocess=QueryFor.replace("PDPDSFX", PDPDSFX);
			 String QueryForFamilyDedAmount=QueryForFamilySuffixPreprocess.replace("Begin_Date",BeginDate);
			 String QueryForFamilyPreprocessAccumsAmount=QueryForFamilyDedAmount.replace("AccumsAmount",AccumsAmount);
			 String QueryForFamilyPreprocessAccumsTable=QueryForFamilyPreprocessAccumsAmount.replace("AccumsTable", AccumsTable);
			 String QueryForFamilyPreprocessAccumsTypeColumn=QueryForFamilyPreprocessAccumsTable.replace("AccumsTypeColumn", AccumsTypeColumn);
			 String QueryForFamilyPreprocessAccumsTypeValue=QueryForFamilyPreprocessAccumsTypeColumn.replace("AccumsTypeValue", AccumsTypeValue);
			 String QueryForFamilyPreprocessAccumsOrder=QueryForFamilyPreprocessAccumsTypeValue.replace("AccumsOrder", AccumsOrder);
			// String QueryForFamilyPreprocessDependantID=QueryForFamilyPreprocessAccumsOrder.replace("Dep_ID", Dependant_ID);
			 String QueryForFamilyBeforeProcess=QueryForFamilyPreprocessAccumsOrder.replace("SubscriberID", SubID);
			 
			 String QueryForPostInd=Environment.get("QueryForIndividualPostProcess");
			 String QueryforpostprocessInd=QueryForPostInd.replace("ClaimID", claimid);
			 String QueryForIndividualSuffixPostprocess=QueryforpostprocessInd.replace("PDPDSFX", PDPDSFX);
			 String QueryForIndividualDedAmountPostProcess=QueryForIndividualSuffixPostprocess.replace("Begin_Date",BeginDate);
			 String QueryForIndividualPostprocessAccumsAmount=QueryForIndividualDedAmountPostProcess.replace("AccumsAmount",AccumsAmount);
			 String QueryForIndividualPostprocessAccumsTable=QueryForIndividualPostprocessAccumsAmount.replace("AccumsTable", AccumsTable);
			 String QueryForIndividualPostprocessAccumsTypeColumn=QueryForIndividualPostprocessAccumsTable.replace("AccumsTypeColumn", AccumsTypeColumn);
			 String QueryForIndividualPostprocessAccumsTypeValue=QueryForIndividualPostprocessAccumsTypeColumn.replace("AccumsTypeValue", AccumsTypeValue);
			 //String QueryForIndividualPostprocessAccumsOrder=QueryForIndividualPostprocessAccumsTypeValue.replace("AccumsOrder", AccumsOrder);
			 String QueryForIndividualPostprocessDependantID=QueryForIndividualPostprocessAccumsTypeValue.replace("Dep_ID", Dependant_ID);
			 String QueryForIndividualPostProcess=QueryForIndividualPostprocessDependantID.replace("SubscriberID", SubID);
			 
			 String QueryForPostFam=Environment.get("QueryForFamilyPostProcess");
			 String QueryforpostprocessFam=QueryForPostFam.replace("ClaimID", claimid);
			 String QueryForFamilySuffixPostprocess=QueryforpostprocessFam.replace("PDPDSFX", PDPDSFX);
			 String QueryForFamilyDedAmountPostProcess=QueryForFamilySuffixPostprocess.replace("Begin_Date",BeginDate);
			 String QueryForFamilyPostprocessAccumsAmount=QueryForFamilyDedAmountPostProcess.replace("AccumsAmount",AccumsAmount);
			 String QueryForFamilyPostprocessAccumsTable=QueryForFamilyPostprocessAccumsAmount.replace("AccumsTable", AccumsTable);
			 String QueryForFamilyPostprocessAccumsTypeColumn=QueryForFamilyPostprocessAccumsTable.replace("AccumsTypeColumn", AccumsTypeColumn);
			 String QueryForFamilyPostprocessAccumsTypeValue=QueryForFamilyPostprocessAccumsTypeColumn.replace("AccumsTypeValue", AccumsTypeValue);
			 //String QueryForIndividualPostprocessAccumsOrder=QueryForIndividualPostprocessAccumsTypeValue.replace("AccumsOrder", AccumsOrder);
			 String QueryForFamilyPostProcess=QueryForFamilyPostprocessAccumsTypeValue.replace("SubscriberID", SubID);
			 
			 String QueryforDEDLineItems=Environment.get("QueryForDEDLineItemsPostProcess");
			 String QueryforDEDLineItemspostprocess=QueryforDEDLineItems.replace("ClaimID", claimid);
			 
			 String QueryForCopay=Environment.get("QueryForCopayCoinsurance");
			 String QUeryForCopayCoinsurance=QueryForCopay.replace("ClaimID", claimid);
			 
		String Queries[]= {QueryForIndividualBeforeProcess,QueryForFamilyBeforeProcess,
				QueryForIndividualPostProcess,QueryForFamilyPostProcess,
				QueryforDEDLineItemspostprocess,QUeryForCopayCoinsurance};
		return Queries;
		
		
	}
		
	public static String[] get_Query(String claimid, String SubID,String BeginDate,String PDPD_SFX_NUM) {
		//String BeginingDate=get_Begin_Date();
	
		
		String Queryfor=Environment.get("QueryForIndividualDEDPostProcess");
		String Queryforpostprocess=Queryfor.replace("ClaimID", claimid);
		String QueryForIndividualDEDPostprocess=Queryforpostprocess.replace("PDPDSFX", PDPD_SFX_NUM);
		String QueryForIndividualDedAmount=QueryForIndividualDEDPostprocess.replace("Begin_Date",BeginDate);
		String QueryForPostProcessDED=QueryForIndividualDedAmount.replace("SubscriberID", SubID);
		
		String QueryforDEDLineItems=Environment.get("QueryForDEDLineItemsPostProcess");
		String QueryforDEDLineItemspostprocess=QueryforDEDLineItems.replace("ClaimID", claimid);
		
		
		String Queryforoop=Environment.get("QueryForIndividualOOPPostProcess");
		String Queryforpostprocessoop=Queryforoop.replace("ClaimID", claimid);
		String QueryForIndividualOOPPostprocess=Queryforpostprocessoop.replace("PDPDSFX", PDPD_SFX_NUM);
		String QueryForIndividualOopAmount=QueryForIndividualOOPPostprocess.replace("Begin_Date",BeginDate);
		String QueryForPostProcessOOP=QueryForIndividualOopAmount.replace("SubscriberID", SubID);
		
		
		String QueryForCopay=Environment.get("QueryForCopayCoinsurance");
		String QUeryForCopayCoinsurance=QueryForCopay.replace("ClaimID", claimid);
		
		
		String QueryforDEDbefore=Environment.get("QueryForDEDBeforeProcess");
		String QueryforbeforeprocessSDED=QueryforDEDbefore.replace("Begin_Date",BeginDate);
		String QueryForBeforeProcesDED=QueryforbeforeprocessSDED.replace("SubscriberID", SubID);
		String QueryIndividualDEDBeforeProcess=QueryForBeforeProcesDED.replace("PDPDSFX", PDPD_SFX_NUM);
		
		String QueryforOOPbefore=Environment.get("QueryForOOPBeforeProcess");
		String QueryforbeforeprocessSOOP=QueryforOOPbefore.replace("Begin_Date",BeginDate);
		String QueryForBeforeProcessOOP=QueryforbeforeprocessSOOP.replace("SubscriberID", SubID);
		String QueryIndividualOOPBeforeProcess=QueryForBeforeProcessOOP.replace("PDPDSFX", PDPD_SFX_NUM);
		
		String QueryforFamilyDEDbefore=Environment.get("QueryForFamilyDEDBeforeProcess");
		String QueryforFamilyDEDbeforeProcess=QueryforFamilyDEDbefore.replace("Begin_Date",BeginDate);
		String QueryForBeforeProcesDEDFamily=QueryforFamilyDEDbeforeProcess.replace("SubscriberID", SubID);
		String QueryFamilyDEDBeforeProcess=QueryForBeforeProcesDEDFamily.replace("PDPDSFX", PDPD_SFX_NUM);
		
		String QueryforFamilyOOPbefore=Environment.get("QueryForFamilyOOPBeforeProcess");
		String QueryforFamilybeforeprocessOOP=QueryforFamilyOOPbefore.replace("Begin_Date",BeginDate);
		String QueryForFamilyBeforeProcessOOP=QueryforFamilybeforeprocessOOP.replace("SubscriberID", SubID);
		String QueryFamilyOOPBeforeProcess=QueryForFamilyBeforeProcessOOP.replace("PDPDSFX", PDPD_SFX_NUM);
		
		String QueryforFamilyDEDPost=Environment.get("QueryForFamilyDEDPostProcess");
		String QueryforFamilyDedPost=QueryforFamilyDEDPost.replace("Begin_Date",BeginDate);
		String QueryForFamilyDEDPostProcess=QueryforFamilyDedPost.replace("SubscriberID", SubID);
		String QueryFamilyDEDPOstProcess=QueryForFamilyDEDPostProcess.replace("PDPDSFX", PDPD_SFX_NUM);
		String QueryForFamilyDEDPOSTProcess=QueryFamilyDEDPOstProcess.replace("ClaimID", claimid);
		
		String QueryforFamilyOOPPost=Environment.get("QueryForFamilyOOPPostProcess");
		String QueryforFamilyOopPost=QueryforFamilyOOPPost.replace("Begin_Date",BeginDate);
		String QueryForFamilyOOPPostProcess=QueryforFamilyOopPost.replace("SubscriberID", SubID);
		String QueryFamilyOOPPOstProcess=QueryForFamilyOOPPostProcess.replace("PDPDSFX", PDPD_SFX_NUM);
		String QueryForFamilyOOPPOSTProcess=QueryFamilyOOPPOstProcess.replace("ClaimID", claimid);
		
		String Quiries[]= {QueryForPostProcessDED,QueryforDEDLineItemspostprocess,QueryForPostProcessOOP,QUeryForCopayCoinsurance,QueryIndividualDEDBeforeProcess,QueryIndividualOOPBeforeProcess,QueryFamilyDEDBeforeProcess,QueryFamilyOOPBeforeProcess,QueryForFamilyDEDPOSTProcess,QueryForFamilyOOPPOSTProcess};
		return Quiries;

	}

	
public static String get_Begin_Date() 
  {
	String BeginDate="07/01/";
    String timeStamp = new SimpleDateFormat("yyyy").format(new Date());
    BeginDate=BeginDate+timeStamp;
    return BeginDate;
  }

	/*public static String[] get_Summary_Details(DataTable1 dt1) {

		String TestCaseNo = dt1.getValue("TestCaseNo");
		System.out.println("TestCaseNo-> " + TestCaseNo);
		Assert.done("Current TestCaseNo-> " + TestCaseNo);
		String SubID = dt1.getValue("SubcriberID");
		System.out.println("Subcriber ID-> " + SubID);
		Assert.done("Subcriber ID-> " + SubID);
		String Deductibles = dt1.getValue("Deductibles");
		System.out.println("Deductibles-> " + Deductibles);
		Assert.done("Deductibles-> " + Deductibles);
		String OutOfPocket = dt1.getValue("OutofPocket");
		System.out.println("OutOfPocket-> " + OutOfPocket);
		Assert.done("OutOfPocket-> " + OutOfPocket);
		String claimid = dt1.getValue("NewClaimID");
		System.out.println("NewClaimID-> " + claimid);
		Assert.done("NewClaimID-> " + claimid);
		String ClaimType = dt1.getValue("ClaimType");
		String[] summarydetails= {TestCaseNo,SubID,Deductibles,OutOfPocket,claimid,ClaimType};
		return summarydetails;

	}

*/}