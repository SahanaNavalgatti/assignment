package org.bcbsri.selfservice.dbutility;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dell.acoe.framework.selenium.util.DBUtil;
import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.selenium.testdata.DataTable1;
import com.ntt.cryptic.aesTest;
public class testauto {
	public static void main(String[] args) throws Exception  {

	
		// TODO Auto-generated method stub
		String env="testMajor";
		String testfilename="PCP";
		String testdatapath ="C:\\Users\\A152TSO\\SOA_ESB\\resources\\testdata"+"\\"+env+"\\"+testfilename+".xls";
		String[] testcasevalues = DbutilityConfigg.ReadExcel("UpdatePCP_Input");
		
		//System.out.println("testcasevalues : " + testcasevalues);
        int TCcount = testcasevalues.length;
        //int TCcount=30;
            String username = "sySVCUAUTO";
            String password = "QSCG2qscg2";
           
            String jdbcDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
            String dbURL = "jdbc:sqlserver://n10ppmoFADB0001.cishoc.com:11000;databaseName=fabripr0";
            ResultSet rset = null;
            String pass="";
            //Dbvalidation.Sybase_Connection();
               for (int j = 1; j < TCcount; j++) {
                     String TCIDS = testcasevalues[j];
                     int rownum = 1;
                     
                     DataTable1 dt1 = new DataTable1(testdatapath, "UpdatePCP_Input", TCIDS);
                     
                     //String SubID = dt1.getValue("MemeCk");
                     //Assert.done("Subcriber ID-> " + SubID);
                     //String EffectiveDate = dt1.getValue("EffectiveDate");
                     //String TestCaseValue=dt1.getValue("TestCaseNo");
                     String claimid = "null";
                     //String OriginalClaimID = dt1.getValue("OriginalClaim_ID");
                     String DBQueryForSummary="select TOP 11 MEME_CK as MemeCk,PRPR_ID as PRPRid,MEPR_PCP_TYPE as PCPType,MEPR_CR_EFF_DT FROM CMC_MEPR_PRIM_PROV�where PRPR_ID <> '' and MEPR_CR_EFF_DT<dateadd(day,-7,getdate()) order by MEPR_CR_EFF_DT desc";
                     //pass = aesTest.decrypt(password);
                     Connection con = DBUtil.getConnection(jdbcDriver, dbURL, username, password);
                     
                     /* Assert.done("NewClaimID-> " + claimid); */
                     String MemeCk=null;
                     String PRPRid=null;
                     String PCPType=null;
                     //String PDPDSFX = dt1.getValue("PDPD_ACC_SFX");
                     //String SubscriberType = dt1.getValue("SubscriberType").trim();
                     //String DependentID = dt1.getValue("DependentID");
                     if (con != null) {
                     System.out.println("Connection established to FDATST6");
                  	   rset=DBUtil.getResultSet(jdbcDriver, dbURL, username, password, DBQueryForSummary);
                  	   //System.out.println(DBQueryForSummary);
                  	   while(rset.next()) {
                  		 MemeCk=rset.getString("MemeCk");
                  		PRPRid=rset.getString("PRPRid");
                  		PCPType=rset.getString("PCPType");
                  	   }rset.close();
                  	  // dt1.setValue("LineItems", rownum, ClaimLInItemCount.toString());
                         dt1.setValue("MemeCk", rownum, MemeCk);
                         dt1.setValue("PRPRid", rownum, PRPRid);
                         dt1.setValue("PCPType", rownum, PCPType);
                         
                       
    
                     }else {
                  	   System.out.println("Connection Failed");
                     }
                  	
	}
}   
}
