package org.bcbsri.selfservice.dbutility;

public class DbUtilityConfig {

}
