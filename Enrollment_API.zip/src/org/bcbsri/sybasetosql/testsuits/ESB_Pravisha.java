package org.bcbsri.sybasetosql.testsuits;

import com.dell.acoe.framework.run.TestRunner;

public class ESB_Pravisha {

	public static void main(String[] args) 
	{
		TestRunner.runTests("C:\\Users\\A152TSO\\SOA_ESB\\resources\\config\\SybaseToSQL_Environment_Sheet_Jenkins_Minor_Local.xls");
		
	
	}
}
