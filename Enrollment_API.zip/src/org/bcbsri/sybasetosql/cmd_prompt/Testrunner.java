package org.bcbsri.sybasetosql.cmd_prompt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

<<<<<<< HEAD
=======
//import org.bcbsri.selfservice.commonMethods.UtilMethod;
>>>>>>> 9c58488f59f36dbb9d2367371582f6c2ec72ebbe

import com.dell.acoe.framework.config.Environment;

public class Testrunner {

	public static void launchRunner(String files_path,String endpoint,String xmlFile,String testSuite, String testCase) {
		String folderPath = Environment.get("Output_FilesPath");
		String xmlFilesPath = Environment.get("XML_FilePath");
		xmlFile = xmlFilesPath+xmlFile+".xml";
		files_path = folderPath+files_path+"";
		
		String[] command =
	    {
	        "cmd",
	    };
	    Process p;{
		try {
			p = Runtime.getRuntime().exec(command);
		        new Thread(new SyncPipe(p.getErrorStream(), System.err)).start();
	                new Thread(new SyncPipe(p.getInputStream(), System.out)).start();
	                PrintWriter stdin = new PrintWriter(p.getOutputStream());
	                stdin.println("cd /d C:\\Windows");
	                stdin.println("cd C:\\Program Files (x86)\\SmartBear\\SoapUI-5.5.0\\bin");	
	                //stdin.println("cd C:\\Users\\A152TSO\\OneDrive - Blue Cross and Blue Shield of Rhode Island\\Jars\\Documents\\SoapUI-5.5.0\\bin");
	              
	                //stdin.println("testrunner.bat -e"+endpoint+" -s"+testSuite+" -c"+testCase+" -r -a -I -f"+files_path+" "+"-Ptestdatapath="+testdatapath+" "+xmlFile+"");
	                stdin.println("testrunner.bat -e"+endpoint+" -s"+testSuite+" -c"+testCase+" -r -a -I -f"+files_path+" "+xmlFile+"");
	                stdin.close();
	                p.waitFor();
	               
	              
	    	} catch (Exception e) {
	 		
		}
}
}
}

