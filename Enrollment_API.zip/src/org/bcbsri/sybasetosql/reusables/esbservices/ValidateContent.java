package org.bcbsri.sybasetosql.reusables.esbservices;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import com.dell.acoe.framework.selenium.verify.Assert;

public class ValidateContent {

	public static void readContent(File folder) throws IOException {
		File[] fileNames = folder.listFiles();
		String filename = "";
		for (File file : fileNames) {
			// if directory call the same method again
			if (file.isDirectory()) {
				readContent(file);
			} else {
				try {
					filename = file.getName();
					readFileContent(file,filename);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
	}
	}
	
	public static void readFileContent(File file, String Filename) throws Exception{
			String line = null;
			String str = null;
			String json1 = null;
			int lineNumber = 0;
			String word = "---------------- Response --------------------------";
			int num = 0;
			int lineNo = 0;
			ArrayList<String> fileContent = new ArrayList<>();
			try (BufferedReader br = new BufferedReader(new FileReader(file))) {
				// Read lines from the file, returns null when end of stream
				// is reached
				while ((line = br.readLine()) != null) {
					lineNumber++;
					if (word.equals(line)) {
						num = lineNumber;

					}
				}
				br.close();
			}
			try (BufferedReader br = new BufferedReader(new FileReader(file))) {
				// Read lines from the file, returns null when end of stream
				// is reached
				while ((str = br.readLine()) != null) {
					lineNo++;
					if (lineNo >= num) {
						fileContent.add(str);

					}
				}
				String sub = fileContent.toString();
				if(sub.contains("#status# : HTTP/1.1 200 OK")) {
					Assert.pass("TestCase: Pass");
					Assert.done("Data is generated in the file : "+Filename+"");
				}
				else {
					Assert.fail("TestCase Failed");
				}
			}
	}
	
}
