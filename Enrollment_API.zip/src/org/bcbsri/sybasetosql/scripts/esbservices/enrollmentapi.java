<<<<<<< HEAD
package org.bcbsri.sybasetosql.scripts.esbservices;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.bcbsri.selfservice.cmd_prompt.Testrunner;
import org.bcbsri.selfservice.commonMethods.Config;
import org.bcbsri.selfservice.commonMethods.UtilMethod;

import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.run.TestRunner;
import com.dell.acoe.framework.selenium.report.Soap;

public class enrollmentapi {
	
	public static void runTest() throws Exception {
		Config.init_updateRegistrationFlag();
		String files_path =UtilMethod.createNewReportPath();
		String endpointMinor = Config.endpointMinor;
		String endpointMajor = Config.endpointMajor;
		String Env=Environment.get("TestMajorRun");
		String testMinorExecute = Environment.get("Test_Minor_Execution");
		String testMajorExecute = Environment.get("Test_Major_Execution");
		String xmlFile = "Enrollmentpipeline.xml";
		String testSuite = Config.testSuite;
		String testCase = Config.testCase;
		String testdatapath =Environment.get("Testdatasoap_dependent_test");
		
		String env = "";
		
		
		String fileDelete = "";
		String testfilename = "RegistrationFlag";
		
	
		
			//String testCase = "Minor";
			xmlFile = Environment.get("test_data_path")+xmlFile;	
			Testrunner.launchRunner(files_path,testdatapath,xmlFile,testSuite,testCase);
		
		
	
		
		
			
	}
}
=======
package org.bcbsri.sybasetosql.scripts.esbservices;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.bcbsri.selfservice.cmd_prompt.Testrunner;
//import org.bcbsri.selfservice.commonMethods.Config;
//import org.bcbsri.selfservice.commonMethods.UtilMethod;

import com.dell.acoe.framework.config.Environment;
import com.dell.acoe.framework.run.TestRunner;
import com.dell.acoe.framework.selenium.report.Soap;

public class enrollmentapi {
	
	public static void runTest() throws Exception {
		
		String xmlFile = "Enrollmentpipeline.xml";
	
		//String testdatapath =Environment.get("Testdatasoap_dependent_test");
		
		String env = "";
		
		
		String fileDelete = "";
		String testfilename = "RegistrationFlag";
		
	
		
			//String testCase = "Minor";
			xmlFile = Environment.get("test_data_path")+xmlFile;	
			Testrunner.launchRunner("","",xmlFile,"","");
		
		
	
		
		
			
	}
}
>>>>>>> 9c58488f59f36dbb9d2367371582f6c2ec72ebbe
